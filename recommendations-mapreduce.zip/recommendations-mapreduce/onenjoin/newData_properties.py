################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

# hbase config
hbase_zookeeper_quorum='hdpnn-dv-msdc02.ds.dtveng.net,hdpnn-dv-msdc01.ds.dtveng.net,hdpdn-dv-msdc03.ds.dtveng.net'
hbase_zookeeper_clientPort='2181'


# path of output ams, ppv, social, stream
programPath="/data/dv/recommendation/processed/guidedata/programs/"
channelPath="/data/dv/recommendation/processed/guidedata/channels/"
flixterPath="/data/dv/recommendation/landingzone/onproduct/flixters"
betterPath="/data/dv/recommendation/landingzone/onproduct/bettercategories"
eventMappingPath="/data/dv/ref/eventmappingweighted"

stagingPath="huyba/data/dv/recommendation/staging"
outputDataPath="huyba/data/dv/recommendation/processed/newuvh"

amsPath="/data/dv/recommendation/processed/ams/"
ppvPath="/data/dv/recommendation/processed/ppv/"
socialPath="/data/dv/recommendation/processed/social/"
streamingPath="/data/dv/recommendation/processed/streaming/"
cdnPath="/data/dv/recommendation/processed/cdn/"
remotePath="/data/dv/recommendation/processed/remote/"

# Jars
onenJoinJar="recommendations-onenjoin-0.0.1-SNAPSHOT.jar"
ppvFilterJar="recommendations-ppvfilter-0.0.1-SNAPSHOT.jar"
subtractionJar="recommendations-subtraction-0.0.1-SNAPSHOT.jar"

# get last batch
lookupTable='demo_5_2014_lookupTable'
batchColumn='content:batch'
insertedTimeCol='insertedTime'

lookupFamilyName='content'
lookupColumnQualifier='batch'

# Hbase table is used to store information such as: jobId, start time, end time ..
recommendationJobHistory='demo_5_2014_recommendationsjobhistory'
columnFamilyOfRJH='h'


# data type of guide data
dataTypeProgram='program'
dataTypeChannel='channel'

# data type of new data
dataType='newData'

timeFormat='HHmmss'
dateTimeFormat='yyyyMMddHHmmss'
timeOfDay='[{"key":"Daytime","fromHour":"090000","toHour":"175959"},{"key":"Early Fringe","fromHour":"180000","toHour":"195959"},{"key":"Prime Fringe","fromHour":"200000","toHour":"215959"},{"key":"Late Evening","fromHour":"220000","toHour":"005959"},{"key":"Late Night","fromHour":"010000","toHour":"045959"},{"key":"Early Morning","fromHour":"050000","toHour":"085959"}]'
