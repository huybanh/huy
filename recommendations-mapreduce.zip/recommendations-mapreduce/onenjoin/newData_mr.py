#!/usr/bin/python


################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################


import sys
import os
import time
import subprocess
import imp
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from newData_properties import *
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
rjhTable = HTable(config, recommendationJobHistory)

lookupTableInstance = HTable(config, lookupTable)

fileSystem = FileSystem.get(config)
location = os.getcwd()
utils = imp.load_source('newData', location + '/ingestionUtils/ingestionUtils.py')

# Get current date for add filter
insertedTime=time.strftime("%Y%m%d")

# Get last batch of program, channel
def newDataLastBatch(batchNumber):
    print '===========================START GET LAST BATCH FOR NEW DATA============================='
    try:
	programLastBatch = utils.lookupString(dataTypeProgram, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
	channelLastBatch = utils.lookupString(dataTypeChannel, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
	print programLastBatch 
	print channelLastBatch
        return programLastBatch, channelLastBatch
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "newDataLastBatch", str(sys.exc_info()[1]))
    print '===========================END GET LAST BATCH FOR NEW DATA============================='

def runNewData(batchNumber):
    print '===========================START ALL NEW DATA============================='
    try:
        amsLocation = Path(amsPath + str(batchNumber))
        ppvLocation = Path(ppvPath + str(batchNumber))
        socialLocation = Path(socialPath + str(batchNumber))
        streamingLocation = Path(streamingPath + str(batchNumber))
        cdnLocation = Path(cdnPath + str(batchNumber))
        remoteLocation = Path(remotePath + str(batchNumber))
        /*if not fileSystem.exists(amsLocation) or not fileSystem.isDirectory(amsLocation):
            subprocess.call('hadoop fs -mkdir ' + amsPath + batchNumber, shell=True)
        if not fileSystem.exists(ppvLocation) or not fileSystem.isDirectory(ppvLocation):
            subprocess.call('hadoop fs -mkdir ' + ppvPath + batchNumber, shell=True)
        if not fileSystem.exists(socialLocation) or not fileSystem.isDirectory(socialLocation):
            subprocess.call('hadoop fs -mkdir ' + socialPath + batchNumber, shell=True)
        if not fileSystem.exists(streamingLocation) or not fileSystem.isDirectory(streamingLocation):
            subprocess.call('hadoop fs -mkdir ' + streamingPath + batchNumber, shell=True)
        if not fileSystem.exists(cdnLocation) or not fileSystem.isDirectory(cdnLocation):
            subprocess.call('hadoop fs -mkdir ' + cdnPath + batchNumber, shell=True)
        if not fileSystem.exists(remoteLocation) or not fileSystem.isDirectory(remoteLocation):
            subprocess.call('hadoop fs -mkdir ' + remotePath + batchNumber, shell=True)*/

        programLastBatch, channelLastBatch = newDataLastBatch(batchNumber)
        /*params = {
        'dataType':dataType,
        'batchNumber':str(batchNumber),
        'workingDir':location,
        'programPath':str(programPath) + str(programLastBatch),
        'channelPath':str(channelPath) + str(channelLastBatch),
        'amsPath':str(amsPath) + str(batchNumber),
        'ppvPath':str(ppvPath) + str(batchNumber),
        'socialPath':str(socialPath) + str(batchNumber),
        'streamingPath':str(streamingPath) + str(batchNumber),
        'cdnPath':str(cdnPath) + str(batchNumber),
        'remotePath':str(remotePath) + str(batchNumber),
        'ppvFilterStagingPath':str(ppvFilterStagingPath),
        'ppvFilterJar':ppvFilterJar,
        'outputDataPath':str(outputDataPath) + str(batchNumber),
        'flixterPath':flixterPath,
        'betterPath':betterPath,
        'eventMappingPath':eventMappingPath,
        'timeFormat':timeFormat,
        'dateTimeFormat':dateTimeFormat,
        'timeOfDay':timeOfDay,
#        'insertedTime':'20141009'
        'insertedTime':insertedTime
        }*/
        
        #utils.process(location + '/newData/newData.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'newData', batchNumber)
        hadoopCommand = 'hadoop jar ' + onenJoinJar + ' com.directv.recommendations.onenjoin.OneNJoinDriver '
        subprocess.call(hadoopCommand + 
        	'-JOINFIELD TMS -IN AmsMapper ' + amsPath + '/' + batchNumber + 
        	' -IN PpvMapper ' + ppvPath + '/' + batchNumber +
        	' -IN SocialMapper ' + socialPath + '/' + batchNumber + 
        	' -IN StreamingMapper ' + streamingPath + '/' + batchNumber +
        	' -IN CdnMapper ' + cdnPath + '/' + batchNumber + 
        	' -IN RemoteMapper ' + remotePath + '/' + batchNumber +
        	' -IN ProgramMapper ' + programPath + str(programLastBatch) +
        	#' -IN ChannelMapper ' + channelPath + str(channelLastBatch) +
        	' -IN FlixterMapper ' + flixterPath +
        	' -IN CategoryMapper ' + betterPath +
        	#' -IN EventMappingMapper ' + eventMappingPath +
        	' -OUT_INTERMEDIATE ' + outputDataPath + 'onen/' + batchNumber + '/tms', shell=True)

        subprocess.call(hadoopCommand + 
        	'-JOINFIELD CHANNEL -IN_INTERMEDIATE ' + outputDataPath + 'onen/' + batchNumber + '/tms' + 
        	' -IN ChannelMapper ' + channelPath + str(channelLastBatch) +
        	#' -IN EventMappingMapper ' + eventMappingPath +
        	' -OUT_INTERMEDIATE ' + outputDataPath + 'onen/' + batchNumber + '/channel', shell=True)

        subprocess.call(hadoopCommand + 
        	'-JOINFIELD EVENTTYPE -IN_INTERMEDIATE ' + outputDataPath + 'onen/' + batchNumber + '/channel' + 
        	#' -IN ChannelMapper ' + channelPath + str(channelLastBatch) +
        	' -IN EventMappingMapper ' + eventMappingPath +
        	' -OUT ' + outputDataPath + 'onen/' + batchNumber + '/final', shell=True)
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "preparingData", str(sys.exc_info()[1]))
    print '===========================END ALL NEW DATA============================='

def main():
    numberParam = len(sys.argv)
    if numberParam == 2:
        batchNumber = str(sys.argv[1])
        try:
            runNewData(batchNumber);
            #subprocess.call(location + '/newData/putLastBatch.sh ' + batchNumber + ' ' + str(insertedTime), shell=True)
        except:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "main", str(sys.exc_info()[1]))
    else:
        print '===========================Not enough parameter============================='
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "main", 'Not enough parameter')

if __name__ == '__main__':
    main()
