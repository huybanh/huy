package com.directv.recommendations.onenjoin;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

final class OneNJoinFinalReducer extends Reducer<OneNJoinKey, OneNJoinValue, NullWritable, Text> {
	
	private String currentJoinValue;
	
	private final OneNJoinValue currentRecord = new OneNJoinValue();

	private final NullWritable outKey = NullWritable.get();
	
	private final Text outValue = new Text();

	@Override
	protected void reduce(OneNJoinKey key, Iterable<OneNJoinValue> values,
			Reducer<OneNJoinKey, OneNJoinValue, NullWritable, Text>.Context context) throws IOException, InterruptedException {
		
		String comingJoinValue = key.getJoinValue();
		if (currentJoinValue == null || !currentJoinValue.equals(comingJoinValue)) {
			currentJoinValue = comingJoinValue;
		}

		boolean rightSide = !key.isLeftSide();
		Iterator<OneNJoinValue> it = values.iterator();
		while (it.hasNext()) {
			OneNJoinValue v = it.next();
			currentRecord.populateFrom(v);
			if (rightSide) {
				outValue.set(currentRecord.buildText());
				context.write(outKey, outValue);
			}
		}
	}

}
