package com.directv.recommendations.onenjoin;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Reducer;

final class OneNJoinIntermediateReducer extends Reducer<OneNJoinKey, OneNJoinValue, NullWritable, OneNJoinValue> {
	
	private String currentJoinValue;

	private final NullWritable outKey = NullWritable.get();
	
	private final OneNJoinValue outValue = new OneNJoinValue();

	@Override
	protected void reduce(OneNJoinKey key, Iterable<OneNJoinValue> values,
			Reducer<OneNJoinKey, OneNJoinValue, NullWritable, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		String comingJoinValue = key.getJoinValue();
		if (currentJoinValue == null || !currentJoinValue.equals(comingJoinValue)) {
			currentJoinValue = comingJoinValue;
		}
		
		boolean rightSide = !key.isLeftSide();
		Iterator<OneNJoinValue> it = values.iterator();
		while (it.hasNext()) {
			OneNJoinValue v = it.next();
			outValue.populateFrom(v);
			if (rightSide) {
				context.write(outKey, outValue);
			}
		}
	}

}
