package com.directv.recommendations.onenjoin;

import org.apache.hadoop.mapreduce.Partitioner;

final class OneNJoinPartitioner extends Partitioner<OneNJoinKey, OneNJoinValue> {

	@Override
	public int getPartition(OneNJoinKey key, OneNJoinValue value, int module) {
		
		return Math.abs(key.getKeyHashCode()) % module;
	}

}
