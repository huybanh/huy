package com.directv.recommendations.onenjoin;

import java.io.IOException;
import java.util.LinkedList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.OutputFormat;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class OneNJoinDriver {
	
	static final String CLOUDREC_PUVH_JOINFIELD_NUMBER = "CLOUDREC_PUVH_JOINFIELD_NUMBER";

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Job job = createJob(args);
		job.waitForCompletion(true);
	}

	@SuppressWarnings({ "unchecked"})	
	private static Job createJob(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Integer joinFieldNumber = null;
		LinkedList<Class<Mapper<?, ?, ?, ?>>> mappers = new LinkedList<Class<Mapper<?,?,?,?>>>();
		LinkedList<String> inputPaths = new LinkedList<String>();
		
		Class<? extends Mapper<?, ?, ?, ?>> intermediateMapper = null;
		String intermediatePath = null;
		
		Class<? extends Reducer<?, ?, ?, ?>> outputReducer = null;
		Class<? extends Writable> outputValueClass = null;
		@SuppressWarnings("rawtypes")
		Class<? extends OutputFormat> outputFormatClass = null;
		String outputPath = null;
		
		int i = 0;
		String joinFieldName = null;
		String packageName = OneNJoinDriver.class.getPackage().getName() + ".ext.";
		while (true) {
			if (i == args.length) {
				break;
			}
			if ("-JOINFIELD".equals(args[i])) {
				i++;
				joinFieldName = args[i];
				joinFieldNumber = OneNJoinValue.parseFieldNumber(joinFieldName);
				i++;
			}
			if ("-IN".equals(args[i])) {
				i++;
				mappers.add((Class<Mapper<?, ?, ?, ?>>) Class.forName(packageName + args[i]));
				i++;
				inputPaths.add(args[i]);
				i++;
				continue;
			}
			if ("-IN_INTERMEDIATE".equals(args[i])) {
				i++;
				intermediateMapper = IntermediateJoinMapper.class;
				intermediatePath = args[i];
				i++;
				continue;
			}
			if ("-OUT_INTERMEDIATE".equals(args[i])) {
				if (outputPath != null) {
					throw new RuntimeException("Output is already set.");
				}
				i++;
				outputReducer = OneNJoinIntermediateReducer.class;
				outputValueClass = OneNJoinValue.class;
				outputFormatClass = SequenceFileOutputFormat.class;
				outputPath = args[i];
				i++;
				continue;
			}
			if ("-OUT".equals(args[i])) {
				if (outputPath != null) {
					throw new RuntimeException("Output is already set.");
				}
				i++;
				outputReducer = OneNJoinFinalReducer.class;
				outputValueClass = Text.class;
				outputFormatClass = TextOutputFormat.class;
				outputPath = args[i];
				i++;
				continue;
			}
			throw new RuntimeException("Unexpected parameter: " + args[i]);
		}
		

		//job configuration
		Configuration hdfsConf = new Configuration();
		if (joinFieldNumber == null) {
			throw new RuntimeException("Missing configuration: -JOINFIELD");
		}
		hdfsConf.set(CLOUDREC_PUVH_JOINFIELD_NUMBER, String.valueOf(joinFieldNumber));
		Job job = new Job(hdfsConf, "OneNJoining to " + outputPath);
		job.setJarByClass(OneNJoinDriver.class);
		job.setPartitionerClass(OneNJoinPartitioner.class);
		
		//inputs
		for (int n = 0; n < mappers.size(); n++) {
			String onePath = inputPaths.get(n);
			Class<Mapper<?, ?, ?, ?>> mapperClass = mappers.get(n);
			MultipleInputs.addInputPath(job, new Path(onePath), TextInputFormat.class, mapperClass);
			System.out.println("Added input path: " + mapperClass.getName() + "@" + onePath);
		}
		
		if (intermediatePath != null) {
			MultipleInputs.addInputPath(job, new Path(intermediatePath), SequenceFileInputFormat.class, intermediateMapper);
			System.out.println("Added input path: " + intermediateMapper.getName() + "@" + intermediatePath);
		}
		
		//mapper output
		job.setMapOutputKeyClass(OneNJoinKey.class);
		job.setMapOutputValueClass(OneNJoinValue.class);
		
		//reducer
		job.setReducerClass(outputReducer);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(outputValueClass);
		job.setOutputFormatClass(outputFormatClass);
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		System.out.println("Output format: " + outputValueClass.getName() + "@" + outputFormatClass.getName());
		System.out.println("Output path: " + outputReducer.getName() + "@" + outputPath);
		System.out.println("Join field: " + joinFieldName);
		return job;
	}

}
