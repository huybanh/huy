package com.directv.recommendations.onenjoin;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.mapreduce.Mapper;

class IntermediateJoinMapper extends Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue> {

	private final OneNJoinKey outKey = new OneNJoinKey();
	
	private int joinFieldNumber;
	
	@Override
	protected void setup(Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		joinFieldNumber = Integer.parseInt(context.getConfiguration().get(OneNJoinDriver.CLOUDREC_PUVH_JOINFIELD_NUMBER));
	}

	@Override
	protected void map(NullWritable key, OneNJoinValue value, 
			Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		String joinValue = value.getFieldValueByFieldNumber(joinFieldNumber);
		if (joinValue == null) {
			joinValue = "";
		}

		//emit
		context.getCounter(Counter.RIGHT_COUNT).increment(1);
		outKey.setLeftSide(false);
		outKey.setJoinValue(joinValue);
		context.write(outKey, value);
	}

}

/*class IntermediateJoinChannelMapper extends Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue> {
	
	private final OneNJoinKey outKey = new OneNJoinKey();

	@Override
	protected void map(NullWritable key, OneNJoinValue value, 
			Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		outKey.setId(value.getChannelId());
		outKey.setLeftSide(false);
		context.write(outKey, value);
	}

}

class IntermediateJoinEventTypeMapper extends Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue> {
	
	private final OneNJoinKey outKey = new OneNJoinKey();

	@Override
	protected void map(NullWritable key, OneNJoinValue value, 
			Mapper<NullWritable, OneNJoinValue, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		outKey.setId(value.getEventType());
		outKey.setLeftSide(false);
		context.write(outKey, value);
	}

}*/
