package com.directv.recommendations.onenjoin.ext;

import com.directv.recommendations.onenjoin.FieldArrangementJoinMapper;
import com.directv.recommendations.onenjoin.OneNJoinValue;

public abstract class UvhMapper extends FieldArrangementJoinMapper {
	
	int fieldIndexTms = -1;
	int fieldIndexChannel = -1;
	int fieldIndexEventType = -1;
	int fieldIndexEventTime = -1;
	int fieldIndexStartTimeSchedule = -1;
	int fieldIndexScheduleDuration = -1;

	@Override
	protected final int getFieldIndexByFieldNumber(int fieldNumber) {
		if (OneNJoinValue.FIELD_NUMBER_TMS == fieldNumber) {
			return this.fieldIndexTms;
		}
		if (OneNJoinValue.FIELD_NUMBER_CHANNEL == fieldNumber) {
			return this.fieldIndexChannel;
		}
		if (OneNJoinValue.FIELD_NUMBER_EVENTTYPE == fieldNumber) {
			return this.fieldIndexEventType;
		}
		throw new RuntimeException("Malconfigured field number");
	}

	@Override
	protected final void fillOutputValues(OneNJoinValue outputValue, String[] inputFields, String mainText) {
		
		outputValue.setUvhData(mainText);
		if (fieldIndexTms > -1) {
			outputValue.setTmsId(inputFields[fieldIndexTms]);
		}
		if (fieldIndexChannel > -1) {
			outputValue.setChannelId(inputFields[fieldIndexChannel]);
		}
		if (fieldIndexEventType > -1) {
			outputValue.setEventType(inputFields[fieldIndexEventType]);
		}
		if (fieldIndexEventTime > -1) {
			outputValue.setEventTime(inputFields[fieldIndexEventTime]);
		}
		if (fieldIndexStartTimeSchedule > -1) {
			outputValue.setStartTimeSchedule(inputFields[fieldIndexStartTimeSchedule]);
		}
		if (fieldIndexScheduleDuration > -1) {
			outputValue.setScheduleDuration(inputFields[fieldIndexScheduleDuration]);
		}
	}

	@Override
	protected boolean isLeftSide() {
		return false;
	}

}
