package com.directv.recommendations.onenjoin.ext;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.directv.recommendations.onenjoin.OneNJoinKey;
import com.directv.recommendations.onenjoin.OneNJoinValue;

public final class StreamingMapper extends UvhMapper {

	@Override
	protected String getInputFields() {
		return "streamrowkey,accountId,streamingStart,streamingEnd,channelNumber,viewedDuration,eventType,materialId,"
				+ "tmsId,source,deviceType,zipCode,fipsCountyCode,DMA,utcOffset,utcInt,DMAname";
	}

	@Override
	protected String getOutputFields() {//TODO remove uncommon fields
		return "streamrowkey,accountId,tmsId,streamingStart as eventTime,source,eventType,!sourceType,streamingStart,"
				+ "streamingEnd,!channelId,!cardId,viewedDuration as durationViewed,!profileId,!deviceId,deviceType,zipCode,"
				+ "channelNumber,DMA,!startTimeSchedule,!endTimeSchedule,!scheduleDuration,!statusCDN,fipsCountyCode,"
				+ "utcOffset,utcInt,DMAname";
	}

	@Override
	protected void setup(Mapper<LongWritable, Text, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		super.setup(context);
		fieldIndexTms = super.inputFieldIndexes.get("tmsId");
		//fieldIndexChannel = super.inputFieldIndexes.get("channelId");
		fieldIndexEventType = super.inputFieldIndexes.get("eventType");
		fieldIndexEventTime = super.inputFieldIndexes.get("streamingStart");
		//fieldIndexStartTimeSchedule = super.inputFieldIndexes.get("startTimeSchedule");
		//fieldIndexScheduleDuration = super.inputFieldIndexes.get("scheduleDuration");
	}

}
