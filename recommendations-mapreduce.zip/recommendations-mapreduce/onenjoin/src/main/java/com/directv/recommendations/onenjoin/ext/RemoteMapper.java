package com.directv.recommendations.onenjoin.ext;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.directv.recommendations.onenjoin.OneNJoinKey;
import com.directv.recommendations.onenjoin.OneNJoinValue;

public final class RemoteMapper extends UvhMapper {

	@Override
	protected String getInputFields() {
		return "remoterowkey,eventTime,accountId,cardId,tmsId,startTime,deviceType,eventType,source,"
				+ "zipCode,fipsCountyCode,DMA,utcOffset,utcInt,DMAname";
	}

	@Override
	protected String getOutputFields() {//TODO remove uncommon fields
		return "remoterowkey,accountId,tmsId,eventTime,source,eventType,!sourceType,startTime,!endTime,"
				+ "!channelId,cardId,!durationViewed,!profileId,!deviceId,deviceType,zipCode,!channelNumber,DMA,"
				+ "!startTimeSchedule,!endTimeSchedule,!scheduleDuration,!statusCDN,fipsCountyCode,utcOffset,utcInt,DMAname";
	}

	@Override
	protected void setup(Mapper<LongWritable, Text, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		super.setup(context);
		fieldIndexTms = super.inputFieldIndexes.get("tmsId");
		//fieldIndexChannel = super.inputFieldIndexes.get("channelId");
		fieldIndexEventType = super.inputFieldIndexes.get("eventType");
		fieldIndexEventTime = super.inputFieldIndexes.get("eventTime");
		//fieldIndexStartTimeSchedule = super.inputFieldIndexes.get("startTimeSchedule");
		//fieldIndexScheduleDuration = super.inputFieldIndexes.get("scheduleDuration");
	}

}
