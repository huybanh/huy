package com.directv.recommendations.onenjoin.ext;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.directv.recommendations.onenjoin.OneNJoinKey;
import com.directv.recommendations.onenjoin.OneNJoinValue;

public final class ChannelMapper extends UvhMapper {

	@Override
	protected String getInputFields() {
		return "channelId,channelType,channelObjectId,marketId,insertedTime";
	}

	@Override
	protected String getOutputFields() {//TODO remove uncommon fields
		return "channelId,channelType,channelObjectId,marketId,insertedTime";
	}

	@Override
	protected void setup(Mapper<LongWritable, Text, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		super.setup(context);
		//fieldIndexTms = super.inputFieldIndexes.get("tmsId");
		fieldIndexChannel = super.inputFieldIndexes.get("channelId");
		//fieldIndexEventType = super.inputFieldIndexes.get("eventType");
		//fieldIndexEventTime = super.inputFieldIndexes.get("eventTime");
		//fieldIndexStartTimeSchedule = super.inputFieldIndexes.get("startTimeSchedule");
		//fieldIndexScheduleDuration = super.inputFieldIndexes.get("scheduleDuration");
	}

	@Override
	protected boolean isLeftSide() {
		return true;
	}

}
