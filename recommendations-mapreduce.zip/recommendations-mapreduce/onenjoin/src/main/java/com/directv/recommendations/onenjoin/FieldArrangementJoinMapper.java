package com.directv.recommendations.onenjoin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.directv.recommendations.onenjoin.ext.AmsMapper;

public abstract class FieldArrangementJoinMapper extends Mapper<LongWritable, Text, OneNJoinKey, OneNJoinValue> {
	
	//configurations from subclasses
	private int[] fieldMap; //map an output field to an input field
	private int joinFieldIndex;
	private int outputFieldCount = 26;

	//internal states
	private final StringBuilder stringBuilder = new StringBuilder();
	
	private final OneNJoinKey outKey = new OneNJoinKey();
	private final OneNJoinValue outValue = new OneNJoinValue();
	
	//meta data
	protected HashMap<String, Integer> inputFieldIndexes = new HashMap<String, Integer>();

	@Override
	protected void setup(Mapper<LongWritable, Text, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {
		
		//input field indexes
		String[] inputFields = getInputFields().split(",");
		for (int i = 0; i < inputFields.length; i++) {
			inputFieldIndexes.put(inputFields[i], i);
		}

		//in/out field map & indexes
		fieldMap = buildFieldMap(getInputFields(), getOutputFields());
		dump(this.getClass().getName(), getInputFields(), getOutputFields(), fieldMap);
		int joinFieldNumber = Integer.parseInt(context.getConfiguration().get(OneNJoinDriver.CLOUDREC_PUVH_JOINFIELD_NUMBER));
		joinFieldIndex = getFieldIndexByFieldNumber(joinFieldNumber);
		outputFieldCount = getOutputFields().split(",").length;
	}

	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, OneNJoinKey, OneNJoinValue>.Context context) throws IOException, InterruptedException {

		String[] inputValues = value.toString().split(";");
		stringBuilder.setLength(0);
		for (int i = 0; i < outputFieldCount; i++) {
			int mappedIndex = fieldMap[i];
			if (mappedIndex < 0 || mappedIndex >= inputValues.length) {
				//no mapped field or current record is short -> empty field
				stringBuilder.append(";");
				continue;
			}
			
			//put mapped value to output
			stringBuilder.append(inputValues[mappedIndex] + ";");
		}
		
		//output
		if (joinFieldIndex > -1) {
			outKey.setJoinValue(inputValues[joinFieldIndex]);
		} else {
			outKey.setJoinValue("");
		}
		
		//emit
		boolean leftSide = isLeftSide();
		if (leftSide) {
			context.getCounter(Counter.LEFT_COUNT).increment(1);
		} else {
			context.getCounter(Counter.RIGHT_COUNT).increment(1);
		}
		outKey.setLeftSide(leftSide);
		outValue.reset();
		fillOutputValues(outValue, inputValues, stringBuilder.toString());
		context.write(outKey, outValue);
	}

	protected abstract String getInputFields();
	
	protected abstract String getOutputFields();
	
	//protected abstract int getInputJoinFieldIndex();
	protected abstract int getFieldIndexByFieldNumber(int fieldNumber);
	
	protected abstract boolean isLeftSide();
	
	protected abstract void fillOutputValues(OneNJoinValue outputValue, String[] inputFields, String mainText);

	static int[] buildFieldMap(String inputFields, String outputFields) {
		
		String[] outputFieldArray = outputFields.split(",");
		ArrayList<String> outputFieldList = new ArrayList<String>();
		for (String one : outputFieldArray) {
			one = one.split(" ")[0].trim();
			outputFieldList.add(one);
		}
		
		String[] inputFieldArray = inputFields.split(",");
		HashMap<String, Integer> inputFieldIndexes = new HashMap<String, Integer>();
		int fieldIndex = 0;
		for (String one : inputFieldArray) {
			one = one.trim();
			if (inputFieldIndexes.containsKey(one)) {
				throw new RuntimeException("Duplicated field: " + one);
			}
			if (outputFieldList.contains(one)) {
				inputFieldIndexes.put(one, fieldIndex);
			}
			fieldIndex++;
		}
		
		int[] fieldMap = new int[outputFieldList.size()];
		for (int i = 0; i < fieldMap.length; i++) {
			String oneField = outputFieldList.get(i);
			Integer oneFieldIndex = inputFieldIndexes.get(oneField);
			if (oneFieldIndex == null) {
				//System.out.println("Field unused: " + oneField);
				fieldMap[i] = -1;
			} else {
				fieldMap[i] = oneFieldIndex;
			}
		}

		return fieldMap;
	}
	
	private static void dump(String name, String inputFields, String outputFields, int[] fieldMap) {

		System.out.println("Mapper: " + name);
		System.out.println("Input fields : " + inputFields);
		System.out.println("Output fields: " + outputFields);
		String[] inputFieldArray = inputFields.split(","); 
		String[] outputFieldArray = outputFields.split(",");
		List<String> unusedFields = Arrays.asList(inputFieldArray);
		LinkedList<String> unusedFieldList = new LinkedList<String>(unusedFields);
		
		System.out.print("Field mapping: ");
		for (int i = 0; i < outputFieldArray.length; i++) {
			int fieldIndex = fieldMap[i];
			String fieldName;
			if (fieldIndex < 0) {
				fieldName = "";
			} else {
				fieldName = inputFieldArray[fieldIndex];
				unusedFieldList.remove(fieldName);
			}
			System.out.print("[" + fieldName + "]");
		}
		System.out.println();

		System.out.print("Unused fields: ");
		for (String s : unusedFieldList) {
			System.out.print( s + " ");
		}
		System.out.println();
	}
	
	/*
	 * Test input map
	 * */
	public static void main(String[] args) throws IOException, InterruptedException {
		FieldArrangementJoinMapper ams = new AmsMapper();
		//buildFieldMap(ams.getInputFields(), ams.getOutputFields());
		ams.setup(null);
	}
}
