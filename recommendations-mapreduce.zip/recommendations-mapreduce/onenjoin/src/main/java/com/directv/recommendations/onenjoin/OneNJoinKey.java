package com.directv.recommendations.onenjoin;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public final class OneNJoinKey implements WritableComparable<OneNJoinKey> {
	
	private String joinValue;
	
	/*
	 * We are doing 1-n joining: one record on left side joins to 
	 * many records on the right side
	 * 
	 * */
	private boolean leftSide;

	@Override
	public void readFields(DataInput in) throws IOException {
		joinValue = in.readUTF();
		leftSide = in.readBoolean();
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(joinValue);
		out.writeBoolean(leftSide);
	}

	@Override
	public int compareTo(OneNJoinKey o) {
		int c = this.joinValue.compareTo(o.joinValue);
		if (c != 0) {
			return c;
		}
		if (this.leftSide) {
			if (o.leftSide) {
				return 0;
			} else {
				return -1; //leftside is smaller, so it goes first to reducers
			}
		} else {
			if (o.leftSide) {
				return 1;
			} else {
				return 0;
			}
		}
	}
	
	int getKeyHashCode() {
		return joinValue.hashCode();
	}

	public void setJoinValue(String joinValue) {
		this.joinValue = joinValue;
	}

	public void setLeftSide(boolean leftSide) {
		this.leftSide = leftSide;
	}

	public String getJoinValue() {
		return joinValue;
	}

	public boolean isLeftSide() {
		return leftSide;
	}

}
