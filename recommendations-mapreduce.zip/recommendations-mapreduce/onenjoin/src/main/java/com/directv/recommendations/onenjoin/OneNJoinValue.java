package com.directv.recommendations.onenjoin;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public final class OneNJoinValue implements Writable {
	
	public static final int FIELD_NUMBER_TMS = 0;
	public static final int FIELD_NUMBER_CHANNEL = 1;
	public static final int FIELD_NUMBER_EVENTTYPE = 2;
	
	private String uvhData;
	private boolean uvhDataSet;

	private String programData;
	private boolean programDataSet;
	
	private String channelData;
	private boolean channelDataSet;

	private String eventMappingData;
	private boolean eventMappingDataSet;
	
	/*
	 * Joining keys (from UVH)
	 * */
	private String tmsId;
	private boolean tmsIdSet;
	
	private String channelId;
	private boolean channelIdSet;
	
	private String eventType;
	private boolean eventTypeSet;
	
	/*
	 * values for calculating dayOfWeek,timeOfDay (from UVH)
	 * */
	private String eventTime;
	private boolean eventTimeSet;
	
	private String startTimeSchedule;
	private boolean startTimeScheduleSet;
	
	/*
	 * values for calculating runLength 
	 */
	private String maxRunLength; //from programs
	private boolean maxRunLengthSet;
	
	private String scheduleDuration; //from uvh
	private boolean scheduleDurationSet;
	
	private final StringBuilder builder = new StringBuilder();

	@Override
	public void readFields(DataInput in) throws IOException {
		
		uvhDataSet = in.readBoolean();
		if (uvhDataSet) {
			uvhData = in.readUTF();
		}
		
		programDataSet = in.readBoolean();
		if (programDataSet) {
			programData = in.readUTF();
		}
		
		channelDataSet = in.readBoolean();
		if (channelDataSet) {
			channelData = in.readUTF();
		}
		
		eventMappingDataSet = in.readBoolean();
		if (eventMappingDataSet) {
			eventMappingData = in.readUTF();
		}
		
		/*
		 * Joining keys (from UVH)
		 * */
		tmsIdSet = in.readBoolean();
		if (tmsIdSet) {
			tmsId = in.readUTF();
		}
		
		channelIdSet = in.readBoolean();
		if (channelIdSet) {
			channelId = in.readUTF();
		}
		
		eventTypeSet = in.readBoolean();
		if (eventTypeSet) {
			eventType = in.readUTF();
		}
		
		/*
		 * values for calculating dayOfWeek,timeOfDay (from UVH)
		 * */
		eventTimeSet = in.readBoolean();
		if (eventTimeSet) {
			eventTime = in.readUTF();
		}
		
		startTimeScheduleSet = in.readBoolean();
		if (startTimeScheduleSet) {
			startTimeSchedule = in.readUTF();
		}
		
		/*
		 * values for calculating runLength 
		 */
		maxRunLengthSet = in.readBoolean();
		if (maxRunLengthSet) {
			maxRunLength = in.readUTF();
		}
		
		scheduleDurationSet = in.readBoolean();
		if (scheduleDurationSet) {
			scheduleDuration = in.readUTF();
		}
		
	}

	@Override
	public void write(DataOutput out) throws IOException {
		
		out.writeBoolean(uvhDataSet);
		if (uvhDataSet) {
			out.writeUTF(uvhData);
		}
		
		out.writeBoolean(programDataSet);
		if (programDataSet) {
			out.writeUTF(programData);
		}
		
		out.writeBoolean(channelDataSet);
		if (channelDataSet) {
			out.writeUTF(channelData);
		}
		
		out.writeBoolean(eventMappingDataSet);
		if (eventMappingDataSet) {
			out.writeUTF(eventMappingData);
		}
		
		/*
		 * Joining keys (from UVH)
		 * */
		out.writeBoolean(tmsIdSet);
		if (tmsIdSet) {
			out.writeUTF(tmsId);
		}
		
		out.writeBoolean(channelIdSet);
		if (channelIdSet) {
			out.writeUTF(channelId);
		}
		
		out.writeBoolean(eventTypeSet);
		if (eventTypeSet) {
			out.writeUTF(eventType);
		}
		
		/*
		 * values for calculating dayOfWeek,timeOfDay (from UVH)
		 * */
		out.writeBoolean(eventTimeSet);
		if (eventTimeSet) {
			out.writeUTF(eventTime);
		}
		
		out.writeBoolean(startTimeScheduleSet);
		if (startTimeScheduleSet) {
			out.writeUTF(startTimeSchedule);
		}
		
		/*
		 * values for calculating runLength 
		 */
		out.writeBoolean(maxRunLengthSet);
		if (maxRunLengthSet) {
			out.writeUTF(maxRunLength);
		}
		
		out.writeBoolean(scheduleDurationSet);
		if (scheduleDurationSet) {
			out.writeUTF(scheduleDuration);
		}
		
	}

	void reset() {
		uvhDataSet = false;
		programDataSet = false;
		channelDataSet = false;
		eventMappingDataSet = false;
		
		/*
		 * Joining keys
		 * */
		tmsIdSet = false;
		channelIdSet = false;
		eventTypeSet = false;
		
		/*
		 * values for calculating dayOfWeek,timeOfDay
		 * */
		eventTimeSet = false;
		startTimeScheduleSet = false;
		
		/*
		 * values for calculating runLength 
		 */
		maxRunLengthSet = false;
		scheduleDurationSet = false;
	}

	String getFieldValueByFieldNumber(int fieldNumber) {
		if (FIELD_NUMBER_TMS == fieldNumber) {
			return this.tmsId;
		}
		if (FIELD_NUMBER_CHANNEL == fieldNumber) {
			return this.channelId;
		}
		if (FIELD_NUMBER_EVENTTYPE == fieldNumber) {
			return this.eventType;
		}
		throw new RuntimeException("Malconfigured field number");
	}

	public static int parseFieldNumber(String fieldName) {
		if ("TMS".equals(fieldName)) {
			return FIELD_NUMBER_TMS;
		}
		if ("CHANNEL".equals(fieldName)) {
			return FIELD_NUMBER_CHANNEL;
		}
		if ("EVENTTYPE".equals(fieldName)) {
			return FIELD_NUMBER_EVENTTYPE;
		}
		throw new RuntimeException("Malconfigured field number");
	}

	void populateFrom(OneNJoinValue v) {
		
		if (v.uvhDataSet) {
			this.uvhData = v.uvhData;
			this.uvhDataSet = true;
		}
		if (v.programDataSet) {
			this.programData = v.programData;
			this.programDataSet = true;
		}
		if (v.channelDataSet) {
			this.channelData = v.channelData;
			this.channelDataSet = true;
		}
		if (v.eventMappingDataSet) {
			this.eventMappingData = v.eventMappingData;
			this.eventMappingDataSet = true;
		}
		
		/*
		 * Joining keys (from UVH)
		 * */
		if (v.tmsIdSet) {
			this.tmsId = v.tmsId;
			this.tmsIdSet = true;
		}
		if (v.channelIdSet) {
			this.channelId = v.channelId;
			this.channelIdSet = true;
		}
		if (v.eventTypeSet) {
			this.eventType = v.eventType;
			this.eventTypeSet = true;
		}
		
		/*
		 * values for calculating dayOfWeek,timeOfDay (from UVH)
		 * */
		if (v.eventTimeSet) {
			this.eventTime = v.eventTime;
			this.eventTimeSet = true;
		}
		if (v.startTimeScheduleSet) {
			this.startTimeSchedule = v.startTimeSchedule;
			this.startTimeScheduleSet = true;
		}
		
		/*
		 * values for calculating runLength 
		 */
		if (v.maxRunLengthSet) {
			this.maxRunLength = v.maxRunLength;
			this.maxRunLengthSet = true;
		}
		if (v.scheduleDurationSet) {
			this.scheduleDuration = v.scheduleDuration;
			this.scheduleDurationSet = true;
		}
	}

	String buildText() {
		builder.setLength(0);
		//TODO ordering
		if (uvhDataSet) {
			builder.append(uvhData + ";");
		} else {
			builder.append(";");
		}
		if (programDataSet) {
			builder.append(programData + ";");
		} else {
			builder.append(";");
		}
		if (channelDataSet) {
			builder.append(channelData + ";");
		} else {
			builder.append(";");
		}
		if (eventMappingDataSet) {
			builder.append(eventMappingData + ";");
		} else {
			builder.append(";");
		}
		
		if (tmsIdSet) {
			builder.append(tmsId + ";");
		} else {
			builder.append(";");
		}
		if (channelIdSet) {
			builder.append(channelId + ";");
		} else {
			builder.append(";");
		}
		if (eventTypeSet) {
			builder.append(eventType + ";");
		} else {
			builder.append(";");
		}
		
		if (eventTimeSet) {
			builder.append(eventTime + ";");
		} else {
			builder.append(";");
		}
		if (startTimeScheduleSet) {
			builder.append(startTimeSchedule + ";");
		} else {
			builder.append(";");
		}
		
		if (maxRunLengthSet) {
			builder.append(maxRunLength + ";");
		} else {
			builder.append(";");
		}
		if (scheduleDurationSet) {
				builder.append(scheduleDuration);
		}
		return builder.toString();
	}
	
	/*public String getTmsId() {
		return tmsId;
	}

	public String getChannelId() {
		return channelId;
	}

	public String getEventType() {
		return eventType;
	}*/

	public void setUvhData(String uvhData) {
		this.uvhData = uvhData;
		this.uvhDataSet = true;
	}

	public void setProgramData(String programData) {
		this.programData = programData;
		this.programDataSet = true;
	}

	public void setChannelData(String channelData) {
		this.channelData = channelData;
		this.channelDataSet = true;
	}

	public void setEventMappingData(String eventMappingData) {
		this.eventMappingData = eventMappingData;
		this.eventMappingDataSet = true;
	}

	public void setTmsId(String tmsId) {
		this.tmsId = tmsId;
		this.tmsIdSet = true;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
		this.channelIdSet = true;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
		this.eventTypeSet = true;
	}

	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
		this.eventTimeSet = true;
	}

	public void setStartTimeSchedule(String startTimeSchedule) {
		this.startTimeSchedule = startTimeSchedule;
		this.startTimeScheduleSet = true;
	}

	public void setMaxRunLength(String maxRunLength) {
		this.maxRunLength = maxRunLength;
		this.maxRunLengthSet = true;
	}

	public void setScheduleDuration(String scheduleDuration) {
		this.scheduleDuration = scheduleDuration;
		this.scheduleDurationSet = true;
	}
}
