package com.directv.recommendations.onenjoin;

public enum Counter {

	LEFT_COUNT, RIGHT_COUNT;
}
