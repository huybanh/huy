
export HADOOP_CLASSPATH=/etc/hbase/conf/:/opt/cloudera/parcels/CDH-4.6.0-1.cdh4.6.0.p0.26/lib/hbase/*

hadoop jar bulkload-0.1-SNAPSHOT.jar com.dtv.ingestion.hbasebulk.HFileGenDriver bulkload_lookup2 $1 $2 bulkload/stagging false