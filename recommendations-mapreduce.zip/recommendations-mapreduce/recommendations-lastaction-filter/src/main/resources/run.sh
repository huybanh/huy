hadoop jar recommendations-filter-0.0.1-SNAPSHOT.jar com.directv.recommendations.analytics.filter.Driver config.xml
