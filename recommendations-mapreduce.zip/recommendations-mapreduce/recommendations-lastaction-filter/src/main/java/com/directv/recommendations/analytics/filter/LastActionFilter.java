/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;

public class LastActionFilter {
	private final Map<String, String[]> filterDict;

	private static final String EXCLUDING_GENRE_KEY = "genre";
	private static final String EXCLUDING_TMSID_KEY = "tmsid";
	private static final String EXCLUDING_TITLE_KEY = "title";

	private static final String GENRE1_FILTER_RULE = "\"genre1\":\"%s\"";
	private static final String GENRE2_FILTER_RULE = "\"genre2\":\"%s\"";
	private static final String GENRE3_FILTER_RULE = "\"genre3\":\"%s\"";
	private static final String TMSID_FILTER_RULE = "\"tmsId\":\"%s\"";
	private static final String TITLE_FILTER_RULE = "\"programTitle\":\"%s\"";

	private LastActionFilter(Configuration conf) {
		filterDict = new HashMap<String, String[]>();

		if (conf != null) {
			filterDict.put(EXCLUDING_GENRE_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_GENRE_KEY));
			filterDict.put(EXCLUDING_TMSID_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_TMSID_KEY));
			filterDict.put(EXCLUDING_TITLE_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_TITLE_KEY));
		}
	}

	private LastActionFilter(Properties conf) {
		filterDict = new HashMap<String, String[]>();

		if (conf != null) {
			filterDict.put(EXCLUDING_GENRE_KEY.toLowerCase(),
					conf.getProperty(EXCLUDING_GENRE_KEY, "").split(","));
			filterDict.put(EXCLUDING_TMSID_KEY.toLowerCase(),
					conf.getProperty(EXCLUDING_TMSID_KEY, "").split(","));
			filterDict.put(EXCLUDING_TITLE_KEY.toLowerCase(),
					conf.getProperty(EXCLUDING_TITLE_KEY, "").split(","));
		}
	}

	public static LastActionFilter configureInternal(Configuration conf) {
		return new LastActionFilter(conf);
	}

	// for unit test
	public static LastActionFilter configureExternal(Properties property) {
		return new LastActionFilter(property);
	}

	public boolean existGroupGenre(String[] fields) {
		String columnName = fields[1];
		int sepIndex = fields[1].lastIndexOf(".");

		String groupGenre = columnName.substring(sepIndex + 1);
		String[] excludes = filterDict.get(EXCLUDING_GENRE_KEY);
		return find(groupGenre, excludes);
	}

	private boolean find(String key, String[] excludes) {
		for (int i = 0; i < excludes.length; i++) {
			String genre = excludes[i];
			if (key.equalsIgnoreCase(genre)) {
				return true;
			}
		}
		return false;
	}

	// High performance (just process with String)
	private boolean filter(String value, String filteredPattern,
			String[] excludes) {
		if (excludes == null || excludes.length == 0) {
			return true;
		}

		for (String ex : excludes) {
			String pattern = String.format(filteredPattern, ex);

			if (value.indexOf(pattern) > 0) {
				return true;
			}
		}

		return false;
	}

	public String filterAll(String[] fields) throws IOException {

		List<String> filteredValues = new ArrayList<String>();

		String[] values = fields[2].replaceAll("^\\[\\{|\\}\\]$", "").split(
				"\\},\\{");

		for (String value : values) {

			if (filter(value, TMSID_FILTER_RULE,
					filterDict.get(EXCLUDING_TMSID_KEY))) {
				continue;
			} else if (filter(value, TITLE_FILTER_RULE,
					filterDict.get(EXCLUDING_TITLE_KEY))) {
				continue;
			} else if (filter(value, GENRE1_FILTER_RULE,
					filterDict.get(EXCLUDING_GENRE_KEY))) {
				continue;
			} else if (filter(value, GENRE2_FILTER_RULE,
					filterDict.get(EXCLUDING_GENRE_KEY))) {
				continue;
			} else if (filter(value, GENRE3_FILTER_RULE,
					filterDict.get(EXCLUDING_GENRE_KEY))) {
				continue;
			}

			filteredValues.add(value);
		}

		if (filteredValues.size() > 0) {
			return "[{" + StringUtils.join(filteredValues, "},{") + "}]";
		} else {
			return "[]";
		}
	}
}
