/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.filter;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * HFile generating driver
 */
public class Driver {

	/**
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ClassNotFoundException
	 * @throws Exception
	 */
	public static void main(String[] args) throws IOException,
			ClassNotFoundException, InterruptedException {

		if (args.length < 1) {
			System.err.println("Enter argurment environment!");
			return;
		}

		String excludePath = args[0];

		Configuration hdfsConf = new Configuration();
		if (System.getenv("HADOOP_TOKEN_FILE_LOCATION") != null) {
			hdfsConf.set("mapreduce.job.credentials.binary",
					System.getenv("HADOOP_TOKEN_FILE_LOCATION"));
		}

		hdfsConf.addResource(new Path(excludePath));

		String inputPath = hdfsConf
				.get("com.directv.recommendations.analytics.input");
		String outputPath = hdfsConf
				.get("com.directv.recommendations.analytics.output");

		System.out.println("input: " + inputPath);
		System.out.println("output: " + outputPath);

		Path outPath = new Path(outputPath);
		FileSystem fileSystem = FileSystem.newInstance(new Configuration(true));

		if (fileSystem.exists(outPath)) {
			System.out.println("Delete " + outputPath);
			fileSystem.delete(outPath, true);
		}

		Job job = new Job(hdfsConf, "Filter cbcf on " + inputPath);
		job.setJarByClass(FilterMapper.class);
		job.setMapperClass(FilterMapper.class);
		job.setMapOutputKeyClass(NullWritable.class);
		job.setMapOutputValueClass(Text.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setNumReduceTasks(0);

		FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		job.waitForCompletion(true);
	}
}
