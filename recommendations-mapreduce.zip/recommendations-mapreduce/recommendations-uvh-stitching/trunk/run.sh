
#$1: input
#$2: output
#$3: sessionExtensionMinutes
#$4: viewingDurationThreshold (in percentage)

hadoop jar recommendations-udf-eventgroupping-0.0.1-SNAPSHOT.jar com.directv.recommendations.analytics.stiching.StichingDriver $1 $2 $3 $4
