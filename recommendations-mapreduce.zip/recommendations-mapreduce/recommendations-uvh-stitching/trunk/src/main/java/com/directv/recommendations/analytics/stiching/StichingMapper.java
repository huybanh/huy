package com.directv.recommendations.analytics.stiching;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.directv.recommendations.genericfilter.GenericFilter;

class StichingMapper extends Mapper<LongWritable, Text, StichingKey, Text> {
	
	private final StichingKey stichingKey = new StichingKey();
	
	private GenericFilter genFilter;

	@Override
	protected void setup(Mapper<LongWritable, Text, StichingKey, Text>.Context context) throws IOException, InterruptedException {
		genFilter = GenericFilter.load(StichingMapper.class.getName(), context.getConfiguration());
	}

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		
		String[] fields = value.toString().split(";");
		if (genFilter != null && genFilter.filter(fields, context)) {
			return;
		}
		stichingKey.parse(fields);
		context.write(stichingKey, value);
	}
	
}
