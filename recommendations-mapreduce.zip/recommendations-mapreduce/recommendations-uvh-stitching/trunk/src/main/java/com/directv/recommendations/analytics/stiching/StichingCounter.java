package com.directv.recommendations.analytics.stiching;

public enum StichingCounter {

	LIVE_VIEW_TOTAL,
	LIVE_VIEW_SINGLES,
	LIVE_VIEW_GROUPS,
	LIVE_VIEW_GROUPED_ENTRIES,
	LIVE_VIEW_FILTERED,
	
	PLAYBACK_TOTAL,
	PLAYBACK_FILTERED,
	
	OTHER_EVENTS;
}
