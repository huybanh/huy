package com.directv.recommendations.analytics.stiching;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

class StichingPartitioner extends Partitioner<StichingKey, Text> {

	@Override
	public int getPartition(StichingKey key, Text value, int numPartitions) {
		int i = (key.accountId + key.tmsId).hashCode() % numPartitions;
		return Math.abs(i);
	}
	
	public static void main(String[] args) {
		System.out.println(String.valueOf(System.currentTimeMillis()).hashCode() % 3);
	}
}
