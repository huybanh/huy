package com.directv.recommendations.analytics.stiching;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.directv.recommendations.genericfilter.GenericFilter;

/**
 * HFile generating driver
 */
public class StichingDriver extends Configured implements Tool {
	
	static final String CLOUDREC_VIEWINGDURATION_THRESHOLD = "cloudrec.viewingduration.threshold";

	static final String CLOUDREC_SESSION_EXTENSION_MINUTES = "cloudrec.session.extension.minutes";
	
	public static void main(String[] args) throws Exception {
        int res = ToolRunner.run(new Configuration(), new StichingDriver(), args);
        System.exit(res);
    }

	/**
	 * @param args
	 *            args[0]: lookup table name 
	 *            args[1]: lookup key
	 *            args[2]: input folder
	 *            args[3]: outputRoot folder
	 *            
	 * @throws IOException 
	 * @throws InterruptedException 
	 * @throws ClassNotFoundException 
	 * @throws Exception
	 */
	@Override
	public int run(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		String inputPath = null;
		String outputPath = null;
		Integer sessionExtensionMinutes = null;
		Integer viewingDurationThreshold = null;
		String filterRules = null;
		
		//optional generic filter
		int i = -1;
		while (true) {
			i++;
			if (i >= args.length) {
				break;
			}
			if ("-IN".equals(args[i])) {
				i++;
				inputPath = args[i];
			} else if ("-OUT".equals(args[i])) {
				i++;
				outputPath = args[i];
			} else if ("-MINUTES".equals(args[i])) {
				i++;
				sessionExtensionMinutes = Integer.parseInt(args[i]);
			} else if ("-PERCENT".equals(args[i])) {
				i++;
				viewingDurationThreshold = Integer.parseInt(args[i]);
			} /*else if ("-libjars".equals(args[i])) {
				i++;
			} */else if ("-FILTER".equals(args[i])) {
				i++;
				filterRules = args[i];
			} else {
				throw new RuntimeException("Unknown param: " + args[4]);
			}
		}

		Configuration hdfsConf = this.getConf();
		hdfsConf.set(CLOUDREC_SESSION_EXTENSION_MINUTES, String.valueOf(sessionExtensionMinutes));
		hdfsConf.set(CLOUDREC_VIEWINGDURATION_THRESHOLD, String.valueOf(viewingDurationThreshold));
		
		//hadoop credential token
		String hadoopToken = System.getenv("HADOOP_TOKEN_FILE_LOCATION");
		if (hadoopToken != null) {
			hdfsConf.set("mapreduce.job.credentials.binary", hadoopToken);
		}
		
		if (filterRules != null) {
			GenericFilter.configure(StichingMapper.class.getName(), filterRules, hdfsConf);
		}
		
		String jobName;
		if (filterRules == null) {
			jobName = "Event stitching (no filter rules specified)";
		} else {
			jobName = "Event stitching & Filtering by " + filterRules;
		}
		Job job = new Job(hdfsConf, jobName);
		job.setJarByClass(StichingMapper.class);
		job.setMapperClass(StichingMapper.class);
		job.setMapOutputKeyClass(StichingKey.class);
		job.setMapOutputValueClass(Text.class);
		job.setInputFormatClass(TextInputFormat.class);
		
		job.setReducerClass(StichingReducer.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		//partitioner
		job.setPartitionerClass(StichingPartitioner.class);
		
		FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		job.waitForCompletion(true);
		return 0;
	}
}

