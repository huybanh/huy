package com.directv.recommendations.analytics.stiching;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

class StichingReducer extends Reducer<StichingKey, Text, NullWritable, Text> {
	
	//private LinkedList<StichingKey> previousKeys = new LinkedList<StichingKey>();
	
	private String currentUvh = null;
	
	private int totalViewedDuration;
	
	private int totalGroupCount;
	
	private String currentAccountId;
	
	private String currentTmsId;
	
	private long currentScheduleStart;
	
	private long currentScheduleEnd;
	
	private long currentEventTime;
	
	private int currentRunLength;
	
	private final NullWritable outKey = NullWritable.get();
	private final Text outValue = new Text();
	
	private int sessionExtensionMinutes;
	private int viewingDurationThreshold;

	@Override
	protected void setup(Context context) throws IOException,InterruptedException {
		
		String s = context.getConfiguration().get(StichingDriver.CLOUDREC_SESSION_EXTENSION_MINUTES);
		sessionExtensionMinutes = Integer.parseInt(s);
		s = context.getConfiguration().get(StichingDriver.CLOUDREC_VIEWINGDURATION_THRESHOLD);
		viewingDurationThreshold = Integer.parseInt(s);
		currentUvh = null;
		//previousKeys.clear();
		totalViewedDuration = 0;
		totalGroupCount = 0;
		super.setup(context);
	}

	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException {
		
		/*if (!previousKeys.isEmpty()) {
			emit(context);
		}*/
		if (currentUvh != null) {
			emit(context);
		}
		super.cleanup(context);
	}

	/* 
	 * Keys are ordered by: accountId, tmsId, scheduleStartTime, eventTime
	 */
	@Override
	protected void reduce(StichingKey key, Iterable<Text> values, Context context) 
	throws IOException, InterruptedException {
		
		if ("LiveViewEvent".equals(key.eventType)) {
			reduceLiveView(key, values, context);
			context.getCounter(StichingCounter.LIVE_VIEW_TOTAL).increment(1);
			
		} else if ("PlayBackEvent".equals(key.eventType)) {
			if (key.viewedDuration >= key.runLength * this.viewingDurationThreshold / 100) {
				passthrough(values, context);
			} else {
				context.getCounter(StichingCounter.PLAYBACK_FILTERED).increment(1);
			}
			context.getCounter(StichingCounter.PLAYBACK_TOTAL).increment(1);
			
		} else {
			passthrough(values, context);
			context.getCounter(StichingCounter.OTHER_EVENTS).increment(1);
		}
	}
	
	private void reduceLiveView(StichingKey key, Iterable<Text> values, Context context) 
	throws IOException, InterruptedException {
		
		if (/*previousKeys.isEmpty()*/ currentUvh == null) {
			//very first key, just keep in
			addKey(key, values);
			return;
		} else if (currentEventTime < currentScheduleStart || 
					currentEventTime > currentScheduleEnd + sessionExtensionMinutes * 60000) {
			
			//current key is invalid: eventTime (before start) -> emit
			emit(context);
			addKey(key, values);
			return;
		}
		
		if (!currentAccountId.equals(key.accountId) || !currentTmsId.equals(key.tmsId) ||
				currentScheduleStart != key.scheduleStartTime ||
				currentScheduleEnd + sessionExtensionMinutes * 60000 < key.eventTime) {
			
			//moving to another tmsid or another accountid, or an event out of session -> emit
			emit(context);
			addKey(key, values);
			return;
		}
		
		addKey(key, values);
	}
	
	private void passthrough(Iterable<Text> values, Context context) 
	throws IOException, InterruptedException {
		
		Iterator<Text> it = values.iterator();
		while (it.hasNext()) {
			Text one = it.next();
			outValue.set(one.toString());
			context.write(outKey, outValue);
		}
	}
	
	private void addKey(StichingKey key, Iterable<Text> values) {
		
		Iterator<Text> it = values.iterator();
		while (it.hasNext()) {
			
			Text oneLine = it.next();
			if (currentUvh == null) {
				currentUvh = oneLine.toString();
				currentAccountId = key.accountId;
				currentTmsId = key.tmsId;
				currentScheduleStart = key.scheduleStartTime;
				currentScheduleEnd = key.scheduleEndTime;
				currentEventTime = key.eventTime;
				currentRunLength = key.runLength;
			}
			
			StichingKey k = new StichingKey();
			k.copy(key);
			//previousKeys.add(k);
			totalViewedDuration = totalViewedDuration + key.viewedDuration;
			totalGroupCount++;
		}
	}
	
	private void emit(Context context) throws IOException, InterruptedException {
		
		if (currentUvh == null) {
			return;
		}
		
		if (totalViewedDuration < currentRunLength * this.viewingDurationThreshold / 100) {
			//filter out these short event
			context.getCounter(StichingCounter.LIVE_VIEW_FILTERED).increment(1);
			
			//clean current values
			currentUvh = null;
			totalViewedDuration = 0;
			totalGroupCount = 0;
			return;
		}
		
		if (totalGroupCount == 1) {
			context.getCounter(StichingCounter.LIVE_VIEW_SINGLES).increment(1);
		} else {
			context.getCounter(StichingCounter.LIVE_VIEW_GROUPS).increment(1);
			context.getCounter(StichingCounter.LIVE_VIEW_GROUPED_ENTRIES).increment(totalGroupCount);
		}
		
		if (totalGroupCount == 1) {
			outValue.set(currentUvh);
			
		} else {
			StichingKey combinedUvh = new StichingKey();
			//combinedUvh.eventTime = earliestStart;
			combinedUvh.eventTime = currentEventTime;
			//combinedUvh.viewedDuration = totalDuration;
			combinedUvh.viewedDuration = totalViewedDuration;
			combinedUvh.accountId = currentAccountId;
			combinedUvh.scheduleStartTime= currentScheduleStart;
			combinedUvh.scheduleEndTime = currentScheduleEnd;
			combinedUvh.tmsId = currentTmsId;
			outValue.set(combinedUvh.putViewedDuration(currentUvh));
		}
		context.write(outKey, outValue);
		
		//clean current values
		currentUvh = null;
		totalViewedDuration = 0;
		totalGroupCount = 0;
	}

}
