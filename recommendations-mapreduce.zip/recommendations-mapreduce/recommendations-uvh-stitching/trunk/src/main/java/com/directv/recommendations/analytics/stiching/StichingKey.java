package com.directv.recommendations.analytics.stiching;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.io.WritableComparable;

class StichingKey implements WritableComparable<StichingKey> {
	
	/*
	 * Components of key
	 * */
	String accountId; //partition factor
	
	String tmsId; //partition factor
	
	long eventTime;
	
	long scheduleStartTime;
	
	/*
	 * None components of key
	 * */
	long scheduleEndTime;
	
	int viewedDuration; //in minute
	
	String eventType;
	
	int runLength;
	
	private SimpleDateFormat dateFormatUvh = new SimpleDateFormat("yyyyMMddHHmmss");

	/* Keys are ordered by: accountId, tmsId, scheduleStartTime, eventTime 
	 */
	@Override
	public int compareTo(StichingKey o) {
		int c = this.accountId.compareTo(o.accountId);
		if (c != 0) {
			return c;
		}
		c = this.tmsId.compareTo(o.tmsId);
		if (c != 0) {
			return c;
		}
		
		//don't want to get arithmetic overflow error
		//c = (int) (this.scheduleStartTime - o.scheduleStartTime);
		
		c = compare(this.scheduleStartTime, o.scheduleStartTime);
		if (c != 0) {
			return c;
		}
		return compare(this.eventTime, o.eventTime);
	}
	
	private static int compare(long l1, long l2) {
		if (l1 > l2) {
			return 1;
		} else if (l1 < l2) {
			return -1;
		} else {
			return 0;
		}
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(accountId);
		out.writeUTF(tmsId);
		out.writeLong(eventTime);
		out.writeLong(scheduleStartTime);
		
		out.writeLong(scheduleEndTime);
		out.writeInt(viewedDuration);
		out.writeUTF(eventType);
		out.writeInt(runLength);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		accountId = in.readUTF();
		tmsId = in.readUTF();
		eventTime = in.readLong();
		scheduleStartTime = in.readLong();
		
		scheduleEndTime = in.readLong();
		viewedDuration = in.readInt();
		eventType = in.readUTF();
		runLength = in.readInt();
	}
	
	void copy(StichingKey another) {
		this.accountId = another.accountId;
		this.eventTime = another.eventTime;
		this.scheduleEndTime = another.scheduleEndTime;
		this.scheduleStartTime = another.scheduleStartTime;
		this.tmsId = another.tmsId;
		this.viewedDuration = another.viewedDuration;
		this.eventType = another.eventType;
		this.runLength = another.runLength;
	}

	/**
	 * CREATE EXTERNAL TABLE rawData
(
  	rowkey string, 
1	accountId string, 
2	tmsId string,
3	eventTime string,
	source string, 
5	eventType string,
	sourceType string,
	startTime string,
	endTime string,
	channelId string, 
10	cardId string, 
11	durationViewed int, 
	profileId string, 
	deviceId string,
	deviceType string, 
15	channelNumber string, 
16	startTimeSchedule string, 
17	endTimeSchedule string, 
	statusCdn string, 
	interpretedEventType string, 
20	weight string, 
	addition string, 
	dayOfWeek string, 
	timeOfDay string, 
	mainCategory string,
25	genre1 string,
	genre2 string, 
	genre3 string, 
	title string,
	programId string,
30	rating string,
	releaseYear string, 
	originalAirDate string,
33	runLength int,
	delivery string,
	actor1 string,
	actor2 string,
	actor3 string,
	actor4 string,
	actor5 string,
	directory1 string, 
	directory2 string,
	directory3 string,
	duration string,
	zipcode string,
	fipCoutryCode string,
	dma string,
	utcOffset string, 
	utcInt string,
	dmaDescription string,
	channelType string, 
	channelObjectId string,
	marketId string,
	tone1 string,
	tone2 string,
	tone3 string,
	mood1 string,
	mood2 string,
	mood3 string,
	theme1 string,
	theme2 string,
	theme3 string,
	rottenTomato string, 
	critic1 string,
	critic2 string,
	critic3 string, 
	audienceScore string
)
	 * 
	 */
	void parse(String[] fields) {
		//accountId: 1
		//tmsId: 2
		//eventTime: 3
		//scheduleStartTime:16
		//scheduleEndTime: 17
		//viewedDuration: 11
		
		//key is usually reused, so reset first to avoid stale values
		//from previous records (in case this record is invalid)
		accountId = "";
		tmsId = "";
		eventTime = 0;
		scheduleStartTime = 0;
		scheduleEndTime = 0;
		viewedDuration = 0;
		eventType = null;
		runLength = 0;
		
		/*if (uvh == null) {
			return;
		}*/
		
		//performance consideration: replace split() by index handling?
		if (fields.length <= 1) {
			return;
		}
		accountId = fields[1]; //1
		
		if (fields.length <= 2) {
			return;
		}
		tmsId = fields[2]; //2
		
		if (fields.length <= 3) {
			return;
		}
		eventTime = parseDate(fields[3], dateFormatUvh); //3
		
		if (fields.length <= 5) {
			return;
		}
		eventType = fields[5]; //5
		
		if (fields.length <= 11) {
			return;
		}
		viewedDuration = parseInt(fields[11]); //11
		
		if (fields.length <= 16) {
			return;
		}
		scheduleStartTime = parseDate(fields[16], dateFormatUvh); //16
		
		if (fields.length <= 17) {
			return;
		}
		scheduleEndTime = parseDate(fields[17], dateFormatUvh); //17
		
		if (fields.length <= 33) {
			return;
		}
		runLength = parseInt(fields[33]); //33
		
	}
	
	private static long parseDate(String value, SimpleDateFormat dateFormat) {
		try {
			Date d = dateFormat.parse(value);
			return d.getTime();
		} catch (ParseException e) {
			return 0;
		}
	}
	
	private static int parseInt(String value) {
		if ("".equals(value.trim())) {
			return 0;
		}
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException pe) {
			return 0;
		}
	}
	
	/*private static long parseLong(String value) {
		if ("".equals(value.trim())) {
			return 0;
		}
		try {
			return Long.parseLong(value);
		} catch (NumberFormatException pe) {
			return 0;
		}
	}*/
	
	String putViewedDuration(String baseUvh) {
		return putField(baseUvh, 11, String.valueOf(viewedDuration));
	}

	private String putField(String baseUvh, int fieldPosition, String value) {
		
		int fromIndex = 0;
		for (int i = 0; i < fieldPosition; i++) {
			fromIndex = baseUvh.indexOf(';', fromIndex);
			if (fromIndex < 0) {
				//too short uvh, can't put?
				// To do: should expand the record
				return baseUvh;
			}
			fromIndex++;
		}
		
		int toIndex = baseUvh.indexOf(';', fromIndex);
		if (toIndex < 0) {
			return baseUvh.substring(0, fromIndex) + value;
		} else {
			return baseUvh.substring(0, fromIndex) + value + baseUvh.substring(toIndex);
		}
	}
	
	private static void testPutField() {
		StichingKey k = new StichingKey();
		String uvh = "aaa;bb;;;;cccc";
		k.parse(uvh.split(";"));
		sure(k.putField(uvh, 0, "xxx"), "xxx;bb;;;;cccc");
		sure(k.putField(uvh, 1, "xxx"), "aaa;xxx;;;;cccc");
		sure(k.putField(uvh, 2, "xxx"), "aaa;bb;xxx;;;cccc");
		sure(k.putField(uvh, 3, "xxx"), "aaa;bb;;xxx;;cccc");
		sure(k.putField(uvh, 4, "xxx"), "aaa;bb;;;xxx;cccc");
		sure(k.putField(uvh, 5, "xxx"), "aaa;bb;;;;xxx");
		//sure(k.putField(uvh, 6, "xxx"), "aaa;bb;;;;;xxx");
	}
	
	public static void main(String[] args) {
		
		StichingKey k = new StichingKey();
		String uvh = "";
		k.parse(uvh.split(";"));
		sure(k.accountId, "");
		
		uvh = "1;2;3";
		k.parse(uvh.split(";"));
		sure(k.accountId, "2");
		
		uvh = "21479728-20140824222432-EP008159770362;21479728;EP008159770362;20140824222432;1;" +
				"LiveViewEvent;;20140824222432;20140824223000;8232;2216343430;6;;;;;20140824220000;" +
				"20140824223000;;Watch;1;0;Sunday;Late Evening;TV;Educational;Series;Science/Nature;" +
				"How Do They Do It?;EP008159770362_751870;TVG;;20140710000000;30;Linear;;;;;;;;;" +
				"30;80132;;752;;SUB;0;0;;;;;;;;;;;;;;;;;2014082421480946-20140824030130-EP019709270003;" +
				"21480946;EP019709270003;20140824030130;1;RecordingEvent;Recording;20140824020000;" +
				"20140824030000;8238;2743726933;60;;;;;20140824020000;20140824030000;;Record;0.8;0;" +
				"Sunday;Late Night;TV;Series;Reality;Documentary;Redwood Kings: Cut Masters;EP019709270003_752182;" +
				"TVPG;;20140823000000;\\N;Linear;;;;;;;;;60;27344;;560;;SUB;0;0;;;;;;;;;;;;;;;;;20140824;";
		
		k.parse(uvh.split(";"));
		//accountId: 1
		//tmsId: 2
		//eventTime: 3
		//viewedDuration: 11
		//scheduleStartTime:16
		//scheduleEndTime: 17
		sure(k.accountId, "21479728");
		sure(k.tmsId, "EP008159770362");
		sure(k.eventTime, 20140824222432l);
		sure(k.viewedDuration, 6);
		sure(k.scheduleStartTime, 20140824220000l);
		sure(k.scheduleEndTime, 20140824223000l);
		
		testPutField();
	}
	
	private static void sure(String value, String expected) {
		if (!value.equals(expected)) {
			throw new RuntimeException(value);
		}
		System.out.println("OK: " + value);
	}
	
	private static void sure(long value, long expected) {
		if (value != expected) {
			throw new RuntimeException(String.valueOf(value));
		}
		System.out.println("OK: " + value);
	}
}

