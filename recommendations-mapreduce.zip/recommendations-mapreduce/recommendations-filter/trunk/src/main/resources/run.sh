hadoop jar recommendations-filter-0.0.1-SNAPSHOT.jar com.directv.recommendations.analytics.filter.Driver -conf <configuration file> <mapper class> <input path> <output path>
