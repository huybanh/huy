/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.filter;

import org.apache.hadoop.mapreduce.Mapper;

public class FilterUtil {

	public static int indexOf(String input, char start, int endIndex) {
		char[] buffer = input.toCharArray();
		int i = 0;
		for (i = endIndex - 1; i >= 0; i--) {
			if (buffer[i] == start) {
				break;
			}
		}
		return i;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Class getMapperClazz(String clazzName) throws ClassNotFoundException {
		Class<? extends Mapper<?, ?, ?, ?>> mapperClazz = null;
		if (clazzName != null) {
			mapperClazz = (Class<? extends Mapper<?, ?, ?, ?>>) Class.forName("com.directv.recommendations.analytics.mapred." + clazzName);

		} else {
			throw new NullPointerException();
		}

		return mapperClazz;
	}
}
