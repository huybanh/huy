/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;

public class LAFilter {
	public static final String EXCLUDING_GENRE_KEY = "genre";
	public static final String EXCLUDING_TMS_GENRE_KEY = "tmsgenre";
	public static final String EXCLUDING_TMSID_KEY = "tmsid";
	public static final String EXCLUDING_TITLE_KEY = "title";

	public static final String GENRE1_FILTER_RULE = "\"genre1\":\"%s\"";
	public static final String GENRE2_FILTER_RULE = "\"genre2\":\"%s\"";
	public static final String GENRE3_FILTER_RULE = "\"genre3\":\"%s\"";

	public static final String TMS_GENRE1_FILTER_RULE = "\"tmsGenre1\":\"%s\"";
	public static final String TMS_GENRE2_FILTER_RULE = "\"tmsGenre2\":\"%s\"";
	public static final String TMS_GENRE3_FILTER_RULE = "\"tmsGenre3\":\"%s\"";

	public static final String TMSID_FILTER_RULE = "\"tmsId\":\"%s\"";
	public static final String TITLE_FILTER_RULE = "\"programTitle\":\"%s\"";

	private final List<LARule> rules;
	private LARule genreRule;
	private LARule tmsidRule;
	private LARule titleRule;
	private LARule tmsGenreRule;

	private static final LAFilter INSTANCE = new LAFilter();

	private LAFilter() {
		rules = new ArrayList<LARule>();
		//filterDict = new HashMap<String, String[]>();
	}

	public static LAFilter getInstance() {
		return INSTANCE;
	}

	public void loadConfiguration(Configuration conf) {
		if (conf != null) {

			genreRule = new LARule(EXCLUDING_GENRE_KEY);
			genreRule.setRuleDicts(conf.getStrings(EXCLUDING_GENRE_KEY));
			genreRule.setRulePatterns(new String[]{GENRE1_FILTER_RULE, GENRE2_FILTER_RULE, GENRE3_FILTER_RULE});

			tmsidRule = new LARule(EXCLUDING_TMSID_KEY);
			tmsidRule.setRuleDicts(conf.getStrings(EXCLUDING_TMSID_KEY));
			tmsidRule.setRulePatterns(new String[]{TMSID_FILTER_RULE});

			titleRule = new LARule(EXCLUDING_TITLE_KEY);
			titleRule.setRuleDicts(conf.getStrings(EXCLUDING_TITLE_KEY));
			titleRule.setRulePatterns(new String[]{TITLE_FILTER_RULE});

			tmsGenreRule = new LARule(EXCLUDING_TMS_GENRE_KEY);
			tmsGenreRule.setRuleDicts(conf.getStrings(EXCLUDING_TMS_GENRE_KEY));
			tmsGenreRule.setRulePatterns(new String[]{TMS_GENRE1_FILTER_RULE, TMS_GENRE2_FILTER_RULE, TMS_GENRE3_FILTER_RULE});

			rules.add(genreRule);
			rules.add(tmsidRule);
			rules.add(titleRule);
			rules.add(tmsGenreRule);
		}
	}

	public boolean existGroupGenre(String[] fields) {
		String columnName = fields[1];
		int sepIndex = fields[1].lastIndexOf(".");

		String groupGenre = columnName.substring(sepIndex + 1);
		return genreRule.find(groupGenre);
	}

	public String filterAll(String[] fields) throws IOException {

		List<String> filteredValues = new ArrayList<String>();

		String[] values = fields[2].replaceAll("^\\[\\{|\\}\\]$", "").split("\\},\\{");

		boolean filter = false;
		for (String value : values) {

			for(LARule rule : rules) {
				if(rule.validate(value)) {
					filter = true;
					break;
				}
			}
			if(filter) {
				continue;
			}

			filteredValues.add(value);
		}

		if (filteredValues.size() > 0) {
			return "[{" + StringUtils.join(filteredValues, "},{") + "}]";
		} else {
			return "[]";
		}
	}
}
