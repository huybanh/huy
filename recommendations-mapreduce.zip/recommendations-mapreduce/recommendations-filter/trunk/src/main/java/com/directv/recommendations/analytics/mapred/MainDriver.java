/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.mapred;

import java.io.IOException;
import java.io.PrintStream;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.directv.recommendations.analytics.filter.FilterUtil;

/**
 * CBCF filter driver.
 * @author TuTX1
 * 
 */
public class MainDriver extends Configured implements Tool {
	
	private void printUsageArgument(PrintStream out) {
		out.println("-conf <configuration file>     specify an application configuration file");
		out.println("<input directory>     specify an application input directory");
		out.println("<output directory>     specify an application output directory");
	}

	@SuppressWarnings("unchecked")
	private Job createJob(Configuration hdfsConf, String mapperClazz, String inputPath, String outputPath) throws IOException, IllegalStateException, ClassNotFoundException {
		if (System.getenv("HADOOP_TOKEN_FILE_LOCATION") != null) {
			hdfsConf.set("mapreduce.job.credentials.binary", System.getenv("HADOOP_TOKEN_FILE_LOCATION"));
		}

		System.out.println("input: " + inputPath);
		System.out.println("output: " + outputPath);

		Path outPath = new Path(outputPath);
		FileSystem fileSystem = FileSystem.newInstance(new Configuration(true));

		if (fileSystem.exists(outPath)) {
			System.out.println("Delete " + outputPath);
			fileSystem.delete(outPath, true);
		}

		Job job = new Job(hdfsConf, "Run job for " + mapperClazz);
		job.setJarByClass(MainDriver.class);
		job.setMapperClass(FilterUtil.getMapperClazz(mapperClazz));
		job.setMapOutputKeyClass(NullWritable.class);
		job.setMapOutputValueClass(Text.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setNumReduceTasks(0);

		FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(outputPath));

		return job;
	}

	/**
	 * Main class to create map reduce job.
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new MainDriver(), args);
		System.exit(res);
	}

	@Override
	public int run(String[] args) throws Exception {
		Configuration conf = getConf();

		if(args.length < 3) {
			printUsageArgument(System.out);
			return 0;
		}

		Job job = createJob(conf, args[0], args[1], args[2]);

		return  job.waitForCompletion(true) ? 0 : 1;
	}
}
