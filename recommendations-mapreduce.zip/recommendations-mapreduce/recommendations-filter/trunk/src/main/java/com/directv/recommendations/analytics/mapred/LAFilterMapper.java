/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.mapred;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.directv.recommendations.analytics.filter.LAFilter;

/**
 * 
 * @author TuTX1
 *
 */
class LAFilterMapper extends Mapper<LongWritable, Text, NullWritable, Text> {
	protected final NullWritable outKey = NullWritable.get();
	protected Text outValue = new Text();
	protected LAFilter genFilter;

	@Override
	protected void setup(Mapper<LongWritable, Text, NullWritable, Text>.Context context)
			throws IOException, InterruptedException {
		// genFilter = Filter.configureInternal(context.getConfiguration());
	}

	@Override
	protected void map(LongWritable key, Text value,Mapper<LongWritable, Text, NullWritable, Text>.Context context)
			throws IOException, InterruptedException {

		String inputLine = value.toString();
		String[] fields = inputLine.split(";");

		// validate input
		if (fields.length < 2 || genFilter == null) {
			context.getCounter(LACounter.NULL_INPUT_COUNT).increment(1);
			return;
		}

		if (genFilter.existGroupGenre(fields)) {
			context.getCounter(LACounter.GENRE_FILTERED_COUNT).increment(1);
			return;
		}

		String outputLine = genFilter.filterAll(fields);

		// validate output
		if (outputLine == null) {
			context.getCounter(LACounter.NULL_OUTPUT_COUNT).increment(1);
			return;
		}

		// System.out.println(outputLine);

		outValue.set(outputLine);

		context.write(outKey, outValue);
	}
}
