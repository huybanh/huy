package com.directv.recommendations.analytics.filter;

public class LARule {

	private String ruleName;
	private String[] rulePatterns;
	private String[] ruleDicts;
	
	public LARule(String ruleName) {
		this.ruleName = ruleName;
	}
	
	public boolean find(String key) {
		
		if(ruleDicts == null || ruleDicts.length == 0) {
			return false;
		}
		
		for (int i = 0; i < ruleDicts.length; i++) {
			String genre = ruleDicts[i];
			if (key.equalsIgnoreCase(genre)) {
				return true;
			}
		}
		return false;
	}
	
	public boolean validate(String value) {
		if (ruleDicts == null || ruleDicts.length == 0 || rulePatterns == null || rulePatterns.length == 0) {
			return true;
		}

		for (String ex : ruleDicts) {
			for(String filteredPattern : rulePatterns) {
				String pattern = String.format(filteredPattern, ex);

				if (value.indexOf(pattern) > 0) {
					return true;
				}
			}
		}

		return false;
	}
	
	public String getRuleName() {
		return ruleName;
	}
	
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	
	public String[] getRulePatterns() {
		return rulePatterns;
	}
	
	public void setRulePatterns(String[] rulePatterns) {
		this.rulePatterns = rulePatterns;
	}
	
	public String[] getRuleDicts() {
		return ruleDicts;
	}
	
	public void setRuleDicts(String[] ruleDicts) {
		this.ruleDicts = ruleDicts;
	} 

}
