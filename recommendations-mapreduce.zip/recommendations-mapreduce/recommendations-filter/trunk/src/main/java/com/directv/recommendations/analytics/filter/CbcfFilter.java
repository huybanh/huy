/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;

import com.directv.recommendations.analytics.dto.KeyValue;

/**
 * Filter class that create filter rule to remove value.
 * 
 * @author TuTX1
 *
 */
public class CbcfFilter {
	private final Map<String, String[]> filterDict;

	private static final String EXCLUDING_GENRE_KEY = "genre";
	private static final String EXCLUDING_ACTOR_KEY = "actor";
	private static final String EXCLUDING_DIRECTOR_KEY = "director";
	private static final String EXCLUDING_THEME_KEY = "theme";
	private static final String EXCLUDING_TONE_KEY = "tone";
	private static final String EXCLUDING_MOOD_KEY = "tood";
	private static final String EXCLUDING_TMS_GENRE = "tmsgenre";

	private static final String FILTER_RULE = "{\"key\":\"%s\"";
	
	private static final CbcfFilter INSTANCE = new CbcfFilter();

	private CbcfFilter() {
		filterDict = new HashMap<String, String[]>();
	}

	public static CbcfFilter getInstance() {
		return INSTANCE;
	}

	public void loadConfiguration(Configuration conf) {
		if (conf != null) {
			filterDict.put(EXCLUDING_GENRE_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_GENRE_KEY));
			filterDict.put(EXCLUDING_ACTOR_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_ACTOR_KEY));
			filterDict.put(EXCLUDING_DIRECTOR_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_DIRECTOR_KEY));
			filterDict.put(EXCLUDING_THEME_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_THEME_KEY));
			filterDict.put(EXCLUDING_TONE_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_TONE_KEY));
			filterDict.put(EXCLUDING_MOOD_KEY.toLowerCase(),
					conf.getStrings(EXCLUDING_MOOD_KEY));
			filterDict.put(EXCLUDING_TMS_GENRE.toLowerCase(),
					conf.getStrings(EXCLUDING_TMS_GENRE));
		}
	}

	private boolean find(String key, String[] excludes) {
		for (int i = 0; i < excludes.length; i++) {
			String genre = excludes[i];
			if (key.equalsIgnoreCase(genre)) {
				return true;
			}
		}
		return false;
	}

	// Low performance solution (serialized and de-serialized json is not
	// necessary)
	@Deprecated
	protected List<KeyValue> filter(KeyValue[] values, String[] excludes) {
		if (excludes == null || excludes.length == 0) {
			return Arrays.asList(values);
		}

		List<KeyValue> filteredValues = new ArrayList<KeyValue>();
		for (KeyValue v : values) {
			String key = v.getKey();

			if (find(key, excludes)) {
				continue;
			}

			filteredValues.add(v);
		}
		return filteredValues;
	}

	// High performance (just process with String)
	private String filter(String inputLine, String[] excludes) {
		if (excludes == null || excludes.length == 0) {
			return inputLine;
		}

		int firstIndex, lastIndex = 0;
		String filteredVaule = inputLine;

		for (String ex : excludes) {
			String pattern = String.format(FILTER_RULE, ex);

			int index = inputLine.indexOf(pattern);

			if (index < 0) {
				continue;
			}

			firstIndex = FilterUtil.indexOf(inputLine, '{', index);
			lastIndex = index + pattern.length();

			// for first element
			if (lastIndex == inputLine.length() - 1) {
				firstIndex = firstIndex - 1;
			} else {
				lastIndex = lastIndex + 1;
			}

			String replacement = inputLine.substring(firstIndex, lastIndex);
			filteredVaule = filteredVaule.replace(replacement, "");

		}

		return filteredVaule;
	}

	/**
	 * Filter function.
	 * @param inputLine
	 * @param fields
	 * @return
	 * @throws IOException
	 */
	public String filterAll(String inputLine, String[] fields)	throws IOException {
		String columnName = fields[1];
		int sepIndex = fields[1].indexOf(".");

		String attribute = columnName.substring(sepIndex + 1, columnName.indexOf(".", sepIndex + 1));
		String[] excludes = filterDict.get(attribute.toLowerCase());

		String filteredValue = filter(inputLine, excludes);

		return filteredValue;
	}
}
