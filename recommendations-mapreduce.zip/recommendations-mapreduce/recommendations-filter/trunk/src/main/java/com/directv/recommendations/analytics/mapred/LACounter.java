package com.directv.recommendations.analytics.mapred;

public enum LACounter {
	NULL_INPUT_COUNT, NULL_OUTPUT_COUNT, GENRE_FILTERED_COUNT;
}
