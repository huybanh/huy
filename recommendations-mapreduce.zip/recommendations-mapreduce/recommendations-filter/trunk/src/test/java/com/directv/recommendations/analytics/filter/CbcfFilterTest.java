package com.directv.recommendations.analytics.filter;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.junit.Before;
import org.junit.Test;

//@Ignore
public class CbcfFilterTest {
	private CbcfFilter filter;
	private Configuration conf;

	@Before
	public void init() throws IOException {
		
		conf = new Configuration();
		conf.addResource(ClassLoader.getSystemResource("cbcf/config.xml"));
		filter = CbcfFilter.getInstance();
		filter.loadConfiguration(conf);
		
	}

	@Test
	public void testFilterAll() throws IOException {
		String input = "0;Month.Director.Movies.Monday;[{\"value\":1.3333333333333333,\"key\":\"Bernie Denk\"},{\"value\":1.189189189189189,\"key\":\"Tyler Perry\"},{\"value\":1.141304347826087,\"key\":\"Max Mayer\"},{\"value\":1.1170212765957446,\"key\":\"Steve Anderson\"},{\"value\":1.0975609756097562,\"key\":\"Blair Treu\"},{\"value\":1.0869565217391304,\"key\":\"Pete Docter\"},{\"value\":0.9545454545454546,\"key\":\"Rob L. Cohen\"},{\"value\":0.6421052631578947,\"key\":\"Mabrouk El Mechri\"},{\"value\":0.45901639344262296,\"key\":\"Peter Berg\"},{\"value\":0.2,\"key\":\"Ted Kotcheff\"},{\"value\":0.11403508771929824,\"key\":\"Dennis Iliadis\"},{\"value\":0.08823529411764706,\"key\":\"Chia-Liang Liu\"},{\"value\":0.044444444444444446,\"key\":\"Vic Sarin\"},{\"value\":0.031578947368421054,\"key\":\"Joel Zwick\"},{\"value\":0.023529411764705882,\"key\":\"Chano Urueta\"},{\"value\":0.011111111111111112,\"key\":\"Craig Pryce\"},{\"value\":0.011111111111111112,\"key\":\"José A. Medina\"},{\"value\":0.010416666666666666,\"key\":\"Chris Butler\"},{\"value\":0.010416666666666666,\"key\":\"Sam Fell\"},{\"value\":0.009433962264150943,\"key\":\"M. Night Shyamalan\"},{\"value\":0.009433962264150943,\"key\":\"Thor Freudenthal\"},{\"value\":0.008333333333333333,\"key\":\"Seth Gordon\"},{\"value\":0.008130081300813009,\"key\":\"Ron Howard\"},{\"value\":0.008,\"key\":\"Paul Feig\"}]";

		// performance testing
		int inter = 100000;
		long start = System.currentTimeMillis();
		for (int i = 0; i < inter; i++) {
			filter.filterAll(input, input.split(";"));
		}
		long end = System.currentTimeMillis();

		System.out.println("time response: " + (end - start));

	}

	@Test
	public void testSubstring() {
		String input = "A.B.B.C";

		int index = input.indexOf(".");

		System.out.println(input.indexOf(".", index + 1));

		System.out.println(index);
	}

	@Test
	public void filter() throws JsonParseException, JsonMappingException,
			IOException {
		String input = "0;Month.Genre.Movies.Monday;[{\"value\":0.0,\"key\":\"Movies\"},{\"value\":0.0,\"key\":\"Sports\"},{\"value\":6.467101303736134,\"key\":\"TV\"},{\"value\":3.4386363636363635,\"key\":\"Animation\"},{\"value\":3.371969696969697,\"key\":\"Kids\"},{\"value\":2.046969696969697,\"key\":\"News\"},{\"value\":1.6341954022988507,\"key\":\"Reality\"},{\"value\":1.325,\"key\":\"Educational\"},{\"value\":0.7758620689655173,\"key\":\"Documentary\"},{\"value\":0.1567204301075269,\"key\":\"Talk\"},{\"value\":0.11505376344086021,\"key\":\"Comedy\"},{\"value\":0.06666666666666667,\"key\":\"Cooking\"},{\"value\":0.03888888888888889,\"key\":\"Drama\"},{\"value\":0.03773584905660377,\"key\":\"Suspense\"},{\"value\":0.03773584905660377,\"key\":\"Mystery/Crime\"}]";

		String expected = "0;Month.Genre.Movies.Monday;[{\"value\":0.0,\"key\":\"Movies\"},{\"value\":0.0,\"key\":\"Sports\"},{\"value\":6.467101303736134,\"key\":\"TV\"},{\"value\":3.4386363636363635,\"key\":\"Animation\"},{\"value\":3.371969696969697,\"key\":\"Kids\"},{\"value\":2.046969696969697,\"key\":\"News\"},{\"value\":1.6341954022988507,\"key\":\"Reality\"},{\"value\":1.325,\"key\":\"Educational\"},{\"value\":0.7758620689655173,\"key\":\"Documentary\"},{\"value\":0.1567204301075269,\"key\":\"Talk\"},{\"value\":0.11505376344086021,\"key\":\"Comedy\"},{\"value\":0.06666666666666667,\"key\":\"Cooking\"},{\"value\":0.03888888888888889,\"key\":\"Drama\"},{\"value\":0.03773584905660377,\"key\":\"Suspense\"},{\"value\":0.03773584905660377,\"key\":\"Mystery/Crime\"}]";
		String actual = filter.filterAll(input, input.split(";"));
		System.out.println(actual);
		assertEquals(expected, actual);
	}
}
