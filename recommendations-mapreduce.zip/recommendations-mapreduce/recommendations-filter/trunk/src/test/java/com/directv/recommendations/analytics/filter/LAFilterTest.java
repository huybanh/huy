/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.recommendations.analytics.filter;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.junit.Before;
import org.junit.Test;

//@Ignore
public class LAFilterTest {
	private LAFilter filter;
	private Configuration conf;

	@Before
	public void init() throws IOException {
		conf = new Configuration();
		conf.addResource(ClassLoader.getSystemResource("la/config.xml"));
		filter = LAFilter.getInstance();
		filter.loadConfiguration(conf);
	}

	//@Test
	public void testFilterAll() throws IOException {
		String input = "0;Sports.Watch.Auto;[{\"source\":\"1\",\"eventType\":\"LiveViewEvent\",\"accountId\":\"0\",\"durationViewed\":60,\"runLength\":60,\"lastModifiedDate\":null,\"mainCategory\":\"Sports\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Auto\",\"genre2\":\"\",\"genre3\":\"\",\"tmsId\":\"EP019637920005\",\"eventTime\":\"20141026020000\",\"programTitle\":\"Bitchin' Rides\"},{\"source\":\"1\",\"eventType\":\"LiveViewEvent\",\"accountId\":\"0\",\"durationViewed\":55,\"runLength\":60,\"lastModifiedDate\":null,\"mainCategory\":\"Sports\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Auto\",\"genre2\":\"\",\"genre3\":\"\",\"tmsId\":\"EP019637920006\",\"eventTime\":\"20141026010544\",\"programTitle\":\"Bitchin' Rides\"},{\"source\":\"1\",\"eventType\":\"LiveViewEvent\",\"accountId\":\"0\",\"durationViewed\":60,\"runLength\":60,\"lastModifiedDate\":null,\"mainCategory\":\"Sports\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Auto\",\"genre2\":\"\",\"genre3\":\"\",\"tmsId\":\"SH013792220000\",\"eventTime\":\"20141005235932\",\"programTitle\":\"Choques Extremos\"}]";

		// performance testing
		int inter = 100000;
		long start = System.currentTimeMillis();
		for (int i = 0; i < inter; i++) {
			filter.filterAll(input.split(";"));
		}
		long end = System.currentTimeMillis();

		System.out.println("time response: " + (end - start));

	}

	@Test
	public void filter() throws JsonParseException, JsonMappingException,
			IOException {
		String input = "0;Sports.Watch.Auto;[{\"source\":\"1\",\"eventType\":\"LiveViewEvent\",\"accountId\":\"0\",\"durationViewed\":60,\"runLength\":60,\"lastModifiedDate\":null,\"mainCategory\":\"Sports\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Auto\",\"genre2\":\"\",\"genre3\":\"\",\"tmsId\":\"EP019637920005\",\"eventTime\":\"20141026020000\",\"programTitle\":\"Bitchin' Rides\"},{\"source\":\"1\",\"eventType\":\"LiveViewEvent\",\"accountId\":\"0\",\"durationViewed\":55,\"runLength\":60,\"lastModifiedDate\":null,\"mainCategory\":\"Sports\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Auto\",\"genre2\":\"\",\"genre3\":\"\",\"tmsId\":\"EP019637920006\",\"eventTime\":\"20141026010544\",\"programTitle\":\"Bitchin' Rides\"},{\"source\":\"1\",\"eventType\":\"LiveViewEvent\",\"accountId\":\"0\",\"durationViewed\":60,\"runLength\":60,\"lastModifiedDate\":null,\"mainCategory\":\"Sports\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Auto\",\"genre2\":\"\",\"genre3\":\"\",\"tmsId\":\"SH013792220000\",\"eventTime\":\"20141005235932\",\"programTitle\":\"Choques Extremos\"}]";

		String expected = "[]";
		String actual = filter.filterAll(input.split(";"));

		assertEquals(expected, actual);
	}

}
