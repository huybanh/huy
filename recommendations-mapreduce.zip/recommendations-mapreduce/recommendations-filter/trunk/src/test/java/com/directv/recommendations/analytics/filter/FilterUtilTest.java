package com.directv.recommendations.analytics.filter;

import org.junit.Test;
import static org.junit.Assert.*;

public class FilterUtilTest {
	
	@Test
	public void testGetMapperClazz() throws ClassNotFoundException {
		Class mapper = FilterUtil.getMapperClazz("CbcfFilterMapper");
		String expected = "com.directv.recommendations.analytics.mapred.CbcfFilterMapper";
		String actual = mapper.getCanonicalName();
		assertEquals(expected, actual);
		
		mapper = FilterUtil.getMapperClazz("LAFilterMapper");
		expected = "com.directv.recommendations.analytics.mapred.LAFilterMapper";
		actual = mapper.getCanonicalName();
		assertEquals(expected, actual);
	}
}
