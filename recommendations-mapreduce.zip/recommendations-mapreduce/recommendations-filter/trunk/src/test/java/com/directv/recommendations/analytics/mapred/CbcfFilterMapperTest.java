package com.directv.recommendations.analytics.mapred;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.mock;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InOrder;

import com.directv.recommendations.analytics.filter.CbcfFilter;

/**
 * 
 * @author TuTX1
 * 
 */
@Ignore
public class CbcfFilterMapperTest {
	private CbcfFilterMapper mapper;
	private Mapper<LongWritable, Text, NullWritable, Text>.Context context;
	private NullWritable key;
	private Configuration conf;

	@SuppressWarnings("unchecked")
	@Before
	public void init() throws IOException, InterruptedException {
		mapper = new CbcfFilterMapper();
		context = mock(Context.class);

		conf = new Configuration();
		conf.addResource(ClassLoader.getSystemResource("cbcf/config.xml"));
		mapper.genFilter = CbcfFilter.getInstance();
		mapper.genFilter.loadConfiguration(conf);

		mapper.outValue = mock(Text.class);
		key = NullWritable.get();
	}

	@Test
	public void testSingleLine() throws IOException, InterruptedException {
		mapper.map(
				new LongWritable(1L),
				new Text(
						"0;Month.Director.Movies.Monday;[{\"value\":1.3333333333333333,\"key\":\"Bernie Denk\"},{\"value\":1.189189189189189,\"key\":\"Tyler Perry\"},{\"value\":1.141304347826087,\"key\":\"Max Mayer\"},{\"value\":1.1170212765957446,\"key\":\"Steve Anderson\"},{\"value\":1.0975609756097562,\"key\":\"Blair Treu\"},{\"value\":1.0869565217391304,\"key\":\"Pete Docter\"},{\"value\":0.9545454545454546,\"key\":\"Rob L. Cohen\"},{\"value\":0.6421052631578947,\"key\":\"Mabrouk El Mechri\"},{\"value\":0.45901639344262296,\"key\":\"Peter Berg\"},{\"value\":0.2,\"key\":\"Ted Kotcheff\"},{\"value\":0.11403508771929824,\"key\":\"Dennis Iliadis\"},{\"value\":0.08823529411764706,\"key\":\"Chia-Liang Liu\"},{\"value\":0.044444444444444446,\"key\":\"Vic Sarin\"},{\"value\":0.031578947368421054,\"key\":\"Joel Zwick\"},{\"value\":0.023529411764705882,\"key\":\"Chano Urueta\"},{\"value\":0.011111111111111112,\"key\":\"Craig Pryce\"},{\"value\":0.011111111111111112,\"key\":\"José A. Medina\"},{\"value\":0.010416666666666666,\"key\":\"Chris Butler\"},{\"value\":0.010416666666666666,\"key\":\"Sam Fell\"},{\"value\":0.009433962264150943,\"key\":\"M. Night Shyamalan\"},{\"value\":0.009433962264150943,\"key\":\"Thor Freudenthal\"},{\"value\":0.008333333333333333,\"key\":\"Seth Gordon\"},{\"value\":0.008130081300813009,\"key\":\"Ron Howard\"},{\"value\":0.008,\"key\":\"Paul Feig\"}]"),
				context);
		InOrder inOrder = inOrder(mapper.outValue, context);
		assertCountedOnce(
				inOrder,
				"0;Month.Director.Movies.Monday;[{\"value\":1.3333333333333333,\"key\":\"Bernie Denk\"},{\"value\":1.189189189189189,\"key\":\"Tyler Perry\"},{\"value\":1.141304347826087,\"key\":\"Max Mayer\"},{\"value\":1.1170212765957446,\"key\":\"Steve Anderson\"},{\"value\":1.0975609756097562,\"key\":\"Blair Treu\"},{\"value\":1.0869565217391304,\"key\":\"Pete Docter\"},{\"value\":0.9545454545454546,\"key\":\"Rob L. Cohen\"},{\"value\":0.6421052631578947,\"key\":\"Mabrouk El Mechri\"},{\"value\":0.45901639344262296,\"key\":\"Peter Berg\"},{\"value\":0.2,\"key\":\"Ted Kotcheff\"},{\"value\":0.11403508771929824,\"key\":\"Dennis Iliadis\"},{\"value\":0.08823529411764706,\"key\":\"Chia-Liang Liu\"},{\"value\":0.044444444444444446,\"key\":\"Vic Sarin\"},{\"value\":0.031578947368421054,\"key\":\"Joel Zwick\"},{\"value\":0.023529411764705882,\"key\":\"Chano Urueta\"},{\"value\":0.011111111111111112,\"key\":\"Craig Pryce\"},{\"value\":0.011111111111111112,\"key\":\"José A. Medina\"},{\"value\":0.010416666666666666,\"key\":\"Chris Butler\"},{\"value\":0.010416666666666666,\"key\":\"Sam Fell\"},{\"value\":0.009433962264150943,\"key\":\"M. Night Shyamalan\"},{\"value\":0.009433962264150943,\"key\":\"Thor Freudenthal\"},{\"value\":0.008333333333333333,\"key\":\"Seth Gordon\"},{\"value\":0.008130081300813009,\"key\":\"Ron Howard\"},{\"value\":0.008,\"key\":\"Paul Feig\"}]");

		mapper.map(
				new LongWritable(2L),
				new Text(
						"0;Last6Months.Tone.Movies.Monday;[{\"value\":1.3333333333333333,\"key\":\"Gentle\"},{\"value\":1.3333333333333333,\"key\":\"Sweet\"},{\"value\":1.3333333333333333,\"key\":\"Bright\"}]"),
				context);
		inOrder = inOrder(mapper.outValue, context);
		assertCountedOnce(
				inOrder,
				"0;Last6Months.Tone.Movies.Monday;[{\"value\":1.3333333333333333,\"key\":\"Gentle\"},{\"value\":1.3333333333333333,\"key\":\"Sweet\"},{\"value\":1.3333333333333333,\"key\":\"Bright\"}]");
	}

	private void assertCountedOnce(InOrder inOrder, String w) throws IOException, InterruptedException {
		inOrder.verify(mapper.outValue).set(eq(w));
		inOrder.verify(context).write(eq(key), eq(mapper.outValue));
	}
}