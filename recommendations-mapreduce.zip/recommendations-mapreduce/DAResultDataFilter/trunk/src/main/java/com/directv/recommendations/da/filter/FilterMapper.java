package com.directv.recommendations.da.filter;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

class FilterMapper extends Mapper<Text, Text, Text, Text> {
	
	@Override
	protected void setup(Mapper<Text, Text, Text, Text>.Context context) throws IOException, InterruptedException {
		
	}

	@Override
	protected void map(Text key, Text value, Context context) throws IOException, InterruptedException {
		context.write(key, value);
	}
	
}
