#!/usr/bin/python
################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

from common_properties import *
from datetime import datetime
import subprocess
import imp
import os
import time
import sys
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *


currentLocation = os.getcwd();
#import properties
properties = imp.load_source('load properties file', currentLocation + '/what-is-hot/daily/ConvertWIH_properties.py')
cmproperties = imp.load_source('load properties file', currentLocation + '/common_properties.py')
lookupTable_key = properties.lookupTable_key
lookupTable = properties.lookupTable
lookupTable_columnFamily = properties.lookupTable_columnFamily
lookupTable_columnName = properties.lookupTable_columnName
bulkload_lookupTable = properties.bulkload_lookupTable
bulkload_familyName = properties.bulkload_familyName
bulkload_lookupKey = properties.bulkload_lookupKey

utils = imp.load_source('utils',currentLocation + cmproperties.common_util);

config = HBaseConfiguration.create()
rjhTable = HTable(config, cmproperties.validation_table)

print bulkload_lookupTable

#initialize bulkload util

key_batch = str(sys.argv[1])

try:
	
	
	bulkloadUtil = imp.load_source('dataAnalytic', currentLocation + '/bulkload/bulkload_util.py');	

	batch_number = str(sys.argv[1])
	
	print "my patch number " + batch_number

	key_batch = batch_number

	print "my key batch" + key_batch

	bulkloadUtil.bulkload(lookupTable_key, lookupTable, lookupTable_columnFamily, lookupTable_columnName, bulkload_jarName, bulkload_lookupTable, bulkload_familyName, bulkload_lookupKey , bulkload_staging, bulkload_error, batch_number, hadoop_lib)
except:
	print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + cmproperties.validation_table + ' KEY ' + key_batch
	utils.updateFailedJobs(rjhTable, cmproperties.validation_columnFamily, key_batch, properties.validation_dataType, "except", str(sys.exc_info()[1]))
	sys.exit(2)

