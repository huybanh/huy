
#
 # DIRECTV PROPRIETARY
 # Copyright© 2014 DIRECTV, INC.
 # UNPUBLISHED WORK
 # ALL RIGHTS RESERVED
 #
 # This software is the confidential and proprietary information of
 # DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,
 # distribution or disclosure of the software or Proprietary Information,
 # in whole or in part, must comply with the terms of the license
 # agreement, nondisclosure agreement or contract entered into with
 # DIRECTV providing access to this software.
 #
#============================================================================== initialization =================================================================================h

# run the app by command "Rscript runApp.R [path_to_csv_file]
workingDirectory <- getwd()
locationToWIHFile = paste(workingDirectory, "what-is-hot/firsttime/WhatIsHot_dby.R", sep = "/")
print(locationToWIHFile)
source(locationToWIHFile)
args <- commandArgs(trailingOnly = TRUE)

for (i in 1:length(args)){
	if ((args[i]) == "wih") {
		if (length(args) <2 ) {
			print("computing wih requires 2 arguments: runApp.R wih [dataurl] [firstwindowtime] [firsttime] [firstrunaday] [minusdatafromdate]")
			return(NA)
		}
		filePath <- args[i+1]
		firstwindowtime <- args[i+2]
		firsttime <- args[i+3]
		firstrunaday <- args[i+4]
		minusdatafromdate <- args[i+5]
		first <- TRUE
		if (firsttime == 0) 
			first = FALSE
		firstrun = TRUE
		if (firstrunaday  == 0)
			minus <- TRUE
		#print('ComputeMainWIH(dataUrl = ' + filePath + ', firstWindowTime = ' + firstwindowtime + ', firstTimes = ' + first + ', firstRunADay = ' + firstrun + ',minusDataFromDate = ' + minusdatafromdate + ')')
		ComputeMainWIH(dataUrl = filePath, firstWindowTime = firstwindowtime, firstTimes = first, firstRunADay = firstrun, minusDataFromDate = minusdatafromdate)
		i <- i + 1
	}
}
