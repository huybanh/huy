#!/usr/bin/python

import subprocess
import imp
import os
import sys
from org.apache.pig.scripting import Pig
from org.apache.hadoop.fs import *
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from datetime import datetime

currentLocation = os.getcwd()
# Configuration 
config = HBaseConfiguration.create()
fileSystem = FileSystem.get(config)

#import properties
properties = imp.load_source('load properties file', currentLocation + '/what-is-hot/firsttime/production_whatishot_properties.py')
dataTypes = properties.dataTypes
pig_script_merge = properties.pig_script_merge
master_wih_day_by_day = properties.master_wih_day_by_day
master_new_wih = properties.master_new_wih
prefix_out = properties.prefix_out
lookupTable = properties.lookupTable
lookupTable_columnFamily = properties.lookupTable_columnFamily
lookupTable_columnName = properties.lookupTable_columnName
pig_script_merge = currentLocation + pig_script_merge

cmproperties = imp.load_source('load properties file', currentLocation + '/common_properties.py')
#initialize DI Integration
diIntegration = imp.load_source('dataAnalytic',currentLocation + cmproperties.common_lastbatch_python_script);
#validation parameters
utils = imp.load_source('utils', currentLocation + cmproperties.common_util);
rjhTable = HTable(config, cmproperties.validation_table)

# Main logical
def runMergeWIH():
	key_batch = ""
	try:
		params = {
		};
		#DI Integration
		print '*****************************GETTING BATCHNUMBER***********************************'
	 	diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName);
		print params
		key_batch = params['batchNumber_insertedTime']
		# Define variables
		currentFolder = ''
		# Open old location (wih day by day)
		oldPath = Path(master_wih_day_by_day)
		# Get list of folders
		listOldFolder = fileSystem.listStatus(oldPath)
		print listOldFolder
		listFolder = ''
		# Loop each sub folder in wih day by day master folder
		for line in listOldFolder:
			# Cast the line object to String
			rawLine = str(line.getPath())
			# Split the string input by "/"
			listSplit = rawLine.split("/");
			# Get sub folder name
			currentFolder = listSplit[len(listSplit) - 1]
			# Put current folder to the folder list
			listFolder = listFolder + ',' + currentFolder

		# Open new location (new wih)
		newPath = Path(master_new_wih)
		# Get list of folders
		listNewFolder = fileSystem.listStatus(newPath)
		# Loop each sub folder in new wih master folder
		for line in listNewFolder:
			# Cast the line object to String
			rawLine = str(line.getPath())
			# Split the string input by "/"
			listSplit = rawLine.split("/");
			# Get sub folder name
			currentFolder = listSplit[len(listSplit) - 1]
			# Search in listFolder to find if the current folder exist or not
			index = listFolder.find(currentFolder)
			
			# If sub folder in new wih doesn't exist in wih day by day
			if index == -1:# Not match

				#runPigNormalize(currentFolder);
				# Delete the sub folder in new wih
				#subprocess.call('hadoop fs -rm -r ' + master_new_wih + currentFolder, shell=True)
				workingFolder = master_new_wih + currentFolder
				# Move to destionation folder
				subprocess.call('hadoop fs -mv ' + workingFolder + ' ' + master_wih_day_by_day + currentFolder, shell=True)
				
			# If sub folder in new wih already exist in wih day by day
			if index != -1:# Match
				# Merge two sub folders by Pig
				runPigMerge(currentFolder);
				# Delete the sub folder in new wih
				subprocess.call('hadoop fs -rm -r ' + master_new_wih + currentFolder, shell=True)
				workingFolder = master_wih_day_by_day + currentFolder
				# Delete the sub folder in wih day by day
				subprocess.call('hadoop fs -rm -r ' + workingFolder, shell=True)
				# Rename the output of Pig to the destination folder 
				subprocess.call('hadoop fs -mv ' + workingFolder + prefix_out + ' ' + workingFolder, shell=True)
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + cmproperties.validation_table + ' KEY ' + key_batch
		utils.updateFailedJobs(rjhTable, cmproperties.validation_columnFamily, key_batch, properties.validation_dataType, "except", str(sys.exc_info()[1]))
		print str(sys.exc_info()[1])
		sys.exit(2)
			
# Normalized data from Revo R then store to what is hot day by day master
# Params: workFolder: is the name of sub folder inside master folders
# Output: A folder contained normalized data

# Merge two folders into one folder
# Params: workFolder: is the name of sub folder inside master folders
# Output: A folder which have all rows from two folders, 
# if two rows have same(dma, mainCategory, tmsId) then summarize those rows' scores
def runPigMerge(workFolder):
	key_batch = ""
	try:
		params = {
		};
		#DI Integration
		print '*****************************GETTING BATCHNUMBER***********************************'
	 	diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName);
		print params
		key_batch = params['batchNumber_insertedTime']
		
		pigScriptingExcutorMerge = Pig.compileFromFile(pig_script_merge);
		params = {
			'master_wih_day_by_day':master_wih_day_by_day,	
			'master_new_wih':master_new_wih,
			'work_folder':workFolder,
			'prefix_out':prefix_out
		}
			
		# bind params
		pigScriptingExcutorMerge.bind(params).runSingle();
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + cmproperties.validation_table + ' KEY ' + key_batch
		utils.updateFailedJobs(rjhTable, cmproperties.validation_columnFamily, key_batch, properties.validation_dataType, "except", str(sys.exc_info()[1]))
		sys.exit(2)

# Main function
def main():
	runMergeWIH();

if __name__ == '__main__':
	main();
#!/usr/bin/python

