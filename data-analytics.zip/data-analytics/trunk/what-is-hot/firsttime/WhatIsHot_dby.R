#DIRECTV PROPRIETARY
# Copyright� 2014 DIRECTV, INC
# UNPUBLISHED WORK
# ALL RIGHTS RESERVED
#
# This software is the confidential and proprietary information of
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,
# distribution or disclosure of the software or Proprietary Information,
# in whole or in part, must comply with the terms of the license
# agreement, nondisclosure agreement or contract entered into with
# DIRECTV providing access to this software.
#
#============================================================================== Computing What Is Hot Service ============================================================================

library(jsonlite)
workingDirectory <- getwd()
locationToWIHFile = paste(workingDirectory, "what-is-hot/firsttime/Config.R", sep = "/")
print(paste("Load file ", locationToWIHFile, sep = "/"))
source(locationToWIHFile)
locationToCommonProperties = paste(workingDirectory, "common_properties.py", sep = "/")
print(paste("Load file ", locationToCommonProperties, sep = "/"))
source(locationToCommonProperties)
common.config.rule = fromJSON(rule)
print(common.config.rule)

ComputeWIHOnSource <- function(dataUrl = "", bigDataDirRoot, hdfs, firstWindowTime, sub = FALSE) {
  # Computes WIH based on source location
  #
  # Args:
  #   dataUrl: link to location of data to compute
  #   bigDataDirRoot: location fo root HDFS data,
  #	in   hdfs: an of object which store location of HDFS imformation
  #   sub: If TRUE, we calculate sum of percentage with negative percentage value. If FALSE, we calculate sum of percentage with positive value. Default is FALSE.
  #
  # Returns:
  #   Data frame which store result of computing WIH on that location
  #   Format data frame "RegionId","MainCategory","ProgramTitle","Tmsid","Percentage"
  #Get object which points to location of input data
  
  #Initialize a object to point to result data frame
  result <- data.frame()
  
  input.dir <- file.path(bigDataDirRoot, dataUrl)	
  #Get object which points to location of stored temp XDF data which can be used to read chunk of all data
  output.dir <- file.path(bigDataDirRoot, tempLocation)
  print(paste0("input dir ", input.dir))
  print(paste0("output dir ", output.dir))
  rxHadoopListFiles(input.dir)
  
  view.data <- RxTextData(file = input.dir, delimiter = ";", stringsAsFactor = FALSE, fileSystem = hdfs, firstRowIsColNames = FALSE, colInfo = colInfo, rowsPerRead = maxRow)
  parse.data <- RxXdfData(output.dir, varsToKeep = list("tmsid", "durationviewed", "interpretedeventtype", "maincategory", "genre1", "genre2", "genre3", "tmsgenre1", "tmsgenre2", "tmsgenre3", "title", "runlength", "dma", "utcoffset", "programtype", "eventdate")  ,fileSystem = hdfs)
  
  #convert string date to a number
  firstWindowTime <- paste(firstWindowTime,"000000", sep='')
  print(firstWindowTime)
  firstWindowTime <- as.double(firstWindowTime)
  
  tryCatch({
    #Store data as XDF file
    message("Start read input data and store into xdf format")
    print("convert data")
    rxDataStep(inData = view.data, rowSelection = eventtime >= firstWindowTime, transformObjects = list(firstWindowTime = firstWindowTime), outFile = parse.data, overwrite = TRUE)
    print("finish convert data")
    #Open connection to read a chunk fo data
    rxOpen(parse.data)
  },
  error=function(cond) {
    message(cond)
    return (result)
  },
  warning=function(cond) {
    message(cond)
  },
  finally={
    message("Finish pre-process input data")
  })
  
  #A flag make sure whether data of a chunk is empty or not 
  isEmptyData <- FALSE
  #Read each chunk of data which is set maximum row is maxRow
  iBlock <- 1
  while (!isEmptyData) {
    #Group By data by regionid, maincategory, title, tmsid then calculate
    numrow <- 0
    all.data.fetch <- data.frame()
    while (numrow < maxProcessRow & isEmptyData == FALSE) {
      block.data <- rxReadNext(parse.data)
      numrow <- numrow + length(block.data$maincategory)
      print(numrow)
      if(length(block.data$maincategory) != 0)
        all.data.fetch <- rbind(all.data.fetch, block.data)
      else
        isEmptyData = TRUE
    }
    if(length(all.data.fetch)  != 0) {
      print(paste("Block ", iBlock))
      print(numrow)
      block.data <- all.data.fetch
      ###########################################################Exclude all event with filters################################################################
      #Filter data with excluded maincategory
      block.data <- block.data[which(!(block.data$maincategory %in% excludeMain)), ]
      #Filter data with exclude region
      block.data <- block.data[which(!(block.data$dma %in% excludeRegion)), ]
      #Filter data with excluded genre 
      block.data <- block.data[which(!(block.data$genre1 %in% common.config.rule$excludingGenres | block.data$genre2 %in% common.config.rule$excludingGenres | block.data$genre3 %in% common.config.rule$excludingGenres)), ]
      #Filter data with exclude tmsGenre
      block.data <- block.data[which(!(block.data$tmsgenre1 %in% common.config.rule$excludingtmsGenres | block.data$tmsgenre2 %in% common.config.rule$excludingtmsGenres | block.data$tmsgenre3 %in% common.config.rule$excludingtmsGenres)), ]
      #Filter date with program type
      block.data <- block.data[which(!(block.data$programtype %in% common.config.rule$ignoredProgtypes)), ]
      #Filter date with title 
      block.data <- block.data[which(!(block.data$title %in% common.config.rule$ignoredTitle)), ]
      ##########################################################Finish exclude all event with filters###############################################################
     
      ##########################################################Apply weight to WIH for each eventype mapping######################################################
      #Create a new mapping column
      #Create get mapping value for watch, like, purchase and record
      match.for.watch <- block.data$interpretedeventtype == "Watch"
      match.for.like  <- block.data$interpretedeventtype == "Like"
      match.for.record <- block.data$interpretedeventtype == "Record"
      match.for.purchase <- block.data$interpretedeventtype == "Purchase"
      block.data$weight <- otherWeight
      block.data$addition <- otherAddition
      block.data$weight[match.for.watch] <- watchWeight
      block.data$weight[match.for.like] <- likeWeight
      block.data$weight[match.for.record] <- recordWeight
      block.data$weight[match.for.purchase] <- purchaseWeight
      block.data$addition[match.for.watch] <- watchAddition
      block.data$addition[match.for.like] <- likeAddition
      block.data$addition[match.for.record] <- recordAddition
      block.data$addition[match.for.purchase] <- purchaseAddition
      ##########################################################Finish Apply ##########################################################################################
      
      #Aggregate data then sum by formula: (durationview/runlenght + addition) * weight moreover check null data 
      new.result <- aggregate(ifelse((tmp = (ifelse(is.na(block.data$runlength), 0, ifelse(is.na(block.data$durationviewed), 0, block.data$durationviewed) / ifelse(is.na(block.data$runlength), 1.0, block.data$runlength)) + block.data$addition)) > 1.0, 1.0, tmp) * block.data$weight , list(block.data$eventdate,block.data$dma, block.data$maincategory, block.data$tmsid), sum, na.rm = TRUE)
      #Merge all computing result for each block
      result <- rbind(result,new.result)
    }
    #Fetch next block of data
    iBlock <- iBlock + 1
  }
  print("Read All Data")
  print("Generate WIH Day By Day")
  colnames(result) <- c("EventDate", "Dma", "MainCategory", "Tmsid", "Percentage") 
  #print(result)
  result <- aggregate(result$Percentage,list(result$EventDate, result$Dma, result$MainCategory, result$Tmsid), sum)
  colnames(result) <- c("EventDate", "Dma", "MainCategory", "Tmsid", "Percentage")
  
  #store what is hot day by day
  list.eventdate <- unique(result$EventDate)
  print(list.eventdate)
  for(ev in list.eventdate) {
    wih.by.day <- subset(result, EventDate == ev)
    #Remove column event date then store to HDFS
    wih.by.day$EventDate <- NULL
    #Store what is hot day by day to hdfs
    location.folder <- paste(tempLocationDBD, ev, sep = "/")
    #rxHadoopRemove(location.folder)
    RemoveDir(location.folder)
    #rxHadoopMakeDir(location.folder)
    MakeDir(location.folder)
    CopyFileToHDFS(wih.by.day, hdOutputUrl = location.folder, file.name = "tmpwih.csv", delimiter = ",")
  }
  
  #generate result for compute what is hot on source
  result <- aggregate(result$Percentage,list(result$Dma, result$MainCategory, result$Tmsid), sum)
  colnames(result) <- c("Dma","MainCategory","Tmsid","Percentage")
  #Return a data frame of result value
  return (result)
}

MakeDir <- function(location) {
  command <- paste0("hadoop fs -mkdir ", location)
  system(command)
}

RemoveDir <- function(location) {
  command <- paste0("hadoop fs -rm -r ", location)
  system(command)
}


ComputeMainWIH <- function(dataUrl ="/user/d458737/Namhnt/WIH/TestCase1", firstWindowTime = "20140902", firstRunADay = TRUE,  minusDataFromDate  = "20140901",   firstTimes = FALSE) {
  #Compute What Is Hot for new coming data then store to HDFS data. That data will be used for UDS and Zoom Data
  #
  # Args:
  #   dataUrl: Location of new coming data.
  #   firstWindowTime : Location of last day of window time data. For example, if window time is one week, the last day of window is the first day.
  #   firstTime: If TRUE, it is the first times to compute WIH. If FALSE, it is the remaining times you computing WIH. Default is FALSE.
  #   remaining times need to be merged with old result
  # Returns:
  #   
  #Initialize the cluster and set the compute context to Hadoop
  print(minusDataFromDate)
  my.name.node <- hadoop.host
  my.port <- hadoop.port
  big.data.dir.root <- "/"
  
  #Determine the file System which has been used  
  hdfs <- RxHdfsFileSystem(hostName = my.name.node, port = my.port)

  RemoveDir(paste("/user/RevoShare", Sys.info()[["user"]], sep="/"))
  MakeDir(paste("/user/RevoShare", Sys.info()[["user"]], sep="/"))
  hdfs.share <- paste("/user/RevoShare", Sys.info()[["user"]], sep="/")
  shareDir <- paste("/tmp/RevoShare", Sys.info()[["user"]], sep="/") 
  print(shareDir)  
  input.dir <- file.path(big.data.dir.root, dataUrl)
  my.hadoop.cluster <- RxHadoopMR(nameNode = my.name.node, hdfsShareDir = hdfs.share, shareDir = shareDir,showOutputWhileWaiting = TRUE, 
                                  autoCleanup = TRUE, 
                                  port = my.port, 
                                  wait = TRUE,
                                  consoleOutput = TRUE,
                                  fileSystem = hdfs,
                                  resultsTimeout = 10000)
  
  rxSetComputeContext(my.hadoop.cluster)
  
  #Check compute context from Hadoop
  print(rxGetComputeContext())
  
  #Compute New WIH
  result <- ComputeWIHOnSource(dataUrl, big.data.dir.root, hdfs, firstWindowTime)
  
  if(length(result) == 0) {
    return (0)
  }
  
  #If firstTimes is TRUE, it is the first times to compute WIH. If FALSE, it is the remaining times you computing WIH. Default is FALSE.
  #Merging data with old computing and first window date to get the final computing
  if(!firstTimes)
  {
    print("---------------------------------------------------------------------Run on daily -------------------------------------------------------------------------")
    #Compute first day of Window Time WIH with sub equal TRUE because we want to minus these values on computing
    #load What Is Hot with firstWindowTime - 1 day
    if(firstRunADay)
    {
      listDate <- unlist(strsplit(minusDataFromDate, "[.]"))
      print(listDate)
      for (minus.date in listDate)
      {
        print(minus.date)
        minus.result = ReadWhatIsHotResult(paste(locationDBD, minus.date, sep = "/"), big.data.dir.root, hdfs)
        minus.result$Percentage = -minus.result$Percentage
        #Add with previous result
        result <- rbind(result, minus.result)
      }
    }
    #Read the previous WIH computing then merge each other.
    old.result <- ReadWhatIsHotResult(dataUrl = zoomOutUrl, big.data.dir.root, hdfs)
    #print(old.result)
    result <- rbind(result, old.result)
    print("Begin to Merge all data then store to HDFS")
    #print(result)
    #Agggregate then sum all, percentage in last is a negative value and in old is positive value
    result <- aggregate(as.double(result$Percentage), list(result$Dma, result$MainCategory, result$Tmsid), sum)
    colnames(result) <- c("Dma", "MainCategory", "Tmsid", "Percentage")
  }
  
  #Order result based on group by item In Des for Percentage
  order.of.result <- result[order(result$Dma, result$MainCategory, -result$Percentage), ]
  #Filter all excluded Tmsid in order_of_result for zoom data and change_form_of_result for UDS service
  #Write Zoomdata source to HDFS
  CopyFileToHDFS(data.input = order.of.result, hdOutputUrl = zoomOutUrlTemp, file.name = "zoomdata.csv", delimiter = ",")
  
  return (1)
}

ReadWhatIsHotResult <- function(dataUrl = "", big.data.dir.root = "//", hdfs) {
  
  #Read what is hot result which has been compute before
  #
  # Args:
  #   dataUrl : Location of what is hot result which store in HDFS
  #   big.data.dir.root : Location to root of big data
  #   hdfs : hdfs object which show the type of data will be read
  # Returns:
  #   data frame which store result of old what is hot
  
  input.dir <- file.path(big.data.dir.root, dataUrl)
  print(paste(input.dir, '_SUCCESS', sep = "/")) 
  RemoveDir(paste(input.dir, "_SUCCESS", sep = "/"))
  view.data <- RxTextData(file = input.dir, delimiter = ",", stringsAsFactor = FALSE, fileSystem = hdfs, firstRowIsColNames = FALSE, colInfo = storeInfo, rowsPerRead = maxRow)
  #Open connection to read chunk of data
  rxOpen(view.data)
  is.empty.data <- FALSE
  #Read old result to Data Frame
  block.data <-  rxReadNext(view.data)
  old.result <- data.frame()
  while(is.empty.data != TRUE) {
    old.result <- rbind(block.data, old.result)
    block.data <-rxReadNext(view.data)
    if(length(block.data$Tmsid) == 0) {
      is.empty.data = TRUE
    }
  }
  #name of column of data frame
  colnames(old.result) <- c("Dma","MainCategory","Tmsid", "Percentage") 
  return (old.result)
}

#save data.frame directly to hdfs
#       data.input: data frame tobe saved on hadoop
#       hdOutputUrl: link to folder on hadoop where new file locates. for example: "/user/tmp.aepoc1/result"
#       file.name: name of file will saved on hadoop. for example:"abc.csv"
#       hdfs: defines hadoop file system
data.frame.to.hdfs <- function(data.input, hdOutputUrl, file.name, hdfs, sep = ";")
{
  rxSetFileSystem(hdfs)
  big.data.dir.root <- "/"
  #must set compute context to local!!!!
  rxSetComputeContext("local")
  # describe the file on hadoop that our data.frame will saved to
  output.file<-file.path(big.data.dir.root,paste(hdOutputUrl,file.name,sep="/"))
  print(output.file)
  # describe data source links to file above
  out.source<-RxTextData(file = output.file, delimiter = sep, firstRowIsColNames = FALSE ,fileSystem=hdfs)
  # saving
  rxDataStep(data.input,outFile=out.source)
}

#save data.frame directly to hdfs
#       data.input: data frame tobe saved on hadoop
#       hdOutputUrl: link to folder on hadoop where new file locates. for example: "/user/tmp.aepoc1/result"
#       file.name: name of file will saved on hadoop. for example:"abc.csv"
#       hdfs: defines hadoop file system

CopyFileToHDFS <- function(data.input, hdOutputUrl, file.name = "temp.csv", delimiter = ";")
{
  rxHadoopRemove(paste(hdOutputUrl, file.name, sep = "/"))
  write.table(data.input, paste("/tmp", file.name, sep = "/"), sep = delimiter, quote = FALSE, col.names = FALSE, row.names = FALSE)
  rxHadoopCopyFromLocal(paste("/tmp", file.name, sep = "/"), hdOutputUrl)
  file.remove(paste("/tmp", file.name, sep = "/"))
}

