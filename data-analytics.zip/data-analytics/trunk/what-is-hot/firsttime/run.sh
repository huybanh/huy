unset HADOOP_TOKEN_FILE_LOCATION
kinit -kt $1 $2
.  /etc/profile.d/Revolution/bash_profile_additions
workingDir=$(pwd)
hostname=$(whoami)
#Config for Ozzie which can run on RevolutionR
echo "parameter 1: $1"
echo "parameter 2: $2"
echo "parameter 3: $3"
echo "Working dir: $workingDir"
echo "Hostname: $hostname"
echo "Prepare to ComputeWIH"
mkdir /tmp/RevoShare
chmod 777 -R /tmp/RevoShare
mkdir /tmp/RevoShare/$hostname
rm /tmp/RevoShare/$hostname/RevoR.log
pig $workingDir/what-is-hot/firsttime/MainWhatIsHot.py
result=$?
hadoop fs -rm /data/dv/recommendation/analytics/wih/Result/RevoR.log
hadoop fs -put /tmp/RevoShare/$hostname/RevoR.log  /data/dv/recommendation/analytics/wih/Result

if [ $result -eq 0 ] 
then
  echo "Prepare to Merge What Is Hot Day By Day"
  pig $workingDir/what-is-hot/daily/MergeWIH.py
  result=$?
  echo "Prepare to Generate to Json Object for UDS and bulk load to Hbase"
  if [ $result -eq 0 ]
  then
    pig $workingDir/what-is-hot/daily/ConvertWIH.py $3
  else 
    echo "Compute WIh Unsuccessful"
  fi
else
  echo "Compute WIh Unsuccessful"
fi

