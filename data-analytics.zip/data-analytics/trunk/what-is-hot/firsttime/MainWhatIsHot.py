#!/usr/bin/python

from org.apache.pig.scripting import Pig
import sys
import os
import time
import subprocess
import traceback
import imp
import datetime
import os.path as osp
import getpass
from sys import stderr
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count
from datetime import datetime, timedelta

currentLocation = os.getcwd()
#get properties from properties file
properties = imp.load_source('load properties file', currentLocation + '/what-is-hot/firsttime/production_whatishot_properties.py')
cmproperties = imp.load_source('load properties file', currentLocation + '/common_properties.py')
dataurl = properties.dataUrl
windowtime = properties.windowtime
firsttime = properties.firsttime
dataTypes = properties.dataTypes
common_lastbatch_python_script = cmproperties.common_lastbatch_python_script
common_util_script = cmproperties.common_util
lookupTable = properties.lookupTable
lookupTable_columnFamily = properties.lookupTable_columnFamily
lookupTable_columnName = properties.lookupTable_columnName
revor_script = properties.revor_script
location_WIHDBD = properties.master_wih_day_by_day
#locations to script
revor_script = currentLocation + revor_script
firsttime = properties.firsttime
#initialize DI Integration
diIntegration = imp.load_source('dataAnalytic', currentLocation + '/'  + common_lastbatch_python_script);
utils = imp.load_source('utils', currentLocation + '/'  + common_util_script);
config = HBaseConfiguration.create()
rjhTable = HTable(config, cmproperties.validation_table)

def setEnvironmentVariable():
	#get environment variables
	finalPath = []
	#get original class path
	fullHadoopClasspath = subprocess.Popen("hadoop classpath", stdout=subprocess.PIPE, shell=True).stdout.read()
	originalPath = fullHadoopClasspath
	fullHadoopClasspath += ":/usr/lib/hbase/lib/"
	#dedup : in the classpath.
	oldString = fullHadoopClasspath
	# Replace :: by :: in full Hadoop Class Path
	while True:
        	fullHadoopClasspath = oldString.replace( "::", ":" )
        	if oldString == fullHadoopClasspath:
                	break
        	oldString = fullHadoopClasspath
	# fix up malformed Pivotal HD classpath
	fullHadoopClasspath = fullHadoopClasspath.replace( "/.//*", "/*" )
	individualPaths = fullHadoopClasspath.split(":")
	# get more path from os, other library
	for indPath in individualPaths:
        	curPath = os.path.abspath( indPath.rstrip().lstrip() )
        	cleanIndPath = curPath.rstrip( "*" )
        	if cleanIndPath[-1] != "/":
                	cleanIndPath = cleanIndPath + "/"
        	cmd = "ls " + curPath + " | grep -v \":\" | sed '/^$/d' | grep -i 'jar$\|xml$'"
        	curListing =  subprocess.Popen( cmd, stdout=subprocess.PIPE, shell=True).stdout.read().split("\n")
     	   	if len( curListing ) == 1 and curListing[0] == curPath:
           		finalPath.append( curListing )
        	else:
             		for curJar in curListing:
				if 'hbase' in curJar:
					continue
                    		if ( curJar.__len__() > 0 ):
                                	if ( curJar[0] == "/" ):
			         		print( "case 1: ", curJar )
                                        	finalPath.append( curJar )
                                	#else:
                                        #	print( "case 2: ", cleanIndPath + curJar )
                                        #	finalPath.append( cleanIndPath + curJar )
	#append data from original to other enviroment variables
	finalPath.append( originalPath )
	#set class path
	os.environ['CLASSPATH']= ":".join( finalPath )

def exists(hdfs_url):
    """
    check if the url exist
    """
    return check(hdfs_url, test='e')

def check(hdfs_url, test='e'):
    """
    Test the url.
        
    parameters
    ----------
    hdfs_url: string
        The hdfs url
    test: string, optional
        'e': existence
        'd': is a directory
        'z': zero length

        Default is an existence test, 'e'
    """
    command="""hadoop fs -test -%s %s""" % (test, hdfs_url)

    exit_code, stdo, stde = exec_command(command)

    if exit_code != 0:
        return False
    else:
        return True

def exec_command(command):
    """
    Execute the command and return the exit status.
    """
    import subprocess
    from subprocess import PIPE
    pobj = subprocess.Popen(command, stdout=PIPE, stderr=PIPE, shell=True)
    stdo, stde = pobj.communicate()
    exit_code = pobj.returncode
    return exit_code, stdo, stde

"""
  Description:
  Parameter:
  Return Value:
"""
def runRevoR():
	key_batch = ""
	try:
		global params	
		params = {}	
	    	#DI Integration
		print '*****************************GETTING BATCHNUMBER***********************************'
	 	diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName)
		print currentLocation
		print params
		if params['batchNumber_insertedTime'] == params['batchNumber_lastWihRun']:
			sys.exit(2)
		print params['batchNumber_insertedTime']
		print params['batchNumber_lastWihRun']
		print "Woring With WIH"
		lastBatchNumberString = params['batchNumber_insertedTime'][0:8]	
		lastBatchNumber = datetime.strptime(lastBatchNumberString, '%Y%m%d')
		print lastBatchNumber
		key_batch = params['batchNumber_insertedTime']	
		firstday = lastBatchNumber - timedelta(days=windowtime)
		lastWihRun = ''
	        minusDataFromDate = ''
	        minusDataFromDateString = ''
		#Get number of date we need to remove data from WIH
	        if params['batchNumber_lastWihRun'] != '':
	               	lastWihRun = datetime.strptime(params['batchNumber_lastWihRun'][0:8], '%Y%m%d%')
	               	minusDistance = (lastBatchNumber - lastWihRun).days
			if minusDistance < 0:
				sys.exit(1)
	               	minusDataFromDate = firstday - timedelta(days = minusDistance)
	               	tmp = minusDataFromDate
	               	while tmp != firstday:
				if exists(location_WIHDBD + "/" + str(tmp.strftime("%Y%m%d"))):
	                       		minusDataFromDateString = minusDataFromDateString + str(tmp.strftime("%Y%m%d")) + "."
	                       	tmp = tmp +  timedelta(days = 1)
	       	currentWihRun = time.strftime("%Y%m%d")
		print minusDataFromDateString
		#Get location of new data  based on bath number
		data_url = dataurl + 'insertedtime=' + params['batchNumber_insertedTime']
		resultcode = 0
		#0 is false 1 is true
		firstRunADay = 1
		if lastWihRun == currentWihRun:
			firstRunADay = 0
		#Invoke What Is Hot by using os.system
		print "Revo64 CMD BATCH '--args wih " + data_url + ' ' + str(firstday.strftime("%Y%m%d")) + ' ' + str(firsttime) + ' ' + str(firstRunADay) + ' ' + minusDataFromDateString + ' ' + currentLocation + "' " + revor_script + " /tmp/RevoShare/" + getpass.getuser()  +  "/RevoR.log"
		resultcode = os.system("Revo64 CMD BATCH '--args wih " + data_url + ' ' + str(firstday.strftime("%Y%m%d")) + ' ' + str(firsttime) + ' ' + str(firstRunADay) + ' ' + minusDataFromDateString + ' ' + currentLocation +  "' " + revor_script + " /tmp/RevoShare/" + getpass.getuser()  +  "/RevoR.log")
		print "RESULT OF RUNNING COMMAND : " + str(resultcode)
		if resultcode != 0:
			sys.exit(resultcode)
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + cmproperties.validation_table + ' KEY ' + key_batch
		utils.updateFailedJobs(rjhTable, cmproperties.validation_columnFamily, key_batch, properties.validation_dataType, "except", str(sys.exc_info()[1]))
		sys.exit(2)
def main():
	#run RevoR script
	runRevoR();
	traceback.print_exc(file=sys.stdout)
if __name__ == '__main__':
	#Set class path
	setEnvironmentVariable()
	if "CLASSPATH" in os.environ:
        	print "Load CLOASSPATH"
	else:
        	print "Missing CLASSPATH"
	main()
