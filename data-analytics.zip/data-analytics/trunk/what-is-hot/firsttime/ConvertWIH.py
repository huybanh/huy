#!/usr/bin/python
################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
# Importing
from org.apache.pig.scripting import Pig
from datetime import datetime
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
import subprocess
import imp
import os
import time
import sys


print sys.argv
currentLocation = os.getcwd()
print currentLocation
#import properties
properties = imp.load_source('load properties file', currentLocation + '/what-is-hot/firsttime/production_whatishot_properties.py')
cmproperties = imp.load_source('load properties file', currentLocation + '/common_properties.py')
convert_wih = properties.convert_wih
merge_wih_program = properties.merge_wih_program
folder_master_wih = properties.folder_master_wih
input = properties.input
uds = properties.uds
normalize = properties.normalize
folder_master_program = properties.folder_master_program
folder_master_content_details = properties.folder_master_content_details
folder_master_before_convert = properties.folder_master_before_convert
time_length = properties.time_length
limit_jason = properties.limit_jason
all_category = properties.all_category
all_region = properties.all_region
dataTypes = properties.dataTypes
#Look up table
lookupTable = properties.lookupTable
lookupTable_columnName = properties.lookupTable_columnName
lookupTable_columnFamily = properties.lookupTable_columnFamily
#Update Table
updatedTable = properties.updatedTable
updatedTable_columnFamily = properties.updatedTable_columnFamily
updatedTable_columnName = properties.updatedTable_columnName
updatedTable_key = properties.updatedTable_key
bulkload_lookupTable = properties.bulkload_lookupTable
bulkload_familyName = properties.bulkload_familyName
bulkload_lookupKey = properties.bulkload_lookupKey
bulkload_jarName = cmproperties.bulkload_jarName
bulkload_staging = cmproperties.bulkload_staging
bulkload_archive =  cmproperties.bulkload_archive
hadoop_lib = cmproperties.hadoop_lib
udfLib = cmproperties.udfLib
location_result = properties.location_result
common_lastbatch_python_script = currentLocation + cmproperties.common_lastbatch_python_script
udfLib = currentLocation + '/' + udfLib	
#initialize DI Integration
diIntegration = imp.load_source('dataAnalytic', common_lastbatch_python_script);
pig_script = currentLocation + properties.pig_script_convert
#bulkload location
bulkloadShellScript = currentLocation + '/bulkload/run.sh'
bulkloadJarPath  = currentLocation + '/' + bulkload_jarName
#validation parameters
utils = imp.load_source('utils', currentLocation + cmproperties.common_util);
config = HBaseConfiguration.create()
rjhTable = HTable(config, cmproperties.validation_table)

def runPig():
	key_batch = ""
	try:
		
		pigScriptingExcutor = Pig.compileFromFile(pig_script);
		params = {
		'udfLib':udfLib,
		'convert_wih':convert_wih,
		'merge_wih_program':merge_wih_program,	
		'folder_master_wih':folder_master_wih,
		'folder_master_program':folder_master_program,
		'folder_master_before_convert':folder_master_before_convert,
		'folder_master_content_details':folder_master_content_details,
		'input':input,
		'uds':uds,
		'normalize':normalize,
		'time_length':time_length,
		'limit_jason':limit_jason,
		'all_category':all_category,
		'all_region':all_region,
		'location_result':location_result
		};
			
		#DI Integration
		print '*****************************GETTING BATCHNUMBER***********************************'
	 	diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName);
		print params
		key_batch = params['batchNumber_insertedTime']
		params['batchNumber_lastWihRun'] = 'CONSTANT VALUE'
		# bind params
		pigScriptingExcutor.bind(params).runSingle();
		
		# Init variable
		outputPig = folder_master_wih + params['batchNumber_current']
		outputUds = folder_master_wih + uds
		zoomTemp = folder_master_wih + input
		Zoom = folder_master_wih + normalize
		#Delete all files in Zoom
		subprocess.call('hadoop fs -rm -r ' + Zoom + '/* ', shell=True)
		
		# Move all files/folders in Zoom and Delete all folders/files from ZoomTemp
		subprocess.call('hadoop	fs -cp ' + zoomTemp + '/* ' + Zoom, shell=True)
		
		# Delete all folders/files in uds
		subprocess.call('hadoop fs -rm -r ' + outputUds + '/* ', shell=True)
	
		# Move data
		subprocess.call('hadoop fs -mv ' + outputPig + '/* ' + outputUds, shell=True)
	
		# Delete temp folder
		subprocess.call('hadoop fs -rm -r ' + outputPig, shell=True)
		
		
		batch_number = str(sys.argv[1])
		
		#bulkload		
		print '*****************************BULK LOADING***********************************'
		subprocess.call('%s %s %s %s %s %s %s %s %s %s ' % (bulkloadShellScript, bulkloadJarPath, bulkload_lookupTable, bulkload_familyName, bulkload_lookupKey , params['location_result'], bulkload_staging + bulkload_lookupKey, batch_number, bulkload_archive, hadoop_lib), shell=True);	
		
		#Update Last Batch Number Last WihRun When We Finish Coding
		print "******************************************Compute What Is Hot Successfull***************************************"
		diIntegration.updateLookupTable(updatedTable, updatedTable_key, updatedTable_columnFamily, updatedTable_columnName, params['batchNumber_insertedTime'])
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + cmproperties.validation_table + ' KEY ' + key_batch
		utils.updateFailedJobs(rjhTable, cmproperties.validation_columnFamily, key_batch, properties.validation_dataType, "except", str(sys.exc_info()[1]))
		sys.exit(2)
def main():
	runPig();

if __name__ == '__main__':
	main();

