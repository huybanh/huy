#oozie.wf.application.path=hdfs://nn-h1/user/d458737/oozie-jobs/test-workflow
export OOZIE_URL=http://hdpgtwh3-awsw01.ds.dtveng.net:11000/oozie
oozie job -config job.properties -run

