################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
hbase_zookeeper_quorum='hdpnn-h4-awsw01.ds.dtveng.net,hdpnn-h4-awsw03.ds.dtveng.net,hdpnn-h4-awsw02.ds.dtveng.net'
hbase_zookeeper_clientPort='2181'

# Data folder
data_folder='/data/dv/recommendation/processed/prepareduvh'
la_result_folder='/data/dv/recommendation/processed/oozie_results_la'
cbcf_result_folder='/data/dv/recommendation/processed/oozie_results_cbcf'

#
lastaction_path='/data/dev/recommendation/analytics/lastaction/result/20150209110901'
cbcf_path=''
# tablename which of the UVH data
data_tablename = 'finalrawdata2_development'

# Hbase table for CBCF
hbase_cbcf='production_cbcf'
CBCFcolumnFamily='cbcf'
# Hbase table for Last Action
hbase_lastaction='production_lastaction'
LAcolumnFamily='la'

# selected genres
arr_genres=['Watch', 'Record', 'Purchase', 'Like']

SelectNumber=20

#cbcf and last action hbase tables
cbcf_table='development_cbcf'
cbcf_table_by_day='development_cbcf_by_day'
lastaction_table='development_lastaction'
lastaction_table_by_day='development_lastaction_by_day'

#dev_cbcf_by_day
#dev_lastaction_global
#dev_cbcf
