################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import os
import sys
import time
import imp
import subprocess
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from properties_name import *
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

errorList = [];
startTime = datetime.now();
currentLocation = os.getcwd();
#config = HBaseConfiguration.create();
#config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum);
#config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort);
#rjhTable = HTable(config, recommendationJobHistory);
#paramArray = [data_folder, cbcf_folder, la_folder];

#fileSystem = FileSystem.get(config);

def eventsStr(in_arr):
	str = '('
	for i in range(0,len(in_arr)):
		str += "'" + in_arr[i] + "'"
		if (i<len(in_arr)-1): str += ','
	str += ')'
	return str

def main():
	global params;
	params = {	
	'location_data':data_folder,
	'la_result_folder':la_result_folder,
	'cbcf_result_folder':cbcf_result_folder,
	'hbase_lastaction':hbase_lastaction,
	'LAcolumnFamily':LAcolumnFamily,
	'hbase_cbcf':hbase_cbcf,
	'CBCFcolumnFamily':CBCFcolumnFamily,
	'SelectNo':SelectNumber
	}
	pigExcutor  = Pig.compileFromFile(currentLocation + '/data-verification/'+ 'load_uvh.pig');
	stats = pigExcutor.bind(params).runSingle();
	if not stats.isSuccessful():
		print 'Pig job failed'
		sys.exit(0)
	return

if __name__ == '__main__':
	main();