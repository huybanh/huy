arr_genres=['Watch', 'Record', 'Purchase', 'Like']
def ProcessArr(in_arr):
	val = ''
	for item in in_arr:
		for k in range(0, len(arr_genres)):
			if (item[1] == arr_genres[k]):
				val += item[0]
				break
		break
	return str(val)