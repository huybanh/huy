# udf class
cbcfFromCBCFByDay='com.directv.pig.cbcf.cbcf.merging.ConvertFromCBCFByDay'
cbcfOperationClass='com.directv.pig.cbcf.cbcf.merging.CBCFOperations'
cbcfByDayClass='com.directv.pig.cbcf.cbcfbyday.HdfsCbcfByDay'
cbcfClass='com.directv.pig.cbcf.cbcfbytimewindow.HdfsCbcfByTimeWindow'
userTasteClass='com.directv.pig.usertastes.UserTastes'
excludeGenreClass='com.directv.pig.cbcf.excluding.ExcludeGenreFromCbcf'

#bulkload
bulkload_lookupKey_cbcf='bulkload_cbcf'
bulkload_lookupKey_cbcfbyday='bulkload_cbcf_daybyday'
bulkload_lookupTable='production_lookuptable'
bulkload_familyName='cf'

#user taste
userTaste_maxSize='10'
userTaste_mainCategoryNumber='3'
userTaste_filter='Last6Months.Genre(.*)Alldays'
userTaste_filter_tms='Last6Months.TmsGenre(.*)Alldays'
userTaste_mainCategories='["Movies","Sports","TV","AllCategories"]'

#variables
adult='Adult'
watchEvent="Watch"
invalidAccountId='-1'

#moved to common_properties
#excludingRule='{"mainCategory":["Movies","TV","Sports"],"ignoredGenres":["Adult"],"excludingTmsId":[],"excludingTitle":["To Be Announced"], "excludingProgtypes":["Paid Programming"] }'

#properties for DI integration
dataTypes = ['cbcf', 'cbcf_by_day','insertedTime']
lookupTable_cbcf_key='cbcf'
lookupTable_cbcfByDay_key='cbcf_by_day'
lookupTable='production_lookuptable'
lookupTable_columnFamily='cf'
lookupTable_columnName='batch'
updatedTable='production_lookuptable'

# input data 
newInsertedData='/data/dv/recommendation/processed/prepareduvh/insertedtime='   #daily data (inserted data) location 

# output 
cbcfByDayData='/data/dv/recommendation/analytics/cbcf/result/cbcfbyday/'			#cbcf by day result location 
cbcfData='/data/dv/recommendation/analytics/cbcf/result/cbcf/'					#cbcf result location 
userTasteData='/data/dv/recommendation/analytics/cbcf/result/usertaste/'         #usertaste result location    
genreExcludedCbcfByDayData='/data/dv/recommendation/analytics/cbcf/result/excluded_genre_cbcf_byday/'
genreExcludedCbcfData='/data/dv/recommendation/analytics/cbcf/result/excluded_genre_cbcf/'

#validation parameters
validation_dataType='cbcf'
