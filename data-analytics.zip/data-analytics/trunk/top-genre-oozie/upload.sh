hadoop fs -rm -r /data/dv/recommendation/oozie-jobs/top-genre/
hadoop fs -mkdir /data/dv/recommendation/oozie-jobs/top-genre/
hadoop fs -put * /data/dv/recommendation/oozie-jobs/top-genre/

