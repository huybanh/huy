#library
class_LastAction='com.directv.pig.lastaction.globalsettingbased.LastAction'
class_LastEventTime='com.directv.pig.lastaction.globalsettingbased.LastEventTime'
class_LastActionMerger='com.directv.pig.lastaction.merging.LastActionMerger'

#bulkload
bulkload_lookupTable='production_lookuptable'
bulkload_familyName='cf'
bulkload_lookupKey='bulkload_lastaction'

#properties for DI integration
dataTypes = ['lastaction','insertedTime']
lookupTable='production_lookuptable'
lookupTable_key='lastaction'
lookupTable_columnFamily='cf'
lookupTable_columnName='batch'

#lastaction attributes
viewedDurationThreshold='0.3'
gapThreshold='259200'
numberEvents='10'
isGroupCategory='true'
allSubName='AllSubCategory'
lastDayNumber='259200' #in seconds
jsonLastActionRule='{"lastDayNumbers":{"Movies":"-1","TV":"-1","Sports":"3"}}'

#validation parameters
validation_dataType='lastaction'

#tables or location 
location_data='/data/dv/recommendation/processed/prepareduvh/'      #input data location 
location_result='/data/dv/recommendation/analytics/lastaction/result/'		     #output data for result lastaction



