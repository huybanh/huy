#library
cbcfByDayClass='com.directv.pig.cbcf.cbcfbyday.HdfsCbcfByDay'
cbcfClass='com.directv.pig.cbcf.cbcfbytimewindow.HdfsCbcfByTimeWindow'
userTasteClass='com.directv.pig.usertastes.UserTastes'
excludeGenreClass='com.directv.pig.cbcf.excluding.ExcludeGenreFromCbcf'

#bulkload
bulkload_lookupKey_cbcf='bulkload_cbcf'
bulkload_lookupKey_cbcfbyday='bulkload_cbcf_daybyday'
bulkload_lookupTable='production_lookuptable'
bulkload_familyName='cf'

#variables
adult='Adult'
watchEvent="Watch"

#move to common_properties
#excludingRule='{"mainCategory":["Movies","TV","Sports"],"ignoredGenres":["Adult"],"excludingTmsId":[],"excludingTitle":["To Be Announced"], "excludingProgtypes":["Paid Programming"] }'

#user taste
userTaste_maxSize='10'
userTaste_mainCategoryNumber='3'
userTaste_filter='Last6Months.Genre(.*)Alldays'
userTaste_filter_tms='Last6Months.TmsGenre(.*)Alldays'
userTaste_mainCategories='["Movies","Sports","TV","AllCategories"]'

#properties for DI integration
dataTypes = []
lookupTable='production_lookuptable'
lookupTable_cbcf_key='cbcf'
lookupTable_cbcfByDay_key='cbcf_by_day'
lookupTable_columnFamily='cf'
lookupTable_columnName='batch'

batchColumn='cf:batch'
updatedTable='production_lookuptable'

#input
preparedData='/data/dv/recommendation/processed/prepareduvh/'  

#output 
cbcfByDayData='/data/dv/recommendation/analytics/cbcf/result/cbcfbyday/'		 #result of cbcf by day location 	
cbcfData='/data/dv/recommendation/analytics/cbcf/result/cbcf/'				 #result of cbcf location  
userTasteData='/data/dv/recommendation/analytics/cbcf/result/usertaste/'		 #result of usertaste location 
genreExcludedCbcfByDayData='/data/dv/recommendation/analytics/cbcf/result/excluded_genre_cbcf_byday/'
genreExcludedCbcfData='/data/dv/recommendation/analytics/cbcf/result/excluded_genre_cbcf/'

#validation parameters
validation_dataType='cbcf'
