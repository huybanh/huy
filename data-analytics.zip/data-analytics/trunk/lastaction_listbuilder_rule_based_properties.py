#=============library==============#
class_listBuilderLastAction='com.directv.pig.lastaction.listbuilderrulebased.ListBuilderLastAction'
class_listbuilderLastActionMerger='com.directv.pig.lastaction.merging.ListbuilderLastActionMerger'


pig_lib='pig-0.9.0.jar'

#=========================== lookup ===================================#
lookupTable='production_lookuptable'
lookupTable_key='lastaction_integration'
lookupTable_columnFamily='cf'
lookupTable_columnName='batch'
batchColumn='cf:batch'
dataTypes = ['insertedTime','cbcf'] #usertaste is generated in time of cbcf generated. So, their batchnumbers are the same. 


#============================bulkloading =============================#
bulkload_hbase_table='hbase://production_lastaction'
bulkload_hbase_table_cf='la'

#===bulkload for mapreduce version 
bulkload_lookupTable='production_lookuptable'
bulkload_familyName='cf'
bulkload_lookupKey='bulkload_lastaction_mapreduce'

#lastaction attributes
viewedDurationThreshold='0.3'
gapThreshold='259200'
numberEvents='10'
isGroupCategory='true'
allSubName='AllSubCategory'
jsonLastActionRule='{"lastDayNumbers":{"Movies":"-1","TV":"-1","Sports":"3"}}'

#user taste attributes
userTaste_mainCategories='["Movies","Sports","TV","AllCategories","TMS_Movies","TMS_Sports","TMS_TV","TMS_AllCategories", "Mobile_Movies","Mobile_Sports","Mobile_TV","Mobile_AllCategories"]'
allMainCategoryName='AllCategories'
topGettingUserTaste='1'

#validation parameters
validation_dataType='lastaction_integration'


#=====location_data: Input data path, must be set to stitched prepareduvh path====#
location_data='/data/dv/recommendation/processed/90daysfiltereduvh/'  
location_result='/data/dv/recommendation/analytics/lastaction_integration/result/'		 
location_result_usertaste='/data/dv/recommendation/analytics/cbcf/result/usertaste/'
location_output_mapreduce='/data/dv/recommendation/analytics/lastaction_integration/result/mapreduce/'
