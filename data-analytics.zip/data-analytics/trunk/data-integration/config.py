################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
import datetime

hbase_zookeeper_quorum = 'hdpnn-dv-msdc02.ds.dtveng.net,hdpnn-dv-msdc01.ds.dtveng.net,hdpdn-dv-msdc03.ds.dtveng.net'
hbase_zookeeper_clientPort = '2181'

#lookup table and update
lookup_Table = 'demo_5_2014_lookupTable'
batch_Column = 'content:batch'

#folder contains extracted data
lastweek_day_data = '/user/d458737/DA/week_data/'

select_sql = 'select_distinct.sql'
select_values = 'select_values.sql'
create_values = 'create_values.sql'

curr = datetime.date(2014,9,3) #datetime.datetime.today()
#remove LBN when finish testing
LBN = '20140810065052'
#cbcf_window_time=[["Last6Months",180],["Month",30],["2Week",14]]
cbcf_window_time=[["Month",30],["2Week",14]]
wih_window_time=[["1Week",7],["2Week",14]]

#partitioned table and temp table
partitioned_table = 'uvh_tableidx'
cbcf_window_time_table = 'CBCF_DA_WINDOWTIME'
wih_window_time_table = 'WIH_DA_WINDOWTIME'
indexed_valuesTable = 'indexValueTable'
indexed_folder = '/user/d458737/DA/indexed_folder/'
inserted_table = 'uvh_insertedTable'
inserted_data = '/user/d458737/DA/new_inserted_data/'
cbcf_removed_data = '/user/d458737/DA/cbcf_removed_data/'
wih_removed_data = '/user/d458737/DA/wih_removed_data/'
pig_index_file = 'select_indexed_values.pig'
wt_file = 'wtfile.sql'

#called to common for LBN
common_lastbatch_pig_script='../../common/lastBatch.pig'
common_lastbatch_python_script='../../common/lastBatchNumber.py'
lookupTable='demo_5_2014_lookupTable'
lookupTable_key='cbcf'
lookupTable_columnFamily='content'
lookupTable_columnName='batch'
batchColumn='content:batch'
dataTypes = ['cbcf']
