################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
#!/usr/bin/python
from config import *
from org.apache.pig.scripting import Pig

import sys
import os
import time
import imp
from datetime import timedelta
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *

# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

diIntegration = imp.load_source('dataAnalytic', common_lastbatch_python_script);

# private function
# creates dynamic where clause
def whereclause(dates):
	_where = "WHERE ("
	i = 0
	for Date in dates:
		i += 1
		_where += "( Year='"
		_where += str(Date.year)
		_where += "' AND Month='"
		_where += str(Date.month)
		_where += "' AND Day='"
		_where += str(Date.day)
		_where += "')"
		if (i<len(dates)): _where += " OR "
	_where += ");"
	return(_where)

# private function
# executes insert sql
def InsertDaysData(createTable, savingFolder, inDays):

	createfile = open(create_values, 'r')
	createSQLstring = createfile.read()
	create_gen_sql = (createSQLstring % (createTable, createTable, savingFolder))
	createfile.close()
	#os.system('hive -e "' + create_gen_sql + '"')
	datasqlfile = open(wt_file, 'w')
	datasqlfile.write(create_gen_sql)
	datasqlfile.close()
	os.system('hive -f ' + wt_file)
	os.system('rm ' + wt_file)

	datasql = open(select_values, 'r')
	datasqlcontent = datasql.read()
	datasql.close()

	#extract for the range of data
	datasqlweekCMD = (datasqlcontent % (createTable, partitioned_table, whereclause(inDays)))
	datasqlweekfile = open(wt_file, 'w')
	datasqlweekfile.write(datasqlweekCMD)
	datasqlweekfile.close()
	os.system('hive -f ' + wt_file)
	os.system('rm ' + wt_file)

	# print 'savingFolder is ' + savingFolder
	# print 'range of dates are ' + str(inDays)
	# print 'length of date array is ' +  str(len(inDays))
	# print whereclause(inDays)
	return()

# This function extracts the range of data
def getDatesData(curr_date, nDays, createTable, savingFolder, window_time=[], cbcf=False):
	# Running the extraction of script
	selectfile = open(select_sql, 'r')
	selectSQLstring = selectfile.read()
	select_gen_sql = (selectSQLstring % (indexed_valuesTable, indexed_valuesTable, indexed_folder, partitioned_table, indexed_valuesTable))
	selectfile.close()
	datasqlfile = open(wt_file, 'w')
	datasqlfile.write(select_gen_sql)
	datasqlfile.close()
	os.system('hive -f ' + wt_file)
	os.system('rm ' + wt_file)

	# extract days values
	IndexPigFile = Pig.compileFromFile(pig_index_file);
	IndexParams = {
		'INDEX_TABLE_VALUE':indexed_folder
	};
	d_arr = list()
	window_time_days = list()
	indexData = IndexPigFile.bind(IndexParams).runSingle();
	if indexData.isSuccessful():
		BatchIter = indexData.result('CURRENT_DATA').iterator();
		while BatchIter.hasNext():
			try:
				YMDValue = BatchIter.next();
				y, m, d = YMDValue.get(0), YMDValue.get(1), YMDValue.get(2)
				if (y>0 and m>0 and d>0): __d = datetime.date(y, m, d)
				d_arr.append(__d)
			except IndexError:
				print "Error in indexed data"
		d_arr.sort()
	
	if (len(window_time)>0):
		for i in range(len(window_time)):
			ndays = int(window_time[i][1])
			startDate = curr_date - timedelta(days=ndays)
			endDate = curr - timedelta(days=ndays)
			print window_time[i][0], window_time[i][1]
			#for removed days
			for item in d_arr:
				v = item - startDate
				if (item > startDate and item < endDate):
					print 'date item to add is ', item
					window_time_days.append(item)

			if (len(window_time_days)>0):
				#extract for the range of data
				if (cbcf != True):
					savingFolder = savingFolder + str(ndays)
					os.system('hdfs dfs -rm ' + savingFolder)
					# print 'creating folder ', savingFolder
					os.system('hdfs dfs -mkdir ' + savingFolder)
					createTable = createTable + window_time[i][0]

				InsertDaysData(createTable, savingFolder, window_time_days)
	else:
		#for inserted days
		print 'Start date is', curr_date
		print 'numbers of date to extract', nDays
		for item in d_arr:
			v = item - curr_date
			if (item > curr_date and v.days < nDays.days):
				print 'date item to add is ', item
				window_time_days.append(item)

		InsertDaysData(createTable, savingFolder, window_time_days)
	return()

#
# Function to compute inserted date and removed date
# inDate: currentDate; LBN: Last Batch Number
#
def MainFunc(inDate, LBN):
	#from Batch number, convert to date
	_yLBN = int(LBN[0:4])
	_mLBN = int(LBN[4:6])
	_dLBN = int(LBN[6:8])
	LBNd = datetime.date(_yLBN, _mLBN, _dLBN)
	nDays = inDate - LBNd

	#for inserted days
	getDatesData(LBNd, nDays, inserted_table, inserted_data)

	#for wih removed days
	getDatesData(LBNd, 0, wih_window_time_table, wih_removed_data, window_time=wih_window_time)

	#for cbcf removed days
	getDatesData(LBNd, 0, cbcf_window_time_table, cbcf_removed_data, window_time=cbcf_window_time, cbcf=True)
	return()

if __name__ == '__main__':
	params = {
	};
	#DI Integration
 	# diIntegration.getLastBatchNumber(LBN, common_lastbatch_pig_script, dataTypes, lookupTable, batchColumn);	
	
	MainFunc(curr, LBN)
