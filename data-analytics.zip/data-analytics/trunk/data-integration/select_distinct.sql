---------------------------------------------------------------------------------
--                                                                              -
-- DIRECTV PROPRIETARY                                                          -
-- Copyright@ 2014 DIRECTV, INC.                                                -
-- UNPUBLISHED WORK                                                             -
-- ALL RIGHTS RESERVED                                                          -
--                                                                              -
-- This software is the confidential and proprietary information of             -
-- DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           -
-- distribution or disclosure of the software or Proprietary Information,       -
-- in whole or in part, must comply with the terms of the license               -
-- agreement, nondisclosure agreement or contract entered into with             -
-- DIRECTV providing access to this software.                                   -
---------------------------------------------------------------------------------
USE cloudrec;
DROP TABLE IF EXISTS %s;
CREATE EXTERNAL TABLE %s (Year INT, Month INT, Day INT) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' LOCATION '%s';
FROM %s INSERT OVERWRITE TABLE %s SELECT DISTINCT Year, Month, Day;