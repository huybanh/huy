---------------------------------------------------------------------------------
--                                                                              -
-- DIRECTV PROPRIETARY                                                          -
-- Copyright@ 2014 DIRECTV, INC.                                                -
-- UNPUBLISHED WORK                                                             -
-- ALL RIGHTS RESERVED                                                          -
--                                                                              -
-- This software is the confidential and proprietary information of             -
-- DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           -
-- distribution or disclosure of the software or Proprietary Information,       -
-- in whole or in part, must comply with the terms of the license               -
-- agreement, nondisclosure agreement or contract entered into with             -
-- DIRECTV providing access to this software.                                   -
---------------------------------------------------------------------------------
USE cloudrec;

DROP TABLE IF EXISTS %s;
CREATE EXTERNAL TABLE %s (rowkey string, 
		accountId string, 
		tmsId string, 
        eventTime string, 
        source string, 
        eventType string, 
        sourceType string, 
        startTime string,
        endTime string, 
        channelId string, 
        cardId string, 
        durationViewed bigint, 
        profileId string,
        deviceId string, 
        deviceType string, 
        channelNumber string,
		startTimeSchedule string, 
		endTimeSchedule string,
        statusCDN string,
		eventMapping string, 
        weight string, 
        addition string,
        dateofweek string,
        timeofdate string,
        mainCategory string, 
		genre1 string, 
		genre2 string, 
		genre3 string, 
        title string, 
        programId string, 
        rating string, 
        releaseYear string, 
        originalAirDate string, 
        maxRunLength bigint,
        delivery string, 
        actor1 string, 
        actor2 string, 
        actor3 string, 
        actor4 string, 
        actor5 string, 
        director1 string, 
        director2 string, 
        director3 string, 
		duration bigint,
        zipcode bigint,
    	fipCountyCode string,
        dma bigint,
        utcOffset string,
        channelType string,
        channelObjectId string,
        marketId string,  
		tone1 string, 
		tone2 string, 
		tone3 string, 
		mood1 string, 
		mood2 string, 
		mood3 string, 
		theme1 string, 
        theme2 string, 
		theme3 string, 
		rottenTomato string, 
		critic1 string, 
		critic2 string, 
		critic3 string, 
		audienceScore string,
		insertedTime string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
LOCATION '%s';
