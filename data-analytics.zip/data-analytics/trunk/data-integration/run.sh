pig runDI.py
