---------------------------------------------------------------------------------
--                                                                              -
-- DIRECTV PROPRIETARY                                                          -
-- Copyright@ 2014 DIRECTV, INC.                                                -
-- UNPUBLISHED WORK                                                             -
-- ALL RIGHTS RESERVED                                                          -
--                                                                              -
-- This software is the confidential and proprietary information of             -
-- DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           -
-- distribution or disclosure of the software or Proprietary Information,       -
-- in whole or in part, must comply with the terms of the license               -
-- agreement, nondisclosure agreement or contract entered into with             -
-- DIRECTV providing access to this software.                                   -
---------------------------------------------------------------------------------
use cloudrec;

INSERT OVERWRITE TABLE %s SELECT rowkey, 
		accountId, 
		tmsId, 
        eventTime, 
        source, 
        eventType, 
        sourceType, 
        startTime,
        endTime, 
        channelId, 
        cardId, 
        durationViewed, 
        profileId,
        deviceId, 
        deviceType, 
        channelNumber,
		startTimeSchedule, 
		endTimeSchedule,
        statusCDN,
		eventMapping, 
        weight, 
        addition,
        dateofweek,
        timeofdate,
        mainCategory, 
		genre1, 
		genre2, 
		genre3, 
        title, 
        programId, 
        rating, 
        releaseYear, 
        originalAirDate, 
        maxRunLength,
        delivery, 
        actor1, 
        actor2, 
        actor3, 
        actor4, 
        actor5, 
        director1, 
        director2, 
        director3, 
		duration,
        zipcode,
    	fipCountyCode,
        dma,
        utcOffset,
        channelType,
        channelObjectId,
        marketId,  
		tone1, 
		tone2, 
		tone3, 
		mood1, 
		mood2, 
		mood3, 
		theme1, 
        theme2, 
		theme3, 
		rottenTomato, 
		critic1, 
		critic2, 
		critic3, 
		audienceScore,
		insertedTime FROM %s %s
