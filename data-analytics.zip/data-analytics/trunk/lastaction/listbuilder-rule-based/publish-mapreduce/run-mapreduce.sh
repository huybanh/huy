echo '*************************params********************************'
#jarfile=pig-analytics-udf-0.1.6-SNAPSHOT.jar
#clazz=com.directv.analytics.mapreduce.lastaction.LastActionJobDriver
#data=/data/dv/recommendation_backup/processed/90daysfiltereduvh/*
#usertaste=/data/dv/recommendation_backup/analytics/cbcf/result/usertaste/20141210224156
#output=/data/dv/recommendation/analytics/lastaction_integration/result/mapreduce_test
#batchNumber=20141119000001
#rule= '[{"ruleName":"rule1","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"GENRE","operation":"IS","value1":"userTaste","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule2","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DELIVERY","operation":"IS","value1":"linear","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule3","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"GENRE","operation":"IS","value1":"Romance","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule4","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DAY_OF_WEEK","operation":"IS","value1":"Wednesday","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule5","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"TIME_OF_DAY","operation":"IS","value1":"Early Morning","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule6","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"RATING","operation":"IS","value1":"TVG","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"state":"Saved","match":{"type":"AND","statement":[{"filter":{"name":"DEVICE","operation":"IS","value1":"ios moblie","value2":null,"userTaste":false},"match":{"type":null,"statement":[],"parentType":null}}],"parentType":null},"ruleName":"rule7","numberOfEvents":25,"ruleType":"LAST_WATCH","lastModifiedDate":null},{"ruleName":"rule8","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DEVICE","operation":"IS","value1":"Mobile","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule9","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DEVICE","operation":"IS","value1":"Mobile","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule10","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"GENRE","operation":"IS","value1":"userTaste","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule11","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DELIVERY","operation":"IS","value1":"linear","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule12","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"GENRE","operation":"IS","value1":"Romance","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule13","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DAY_OF_WEEK","operation":"IS","value1":"Wednesday","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule14","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"TIME_OF_DAY","operation":"IS","value1":"Early Morning","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule15","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"RATING","operation":"IS","value1":"TVG","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"state":"Saved","match":{"type":"AND","statement":[{"filter":{"name":"DEVICE","operation":"IS","value1":"ios moblie","value2":null,"userTaste":false},"match":{"type":null,"statement":[],"parentType":null}}],"parentType":null},"ruleName":"rule16","numberOfEvents":25,"ruleType":"LAST_WATCH","lastModifiedDate":null},{"ruleName":"rule17","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DEVICE","operation":"IS","value1":"Mobile","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule18","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DEVICE","operation":"IS","value1":"Mobile","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule19","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DEVICE","operation":"IS","value1":"Mobile","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"},{"ruleName":"rule20","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"DEVICE","operation":"IS","value1":"Mobile","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"}]'
#hadoop_lib_folder
jarfile=$1
clazz=$2
data=$3*
usertaste=$4
output=$5
batchNumber=$6
rule=${7}
hadoop_lib_folder=$8
libjars=$9
flattenRule=${10}

echo 'jar file :' $jarfile
echo 'clazz: ' $clazz
echo 'data :' $data
echo 'usertaste :' $usertaste
echo 'output folder ' $output
echo 'batchNumber :' $batchNumber
echo 'rule content:' $rule
echo 'hadoop_lib_folder: '$hadoop_lib_folder
echo 'lib jars: ' $libjars 
echo 'flattenRule:' $flattenRule

echo '***********************export libs*******************************'
if [[ -f action.xml ]];
then
kinit -kt svc.cloudrec.dv2.keytab svc.cloudrec.dv2@DS.DTVENG.NET
export LIBJARS=$libjars
export JAVA_CLASSPATH=`hbase classpath`:/etc/hbase/conf:$JAVA_CLASSPATH
export export HADOOP_CLASSPATH=`hbase classpath`:/etc/hbase/conf:$HADOOP_CLASSPATH:$9/lib/hbase/*
else
export LIBJARS=$libjars
export JAVA_CLASSPATH=`hbase classpath`:/etc/hbase/conf:$JAVA_CLASSPATH
export export HADOOP_CLASSPATH=`hbase classpath`:/etc/hbase/conf:$HADOOP_CLASSPATH:$9/lib/hbase/*
fi

echo '*****************************************EXECUTE SHELL SCRIPT*****************************************'
#hadoop jar $jarfile $clazz -libjars ${LIBJARS} $data $usertaste  $output $batchNumber $rule
#hadoop jar $jarfile $clazz $data $usertaste  $output $batchNumber $rule
#/data/dv/recommendation_backup/processed/90daysfiltereduvh/insertedtime=20141022
hadoop jar $jarfile $clazz  -libjars ${LIBJARS} $data $usertaste  $output $batchNumber "$rule" "$flattenRule"


