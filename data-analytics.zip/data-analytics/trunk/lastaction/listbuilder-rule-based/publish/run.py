#!/usr/bin/python
################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

from common_properties import *
from lastaction_listbuilder_rule_based_properties import *
from org.apache.pig.scripting import Pig

import sys
import os
import time
import subprocess
import imp
import datetime
import re
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count
import imp
import datetime
from datetime import datetime

#locations
currentLocation = os.getcwd();
common_lastbatch_python_script = currentLocation + '/common/lastBatchNumber.py'
common_util_script = currentLocation + '/common/Utils.py'
utils = imp.load_source('utils', common_util_script);
pig_script = currentLocation + '/lastaction/listbuilder-rule-based/publish/publish-lastaction.pig'

#bulkload location
bulkloadShellScript = currentLocation + '/bulkload/run.sh'
bulkloadJarPath  = currentLocation + '/' + bulkload_jarName

#initialize DI Integration
diIntegration = imp.load_source('dataAnalytic', common_lastbatch_python_script);

#validation parameters
config = HBaseConfiguration.create()
rjhTable = HTable(config, validation_table)
fileSystem = FileSystem.get(config)

def runPig():
	pigScriptingExcutor = Pig.compileFromFile(pig_script);
	global params;	
	params = {
	'location_data':location_data,
	'location_result_usertaste':location_result_usertaste,
	'numberEvents':numberEvents,	
	'isGroupCategory':isGroupCategory,	
	'viewedDurationThreshold':viewedDurationThreshold, 
	'gapThreshold':gapThreshold, 
	'pig_udf':udfLib, 
	'lookupTable':lookupTable,
	'batchColumn':batchColumn, 
	'allSubName':allSubName, 
	'dateTimeFormat':dateTimeFormat,
	'lookupTable_columnFamily':lookupTable_columnFamily,
	'lookupTable_key':lookupTable_key,
	'lookupTable_columnName':lookupTable_columnName, 
	'dateFormat':dateFormat, 	
	'common_lib':common_lib, 
	'class_listBuilderLastAction':class_listBuilderLastAction,	
	'bulkload_hbase_table':bulkload_hbase_table,
	'bulkload_hbase_table_cf':bulkload_hbase_table_cf, 
	'userTaste_mainCategories':userTaste_mainCategories,
	'allMainCategoryName':allMainCategoryName,
	'topGettingUserTaste':topGettingUserTaste, 
	'flatten_rule':rule,
	'jsonLastActionRule':jsonLastActionRule
	
	};	

	try:
		#DI Integration
		print '*****************************GETTING BATCHNUMBER***********************************'
		diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName);				
		if len(sys.argv)==3: #from oozie		
			params['batchNumber_current'] = str(sys.argv[1])			
			params['rule'] = str(sys.argv[2])	
			
		params['batchNumber_usertaste'] = params['batchNumber_cbcf'] 
		params['location_result_usertaste'] = params['location_result_usertaste'] + params['batchNumber_usertaste']		
		print params;	

		print '*********************************VALIDATION*****************************************'		
		key_batch = params['batchNumber_current']	
		utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, params['location_data'])
		utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, params['location_result_usertaste'])
		utils.validateDate(rjhTable, validation_columnFamily, key_batch, validation_dataType, params['batchNumber_current'])
		
		#call pig script
		print '*****************************EXECUTING PIG SCRIPT***********************************'			
		stats = pigScriptingExcutor.bind(params).runSingle();
		if not stats.isSuccessful():
			raise 'Pig job failed'
			sys.exit(0)
									
		#update lastBatchNumber	
		#print '*****************************UPDATING BATCHNUMBER TO ***********************************' + params['batchNumber_current']
		#diIntegration.updateLookupTable(updatedTable, lookupTable_key, lookupTable_columnFamily, lookupTable_columnName, params['batchNumber_current'])					
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + validation_table + ' KEY ' + key_batch			
		print str(sys.exc_info()[1])
		utils.updateFailedJobs(rjhTable, validation_columnFamily, key_batch, validation_dataType, "except", str(sys.exc_info()[1]))		
        
				
def main():
	#run pig script
	runPig();

if __name__ == '__main__':
	main();