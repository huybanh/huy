#!/usr/bin/python

from common_properties import *
from lastaction_global_setting_based_properties import *
from org.apache.pig.scripting import Pig

import sys
import os
import time
import subprocess
import imp
import datetime
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count
from datetime import datetime, timedelta

#locations
currentLocation = os.getcwd()
path_analytics = currentLocation
path_lastaction = currentLocation + '/lastaction'
path_demo = currentLocation + '/lastaction/demo'
common_lastbatch_python_script = currentLocation + '/common/lastBatchNumber.py'
common_util_script = currentLocation + '/common/Utils.py'
common_kinit_script = currentLocation + '/common/initializeTicketPrincipal.sh'

utils = imp.load_source('utils', common_util_script)

#bulkload location
bulkloadShellScript = currentLocation + '/bulkload/run.sh'
bulkloadJarPath  = currentLocation + '/' + bulkload_jarName

#initialize DI Integration
diIntegration = imp.load_source('dataAnalytic', common_lastbatch_python_script)

#validation parameters
config = HBaseConfiguration.create()
rjhTable = HTable(config, validation_table)
fileSystem = FileSystem.get(config)


def runPig():
	pigFirstTimeScriptingExcutor  = Pig.compileFromFile(currentLocation + '/lastaction/global-setting-based/firsttime-lastaction.pig')
	pigDailyScriptingExcutor  = Pig.compileFromFile(currentLocation + '/lastaction/global-setting-based/daily-lastaction.pig')
	global params	
	params = {	
	'location_result':location_result,
	'location_data':location_data,
	'numberEvents':numberEvents,
	'isGroupCategory':isGroupCategory,
	'rule':rule,	
	'viewedDurationThreshold':viewedDurationThreshold, 
	'gapThreshold':gapThreshold, 
	'pig_udf':udfLib, 	
	'lookupTable':lookupTable, 
	'allSubName':allSubName, 
	'dateTimeFormat':dateTimeFormat,
	'lookupTable_columnFamily':lookupTable_columnFamily,
	'lookupTable_key':lookupTable_key,
	'lookupTable_columnName':lookupTable_columnName,
	'dateFormat':dateFormat, 	
	'lastDayNumber':lastDayNumber, 	
	'class_LastAction':class_LastAction, 
	'class_LastEventTime':class_LastEventTime, 
	'class_LastActionMerger':class_LastActionMerger,
	'jsonLastActionRule':jsonLastActionRule,
	'mainCategories':mainCategories
	}	

	if len(sys.argv)==2: key_batch = str(sys.argv[1])
	else: key_batch = datetime.now().strftime("%Y%m%d%H%M%S")			
	try:
		#DI Integration
		print '*****************************GETTING BATCHNUMBER***********************************'
		bFirst = True
		diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName)
		
		#run.sh <batchNumber> 
		if len(sys.argv)==2: 
			params['batchNumber_current'] = str(sys.argv[1])			
			bFirst = False
			
		if params['batchNumber_lastaction'] == '' or params['batchNumber_lastaction'] == None:
			bFirst = True
			params['batchNumber_lastaction']=params['batchNumber_current']
		key_batch = params['batchNumber_current']
		
		print '*****************************EXECUTING PIG SCRIPT***********************************'
		if (bFirst): 
			print 'Executing for the first time script'
			stats = pigFirstTimeScriptingExcutor.bind(params)			
		else: 
			print 'Executing for daily script'
			params['location_data']=params['location_data']+'insertedtime=' + params['batchNumber_insertedTime']
			stats = pigDailyScriptingExcutor.bind(params)			
			old_result = params['location_result'] + params['batchNumber_lastaction']			
			utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, old_result)


		print '*********************************VALIDATION*****************************************'		
		utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, params['location_data'])
		utils.validateDate(rjhTable, validation_columnFamily, key_batch, validation_dataType, params['batchNumber_current'])
		result = stats.runSingle()
		if not result.isSuccessful():
			print 'Pig job failed'
			sys.exit(1)

		#update lastBatchNumber
		print '*****************************UPDATING BATCHNUMBER TO ***********************************' + params['batchNumber_current']
		diIntegration.updateLookupTable(lookupTable, lookupTable_key, lookupTable_columnFamily, lookupTable_columnName, params['batchNumber_current'])
		
		#bulkload
		print '*****************************BULK LOADING***********************************'
		subprocess.call('%s %s %s %s %s %s %s %s %s %s ' % (bulkloadShellScript, bulkloadJarPath, bulkload_lookupTable, bulkload_familyName, bulkload_lookupKey ,params['location_result'] + params['batchNumber_current'], bulkload_staging + bulkload_lookupKey, params['batchNumber_current'], bulkload_archive, hadoop_lib), shell=True)
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + validation_table + ' KEY ' + key_batch
		utils.updateFailedJobs(rjhTable, validation_columnFamily, key_batch, validation_dataType, "except", str(sys.exc_info()[1]))
def main():
	#run pig script
	runPig()	

if __name__ == '__main__':
	main()
