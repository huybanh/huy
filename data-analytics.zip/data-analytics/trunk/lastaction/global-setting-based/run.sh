echo '*****************EXCUTING LAST ACTION JOB IN LOCATION ************************'
CURRENT=`pwd`
echo $CURRENT

if [ $# -eq 1 ]; then
	echo '*****************EXCUTING LAST ACTION JOB ************************'
	pig ./lastaction/global-setting-based/lastaction.py $1	
elif [ $# -eq 3 ]; then
	echo '*****************EXCUTING KINIT ************************'
	keytab = $1
	serviceaccount = $2

	if [[ -f action.xml ]]; then
		kinit -kt $1 $2
		export HBASE_CONF_DIR=.
	fi	

	echo '*****************EXCUTING LAST ACTION JOB ************************'
	pig ./lastaction/global-setting-based/lastaction.py $3	
fi


result=$?
echo '*****************FINISHED LAST ACTION JOB ************************'
if [ $result -eq 0 ]; then
	echo "Compute LastAction successfully "  
else
	echo "Compute LastAction unsuccessfully"
fi