#!/usr/bin/python
################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

from common_properties import *
from lastaction_global_setting_based_properties import *


import os
import imp
import sys

#initialize bulkload util
bulkloadUtil = imp.load_source('dataAnalytic', os.getcwd() + '/bulkload/bulkload_util.py');	

batch_number = str(sys.argv[1])

bulkloadUtil.bulkload(lookupTable_key, lookupTable, lookupTable_columnFamily, lookupTable_columnName, bulkload_jarName, bulkload_lookupTable, bulkload_familyName, bulkload_lookupKey , bulkload_staging, bulkload_error, batch_number, hadoop_lib)
