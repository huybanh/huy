echo '***********parameters of bulkload**************'
echo $1 : bulkloadJar
echo $2 : lookupTableName
echo $3 : lookupFamilyName
echo $4 : lookupKey
echo $5 : sourcePath
echo $6 : destParentPath
echo $7 : hfileFolderName
echo $8 : archiveFolder
echo $9 : pathToHadoopLib

if [[ -f action.xml ]];
then
kinit -kt svc.cloudrec.dv2.keytab svc.cloudrec.dv2@DS.DTVENG.NET
export HADOOP_CLASSPATH=.:$9/lib/hbase/*
else
export HADOOP_CLASSPATH=/etc/hbase/conf/:$9/lib/hbase/*
fi

hadoop jar $1 com.dtv.ingestion.hbasebulk.HFileGenDriver $2 $3 $4 $5 $6/$7

distcpOpts='-Ddfs.nameservices=nn-h3,nn-h4'
distcpOpts=$distcpOpts' -Ddfs.ha.namenodes.nn-h3=nn1,nn2'
distcpOpts=$distcpOpts' -Ddfs.namenode.rpc-address.nn-h3.nn1=hdpnn-h3-awsw01.ds.dtveng.net:8020'
distcpOpts=$distcpOpts' -Ddfs.namenode.rpc-address.nn-h3.nn2=hdpnn-h3-awsw02.ds.dtveng.net:8020'
distcpOpts=$distcpOpts' -Ddfs.client.failover.proxy.provider.nn-h3=org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider'
distcpOpts=$distcpOpts' -Ddfs.ha.namenodes.nn-h4=nn3,nn4 -Ddfs.namenode.rpc-address.nn-h4.nn3=hdpnn-h4-awsw01.ds.dtveng.net:8020'
distcpOpts=$distcpOpts' -Ddfs.namenode.rpc-address.nn-h4.nn4=hdpnn-h4-awsw02.ds.dtveng.net:8020'
distcpOpts=$distcpOpts' -Ddfs.client.failover.proxy.provider.nn-h4=org.apache.hadoop.hdfs.server.namenode.ha.ConfiguredFailoverProxyProvider'
echo $distcpOpts

unset HADOOP_TOKEN_FILE_LOCATION
hadoop distcp $distcpOpts hdfs://nn-h3/$6/$7 hdfs://nn-h4/$6/$7

hdfs dfs -mv $6/$7 $8/$7