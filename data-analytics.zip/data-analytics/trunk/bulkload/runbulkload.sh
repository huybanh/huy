
echo '***********parameters of bulkload**************'
echo $1 : bulkloadJar
echo $2 : lookupTableName
echo $3 : lookupFamilyName
echo $4 : lookupKey
echo $5 : hfilePath
echo $6 : errorFolder
echo $7 : pathToHadoopLib

export HADOOP_CLASSPATH=/etc/hbase/conf/:$7/lib/hbase/*

hadoop jar $1 com.dtv.ingestion.hbasebulk.BulkLoadAndSwapTable $2 $3 $4 $5 $6

#deleting of folder is handled inside job
#hdfs dfs -rm -r $5