. ./insert_hbase.properties
echo "--------------tables---------------------------------------------"
echo "table_lookup '$table_lookup'"
echo "table_lastaction $table_lastaction"
echo "table_cbcf $table_cbcf"
echo "table_cbcfbyday $table_cbcf"


echo "----------------------------------------batchnumbers of LastAction and CBCF in lookuptable-------------------------------------------"
echo "put '$table_lookup', 'lastaction', '$table_lookup_column_family:batch', '' " | hbase shell
echo "put '$table_lookup', 'lastaction_integration', '$table_lookup_column_family:batch', '' " | hbase shell

echo "put '$table_lookup', 'cbcf', '$table_lookup_column_family:batch', '' " | hbase shell
echo "put '$table_lookup', 'cbcf_by_day', '$table_lookup_column_family:batch', '' " | hbase shell

echo "----------------------------------------lastaction bulkload------------------------------------------------------------------------"
echo "put '$table_lookup', 'bulkload_lastaction', '$table_lookup_column_family:family_name', 'la' " | hbase shell 
echo "put '$table_lookup', 'bulkload_lastaction', '$table_lookup_column_family:family_name_inactive', 'la' " | hbase shell 
echo "put '$table_lookup', 'bulkload_lastaction', '$table_lookup_column_family:mapper_class', 'HFileGenMapperMultiline' " | hbase shell 
echo "put '$table_lookup', 'bulkload_lastaction', '$table_lookup_column_family:sep_pattern', ';' " | hbase shell 
echo "put '$table_lookup', 'bulkload_lastaction', '$table_lookup_column_family:table_name', '$table_lastaction' " | hbase shell 
echo "put '$table_lookup', 'bulkload_lastaction', '$table_lookup_column_family:table_name_inactive', '$table_lastaction' " | hbase shell 


echo "----------------------------------------CBCF bulkload------------------------------------------------------------------------"
echo "put '$table_lookup', 'bulkload_cbcf', '$table_lookup_column_family:family_name', 'cbcf' " | hbase shell 
echo "put '$table_lookup', 'bulkload_cbcf', '$table_lookup_column_family:family_name_inactive', 'cbcf' " | hbase shell 
echo "put '$table_lookup', 'bulkload_cbcf', '$table_lookup_column_family:mapper_class', 'HFileGenMapperMultiline' " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf', '$table_lookup_column_family:sep_pattern', ';' " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf', '$table_lookup_column_family:table_name', '$table_cbcf'  " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf', '$table_lookup_column_family:table_name_inactive', '$table_cbcf' " | hbase shell
echo "----------------------------------------CBCF By day bulkload-----------------------------------------------------------------------"
echo "put '$table_lookup', 'bulkload_cbcf_daybyday', '$table_lookup_column_family:family_name', 'cbcfbyday' " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf_daybyday', '$table_lookup_column_family:family_name_inactive', 'cbcfbyday' " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf_daybyday', '$table_lookup_column_family:mapper_class', 'HFileGenMapperMultiline' " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf_daybyday', '$table_lookup_column_family:sep_pattern', ';' " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf_daybyday', '$table_lookup_column_family:table_name', '$table_cbcfbyday'  " | hbase shell
echo "put '$table_lookup', 'bulkload_cbcf_daybyday', '$table_lookup_column_family:table_name_inactive', '$table_cbcfbyday' " | hbase shell


