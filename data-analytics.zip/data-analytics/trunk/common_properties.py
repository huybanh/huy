#common properties
bulkload_jarName='bulkload-0.1.6.jar'
udfLib = 'pig-analytics-udf-0.1.10.jar'
common_lib='recommendations-commons-0.1.15.jar'
hadoop_lib='/opt/cloudera/parcels/CDH-4.6.0-1.cdh4.6.0.p395.26'

# folders for bulk load
bulkload_staging='/data/dv/recommendation/staging/bulkload/'
bulkload_archive='/data/dv/recommendation/archive/bulkload/'
bulkload_error='/data/dv/recommendation/error/bulkload/'

# main category configuration
allMainCategory='AllCategories'
mainCategories='["Movies","Sports","TV"]'

common_lastbatch_python_script='/common/lastBatchNumber.py'
common_util='/common/Utils.py'

#table for recommmendation job history
validation_table='production_recommendationsjobhistory'
validation_columnFamily='rjh'

#configuration for date time format
dateTimeFormat="yyyyMMddHHmmss"
dateFormat="yyyyMMdd"

#including & excluding json properties
rule='{"mainCategory":["Movies","TV","Sports"],"eventType":["Watch","Purchase","Like","Record"],"genres":[],"acceptedSpecifiedCategoryGenres":{"Movies":["Romance","Cooking","Reality","Action/Adventure","Comedy","Kids","Science Fiction","Sci-Fi","Sci-Fi/Horror","Fantasy","Kids & Family","Mystery/Crime","Documentary","Animation","House/Garden"],"TV":["Romance","Cooking","Reality","Action/Adventure","Comedy","Kids","Science Fiction","Sci-Fi","Sci-Fi/Horror","Fantasy","Kids & Family","Mystery/Crime","Documentary","Animation","House/Garden"],"Sports":[]}, "excludingtmsGenres":[], "excludingGenres":["News","Shopping","Adult","Special","Specials","Religion","Weather","Highlights","Award Ceremony","Premiere","Premium TV"],"ignoredGenres":["Series","TV Series","PlayOff","Mini-Series","Orginal Series","Sitcom"],"synonymGenres":{"Auto":["Racing"],"Art":["Art/Crafts","Ballet","Dance","Performing Arts"],"Home Repair":["House/Garden","How to"],"Mystery/Crime":["True Crime"],"Fashion/Style":["Life Stype"],"Medical":["Health/Medicine"],"Horror":["Sci-Fi/Horror"],"Events":["Fundraiser"],"Family":["Kids & Family"],"Nature":["Science","Science/Nature","Outdoors","Space Exploration"],"Auto":["Auto","Racing"]},"excludingTmsId":[],"excludingTitle":["To Be Announced"],"excludingChannelNumber":[],"excludingChannelId":[],"excludingSeriesId":[],"excludingChannelRange":[],"dayOfWeek":[],"eventDate":[],"timeOfDay":[],"groupMainCategory":"false","acceptedDayOfWeek":[],"acceptedTimeOfDay":[],"excludingProgtypes":["Paid Programming"],"mobileGenres":["Action","Action sports","Adventure","Animals","Auction","Auto","Auto racing","Badminton","Baseball","Basketball","Beach volleyball","Bicycle","Bicycle racing","Billiards","Biography","Blackjack","Boat racing","Bowling","Boxing","Bullfighting","Business Financial","Canoe","Card games","Cooking","Cricket","Current Affairs","Diving","Documentary","Drag racing","Equestrian","Field hockey","Fishing","Football","Golf","Gymnastics","History","Hockey","Home Repair","Horse","How-To","Hunting","Indoor soccer","Law","Martial arts","Mixed martial arts","Motorcycle","Motorcycle racing","Motorsports","Mountain biking","Nature","News","Newsmagazine","Olympics","Outdoors","Poker","Politics","Pro wrestling","Racing","Rodeo","Roller derby","Rugby","Running","Sailing","Science Fiction","Shooting","Skateboarding","Skiing","Snowboarding","Snowmobile","Soccer","Sports Event","Sports Talk","Surfing","Swimming","Table tennis","Tennis"]}'
#for cbcf only
cbcfTimeWindows='[{"name":"Last6Months","lastDayNumber":180},{"name":"Month","lastDayNumber":30},{"name":"Week","lastDayNumber":14}]'


