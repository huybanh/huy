import os, sys, shutil
from upgradeParameter import *

if __name__ == "__main__":
	params = {
	'pigUdfURL':pigUdfURL,
	'pigUdfFolderName':pigUdfFolderName,
	'pigScriptURL':pigScriptURL,
	'workingDirectory':workingDirectory,
	'changedFolders':changedFolders,
	'svnExportForceCommand':svnExportForceCommand,
	'svnExportCommand':svnExportCommand,
	'mvnBuildCommand':mvnBuildCommand,
	'oldScriptFolderName':oldScriptFolderName,
	'newScriptFolderName':newScriptFolderName,
	'jarName':jarName
	}

	old_script_folder_path = os.getcwd() + '/' + params['oldScriptFolderName']
	new_script_folder_path = os.getcwd() + '/' + params['newScriptFolderName']
	params['workingDirectory'] = os.getcwd()
	
	#rename from old directory to new directory
	os.rename(params['oldScriptFolderName'], params['newScriptFolderName'])

	####################### CHECKING AND BUILD NEW JAR #############################
	checkout_UDF_command = params['svnExportCommand'] + params['pigUdfURL']
	os.system(checkout_UDF_command)

	#cd into UDF new code
	udfCodeAbsolutePath = os.getcwd() + '/' + params['pigUdfFolderName']
	os.chdir(udfCodeAbsolutePath)
	
	#build new code
	os.system(params['mvnBuildCommand'])
	#copy new code to working
	jarPath = os.getcwd() + '/target/' + params['jarName']
	shutil.copy(jarPath, new_script_folder_path)
	
	############################ UPDATING SCRIPT ###################################
	#cd into renamed script folder
	os.chdir(new_script_folder_path)

	#remove old and checkout new script folders
	for updated_package_URL_name in params['changedFolders']:
		#remove old folders
		shutil.rmtree(new_script_folder_path + '/' + updated_package_URL_name)
		#force overwrite checkout command
		checkout_command = params['svnExportForceCommand'] % (params['pigScriptURL'] + '/' + updated_package_URL_name)
		#execute command
		os.system(checkout_command)
