if [ $# -eq 1 ]; then
	echo '*****************EXCUTING CBCF JOB ************************'
	pig ./cbcf/production/firsttime-cbcf/CBCF.py $1
	
elif [ $# -eq 3 ]; then
	echo '*****************EXCUTING KINIT ************************'
	keytab = $1
	serviceaccount = $2

	if [[ -f action.xml ]]; then
		kinit -kt $1 $2
		export HBASE_CONF_DIR=.
	fi	
	
	echo '*****************EXCUTING CBCF JOB ************************'
	pig ./cbcf/production/firsttime-cbcf/CBCF.py $3
fi

result=$?
echo '*****************FINISHED CBCF JOB ************************'
if [ $result -eq 0 ]; then
	echo "Compute CBCF successfully"  
else
	echo "Compute CBCF unsuccessfully"
fi