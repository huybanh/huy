#!/usr/bin/python
################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

from common_properties import *
from production_cbcf_daily_properties import *
from org.apache.pig.scripting import Pig
import imp
import datetime
from datetime import datetime, timedelta
import sys
import os
import subprocess
import imp
from org.apache.hadoop.fs import *
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *


#location
currentLocation = os.getcwd();
common_lastbatch_python_script = currentLocation + common_lastbatch_python_script
common_util_script = currentLocation + '/common/Utils.py'
utils = imp.load_source('utils', common_util_script);

#initialize DI Integration
diIntegration = imp.load_source('dataAnalytic', common_lastbatch_python_script);

#validation parameters
config = HBaseConfiguration.create()
rjhTable = HTable(config, validation_table)
fileSystem = FileSystem.get(config)

def runPig():
	pigScriptingExcutor = Pig.compileFromFile(currentLocation + '/cbcf/production/daily-cbcf/MergeCBCF.pig');
	params = {
	'udfLib':udfLib,
	'cbcfOperationClass':cbcfOperationClass,
	'cbcfClass':cbcfClass,	
	'cbcfByDayClass':cbcfByDayClass,
	'userTasteClass':userTasteClass,
	'mainCategories':mainCategories,
	'allMainCategory':allMainCategory,
	'cbcfTimeWindows':cbcfTimeWindows,
	'adult':adult,
	'watchEvent':watchEvent,
	'dateTimeFormat':dateTimeFormat,
	'dateFormat':dateFormat,
	'excludingRule':rule,
	'userTaste_maxSize':userTaste_maxSize,
	'userTaste_mainCategoryNumber':userTaste_mainCategoryNumber,
	'userTaste_filter':userTaste_filter,
	'userTaste_filter_tms':userTaste_filter_tms,
	'userTaste_mainCategories':userTaste_mainCategories,
	'cbcfByDayData':cbcfByDayData,
	'cbcfData':cbcfData,
	'userTasteData':userTasteData,
	'newInsertedData':newInsertedData,
	'cbcfFromCBCFByDay':cbcfFromCBCFByDay,
	'invalidAccountId':invalidAccountId,
	'excludeGenreClass':excludeGenreClass,
	'rule':rule,
	'genreExcludedCbcfByDayData':genreExcludedCbcfByDayData,
	'genreExcludedCbcfData':genreExcludedCbcfData
	};
		

	
	try:
		#DI Integration	
		print '*****************************GETTING BATCHNUMBER***********************************'
		diIntegration.getLastBatchNumber(params, dataTypes, lookupTable, lookupTable_columnFamily,lookupTable_columnName);			
		params['newInsertedData']=params['newInsertedData'] + params['batchNumber_insertedTime']		
		if len(sys.argv)==2: #from oozie					
			params['batchNumber_current'] = str(sys.argv[1])			
		print params;		
		
				
		print '*********************************VALIDATION-FOR CBCF PRODUCTION DAILY*****************************************'					
		key_batch = params['batchNumber_current']				
		utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, params['cbcfData'] + params['batchNumber_cbcf'])	
		utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, params['cbcfByDayData'] + params['batchNumber_cbcf_by_day'])	
		utils.validateHDFS(rjhTable, validation_columnFamily, key_batch, validation_dataType, fileSystem, params['newInsertedData'])		
		utils.validateDate(rjhTable, validation_columnFamily, key_batch, validation_dataType, params['batchNumber_current'])
		utils.validateDate(rjhTable, validation_columnFamily, key_batch, validation_dataType, params['batchNumber_cbcf'])
		utils.validateDate(rjhTable, validation_columnFamily, key_batch, validation_dataType, params['batchNumber_cbcf_by_day'])
		
		#call pig script
		print '*****************************EXECUTING PIG SCRIPT***********************************'			
		stats = pigScriptingExcutor.bind(params).runSingle();
		if not stats.isSuccessful():
			print 'Pig job failed'
			sys.exit(0)
		
		#update batchnumbers
		print '*****************************UPDATING BATCHNUMBER TO ***********************************' + params['batchNumber_current']
		diIntegration.updateLookupTable(updatedTable, lookupTable_cbcfByDay_key, lookupTable_columnFamily, lookupTable_columnName, params['batchNumber_current'])
		diIntegration.updateLookupTable(updatedTable, lookupTable_cbcf_key, lookupTable_columnFamily, lookupTable_columnName, params['batchNumber_current'])
		params['genreExcludedCbcfData']= params['genreExcludedCbcfData'] +  params['batchNumber_current']
		params['genreExcludedCbcfByDayData']= params['genreExcludedCbcfByDayData'] +  params['batchNumber_current']
		
		#bulkload
		print '************************BULKLOADING **************************************'	
		bulkloadFilePath = currentLocation +'/bulkload/run.sh'
		bulkloadJarPath  = currentLocation + '/' + bulkload_jarName

		subprocess.call('%s %s %s %s %s %s %s %s %s %s ' % (bulkloadFilePath, bulkloadJarPath, bulkload_lookupTable, bulkload_familyName, bulkload_lookupKey_cbcf ,params['genreExcludedCbcfData'], bulkload_staging + bulkload_lookupKey_cbcf, params['batchNumber_current'], bulkload_archive, hadoop_lib), shell=True);	
		subprocess.call('%s %s %s %s %s %s %s %s %s %s ' % (bulkloadFilePath, bulkloadJarPath, bulkload_lookupTable, bulkload_familyName, bulkload_lookupKey_cbcfbyday ,params['genreExcludedCbcfByDayData'], bulkload_staging + bulkload_lookupKey_cbcfbyday, params['batchNumber_current'], bulkload_archive, hadoop_lib), shell=True);	
	except:
		print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + validation_table + ' KEY ' + key_batch
		utils.updateFailedJobs(rjhTable, validation_columnFamily, key_batch, validation_dataType, "except", str(sys.exc_info()[1]))	
def main():
	runPig();

if __name__ == '__main__':
	main();
