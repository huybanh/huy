#!/usr/bin/python

from org.apache.pig.scripting import Pig

import sys
import os
import time
import subprocess
import imp
import datetime
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *

# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

lookupTableName='demo_5_2014_lookupTable'
config = HBaseConfiguration.create();
batchNumberPrefix='batchNumber_'

def lookupString(key, lookupTableName, familyName, columnQualifier):
	lookupTable = HTable(config, lookupTableName)
	lookupGet = Get(Bytes.toBytes(key))
	lookupGet.addColumn(Bytes.toBytes(familyName), Bytes.toBytes(columnQualifier))
	lookupResult = lookupTable.get(lookupGet)
	lookupValue = lookupResult.getValue(Bytes.toBytes(familyName), Bytes.toBytes(columnQualifier))
	if lookupValue == None or lookupValue == '':
		return ''
	return Bytes.toString(lookupValue, 0, len(lookupValue))

def getLastBatchNumber(params, dataTypes, lookupTable, familyName, columnQualifier):
	print "======Get last batch number for ====" + str(dataTypes)    
	for datatype in dataTypes:
		params[batchNumberPrefix + datatype] = lookupString(datatype, lookupTable, familyName, columnQualifier) 
	currentTime = datetime.now()
	batchNumber_current = currentTime.strftime("%Y%m%d%H%M%S")	
	params['batchNumber_current'] = batchNumber_current

def updateLookupTable(updatedTableName, key, column_family, column_name, value):
	updatedTable = HTable(config, updatedTableName)
	putList = []
	put = Put(Bytes.toBytes(key))
	put.add(Bytes.toBytes(column_family), Bytes.toBytes(column_name), Bytes.toBytes(value))
	putList.append(put)
	updatedTable.put(putList)
