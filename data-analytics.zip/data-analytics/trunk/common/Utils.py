#!/usr/bin/python

################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################


from org.apache.pig.scripting import Pig

import sys
import os
import time
import subprocess
import imp
import datetime
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
import datetime as dt
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

def executeJobWithRules(pigScriptingExcutor, params, filePath):
	fp = open(filePath)		
	for line in fp:			
		print line
 		pattern = re.compile(ur'(.+?)\s*=\s*\'(.+?)\'$')			
   		result = re.match(pattern, line)
		params['ruleName'] = result.group(1)
		params['rule'] = result.group(2)				
		pigScriptingExcutor.bind(params).runSingle();

def validateDate(validation_table, validation_columnFamily, validation_key, validation_type, inputDate, formatDate='%Y%m%d%H%M%S'):
		parsedDate = datetime.strptime(inputDate, formatDate)
		if parsedDate.strftime(formatDate) != inputDate:
			updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'validateDateTime', ['message', 'status'], [inputDate + ' is invalid format ' + formatDate, 'FAILED']);
			os._exit(1);    		
		
#********************************************************************************** ###

# whenever a step finished, status of job will be logged to recommendationjobhistory.
def updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, step, columns, values):
    putList = [];
    put = Put(Bytes.toBytes(validation_key));
    for index in range(len(columns)): 
        put.add(Bytes.toBytes(validation_columnFamily), Bytes.toBytes(str(validation_type) + '_' + str(step) + '_' + str(columns[index])), Bytes.toBytes(values[index]));
        putList.append(put);
    validation_table.put(putList);

# whenever any job failed, it will be logged to recommendationjobhistory.
def updateFailedJobs(validation_table, validation_columnFamily, validation_key, validation_type, step, message):
    columns = ['status', 'message'];
    values = ['FAILED', message];
    updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, step, columns, values);
    os._exit(1);
# Check if the parameters from properties file is empty?
def validate(param, paramName, errorList):
    if not param:
        errorList.append(paramName + ' is empty');

def validateParameters(validation_table, validation_columnFamily, validation_key, validation_type, paramArray, paramName):
    errorList = [];
    for i in range(len(paramArray)):
        validate(paramArray[i], paramName[i], errorList);
    if(len(errorList) > 0):
        updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'validateParameters', ['message', 'status'], [';'.join(errorList), 'FAILED']);
        os._exit(1);

# the purpos of this function is to check if folder on HDFS exist or not.
def validateHDFS(validation_table, validation_columnFamily, validation_key, validation_type, fileSystem, folder):
    path = Path(folder);
    if not fileSystem.exists(path):
        updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'validateHDFS', ['message', 'status'], [folder + ' is not exist', 'FAILED']);
        os._exit(1);    
    if not fileSystem.isDirectory(path):
        updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'validateHDFS', ['message', 'status'], [folder + ' is not folder', 'FAILED']);
        os._exit(1);
    ListofFiles = fileSystem.listStatus(path);
    if len(ListofFiles) == 0:
        updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'validateHDFS', ['message', 'status'], ['No news Data Files in ' + folder, 'FAILED']);
        os._exit(1);
                
# validation of batch number
def validateBatchNumber(validation_table, validation_columnFamily, validation_key, validation_type, columnName, paramArray, formatDate='%Y%m%d%H%M%S'):
    errorList = [];
    for i in range(len(paramArray)):
        parsedDate = paramArray.strptime(paramArray[i], formatDate)
        if parsedDate.strftime(formatDate) != paramArray[i]: errorList.append(paramArray[i] + ' is not a valid batch number');

    if (lookupString(validation_key, validation_table, validation_columnFamily, columnName) == paramArray[i]):
        return 0

    if(len(errorList) == 0):
        updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'batchNumber_current', [columnName], [paramArray]);
        os._exit(0);
    else:
        updateRjh(validation_table, validation_columnFamily, validation_key, validation_type, 'validateParameters', ['BN'], [paramArray]);
        os._exit(1);
    return
	
def findJobStateByAlias(processData, targetAlias):
    jobIterator = processData.getJobGraph().iterator();
    while jobIterator.hasNext():
        oneJob = jobIterator.next();
        if targetAlias in oneJob.getAlias():
            return oneJob;
            
def sumNumberRecords(inoutStatList):
    sum = 0;
    for oneState in inoutStatList:
        sum = sum + oneState.getNumberRecords();
    return sum;

# Return current date subtract the num day which need to get data in properties.py
def getDate(numDate):
    now = dt.datetime.now();
    then = now - dt.timedelta(days=int(numDate));
    newThen= then.strftime('%Y%m%d%H%M');
    return long(newThen);

def lookupBytes(key, lookupTable, familyName, columnQualifier):
    print "Looking up for " + familyName + ":" + columnQualifier + "@" + key
    lookupGet = Get(Bytes.toBytes(key))
    lookupGet.addColumn(Bytes.toBytes(familyName), Bytes.toBytes(columnQualifier))
    lookupResult = lookupTable.get(lookupGet)
    return lookupResult.getValue(Bytes.toBytes(familyName), Bytes.toBytes(columnQualifier))

def lookupInt(key, lookupTable, familyName, columnQualifier):
    lookupValue = lookupBytes(key, lookupTable, familyName, columnQualifier)
    return Bytes.toInt(lookupValue);

def lookupLong(key, lookupTable, familyName, columnQualifier):
    lookupValue = lookupBytes(key, lookupTable, familyName, columnQualifier)
    return Bytes.toLong(lookupValue);

def lookupString(key, lookupTable, familyName, columnQualifier):
    lookupValue = lookupBytes(key, lookupTable, familyName, columnQualifier)
    if lookupValue == None or lookupValue =='':
        return ''
    return Bytes.toString(lookupValue, 0, len(lookupValue))
