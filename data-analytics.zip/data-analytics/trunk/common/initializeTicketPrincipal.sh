#kinit -kt svc.cloudrec.dv2.keytab svc.cloudrec.dv2@DS.DTVENG.NET
#$# variable will tell you the number of input arguments the script was passed

if [ $# -le 1 ] 
  then
    echo "No arguments supplied. Cannot initialize ticket-grand for ticket principal"
  else   	
    echo 'keytabname = ' $1
    echo 'hostname = ' $2	 	
    kinit -kt $1 $2	  	
fi

