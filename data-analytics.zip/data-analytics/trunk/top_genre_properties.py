#library
flattenGenre='com.directv.pig.topgenre.TopGenreCBCF'
convertToVector='com.directv.pig.topgenre.ConvertFlattenToVector'
hadoop_home='$HADOOP_HOME:/opt/cloudera/parcels/CDH/lib/Hadoop'

#variables
adult='Adult'
watchEvent='Watch'
filteredGenres='["Adult","Series","TV Series","PlayOff","Mini-Series","Orginal Series","News","Shopping","Special","Specials","Religion","Weather","Highlights","Award Ceremony","Premiere","Premium TV"]'
useDefaultTopGenres=False
duplicatedGenres='[]'

#time window for 5 days
timeWindows='[{"name":"Last5Days","lastDayNumber":5}]'
timeWindowsName='Last5Days'
lastDayNumber=5

#time window for all days
#timeWindows='[{"name":"AllDays","lastDayNumber":-1}]'

#properties for DI integration
dataTypes = ['insertedTime']

#input
preparedData='/data/dv/recommendation/processed/prepareduvh/insertedtime='   #prepared Data location

#output
destinationHTable='production_topgenre'
destinationColFamily='cf:vector'

#default values
#useDefaultTopGenres=true
defaultMovies='Movies'
defaultMoviesValue='[{"value":11983.08022062944,"key":"Comedy"},{"value":11757.879964108934,"key":"Romance"},{"value":8792.466470018802,"key":"Animation"},{"value":8332.67515256641,"key":"Drama"},{"value":7946.417655238392,"key":"Fantasy"},{"value":4738.8875651627,"key":"Science Fiction"},{"value":3458.251015338179,"key":"Action/Adventure"},{"value":2404.3209661141477,"key":"Mystery/Crime"},{"value":1930.800484173921,"key":"Horror"},{"value":1915.3770765531474,"key":"Suspense"}]'
defaultTV='TV'
defaultTVValue='[{"value":139452.59497443272,"key":"Series"},{"value":48787.28086568365,"key":"Animation"},{"value":41281.341900181855,"key":"Mystery/Crime"},{"value":24001.35311981667,"key":"Fantasy"},{"value":18445.932889712203,"key":"Suspense"},{"value":9708.10690061766,"key":"Family"},{"value":5758.681814421687,"key":"History"},{"value":5636.986423003726,"key":"Cooking"},{"value":4965.829477011716,"key":"Horror"},{"value":4432.105652920485,"key":"Science Fiction"}]'
defaultSports='Sports'
defaultSportsValue='[{"value":11983.08022062944,"key":"Football"},{"value":11757.879964108934,"key":"Baseball"},{"value":8792.466470018802,"key":"Basketball"},{"value":8332.67515256641,"key":"Auto"},{"value":7946.417655238392,"key":"Soccer"},{"value":4738.8875651627,"key":"Racing"},{"value":3458.251015338179,"key":"Tennis"},{"value":2404.3209661141477,"key":"Boxing"},{"value":1930.800484173921,"key":"Motorcycle"},{"value":1915.3770765531474,"key":"Fishing"}]'

validation_type='topgenre'
