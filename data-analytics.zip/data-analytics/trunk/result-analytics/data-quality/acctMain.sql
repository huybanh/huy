USE ${hiveconf:database};
FROM ${hiveconf:uvh_table} INSERT INTO TABLE ${hiveconf:result_table} select insertedtime, accountid, MainCategory, sum(durationViewed/RunLength) as TotalViewedPercent where insertedtime = ${hiveconf:insertedtime} and MainCategory!= "Adult" and durationViewed>0 and runlength>0 group by insertedtime, accountid, MainCategory order by TotalViewedPercent desc limit 200;

FROM ${hiveconf:uvh_table} INSERT INTO TABLE ${hiveconf:result_table} select insertedtime, accountid, MainCategory, sum(durationViewed/RunLength) as TotalViewedPercent where insertedtime = ${hiveconf:insertedtime} and MainCategory!= "Adult" and MainCategory = 'Sports' and durationViewed>0 and runlength>0 group by insertedtime, accountid, MainCategory order by TotalViewedPercent desc limit 200;

FROM ${hiveconf:uvh_table} INSERT INTO TABLE ${hiveconf:result_table} select insertedtime, accountid, MainCategory, sum(durationViewed/RunLength) as TotalViewedPercent where insertedtime = ${hiveconf:insertedtime} and MainCategory!= "Adult" and MainCategory = 'Movies' and durationViewed>0 and runlength>0 group by insertedtime, accountid, MainCategory order by TotalViewedPercent desc limit 200;
