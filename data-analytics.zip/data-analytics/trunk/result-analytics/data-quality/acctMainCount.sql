USE ${hiveconf:database};
FROM ${hiveconf:uvh_table} INSERT INTO TABLE ${hiveconf:result_table} select insertedtime, accountid, MainCategory, count(*) as TotalViewedCount where insertedtime = ${hiveconf:insertedtime} and MainCategory!= "Adult" and durationViewed>0 and runlength>0 group by insertedtime, accountid, MainCategory order by TotalViewedCount desc limit 200;
