USE ${hiveconf:database};
FROM ${hiveconf:uvh_table} INSERT INTO TABLE ${hiveconf:result_table} select insertedtime, tmsID, count(distinct accountId) as TotalAccount where insertedtime = ${hiveconf:insertedtime} and durationViewed>0 and MainCategory!= "Adult" group by insertedtime, tmsid order by TotalAccount desc limit 200;
