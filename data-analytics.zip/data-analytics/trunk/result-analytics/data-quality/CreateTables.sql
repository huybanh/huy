USE ${hiveconf:database};

--create table to store result
DROP TABLE IF EXISTS ${hiveconf:sizetrend_table};

--mapping tables with HDFS
CREATE EXTERNAL TABLE ${hiveconf:sizetrend_table} (
	insertedtime bigint,
	accountID string,
	description string,
    NoRecs int
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS TEXTFILE LOCATION '${hiveconf:sizetrend_location}';

--create table to store result
DROP TABLE IF EXISTS ${hiveconf:dataquality_table};

--mapping tables with HDFS
CREATE EXTERNAL TABLE ${hiveconf:dataquality_table} (
	insertedtime bigint,
	description string,
	value int
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS TEXTFILE LOCATION '${hiveconf:dataquality_location}';

--create table to store result
DROP TABLE IF EXISTS ${hiveconf:MainRateTime_table};

--mapping tables with HDFS
CREATE EXTERNAL TABLE ${hiveconf:MainRateTime_table} (
	insertedtime bigint,
	accountID string, 
	MainCategory string, 
	totalviewedpercent float
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS TEXTFILE LOCATION '${hiveconf:MainRateTime_location}';

DROP TABLE IF EXISTS ${hiveconf:TmsIDAccount_table};

--mapping tables with HDFS
CREATE EXTERNAL TABLE ${hiveconf:TmsIDAccount_table} (
	insertedtime bigint,
	tmsID string, 
	totalAcct int
) 

ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS TEXTFILE LOCATION '${hiveconf:TmsIDAccount_location}';


--create table to store result
DROP TABLE IF EXISTS ${hiveconf:acctMain_table};

--mapping tables with HDFS
CREATE EXTERNAL TABLE ${hiveconf:acctMain_table} (
	insertedtime bigint,
	accountID string, 
	MainCategory string, 
	ViewedPercent float
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS TEXTFILE LOCATION '${hiveconf:acctMain_location}';

--create table to store result
DROP TABLE IF EXISTS ${hiveconf:acctMainCount_table};

--mapping tables with HDFS
CREATE EXTERNAL TABLE ${hiveconf:acctMainCount_table} (
	insertedtime bigint,
	accountID string, 
	MainCategory string, 
	ViewedCount int
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' STORED AS TEXTFILE LOCATION '${hiveconf:acctMainCount_location}';
