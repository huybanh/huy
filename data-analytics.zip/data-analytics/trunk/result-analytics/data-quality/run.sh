. ./conf.properties

# write sizetrend to hdfs
hive -hiveconf database=$database -hiveconf sizetrend_table=$result_table -hiveconf sizetrend_location=$all_base_dir -hiveconf dataquality_table=$abnormal_table -hiveconf dataquality_location=$abnormal_dir -hiveconf acctMain_table=$acctMain_table -hiveconf acctMain_location=$acctMain_dir -hiveconf acctMainCount_table=$acctMainCount_table -hiveconf acctMainCount_location=$acctMainCount_dir -hiveconf MainRateTime_table=$mainRate_table -hiveconf MainRateTime_location=$mainRate_dir -hiveconf TmsIDAccount_table=$tmsIDAccount_table -hiveconf TmsIDAccount_location=$tmsIDAccount_dir -f "CreateTables.sql"

status=$?
#
if [ $status -eq 0 ]; then
    echo "SUCCEED"
else
    echo "FAILED"
fi
# write sizetrend to hdfs
hive -hiveconf database=$database -hiveconf uvh_table=$uvh_table -hiveconf insertedtime=$insertedtime -hiveconf result_table=$result_table -f "sizetrend.sql"

status=$?
#
if [ $status -eq 0 ]; then
    echo "SUCCEED"
else
    echo "FAILED"
fi

hive -hiveconf database=$database -hiveconf uvh_table=$uvh_table -hiveconf insertedtime=$insertedtime -hiveconf result_table=$abnormal_table -f "dataquality.sql"
status=$?

if [ $status -eq 0 ]; then
    echo "SUCCEED"
else
    echo "FAILED"
fi

hive -hiveconf database=$database -hiveconf uvh_table=$uvh_table -hiveconf insertedtime=$insertedtime -hiveconf result_table=$acctMain_table -f "acctMain.sql"
status=$?

if [ $status -eq 0 ]; then
    echo "SUCCEED"
else
    echo "FAILED"
fi

hive -hiveconf database=$database -hiveconf uvh_table=$uvh_table -hiveconf insertedtime=$insertedtime -hiveconf result_table=$acctMainCount_table -f "acctMainCount.sql"
status=$?

if [ $status -eq 0 ]; then
    echo "SUCCEED"
else
    echo "FAILED"
fi

hive -hiveconf database=$database -hiveconf uvh_table=$uvh_table -hiveconf insertedtime=$insertedtime -hiveconf result_table=$mainRate_table -f "mainRateTime.sql"
status=$?

if [ $status -eq 0 ]; then
    echo "SUCCEED"
else
    echo "FAILED"
fi

hive -hiveconf database=$database -hiveconf uvh_table=$uvh_table -hiveconf insertedtime=$insertedtime -hiveconf result_table=$tmsIDAccount_table -f "tmsIDAccount.sql"
status=$?

if [ $status -eq 0 ]; then
    echo "SUCCEED"
    impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "invalidate metadata;"
else
    echo "FAILED"
fi
