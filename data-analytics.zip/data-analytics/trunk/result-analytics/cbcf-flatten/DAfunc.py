@outputSchema("AccountID:chararray; TV:int; Sports:int; Movies:int; Actor:int; Director:int; Theme:int; Mood:int; Tone:int")
def CountValues(acctID, windowsTime, _str, time):
	categories=[['Genre','TV'],['Genre','Movies'],['Genre','Sports'],
				['Tone','TV'],['Tone','Movies'],['Tone','Sports'],
				['Mood','TV'],['Mood','Movies'],['Mood','Sports'],
				['Theme','TV'],['Theme','Movies'],['Theme','Sports'],
				['Director','TV'],['Director','Movies'],['Director','Sports'],
				['Actor','TV'],['Actor','Movies'],['Actor','Sports'],
				['AllCategories']]
	arr = _str.split('},{')
	
	output = ''
	category = ''
	
	for cat in categories:
		i = 0
		cattmp = ''
		for _cat in cat:
			cattmp = cattmp + _cat
			if (_cat in windowsTime): i += 1
		if (i==len(cat)): category = category + cattmp #print windowsTime, ' belongs to ', cat

	for item in arr:
		_value=item.replace('[{','')
		value=_value.replace('}]','')
		#print value
		sub=value.split(',')
		_key = ''
		_value = ''
		for kk in sub:
			if ('key' in kk.split(':')[0]): _key = kk.split(':')[1] #print 'key ', kk.split(':')[1]
			if ('value' in kk.split(':')[0]): _value = kk.split(':')[1] #print 'value ', kk.split(':')[1]
		output = output + category + ';' + _key + ';' + _value + '\n'
	return output
