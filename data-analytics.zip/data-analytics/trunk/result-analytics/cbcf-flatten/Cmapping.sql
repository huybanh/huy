USE cloudrec;
DROP TABLE IF EXISTS cbcf_flattenSRC;
CREATE EXTERNAL TABLE cbcf_flattenSRC (
		Genre string,
		cbcf_key string,
		cbcf_value float
	)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '/data/dv/recommendation/results/CBCF/6monthsData.flatten';

DROP TABLE IF EXISTS cbcf_flattenDST;
CREATE EXTERNAL TABLE cbcf_flattenDST (
		Genre string,
		cbcf_key string,
		cbcf_value float
	)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '/data/dv/recommendation/results/CBCF/6monthsDataFinal.flatten';
