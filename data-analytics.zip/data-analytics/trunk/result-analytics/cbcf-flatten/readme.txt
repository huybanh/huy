These scripts extract the cbcf vector and its values.
To run the script correctly, there are some changes need to modify
on HDFS folder, cbcf source is on "/data/dv/recommendation/analytics/cbcf/result/" and because CBCF ran daily, 
its results stored by a name forms by date and hours, in order to run the script, there must provide this name
in the script, latest table named "cbcf_flattenDST", use this table by Hive or Impala should returns appropriate values

detail steps to change and run the script
1. change the cbcf data source in cbcf.pig, from line 20th, change the data folder to appropriate date folder
2. run the script by command ./run.sh
3. all csv files can open and modify by excel