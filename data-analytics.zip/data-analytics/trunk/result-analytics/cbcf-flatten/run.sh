pig -f cbcf.pig
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f Cmapping.sql
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f insert.sql
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='AllCategories' order by cbcf_value limit 1000000" -o "cbcf_all.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='AllCategories' and cbcf_value>0.75 order by cbcf_value desc limit 1000000" -o "cbcf_all.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='GenreTV' order by cbcf_value limit 1000000" -o "cbcf_genreTV.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='GenreMovies' order by cbcf_value limit 1000000" -o "cbcf_genreMovies.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='GenreSports' order by cbcf_value limit 1000000" -o "cbcf_genreSports.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ToneTV' order by cbcf_value limit 1000000" -o "cbcf_ToneTV.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ToneMovies' order by cbcf_value limit 1000000" -o "cbcf_ToneMovies.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ToneSports' order by cbcf_value limit 1000000" -o "cbcf_ToneSports.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='MoodSports' order by cbcf_value limit 1000000" -o "cbcf_MoodSports.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='MoodMovies' order by cbcf_value limit 1000000" -o "cbcf_MoodMovies.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='MoodTV' order by cbcf_value limit 1000000" -o "cbcf_MoodTV.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ThemeTV' order by cbcf_value limit 1000000" -o "cbcf_ThemeTV.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ThemeMovies' order by cbcf_value limit 1000000" -o "cbcf_ThemeMovies.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ThemeSports' order by cbcf_value limit 1000000" -o "cbcf_ThemeSports.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='DirectorSports' order by cbcf_value limit 1000000" -o "cbcf_DirectorSports.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='DirectorMovies' order by cbcf_value limit 1000000" -o "cbcf_DirectorMovies.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='DirectorTV' order by cbcf_value limit 1000000" -o "cbcf_DirectorTV.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ActorTV' order by cbcf_value limit 1000000" -o "cbcf_ActorTV.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ActorMovies' order by cbcf_value limit 1000000" -o "cbcf_ActorMovies.csv" -B;
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "use cloudrec; select cbcf_key, cbcf_value from cbcf_flattenDST where Genre='ActorSports' order by cbcf_value limit 1000000" -o "cbcf_ActorSports.csv" -B;