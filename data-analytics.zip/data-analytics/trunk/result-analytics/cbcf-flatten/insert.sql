use cloudrec;
insert into table cbcf_flattenDST select Genre, cbcf_key, cast(sum(cbcf_value) as float) from cbcf_flattenSRC group by Genre, cbcf_key;