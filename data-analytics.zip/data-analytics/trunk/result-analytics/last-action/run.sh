#impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f top_active_user.sql
. ./conf.properties
#permission
hadoop fs -mkdir $location_analysis
hadoop fs -chmod -R 777  $location_analysis

if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

#run hive scripts
hive $hadoopTokenClause -f "lastaction_result_analysis.sql" -hiveconf location_lastaction_result=$location_lastaction_result -hiveconf location_generic_type=$location_generic_type  -hiveconf location_watch=$location_watch  -hiveconf location_like=$location_like  -hiveconf location_purchase=$location_purchase  -hiveconf location_record=$location_record  -hiveconf location_watch_percentage=$location_watch_percentage  -hiveconf location_like_percentage=$location_like_percentage  -hiveconf location_purchase_percentage=$location_purchase_percentage  -hiveconf location_record_percentage=$location_record_percentage  -hiveconf location_result=$location_analysis 

status=$?
if [ $status -eq 0 ]; then
    echo "SUCCEED"
    impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "invalidate metadata;"
else
    echo "FAILED"
fi