-- mapping result of LastAction to Hive
use cloudrec;
DROP TABLE IF EXISTS  TUNL_LA_TEST2;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_LA_TEST2 (
	accountId string, 
	columnName string,
	lastaction_value string
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_lastaction_result}';


---------- general 
DROP TABLE IF EXISTS  TUNL_ANALYSIS_ALL_MAINCATEGORY;
CREATE EXTERNAL TABLE TUNL_ANALYSIS_ALL_MAINCATEGORY (
	accountId string, 
	total_count bigint
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_generic_type}';



INSERT OVERWRITE TABLE  TUNL_ANALYSIS_ALL_MAINCATEGORY 
SELECT accountId, count(*) as total_count
FROM TUNL_LA_TEST2 
GROUP BY accountId;


-------- sepecific type
---- Watch 
DROP TABLE IF EXISTS  TUNL_ANALYSIS_WATCH;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_WATCH (
	accountId string, 
	total_count bigint
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_watch}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_WATCH
select a.accountId,  count(*)  from  TUNL_LA_TEST2 a 
where a.columnName like '%.Watch.%' group by a.accountId;



DROP TABLE IF EXISTS  TUNL_ANALYSIS_WATCH_PERCENTAGE;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_WATCH_PERCENTAGE (
	accountId string, 
	watch_percentage double
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_watch_percentage}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_WATCH_PERCENTAGE
select a.accountId,  cast(a.total_count as double)/cast( b.total_count as double)*100.0  from  TUNL_ANALYSIS_WATCH a inner join TUNL_ANALYSIS_ALL_MAINCATEGORY b on a.accountId = b.accountId;



--- Purchase
DROP TABLE IF EXISTS  TUNL_ANALYSIS_PURCHASE;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_PURCHASE (
	accountId string, 
	total_count bigint
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_purchase}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_PURCHASE
select a.accountId,  count(*)  from  TUNL_LA_TEST2 a 
where a.columnName like '%.Purchase.%' group by a.accountId;



DROP TABLE IF EXISTS  TUNL_ANALYSIS_PURCHASE_PERCENTAGE;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_PURCHASE_PERCENTAGE (
	accountId string, 
	purchase_percentage double
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_purchase_percentage}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_PURCHASE_PERCENTAGE
select a.accountId,  cast(a.total_count as double)/cast( b.total_count as double)*100.0  from  TUNL_ANALYSIS_PURCHASE a inner join TUNL_ANALYSIS_ALL_MAINCATEGORY b on a.accountId = b.accountId;

---- record
DROP TABLE IF EXISTS  TUNL_ANALYSIS_RECORD;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_RECORD (
	accountId string, 
	total_count bigint
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_record}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_RECORD
select a.accountId,  count(*)  from  TUNL_LA_TEST2 a 
where a.columnName like '%.Record.%' group by a.accountId;



DROP TABLE IF EXISTS  TUNL_ANALYSIS_RECORD_PERCENTAGE;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_RECORD_PERCENTAGE (
	accountId string, 
	record_percentage double
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_record_percentage}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_RECORD_PERCENTAGE
select a.accountId,  cast(a.total_count as double)/cast( b.total_count as double)*100.0  from  TUNL_ANALYSIS_RECORD a inner join TUNL_ANALYSIS_ALL_MAINCATEGORY b on a.accountId = b.accountId;

--- like
DROP TABLE IF EXISTS  TUNL_ANALYSIS_LIKE;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_LIKE (
	accountId string, 
	total_count bigint
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_like}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_LIKE
select a.accountId,  count(*)  from  TUNL_LA_TEST2 a 
where a.columnName like '%.Like.%' group by a.accountId;



DROP TABLE IF EXISTS  TUNL_ANALYSIS_LIKE_PERCENTAGE;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_LIKE_PERCENTAGE (
	accountId string, 
	like_percentage double
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_like_percentage}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_LIKE_PERCENTAGE
select a.accountId,  cast(a.total_count as double)/cast( b.total_count as double)*100.0  from  TUNL_ANALYSIS_LIKE a inner join TUNL_ANALYSIS_ALL_MAINCATEGORY b on a.accountId = b.accountId;


------- aggreate for each user
DROP TABLE IF EXISTS  TUNL_ANALYSIS_RESULT;
CREATE EXTERNAL TABLE IF NOT EXISTS TUNL_ANALYSIS_RESULT (
	accountId string, 
	watch_percentage double,
	record_percentage double,
	purchase_percentage double,
	like_percentage double,
	
	watch_count double,
	record_count double,
	purchase_count double,
	like_count double
) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '${hiveconf:location_result}';

INSERT OVERWRITE TABLE  TUNL_ANALYSIS_RESULT
select watch.accountId,  
 CASE 
     WHEN watch.watch_percentage is null THEN 0.0 
	 ELSE watch.watch_percentage
  END as watch_percentage,		  
  CASE 
     WHEN purchase.purchase_percentage is null THEN 0.0 
	 ELSE purchase.purchase_percentage
  END as purchase_percentage,	   
  CASE 
     WHEN record.record_percentage is null THEN 0.0 
	 ELSE record.record_percentage
  END as record_percentage,		  
  CASE 
     WHEN like_.like_percentage is null THEN 0.0 
	 ELSE like_.like_percentage
  END as like_percentage ,
  
  CASE 
     WHEN watch_count.total_count is null THEN 0.0 
	 ELSE watch_count.total_count-1
  END as watch_count ,
  CASE 
     WHEN record_count.total_count is null THEN 0.0 
	 ELSE record_count.total_count-1
  END as record_count ,
  CASE 
     WHEN purchase_count.total_count is null THEN 0.0 
	 ELSE purchase_count.total_count
  END as purchase_count,
CASE 
     WHEN like_count.total_count is null THEN 0.0 
	 ELSE like_count.total_count-1
  END as like_count 
from  TUNL_ANALYSIS_ALL_MAINCATEGORY general
left join TUNL_ANALYSIS_WATCH_PERCENTAGE watch on general.accountId = watch.accountId
left join TUNL_ANALYSIS_RECORD_PERCENTAGE record on general.accountId = record.accountId
left join TUNL_ANALYSIS_PURCHASE_PERCENTAGE purchase on general.accountId = purchase.accountId
left join TUNL_ANALYSIS_LIKE_PERCENTAGE like_ on general.accountId = like_.accountId
left join TUNL_ANALYSIS_WATCH watch_count on general.accountId = watch_count.accountId
left join TUNL_ANALYSIS_RECORD record_count on general.accountId = record_count.accountId
left join TUNL_ANALYSIS_PURCHASE purchase_count on general.accountId = purchase_count.accountId
left join TUNL_ANALYSIS_LIKE like_count on general.accountId = like_count.accountId;