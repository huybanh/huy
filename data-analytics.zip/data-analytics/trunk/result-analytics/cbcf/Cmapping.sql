USE cloudrec;
DROP TABLE IF EXISTS cbcfSRC;
CREATE EXTERNAL TABLE cbcfSRC (
		accountId string, 
		Genre_TV int,
		Genre_Movies int,
		Genre_Sports int,
		Actor_TV int, 
		Actor_Movies int, 
		Actor_Sports int, 
		Director_TV int, 
		Director_Movies int, 
		Director_Sports int, 
		Theme_TV int, 
		Theme_Movies int, 
		Theme_Sports int, 
		Mood_TV int, 
		Mood_Movies int, 
		Mood_Sports int, 
		Tone_TV int,
		Tone_Movies int,
		Tone_Sports int
	)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '/data/dv/recommendation/results/CBCF/6monthsData';

DROP TABLE IF EXISTS cbcfDST;
CREATE EXTERNAL TABLE cbcfDST (
		accountId string, 
		Genre_TV int,
		Genre_Movies int,
		Genre_Sports int,
		Actor_TV int, 
		Actor_Movies int, 
		Actor_Sports int, 
		Director_TV int, 
		Director_Movies int, 
		Director_Sports int, 
		Theme_TV int, 
		Theme_Movies int, 
		Theme_Sports int, 
		Mood_TV int, 
		Mood_Movies int, 
		Mood_Sports int, 
		Tone_TV int,
		Tone_Movies int,
		Tone_Sports int
	)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
LOCATION '/data/dv/recommendation/results/CBCF/6monthsDataFinal';
