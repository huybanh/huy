@outputSchema("AccountID:chararray; TV:int; Sports:int; Movies:int; Actor:int; Director:int; Theme:int; Mood:int; Tone:int")
def CountValues(acctID, windowsTime, _str, time):
	arr = _str.split('},{')
	NoAttr = len(arr)
	hasWrong = False
	for item in arr:
			twodot = item.split(':')
			for unit in twodot:
				if ('TV' in unit): hasWrong = True
				if ('Sports' in unit): hasWrong = True
				if ('Movies' in unit): hasWrong = True
	if (hasWrong): NoAttr = NoAttr - 3
	Actor_TV = 0
	Actor_Movies = 0
	Actor_Sports = 0
	Director_TV = 0
	Director_Movies = 0
	Director_Sports = 0
	Theme_TV = 0
	Theme_Movies = 0
	Theme_Sports = 0
	Mood_TV = 0
	Mood_Movies = 0
	Mood_Sports = 0
	Tone_TV = 0
	Tone_Movies = 0
	Tone_Sports = 0
	Genre_TV = 0
	Genre_Movies = 0
	Genre_Sports = 0
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Theme' in windowsTime)): Theme_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Theme' in windowsTime)): Theme_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Theme' in windowsTime)): Theme_Sports = NoAttr
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Actor' in windowsTime)): Actor_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Actor' in windowsTime)): Actor_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Actor' in windowsTime)): Actor_Sports = NoAttr
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Director' in windowsTime)): Director_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Director' in windowsTime)): Director_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Director' in windowsTime)): Director_Sports = NoAttr
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Theme' in windowsTime)): Theme_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Theme' in windowsTime)): Theme_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Theme' in windowsTime)): Theme_Sports = NoAttr
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Mood' in windowsTime)): Mood_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Mood' in windowsTime)): Mood_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Mood' in windowsTime)): Mood_Sports = NoAttr
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Tone' in windowsTime)): Tone_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Tone' in windowsTime)): Tone_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Tone' in windowsTime)): Tone_Sports = NoAttr
	if ((time in windowsTime) and ('TV' in windowsTime) and ('Genre' in windowsTime)): Genre_TV = NoAttr
	if ((time in windowsTime) and ('Movies' in windowsTime) and ('Genre' in windowsTime)): Genre_Movies = NoAttr
	if ((time in windowsTime) and ('Sports' in windowsTime) and ('Genre' in windowsTime)): Genre_Sports = NoAttr
	
	output = acctID + ';'+ str(Genre_TV) + ';' + str(Genre_Movies) + ';' + str(Genre_Sports)  + \
			';' + str(Actor_TV) + ';' + str(Actor_Movies) + ';' + str(Actor_Sports) + \
			';' + str(Director_TV) + ';' + str(Director_Movies) + ';' + str(Director_Sports) + \
			';' + str(Theme_TV) + ';' + str(Theme_Movies) + ';' + str(Theme_Sports) + \
			';' + str(Mood_TV) + ';' + str(Mood_Movies) + ';' + str(Mood_Sports) + \
			';' + str(Tone_TV) + ';' + str(Tone_Movies) + ';' + str(Tone_Sports)
	return output
