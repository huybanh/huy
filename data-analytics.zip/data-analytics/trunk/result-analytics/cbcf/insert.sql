use cloudrec;
from cbcfSRC insert into table cbcfDST select accountId, sum(Genre_TV) as Genre_TV, sum(Genre_Movies) as Genre_Movies, sum(Genre_Sports) as Genre_Sports, 
		sum(Actor_TV) as Actor_TV, sum(Actor_Movies) as Actor_Movies, sum(Actor_Sports) as Actor_Sports, 
		sum(Director_TV) as Director_TV, sum(Director_Movies) as Director_Movies, sum(Director_Sports) as Director_Sports, 
		sum(Theme_TV) as Theme_TV, sum(Theme_Movies) as Theme_Movies, sum(Theme_Sports) as Theme_Sports, 
		sum(Mood_TV) as Mood_TV, sum(Mood_Movies) as Mood_Movies, sum(Mood_Sports) as Mood_Sports, 
		sum(Tone_TV) as Tone_TV, sum(Tone_Movies) as Tone_Movies, sum(Tone_Sports) as Tone_Sports group by accountId;