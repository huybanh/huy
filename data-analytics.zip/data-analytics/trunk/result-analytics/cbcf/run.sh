pig -f cbcf.pig
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f Cmapping.sql
impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f insert.sql