FeatureSelection <- function(inputCBCF, outData, varsKeep, firstTime = TRUE, 
  orphanFile = "noCluster.csv", fileSys = RxGetFileSystem()) {
  # Select the cbcf vectors to be extracted for clustering algo.
  # Args: 
  #   inputCBCF: input CBCF as an RxXdfData.
  #   outData: output RxXdfData result.
  #   varsKeep: all the variables to be kept.
  #   orphanFile: CSV file containing list of accountid to be selected.
  #   firstTime: is this featureSelection run for the first time or when re-clustering.
  #   fileSys: File system of input and output data.
  # Returns:
  #   NULL
  
	#selection condition: all users not belonging to any cluster will be re-selected 
	# with additional information (one more cbcf vector)
  filter.data.frame <- NULL
  if (firstTime == FALSE) {
    cat("Loading account list...\n")
    filter.data.frame <- read.csv(orphanFile)
    cat("Successful\n")
  } 
  cat("Selecting features...\n")
  if (is.null(filter.data.frame)) {
    rxDataStep(inData = inputCBCF, outFile= outData, varsToKeep = c("accountid", varsKeep), 
	  overwrite = TRUE)	
  } else {
    rxDataStep(inData = inputCBCF, outFile= outData, transformObjects = list(toKeep = filter.data.frame), rowSelection = (accountid %in% toKeep[["accountid"]]), varsToKeep = c("accountid", varsKeep), overwrite = TRUE)	
  }
  cat("Successful.\n")
}