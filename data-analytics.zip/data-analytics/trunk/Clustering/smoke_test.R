source("clustering_config.R")


dir1 <- "/home/svc.cloudrec.dv2/ThachLN1/CBCF/tmp1.xdf"
dir2 <- "/home/svc.cloudrec.dv2/ThachLN1/CBCF/tmp2.xdf"



                                               
                                               

ClassificationSmokeTest <- function() {
  in.data <- data.frame(accountid = c("a1","a2","a3"),SG1 = c(0.5,1,0.5),SG2 = c(0,1,2),SG3 = c(0,1,1.5)
                                               ,G1 = c(0,1,0.4),G2 = c(0,1,0.2),G3 = c(0,1,1.4),stringsAsFactors = FALSE)
  correct.out <- data.frame(accountid = c("a2","a3"),SG1 = c(1,0.5),SG2 = c(1,2),SG3 = c(1,1.5)
                                               ,G1 = c(1,0.4),G2 = c(1,0.2),G3 = c(1,1.4),stringsAsFactors = FALSE)
  rxDataStep(inData = in.data, outFile = dir1, overwrite = TRUE)
  logic.exp <- "(G1 + G2 + G3 + SG1 + SG2 + SG3) > 0.5"
  FilterAccountsByExpression(dir1,dir2,logic.exp,fileSystem = file.system)
  out.data <- rxDataStep(dir2)
  
  return(all.equal(correct.out == out.data))
}

MinMaxNormalizationSmokeTest <- function() {
  in.data <- data.frame(accountid = c("a1","a2","a3"),SG1 = c(0.5,1,0.5),SG2 = c(0,1,2),SG3 = c(0,1,1.5)
                                               ,G1 = c(0,1,0.4),G2 = c(0,1,0.2),G3 = c(0,1,1.4),stringsAsFactors = FALSE)
  correct.out <- data.frame(accountid = c("a1","a2","a3"),SG1 = c(1,0.5,0),SG2 = c(0,0.5,1),SG3 = c(0,0.5,2/3)
                                               ,G1 = c(0,0.5,1/6),G2 = c(0,0.5,0),G3 = c(0,0.5,1),stringsAsFactors = FALSE)
  rxDataStep(inData = in.data, outFile = dir1, overwrite = TRUE)
  NormalizeCBCFByTransformFunc(dir1, dir2, list(SG = c("SG1","SG2","SG3"), G = c("G1","G2","G3")), func = NormalizeMinMaxFunc, fileSystem = file.system)
  out.data <- rxDataStep(dir2) 
  
  return(all.equal(correct.out, out.data))
}

QuartileNormalizationSmokeTest <- function() {
  in.data <- data.frame(accountid = c("a1","a2","a3"),SG1 = c(0.5,1,0.5),SG2 = c(0,1,2),SG3 = c(0,1,1.5)
                                               ,G1 = c(0,1,0.4),G2 = c(0,1,0.2),G3 = c(0,1,1.4),stringsAsFactors = FALSE)
  correct.out <- data.frame(accountid = c("a1","a2","a3"),SG1 = c(1,0.5,0.25),SG2 = c(0.25,0.5,1),SG3 = c(0.25,0.5,0.5)
                                               ,G1 = c(0.5,0.5,0.5),G2 = c(0.5,0.5,0.25),G3 = c(0.5,0.5,1),stringsAsFactors = FALSE)
  rxDataStep(inData = in.data, outFile = dir1, overwrite = TRUE)
  NormalizeCBCFByTransformFunc(dir1, dir2, list(SG = c("SG1","SG2","SG3"), G = c("G1","G2","G3")), func = NormalizeQuartileFunc, fileSystem = file.system)
  out.data <- rxDataStep(dir2)   
  
  return(all.equal(correct.out, out.data))
}

TestClusterSmokeTest <- function() {
  in.data <- data.frame(cluster = c(1,2,2),accountid = c("a1","a2","a3"),SG1 = c(0.5,1,0.5),SG2 = c(0,1,2),SG3 = c(0,1,1.5)
                                               ,G1 = c(0,1,0.4),G2 = c(0,1,0.2),G3 = c(0,1,1.4),stringsAsFactors = FALSE)
  correct.out <- data.frame(cluster = c(1,2), pass = c(TRUE,FALSE))
  rxDataStep(inData = in.data, outFile = dir1, overwrite = TRUE)
  out.table <- TestCluster(dir1, "cluster", c("SG1","SG2","SG3","G1","G2","G3"), list(top=c(0.1,0.4),bottom=c(0.1,0.1)), clusterSize = list(1,2), fileSystem = file.system)
  
  print(out.table)
  return(all.equal(correct.out, out.table))
}

ClusterRepresentativeTest <- function() {
  in.filter.data <- data.frame(accountid = c("a1","a2","a3"),SG1 = c(0.5,1,0.5),SG2 = c(0,1,2),SG3 = c(0,1,1.5)
                                               ,G1 = c(0,1,0.4),G2 = c(0,1,0.2),G3 = c(0,1,1.4),stringsAsFactors = FALSE)
  in.cluster.data <- data.frame(accountid = c("a1","a2","a3"),cluster = c(1,2,2),SG1 = c(1,0.5,0),SG2 = c(0,0.5,1),SG3 = c(0,0.5,2/3)
                                               ,G1 = c(0,0.5,1/6),G2 = c(0,0.5,0),G3 = c(0,0.5,1),stringsAsFactors = FALSE)
  correct.out <- data.frame(cluster = 1, accountid = as.character("a1"),stringsAsFactors = FALSE)
  rxDataStep(inData = in.cluster.data, outFile = dir1, overwrite = TRUE)
  rxDataStep(inData=in.filter.data, outFile= dir2, overwrite = TRUE)
  out.table <- ProduceRepresentative(dir1, 1, dir2)
  
  print(out.table)
  return(all.equal(correct.out, out.table))
}