#
 # DIRECTV PROPRIETARY
 # Copyright© 2014 DIRECTV, INC.
 # UNPUBLISHED WORK
 # ALL RIGHTS RESERVED
 #
 # This software is the confidential and proprietary information of
 # DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,
 # distribution or disclosure of the software or Proprietary Information,
 # in whole or in part, must comply with the terms of the license
 # agreement, nondisclosure agreement or contract entered into with
 # DIRECTV providing access to this software.
 #
#============================================================================== initialization =================================================================================

# Name node
myNameNode <- 'nn-h3'

# Maximum number of row is read by a chunk
maxRow <<- 1000000

# Total number of row for each processing data
maxProcessRow <<- 1000000

# Port 
myPort <- 8020

# Big data dir root
bigDataDirRoot <- "/"

# Share folder
hdfsShare <- paste("/user", Sys.info()[["user"]], sep="/")




GetHadoopComputeContext <- function() {
  RxHadoopMR(nameNode = myNameNode, hdfsShareDir = hdfsShare, showOutputWhileWaiting = TRUE, autoCleanup = TRUE, port = myPort)
}
GetHadoopFileSystem <- function() {
  RxHdfsFileSystem(hostName = myNameNode, port = myPort)
}

