source("setup.R")


FirstTimeCbcf <- function(number.day = 10, end.date = "20141030")
{
#DescriptionS: calculate CBCF for first time.
#
#Args: 
#   number.day: an integer number of days we that need to calculate CBCF up to end date
#   end.date: a string in format yyyymmdd describes end date (or today)   
#
#Example: FirstTimeCbcf(number.day=14,end.date="20141115",kMainHdfsDir="/data/dv/recommendation_backup/processed/prepareduvh") 
#will execute to calculate CBCF from 20141101 to 20141115 with data in kMainHdfsDir 

  #log file
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Running...\n"))
  log.file <- file.path(paste(getwd(), paste0("firsttimeCBCF",format(Sys.time(), "%Y%m%d%H%M%S"),".txt"), sep="/"))
  if (!file.exists(log.file)){
    file.create(log.file)
  }
  sink(log.file, type = c("output", "message"))
  if(number.day <= 0) {
    cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[ERROR]","number.day must be a positive integer\n"))
	stop()
  }
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Starting to calculate CBCF at first time\n"))
  rxSetComputeContext(my.hadoop.cluster)
  #clean all data of last running first
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Clean all data of last running\n"))
  clean.data()
  
  running.time <- system.time({
    #parsed cbcf data of first time running will be saved in kTempLocation
    FirstTimeParseDataToCbcf(number.day, end.date, hdfs = hdfs)
	k <- CbcfAggregationByDay(KFinalCbcfByday, kTempLocation)
	
	CBCF.aggregation.TIMEWINDOW(started.date = FindFirstDate(end.date,number.day), end.date = end.date, KFinalCbcfBytimewindow)
	
	# clean all data in temp folder after successfully aggregated
	if (k == 1){
	  file.remove(list.files(kTempLocation, full.names = TRUE))
	}
	
	})[3]
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Done!Running time:",running.time," seconds\n"))
  sink()
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Done!Running time:",running.time," seconds\n"))
}

DailyUpdate <- function(insertedtime = "20141217",number.day=180)
{
#Description: update CBCF daily
#
#Args:
#	insertedtime: a string in format yyyymmdd describes the date(end date or today) which up to that date the CBCF will be updated
#   number.day: an integer number describes number of days backwalk from insertedtime to update CBCF 

  rxSetComputeContext(my.hadoop.cluster)
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Running...\n"))
  log.file <- file.path(paste(getwd(), paste0("dailyUpdateCBCF",format(Sys.time(), "%Y%m%d%H%M%S"),".txt"), sep="/"))
  if (!file.exists(log.file)){
    file.create(log.file)
  }
  sink(log.file, type = c("output", "message"))
  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Starting to update CBCF\n"))
  #get cbcf for new dataset related to insertedtime
  rt <- system.time({
  
    get.data.time <- system.time({
	  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Get all CBCF from new dataset input\n"))
	  GetCbcfFromNewData(insertedtime)
	  CbcfAggregationByDay(KNewXdfLocation, kNewTempLocation)
	  cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]",paste("new CBCF has been saved in", KNewXdfLocation)))
	})[3]
	cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Done! Running time:",get.data.time," seconds\n"))
	cat("-------------------------\n")
	#update CBCF for CBCF by time window first
	today <- format(strptime(Sys.Date(), "%Y-%m-%d"), "%Y%m%d")
	cbcf.timewindow.time <- system.time({
	cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Update CBCF by time window\n"))
	UpdateCbcfByTimeWindow(end.date = insertedtime, number.day)
	})[3]
	cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Done! Running time: ",  cbcf.timewindow.time + get.data.time," seconds\n"))
	cat("-------------------------\n")
	#now update CBCF for CBCF by day
	cbcf.day.time <- system.time({
	cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Update CBCF by day\n"))
	i <- UpdateCbcfByDay(end.date = insertedtime, number.day)
	#if UpdateCbcfByDay successufull, we need to clean old cbcf data and temporarily data in daily directory
	if (i == 1){
	  file.remove(list.files(KOldCbcfByday, full.names = TRUE))
	  file.remove(list.files(kNewTempLocation, full.names = TRUE))
	  file.remove(list.files(KNewXdfLocation, full.names = TRUE))
	}
	
	})[3]
	cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Done! Running time: ",  cbcf.day.time + get.data.time," seconds\n"))
	cat("-------------------------\n")
	sink()
	cat(paste0("[",format(Sys.time(), "%Y-%m-%d %H:%M:%S"),"]:[INFO]","Done! Running time: ",  cbcf.day.time + get.data.time," seconds\n"))
	})[3]
	
	
}


GetFolderName <- function(number.day, first.date)
{
#Description: get vector of folder's name keeping data for calculating. This function will call function GetListDate(first.date,number.day)
#             to get list of dates to check whether they are existing in the kMainHdfsDir, then returns valid folder's names
#Arg:
#	number.day:an integer number describes number days need to get
#	first.date: a yyyymmdd format string describes the started date 	
  
  cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]", "Get all subfolders that keep files for executing\n"))
  temp <- rxHadoopListFiles(kMainHdfsDir, intern = TRUE)
  sub.folders <- vector(length = length(temp) - 1)
  pattern <- paste(kMainHdfsDir, "insertedtime=", sep = "/")
  j <- 1
  
  #because the first element of temp is not folder'name. it therefore begins with second element
  for (i in 2 : length(temp)){
    pos<-gregexpr(pattern, temp[i], fixed = TRUE, useBytes = TRUE)[[1]][1]
	sub.folders[j] <- substr(temp[i], pos, nchar(temp[i]))
	j=j+1
  }
  
  #call GetListDate to get list of dates 
  list.date <- GetListDate(number.day, first.date = first.date)
  input.dirs <- vector()
  k = 1
  
  for (i in 1 : length(list.date)){
    index.in.sub.folders <- match(sub.folders[gregexpr(list.date[i], sub.folders, fixed = TRUE, useBytes = TRUE) != -1], sub.folders)
	
	if (length(index.in.sub.folders) != 0){
	  n <- length(index.in.sub.folders)
	  
	  for (j in 1 : n){
	    input.dirs[k] <- sub.folders[index.in.sub.folders[j]]
		k = k + 1
	  }
	  
	}
	
  }
  return (input.dirs)
}


FindFirstDate <- function(end.date, number.day)
{
#Description: find the first date based on the end.date and number.day parameters
#
#Args:
# 	end.date: a string in yyyymmdd format describe the end.date. For example: "20141112"
#	number.day: an integer number describes number of days among first date and end date

  end.date <- as.Date(end.date, "%Y%m%d")
  first.date <- end.date - number.day + 1
  first.date <- format(strptime(first.date, "%Y-%m-%d"), "%Y%m%d") 
  return(first.date)
}


GetListDate <- function(first.date, number.day)
{
#Description:get all dates since firstdate plus number.day.This function will return vector 
#            keeping number of days included the firstdate
#Args:
#  first.date: a string in yyyymmdd describes the first date to begin counting
#  number.day: an integer number describes number days since the first date to return
  
  result <- vector(length = number.day)
  result[1] <- first.date			
  first.date <- as.Date(first.date, "%Y%m%d")
  
  if (number.day > 1){
    for (i in 1 : (number.day - 1)){
      temp.date <- first.date + i
	  temp.date <- format(strptime(temp.date, "%Y-%m-%d"), "%Y%m%d") 
	  result[i + 1] <- temp.date
    }
	
  }
  
  return(result)
}

FirstTimeParseDataToCbcf <- function(number.day, end.date,hdfs)
{
#Description:parse data to CBCF for first time running
#
#Args:
#  number.day: an integer number describes number days need to parse from data set
#  end.date: a string in yyyymmdd describes end date to process

  first.date <- FindFirstDate(end.date, number.day)
  left.date <- format(strptime(as.Date(first.date, "%Y%m%d") - 1, "%Y-%m-%d"), "%Y%m%d")
  right.date <- format(strptime(as.Date(end.date, "%Y%m%d") + 1, "%Y-%m-%d"), "%Y%m%d")
  cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]", paste("Calculate CBCF with data from ", first.date, " to ", end.date), "\n"))
  input.dirs <- GetFolderName( number.day, first.date)
  
  if (length(input.dirs[input.dirs == FALSE]) != number.day){
  
    # Reading data
	if (length(input.dirs) == 0){
	  cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[ERROR]", "There is no valid insertedtime folder to execute!\n"))
	  stop()
	}else{
	  print(input.dirs)
	  ParseDataToCbcf(input.dirs, 1, left.date, right.date)
	}
		
  }else{
      cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[ERROR]", paste("No data traced up to ", end.date, " Please select another day to calculate CBCF"),"\n"))
	  stop()
  }
	
}

ParseDataToCbcf <- function(input.dirs, first, left.date, right.date)
{
#Description: parse data in dataset (input folders) to cbcf
#
#Args: 
#input.dirs: vector of input folders link
#  first: + 0 if calling function is GetCbcfFromNewData
#  	      + 1 if calling function is FirstTimeParseDataToCbcf
#  left.date: left boundary of date
#  right.date: right boundary of date

  for (file.index in 1 : length(input.dirs )){
	input.dir <- file.path(input.dirs[file.index])
	cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]", paste("Loading data from ", input.dir, "...")))
	cat("\n")
	input.source <- RxTextData(file = input.dir, delimiter = ";", stringsAsFactors = FALSE,  
							   firstRowIsColNames = FALSE, colInfo = kColInfo, rowsPerRead = kMaxRow, 
							   missingValueString = "<NA>", fileSystem = hdfs)
							   
	parse.data.source <- RxXdfData(parse.data.dir, fileSystem = hdfs)
	
	xdf.data<-tryCatch({
	
						rxImport(inData = input.source, outFile = parse.data.source, missingValueString = "<NA>", stringsAsFactors = TRUE,
							     overwrite = TRUE, rowSelection = (durationviewed != "<NA>" & runlength != "<NA>" & interpretedeventtype == "Watch" & maincategory == "Movies"
							     & percentage != 0
							     & eventdate > left.date & eventdate < right.date),
							     transforms = list(percentage = durationviewed / runlength * 100),
							     transformObjects = list(left.date = left.date, right.date = right.date)
							    )
								
	cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]",paste0("Calculating CBCF for data in this folder...\n")))
	rxOpen(parse.data.source)
	isEmptyData <- FALSE
	#Read each chunk of data which is set maximum row is kMaxRow
	iBlock <- 1
	result <- data.frame(matrix(NA, nrow = 0, ncol = length(moviegroup) + 2))
	names(result) <- c("eventdate", "accountid", as.vector(moviegroup))
	
	while (!isEmptyData) {
	  numrow <- 0
	  all.data.fetch <- data.frame()
	  
	  while (numrow < kMaxProcessRow & isEmptyData == FALSE) {
	    block.data <- rxReadNext(parse.data.source)
		numrow <- numrow + length(block.data$accountid)
		
		
		if(length(block.data$accountid) != 0)
		  all.data.fetch <- rbind(all.data.fetch, block.data)
		else
		  isEmptyData = TRUE
		  
	  }#end while
	  
	  if(length(all.data.fetch)  != 0) {
	    cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]",paste0("Block ", iBlock," has ")))
		cat(paste0(numrow," records\n"))
		cat("Starting to calculate CBCF for all accountids in block ",iBlock,"...\n")
		
		running.time<-system.time({
		
		  foreach(i = 1:dim(all.data.fetch)[1]) %dopar%
		  {
		    eventdate <- all.data.fetch$eventdate[i]
			account<- all.data.fetch$accountid[i]
			value <- all.data.fetch$percentage[i]
			tmsid <- all.data.fetch$tmsid[i]
			gr.number <- gr.map.data$GROUPNUMBER[gr.map.data$TMSID == tmsid]
			a <- length(gr.number)
			
		if (eventdate > left.date && eventdate < right.date && value > 0 && a != 0){
			  genre.position <- mapping$genre[mapping$groupnumber == gr.number]
			  subgenre.position <- mapping$subgenre[mapping$groupnumber == gr.number]
			  movietype.position <- mapping$movietype[mapping$groupnumber == gr.number]
			  recommendation.position <- mapping$recommendationgr[mapping$groupnumber == gr.number]
			  temp.genre.vector <- c(rep(0, length(genre)))
			  temp.genre.vector[genre.position] <- value
			  temp.subgenre.vector <- c(rep(0, length(subgenre)))
			  temp.subgenre.vector[subgenre.position] <- value
			  temp.movietype.vector <- c(rep(0, length(movietype)))
			  temp.movietype.vector[movietype.position] <- value
			  temp.moviegroup.vector <- c(rep(0, length(moviegroup)))
			  temp.moviegroup.vector[recommendation.position] <- value
			  
			  temp.vector <- c(account, temp.moviegroup.vector, temp.movietype.vector, temp.subgenre.vector, temp.genre.vector)
			  temp.vector <- data.frame(as.list(temp.vector))
			  colnames(temp.vector) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
			  file.name <- paste(eventdate, "csv", sep = ".")
			  
			  if(first == 1){
			    filepath <- paste(kTempLocation, file.name, sep="/")
				write.table(temp.vector, file = filepath, sep = ",", eol = "\n", append = TRUE, col.names = FALSE, row.names = FALSE)
			  }else{
			    filepath <- paste(kNewTempLocation, file.name,sep = "/")
				write.table(temp.vector, file = filepath, sep = ",", eol = "\n", append = TRUE, col.names = FALSE, row.names = FALSE)
			  }
									
			}#enif
			
		   }#end for
		})[3]
		 cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]", paste("Done! Running time of calculating CBCF for block ", iBlock, " is:", running.time, sep = "")," seconds\n"))
	 	
       }#end if
	   
      #Fetch next block of data
      iBlock <- iBlock + 1
    }#end while
						},error = function(err){
						  cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[WARNING]",paste("Folder", input.source, "keeps data beyond date we calculate! Continue reading other folders...\n")))
						},finally = {
						  next
						})
						
	
	cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[INFO]",paste("Completed calculating CBCF with data in folder ", input.dir)))
	cat("\n")
						
  }# end for
}

CbcfAggregationByDay <- function(xdf.location, temp)
{
#Description:calculate CBCF by day from parsed cbcf set. it will be called by FirstTimeCbcf function
#            and UpdateCbcfByDay function
#Args:
#	xdf.location: is full link to directory keeps the output data under xdf format
#	temp: is full link to directory keeps temporary input parsed cbcf data

  if (file.exists(xdf.location)){
    unlink(xdf.location, recursive = TRUE)
  }
  
  dir.create(xdf.location, recursive = TRUE)
  
  #now loading the files to do aggregation
  foreach (i = 1 : length(list.files(temp))) %dopar%
  {
	result <- read.csv(file = file.path(paste(temp, list.files(temp)[i], sep="/")), stringsAsFactors = FALSE, header = FALSE)
	result[] <- lapply(result, function(x) type.convert(as.character(x)))
	cdata <- aggregate(result[, 2 : length(result)], by = list(result[, 1]), sum)
	names(cdata) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	##another format
	rxSetComputeContext('local')
	xdf.aggregation.file <- file.path(paste(xdf.location, substr(list.files(temp)[i], 1, nchar(list.files(temp)[i]) - 4), sep = "/"))
	fgenre <- paste("G", seq(1, 18), sep= "")
	fmoviegroup <- paste("MG", seq(1, 210), sep = "")
	fmovietype <- paste("MT", seq(1, 121), sep = "")
	fsubgenre <- paste("SG", seq(1, 49), sep = "")
	names(cdata) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	rxImport(inData = cdata, outFile = xdf.aggregation.file)
	rxSetComputeContext(my.hadoop.cluster)	
  }
  
  return(1)
}

CBCF.aggregation.TIMEWINDOW <- function(started.date, end.date, xdf.location)
{
#Description: calculate CBCF in time window from started.date to end.date
#
#Args:
#  started.date: a string in format yyyymmdd describes started date of time window
#  end.date: a string in format yyyymmdd describes end date of time window
#  xdf.location: location where keeps cbcf by day under xdf format

  rxSetComputeContext('local')
  
  if (!file.exists(xdf.location)){
    dir.create(xdf.location, recursive = TRUE)	
  }
  
  result <- data.frame(matrix(NA, nrow = 0, ncol = length(moviegroup) + length(movietype) + length(subgenre) + length(genre) + 1))
  names(result) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
  list.files <- list.files(KFinalCbcfByday)
  
  for (i in 1 : length(list.files)){
	date.in.file <- substr(list.files[i], 1, nchar(list.files[i]) - 4)
	
	if (date.in.file >= started.date && date.in.file <= end.date){
	  singlefile <- file.path(paste(KFinalCbcfByday, list.files[i], sep = "/"))
	  
	  if(!file.exists(singlefile))next
	  
	  temp.data <- rxDataStep(inData = singlefile)
	  names(temp.data) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	  result <- rbind(result,temp.data)
	  result[] <- lapply(result, function(x) type.convert(as.character(x)))
	  result <- aggregate(result[, 2 : length(result)], by = list(result[, 1]), sum)
	  names(result)<-c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	}
	
  }
		
  xdf.aggregation.file <- file.path(paste(xdf.location, paste(started.date, end.date, sep = "_"), sep = "/"))
  fgenre <- paste("G", seq(1, 18), sep= "")
  fmoviegroup <- paste("MG", seq(1, 210), sep = "")
  fmovietype <- paste("MT", seq(1, 121), sep = "")
  fsubgenre <- paste("SG", seq(1, 49), sep = "")
  names(result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
  rxImport(inData = result, outFile = xdf.aggregation.file)
  rxSetComputeContext(my.hadoop.cluster)
}

UpdateCbcfByTimeWindow <- function(end.date, number.day)
{
#Description: update CBCF by time window.
#
#Args:
#	end.date: a string in format yyymmdd describes end.date which is the last date to update
#	number.day: an integer describes number of days count down from the end.date
#
#EXAMPLE: UpdateCbcfByTimeWindow("20141115",14) will update CBCF with dates in range from 20141101 to 20141115  
  
  rxSetComputeContext('local')
  
  if(!file.exists(KOldCbcfBytimewindow)){
	dir.create(KOldCbcfBytimewindow,recursive = TRUE)
  }
  
  ##remove all CBCF in OLD
  file.remove(list.files(KOldCbcfBytimewindow, full.names = TRUE))
  ##copy file from FINAL to OLD 
  file.copy(list.files(KFinalCbcfBytimewindow,full.names = TRUE), KOldCbcfBytimewindow)
  #delete files in FINAL CBCF byday
  file.remove(list.files(KFinalCbcfBytimewindow, full.names = TRUE))
  first.date<- FindFirstDate(end.date, number.day)
  ### calculate CBCF for new data in range of first.date to end.date
  new.cbcf.files <- list.files(KNewXdfLocation)
  
  if(length(new.cbcf.files) == 0){
    cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[WARNING]"," There is no new CBCF to aggregate!\n"))
	stop()
  }
  
  list.files <- vector()
  j <- 1
  has.enddate <- FALSE
  
  for(i in 1 : length(new.cbcf.files)){
	temp <- substr(new.cbcf.files[i], 1, nchar(new.cbcf.files[i]) - 4)
	
	if(temp >= first.date && temp <= end.date){
	  list.files[j] <- new.cbcf.files[i]
	  j = j+1
	  
	  if(temp == end.date){
		has.enddate <- TRUE
	  }
	}
  }
  
  if (length(list.files) < 1){
	cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[WARNING]","There is no new update for CBCF in this time window\n"))
  }else{
	result <- data.frame(matrix(NA, nrow = 0, ncol = length(moviegroup) + length(movietype) + length(subgenre) + length(genre) + 1))
	names(result) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	length(result)
	
	for (i in 1 : length(list.files)){
	  temp.file <- file.path(paste(KNewXdfLocation, list.files[i], sep = "/"))
	  temp.newdata <- rxDataStep(inData = temp.file)
	  names(temp.newdata) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	  result <- rbind(result, temp.newdata)
	  result[] <- lapply(result, function(x) type.convert(as.character(x)))
	  result <- aggregate(result[, 2 : length(result)], by = list(result[, 1]), sum)
	  names(result) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	}#endfor
	
	##now add result above with old cbcf by time window
	#if has enddate in new dataset, we need to remove the oldest one in old cbcf
	sub.cbcf <- data.frame(matrix(NA, nrow = 0, ncol = length(moviegroup) + length(movietype) + length(subgenre) + length(genre) + 1))
	names(sub.cbcf) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[WARNING]","Remove Old CBCF\n"))
	
	if (has.enddate){
      date.to.remove <- FindFirstDate(end.date, number.day + 1)
	  removed.file <- file.path(paste(KFinalCbcfByday, date.to.remove, sep = "/"))
	  
      if (file.exists(paste(removed.file, "xdf", sep = "."))){
		remove.data <- rxDataStep(inData = removed.file)
		## subtract data in old.cbcf by remove.data
		remove.data[ , 2 : length(remove.data)] <- 0 - remove.data[ , 2 : length(remove.data)]
		names(remove.data) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
		sub.cbcf <- rbind(sub.cbcf, remove.data)
		names(sub.cbcf) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	  }
	  
	  old.cbcf.file <- file.path(list.files(KOldCbcfBytimewindow, full.names = TRUE))
	  old.cbcf.timewindow <- RxXdfData(old.cbcf.file)
	  rxOpen(old.cbcf.timewindow)
	  a <- rxReadNext(old.cbcf.timewindow)
	  names(a) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	  sub.cbcf <- rbind(sub.cbcf, a)
	  sub.cbcf[] <- lapply(sub.cbcf, function(x) type.convert(as.character(x)))
	  sub.cbcf <- aggregate(sub.cbcf[ , 2:length(sub.cbcf)], by = list(sub.cbcf[ , 1]), sum)
	  names(sub.cbcf) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	  
	  #add sub cbcf to result above to create final cbcf 
	  result <- rbind(result, sub.cbcf)
	  result[] <- lapply(result, function(x) type.convert(as.character(x)))
	  result <- aggregate(result[ , 2:length(result)], by = list(result[ , 1]), sum)
	  names(result) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	
	}
	
	#till this, result keeps data of new final cbcf
	xdf.aggregation.file <- file.path(paste(KFinalCbcfBytimewindow, paste(first.date, end.date,sep = "_"), sep = "/"))
	fgenre <- paste("G", seq(1, 18), sep= "")
	fmoviegroup <- paste("MG", seq(1, 210), sep = "")
	fmovietype <- paste("MT", seq(1, 121), sep = "")
	fsubgenre <- paste("SG", seq(1, 49), sep = "")
	names(result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	rxImport(inData = result, outFile = xdf.aggregation.file)
  }
  
  rxSetComputeContext(my.hadoop.cluster)	
}

UpdateCbcfByDay <- function(end.date, max.day = 180)
{
#Description:update CBCF by day. It calls CbcfAggregationByDay function to aggregate new CBCF data. It will return updated CBCF by day 
#            for those dates in range of end.date back to max.day days result will be saved into FINAL CBCF BY DAY
#Args:
#	end.date: string in yyyymmdd format describes end date 
#	max.day: integer number describes maximum number of days

  ##remove all files in OLD
  file.remove(list.files(KOldCbcfByday, full.names = TRUE))
  ##copy file from FINAL to OLD 
  file.copy(list.files(KFinalCbcfByday,full.names = TRUE), KOldCbcfByday)
  #delete files in FINAL CBCF byday
  file.remove(list.files(KFinalCbcfByday, full.names = TRUE))
  
  #calculate CBCF by day for new insertedtime 
  #kNewTempLocation saving new data
  #KNewXdfLocation will save new cbcf 
  CbcfAggregationByDay(KNewXdfLocation, kNewTempLocation)
  rxSetComputeContext('local')
  first.date <- FindFirstDate(end.date, max.day)
  ### now update total CBCF by day
  old.cbcf.files.temp <- list.files(KOldCbcfByday)
  old.cbcf.files <- vector()
  j <- 1
  
  for (i in 1:length(old.cbcf.files.temp)){
	date.temp <- substr(old.cbcf.files.temp[i], 1, nchar(old.cbcf.files.temp[i]) - 4)
	
	if(date.temp >= first.date && date.temp <= end.date){
	  old.cbcf.files[j] <- old.cbcf.files.temp[i]
	  j <- j + 1
	}
	
  }
  
  new.cbcf.files.temp <- list.files(KNewXdfLocation)
  j <- 1
  new.cbcf.files <- vector()
  
  for (i in 1:length(new.cbcf.files.temp))
  {
	date.temp <- substr(new.cbcf.files.temp[i], 1, nchar(new.cbcf.files.temp[i]) - 4)
	
	if(date.temp >= first.date && date.temp <= end.date){
		new.cbcf.files[j] <- new.cbcf.files.temp[i]
		j <- j + 1
	}
	
  }
  
  if (length(new.cbcf.files) != 0)
  {
	result <- data.frame(matrix(NA, nrow = 0, ncol = length(moviegroup) + length(movietype) + length(subgenre) + length(genre) + 1))
	names(result) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
	
	for (i in 1 : length(new.cbcf.files))
	{
	
	  if (new.cbcf.files[i] %in%  old.cbcf.files){
		#aggregation for this two cbcf
		olddata.file <- file.path(paste(KOldCbcfByday, new.cbcf.files[i], sep = "/"))
		newdata.file <- file.path(paste(KNewXdfLocation, new.cbcf.files[i], sep = "/"))
		temp.olddata <- rxDataStep(inData = olddata.file)
		temp.newdata <- rxDataStep(inData  = newdata.file)
		names(temp.olddata) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
		names(temp.newdata) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
		result <- rbind(result, temp.olddata)
		result <- rbind(result, temp.newdata)
		result[] <- lapply(result, function(x) type.convert(as.character(x)))
		result <- aggregate(result[ , 2 : length(result)], by = list(result[ , 1]), sum)
		names(result) <- c("accountid", as.vector(moviegroup), as.vector(movietype), as.vector(subgenre), as.vector(genre))
		xdf.aggregation.file <- file.path(paste(KFinalCbcfByday, substr(new.cbcf.files[i], 1, nchar(new.cbcf.files[i]) - 4), sep = "/"))
		rxImport(inData = result, outFile = xdf.aggregation.file)
		}else{
			file.copy(file.path(paste(KNewXdfLocation, new.cbcf.files[i], sep = "/")), KFinalCbcfByday)
		}#endif
		
	}#endfor
	
	if(length(old.cbcf.files[!old.cbcf.files %in% new.cbcf.files]) != 0){
	  temp.saved.file <- old.cbcf.files[!old.cbcf.files%in%new.cbcf.files]
	  
	  for(i in 1 : length(temp.saved.file)){
		file.copy(file.path(paste(KOldCbcfByday, temp.saved.file[i], sep = "/")), KFinalCbcfByday)
	  }
	  
	}
	
  }
  
  rxSetComputeContext(my.hadoop.cluster)
  
  # return 1 to inform updated successfully
  return(1)	
}

GetCbcfFromNewData <- function(insertedtime, max.date = 180)
{
#Description: get new CBCF for those accountids in new dataset defined by insertedtime. 
#             Output of this function is CBCFs of those accountids have events traced in dataset insertedtime.
#             The output will be keep temporarily in kNewTempLocation
#
#Args:
#	insertedtime: a string in format yyyymmdd describes the inserted time of data
#	max.date: an integer number describes maximum number of date need to get CBCF from new data set 

  rxSetComputeContext(my.hadoop.cluster)
  
  if(file.exists(kNewTempLocation)){
	unlink(kNewTempLocation,recursive = TRUE)
  }
  
  dir.create(kNewTempLocation,recursive = TRUE)
  left.date<-format(strptime(as.Date(insertedtime, "%Y%m%d") - max.date, "%Y-%m-%d"), "%Y%m%d")
  right.date<-format(strptime(as.Date(insertedtime, "%Y%m%d") + 1, "%Y-%m-%d"), "%Y%m%d")
  input.dirs<-GetFolderName(1, insertedtime)
  
  if(length(input.dirs) != 0){
	input.dirs<-RemoveInsertedTimeFolder(input.dirs)
	
	if(length(input.dirs) != 0){
	  ParseDataToCbcf(input.dirs, 0, left.date, right.date)
	}else{
	cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[ERROR]","This dataset has been processed!\n"))
	  stop()
	}	
  }else{
    cat(paste0("[", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "]:[ERROR]","No folder to process!\n"))
	stop()
   }
	
}

RemoveInsertedTimeFolder <- function(input.dirs)
{
#Description:remove all executed inserted time folder have been executed so far in this day. 
#            Output of this function is a list name of folders that have not been executed so far
#Args:
#  input.dirs: a list of input.dirs keeps new dataset
# 
#Returns: result which keeps the insertedtimes  haven't executed yet

  inserted.list <- input.dirs
  a <- scan(file = executedFolder.file, what = character())
  result <- setdiff(inserted.list, a)
  
  if (length(result) != 0){
   write.table(result, file = executedFolder.file, append = TRUE, col.names = FALSE, sep = "\n", row.names = FALSE)
   return (result)
  }else{
   return ("")
  }

}
