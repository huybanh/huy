#
 # DIRECTV PROPRIETARY
 # Copyright© 2014 DIRECTV, INC.
 # UNPUBLISHED WORK
 # ALL RIGHTS RESERVED
 #
 # This software is the confidential and proprietary information of
 # DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,
 # distribution or disclosure of the software or Proprietary Information,
 # in whole or in part, must comply with the terms of the license
 # agreement, nondisclosure agreement or contract entered into with
 # DIRECTV providing access to this software.
 #
#============================================================================== initialization =================================================================================

# Name node
my.name.node <- 'nn-h3'
# Port 
my.port <- 8020
# Maximum number of row is read by a chunk
kMaxRow <<- 1000000
# Total number of row for each processing data
kMaxProcessRow <<- 1000000
# Big data dir root
big.data.dir.root <- "/"
working.dir <- getwd()
# Share folder
hdfs.share <- paste("/user", Sys.info()[["user"]], sep = "/")
kMainHdfsDir <<- "/data/dv/recommendation/processed/prepareduvh"
# This is main folder on hdfs that keeps subfolders which in turn keeping files for calculation
#kMainHdfsDir<-"/data/dv/recommendation/processed/prepareduvh"
# Local location to save result
#local.output.dir<-"/home/tmp.aepoc1/ChanhNLT/CBCF/result"
local.output.dir <- file.path(paste(working.dir,"result",sep="/"))
#HDFS location to save result
#hdfs.output.dir<-"/user/tmp.aepoc1/Namhnt/ChanhNLT/CBCF/result"
hdfs.output.dir <- "/user/svc.cloudrec.dv2/CHANHNLT1/CBCF/result"
# Xdf output location
#parse.data.dir <- "/user/tmp.aepoc1/Namhnt/ChanhNLT/CBCF/Output/TEST"
parse.data.dir <- "/user/svc.cloudrec.dv2/CHANHNLT1/XDFFOLDER"

inputSchema <<- list (V1 = list(newName = "accountid", type = "character"),
					  V2 = list(newName = "columnName", type = "character"),
					  V3 = list(newName = "value", type = "float64")
					  )

#Column info for data
kColInfo <<- list (V1 = list(newName = "rowkey", type = "character"),
				    V2 = list(newName = "accountid", type = "character"),
					V3 = list(newName = "tmsid", type = "character"),
					V4 = list(newName = "eventtime", type = "float64"),
					V5 = list(newName = "source", type = "character"),
					V6 = list(newName = "eventtype", type = "character"),
					V7 = list(newName = "sourcetype", type = "character"),
					V8 = list(newName = "starttime", type = "character"),
					V9 = list(newName = "endtime", type = "character"),
					V10 = list(newName = "channelid", type = "character"),
					V11 = list(newName = "cardid", type = "character"),
					V12 = list(newName = "durationviewed", type = "float64"),
					V13 = list(newName = "profileid", type = "character"),
					V14 = list(newName = "deviceid", type = "character"),
					V15 = list(newName = "devicetype", type = "character"),
					V16 = list(newName = "channelnumber", type = "character"),
					V17 = list(newName = "starttimeschedule", type = "character"),
					V18 = list(newName = "endtimeschedule", type = "character"),
					V19 = list(newName = "statuscdn", type = "character"),
					V20 = list(newName = "interpretedeventtype", type = "character"),
					V21 = list(newName = "weightx", type = "float64"),
					V22 = list(newName = "additionx", type = "float64"),
					V23 = list(newName = "dayofweek", type = "character"),
					V24 = list(newName = "timeofday", type = "character"),
					V25 = list(newName = "maincategory", type = "character"),
					V26 = list(newName = "genre1", type = "character"),
					V27 = list(newName = "genre2", type = "character"),
					V28 = list(newName = "genre3", type = "character"),
					V29 = list(newName = "title", type = "character"),
					V30 = list(newName = "programid", type = "character"),
					V31 = list(newName = "rating", type = "character"),
					V32 = list(newName = "releaseyear", type = "character"),
					V33 = list(newName = "originalairdate", type = "character"),
					V34 = list(newName = "runlength", type = "float64"),
					V35 = list(newName = "delivery", type = "character"),
					V36 = list(newName = "actor1", type = "character"),
					V37 = list(newName = "actor2", type = "character"),
					V38 = list(newName = "actor3", type = "character"),
					V39 = list(newName = "actor4", type = "character"),
					V40 = list(newName = "actor5", type = "character"),
					V41 = list(newName = "director1", type = "character"),
					V42 = list(newName = "director2", type = "character"),
					V43 = list(newName = "director3", type = "character"),
					V44 = list(newName = "duration", type = "integer"),
					V45 = list(newName = "zipcode", type = "character"),
					V46 = list(newName = "flipcountycode", type = "character"),
					V47 = list(newName = "dma", type = "character"),
					V48 = list(newName = "utcoffset", type = "character"),
					V49 = list(newName = "chaneltype", type = "character"),
					V50 = list(newName = "chanelobjectid", type = "character"),
					V51 = list(newName = "marketid", type = "character"),
					V52 = list(newName = "tone1", type = "character"),
					V53 = list(newName = "tone2", type = "character"),
					V54 = list(newName = "tone3", type = "character"),
					V55 = list(newName = "mood1", type = "character"),
					V56 = list(newName = "mood2", type = "character"),
					V57 = list(newName = "mood3", type = "character"),
					V58 = list(newName = "theme1", type = "character"),
					V59 = list(newName = "theme2", type = "integer"),
					V60 = list(newName = "theme3", type = "character"),
					V61 = list(newName = "rotten_tomato", type = "character"),
					V62 = list(newName = "critic1", type = "character"),
					V63 = list(newName = "critic2", type = "character"),
					V64 = list(newName = "critic3", type = "character"),
					V65 = list(newName = "audiencescore", type = "character"),
					V66 = list(newName = "utcInt", type = "character"),
					V67 = list(newName = "dmaDescription", type = "character"),
					V68 = list(newName = "ppvfilter", type = "character"),
					V69 = list(newName = "serierid", type = "character"),
					V70 = list(newName = "programtype", type = "character"),
					V71 = list(newName = "tmsconnectorid", type = "character"),
					V72 = list(newName = "languague", type = "character"),
					V73 = list(newName = "eventdate", type = "character")
					)
					
#attributes to keep when loading data from uvh
kVarsToKeep <<- c("accountid", "tmsid", "eventdate", "durationviewed", "runlength", "interpretedeventtype", "percentage")
kWatch <<- "Watch"

# Filtering variables
filterColumns <- c("value")
library(foreach)
library(doParallel)
registerDoParallel(cores = 20)

# dir location of 4 vectos
#1. folder for vector genre
kGenreFolder <<- file.path(paste(working.dir,"result/genre",sep="/"))
#2. folder for vector subgenre
kSubGenreFolder <<- file.path(paste(working.dir,"result/subgenre",sep="/"))
#3. folder for vector movie type
kMovieTypeFolder <<-file.path(paste(working.dir,"result/movietype",sep="/"))
#4. folder for vector recommendation group
kMovieGroupFolder <<- file.path(paste(working.dir,"result/recommendationGroup",sep="/"))

##location of setting file
taxonomytree.file <- file.path(paste(working.dir,"settingfolder/taxonomy_tree.csv",sep="/"))
group.map.file <- file.path(paste(working.dir,"settingfolder/group_mapping.csv",sep="/"))


# location to save temp data
kTempLocation <<- file.path(paste(working.dir, "firsttime/temp", sep = "/"))

# location to save final aggregation data
KCsvAggregationLocation <<- file.path(paste(working.dir, "firsttime/csvaggregation", ep= "/"))

#final updated CBCF daily
KFinalCbcfByday <<- file.path(paste(working.dir, "result/FINAL/FINAL_CBCF_BYDAY", sep= "/"))
KFinalCbcfBytimewindow <<- file.path(paste(working.dir, "result/FINAL/FINAL_CBCF_BYTIMEWINDOW", sep= "/"))

#first.time running CBCF aggregation
KOldCbcfByday <<- file.path(paste(working.dir, "result/OLD/OLD_CBCF_BYDAY", sep = "/"))
KOldCbcfBytimewindow <<- file.path(paste(working.dir, "result/OLD/OLD_CBCF_BYTIMEWINDOW", sep = "/"))
####insert new insertedtime 

kNewTempLocation <<- file.path(paste(working.dir, "daily/temp", sep = "/"))
KNewCsvLocation <<- file.path(paste(working.dir, "daily/newCSVaggregation", sep = "/"))
KNewXdfLocation <<- file.path(paste(working.dir, "daily/newCBCF", sep = "/"))
