source("config.R")
#Set connection to hdfs
my.hadoop.cluster <- RxHadoopMR(nameNode = my.name.node, 
								hdfsShareDir = hdfs.share, 
								showOutputWhileWaiting = TRUE, 
								autoCleanup = TRUE, 
								port = my.port,
								#consoleOutput = TRUE
								) 
								
rxSetComputeContext(my.hadoop.cluster)

#Check compute context from Hadoop
print(rxGetComputeContext())

#Determine the file System which has been used  
hdfs <- RxHdfsFileSystem(hostName = my.name.node, port = my.port)

#load taxonomy tree data
print("loading taxonomy tree and group map file...")
taxonomy.tree.data <- read.csv(file = taxonomytree.file, header = TRUE, sep = ",", stringsAsFactors = FALSE)

#load group mapping data
gr.map.data <- read.csv(file = group.map.file, header = TRUE, sep=",", stringsAsFactors = FALSE)

#join two data.frame together based on the groupnumber
#using the right outer join to keep all data in second data frame
#join.data<-merge(x=taxonomy.tree.data,y=gr.map.data,by="GROUPNUMBER",all.y=TRUE)
genre <- unique(taxonomy.tree.data[, 1])
subgenre <- unique(taxonomy.tree.data[, 2])
movietype <- unique(taxonomy.tree.data[, 3])
moviegroup <- unique(taxonomy.tree.data[, 4])
print(paste("number attributes of vector genre", length(genre)))

###
# create data.frame mapping that keeps group mapping number
# and position of each genre, subgenre,movietype, recommendation group value in result vectors
# _____________________________________________________
#|groupnumber|genre|subgenre|movietype|recommendationgr|
#|___________|_____|________|_________|________________|
print("creating mapping table for 4 vectors...")
mapping <- data.frame(matrix(NA, nrow = 0, ncol = 5), stringsAsFactors = FALSE)
max.group <- length(moviegroup) + 1

for (i in 2 : max.group){
  pos.genre <- match(subset(taxonomy.tree.data,taxonomy.tree.data$GROUPNUMBER == i, select = "GENRE")[1, 1], as.vector(genre))
  pos.subgenre <- match(subset(taxonomy.tree.data,taxonomy.tree.data$GROUPNUMBER == i,select = "SUBGENRE")[1, 1], as.vector(subgenre))
  pos.movietype <- match(subset(taxonomy.tree.data,taxonomy.tree.data$GROUPNUMBER == i,select = "MOVIETYPE")[1, 1], as.vector(movietype))
  pos.moviegroup <- match(subset(taxonomy.tree.data,taxonomy.tree.data$GROUPNUMBER == i, select = "RECOMMENDATIONGROUP")[1, 1], as.vector(moviegroup))
  mapping <- rbind(mapping, c(i, pos.genre, pos.subgenre, pos.movietype, pos.moviegroup))
}
colnames(mapping) <- c("groupnumber", "genre", "subgenre", "movietype", "recommendationgr")
genre <- paste("[G]", genre)
subgenre <- paste("[SG]", subgenre)
movietype <- paste("[MT]", movietype)
moviegroup <- paste("[MG]", moviegroup)

#load raw data to calculate the CBCF vector
#initial 4 data.frames represent 4 vectors of each accountid
#data frame represents genre
result.genre <- data.frame(matrix(NA, nrow = 0, ncol = length(genre) + 1))
#data frame represents subgenre	
result.subgenre <- data.frame(matrix(NA, nrow = 0, ncol = length(subgenre) + 1))
#data frame represents movie type
result.movietype <- data.frame(matrix(NA, nrow = 0, ncol = length(movietype) + 1))
#data frame represents recommendation group
result.moviegroup <- data.frame(matrix(NA, nrow = 0, ncol = length(moviegroup) + 1))
# set column name for these data.frame
colnames(result.genre) <- c("accountid", as.vector(genre))
colnames(result.subgenre) <- c("accountid", as.vector(subgenre))
colnames(result.movietype) <- c("accountid", as.vector(movietype))
colnames(result.moviegroup) <- c("accountid", as.vector(moviegroup))

#create 4 folder for 4 vectors 
print("creating temp folder to save temporarily data of 4 vectors...")

clean.data <- function(){
  if (file.exists(kTempLocation)){
	unlink(kTempLocation, recursive = TRUE)
  }
  
  if (file.exists(KFinalCbcfByday)){
    unlink(KFinalCbcfByday, recursive = TRUE)
  }
  
  if (file.exists(KFinalCbcfBytimewindow)){
	unlink(KFinalCbcfBytimewindow, recursive = TRUE)
  }
  
  if (file.exists(KOldCbcfByday)){
	unlink(KOldCbcfByday, recursive = TRUE)
  }
  
  if (file.exists(KOldCbcfBytimewindow)){
	unlink(KOldCbcfBytimewindow, recursive = TRUE)
  }
  
  if (file.exists(KNewXdfLocation)){
	unlink(KNewXdfLocation, recursive = TRUE)
  }
  
  if (file.exists(kNewTempLocation)){
	unlink(kNewTempLocation, recursive = TRUE)
  }
		
  dir.create(kTempLocation, recursive = TRUE)
  dir.create(kNewTempLocation, recursive = TRUE)
  dir.create(KNewXdfLocation, recursive = TRUE)
  dir.create(KFinalCbcfBytimewindow, recursive = TRUE)
  dir.create(KOldCbcfBytimewindow, recursive = TRUE)
  dir.create(KFinalCbcfByday, recursive = TRUE)
  dir.create(KOldCbcfByday, recursive = TRUE)
		
}

##create file keep folders has been executed so far today
kExecutedFolder <<- file.path(paste(getwd(), "daily/executedFolder", sep = "/"))

if (file.exists(kExecutedFolder)){
  unlink(kExecutedFolder, recursive = TRUE)
}

dir.create(kExecutedFolder, recursive = TRUE)

createTraceFile <- function()
{
  today <- format(strptime(Sys.Date(), "%Y-%m-%d"), "%Y%m%d")
  today.file <- paste(today, "txt", sep = ".")
  executedFolder.list.file <- file.path(paste(getwd(), "daily/executedFolder", today.file, sep = "/"))
  file.list <- list.files(kExecutedFolder, full.names = TRUE)
  
  if (length(file.list) != 0)
    if(file.list != executedFolder.list.file){
	  unlink(file.list)
	}
	
	if (!file.exists(executedFolder.list.file)){
	  file.create(executedFolder.list.file)
	}
	
  return (executedFolder.list.file)
}

executedFolder.file <- createTraceFile()

	
	
