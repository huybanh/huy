FilterAccountsByExpression <- function(inDir,outDir, logicExp, fileSystem = rxGetFileSystem()) {  
  # Filters data by a logic expression.
  # 
  # Args:
  #   inDir: A character string specifying input xdf data source.
  #   outDir: A character string specifying output xdf data source.
  #   logicExp: A character string expressing the filtering rule. E.g. "(G1 + G2 + G3) > 1.0"
  #   fileSystem: An object indicating type of file system.
  # Returns:
  #   RxXdfData data source object containing filtered data.  
  
  cat("Checking arguments...\n")
  stopifnot(is.character(inDir))
  stopifnot(is.character(outDir))
  stopifnot(is.character(logicExp))
  cat("Successful.\n")
  
  cat("Filtering expression:",logicExp,"\n")
  
  in.data <- RxXdfData(inDir,fileSystem=fileSystem)
  out.data <- RxXdfData(outDir,fileSystem=fileSystem)
  
  cat("Input data: ",inDir,"\n")
  cat("Filtering accounts...\n")
  rxDataStep(inData = in.data, outFile = out.data, rowSelection = parse(text=logicExp), overwrite = TRUE)
  cat("Successful.\n")
  cat("Output data: ",outDir,"\n")
  
  return(out.data)

}


GetLowActivityFilterExpression <- function(vars,threshold) { 
  # Provides a simple logic expression as input for FilterAccountsByExpression.
  # Args:
  #   vars: A vector of variable names.
  #   threshold: The upper threshold.
  # Returns:
  #   A character string. E.g. "(var1+var2+var3+...+varn)>threshold"
  
  paste0("(",paste(vars,collapse="+"),")>",threshold)
}
