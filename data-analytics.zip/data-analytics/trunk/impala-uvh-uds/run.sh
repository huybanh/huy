. ./conf.properties

if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

hive $hadoopTokenClause -hiveconf hivetable=$uvh_table -hiveconf location=$all_base_dir -hiveconf database=$database -f "uvh_mapping.sql"

status=$?
#
if [ $status -eq 0 ]; then
    echo "SUCCEED"
    impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "invalidate metadata;"
else
    echo "FAILED"
fi
