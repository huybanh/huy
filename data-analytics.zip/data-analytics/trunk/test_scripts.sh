now=$(date +'%Y%m%d%H%M%S')
echo "Current time : $now"
a = $now

echo '*******************************RUNNING SCRIPTS FIRSTTIME**********************************************'
nohup ./lastaction/demo/firsttime-lastaction/run.sh $now > logs/LA_demo_firsttime.log &

nohup ./cbcf/demo/firsttime-cbcf/run.sh $now > logs/CBCF_demo_firsttime.log &

nohup ./cbcf/production/firsttime-cbcf/run.sh $now > logs/CBCF_demo_daily.log &

nohup pig  ./lastaction/production/publish/run.py  $now '[{"ruleName":"rule2_genre","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"GENRE","operation":"IS","value1":"Drama","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"}]' > logs/LA_production_publish.log &

echo '*******************************RUNNING SCRIPTS DAILY***************************************************'

now=$(date +'%Y%m%d%H%M%S')
b = $now

nohup ./lastaction/demo/daily-lastaction/run.sh $now > logs/LA_demo_daily.log &

nohup ./cbcf/demo/daily-cbcf/run.sh $now > logs/CBCF_demo_daily.log &

now=$(date +'%Y%m%d%H%M%S')
c = $now

nohup ./cbcf/production/daily-cbcf/run.sh $now > logs/CBCF_production_daily.log &

nohup pig  ./lastaction/production/daily-sync/run.py  $now '[{"ruleName":"rule2_genre","state":"Published","lastModifiedDate":null,"numberOfEvents":25,"match":{"statement":[{"match":null,"filter":{"name":"GENRE","operation":"IS","value1":"Drama","value2":null,"userTaste":false}}],"type":"AND","parentType":null},"ruleType":"LAST_WATCH"}]' > logs/LA_production_daily-sync.log &


echo 'excuted with batchnumber:'
echo "firsttime: $a"
echo "daily: $b and $c"
