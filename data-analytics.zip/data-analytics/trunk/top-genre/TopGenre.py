#!/usr/bin/python
################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

from top_genre_properties import *
from common_properties import *
from org.apache.pig.scripting import Pig
import imp
import datetime
from datetime import datetime, timedelta
import sys
from sys import stderr
import os
import subprocess
import imp

from org.apache.hadoop.fs import *
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *

#location
currentLocation = os.getcwd();
common_util_script = currentLocation + '/common/Utils.py';
utils = imp.load_source('utils', common_util_script);

#initialize DI Integration
#diIntegration = imp.load_source('dataAnalytic', #common_lastbatch_python_script);
#validation parameters
config = HBaseConfiguration.create()
rjhTable = HTable(config, validation_table)

def runPig():
	pigScriptingExcutor = Pig.compileFromFile(currentLocation + '/top-genre/TopGenre.pig');
	params = {
	'udfLib':udfLib,
	'flattenGenre':flattenGenre,
	'convertToVector':convertToVector,
	'hadoop_home':hadoop_home,
	'hadoop_lib':hadoop_lib,
	'timeWindows':timeWindows,
	'mainCategories':mainCategories,
	'watchEvent':watchEvent,
	'dateTimeFormat':dateTimeFormat,
	'dateFormat':dateFormat,
	'dataTypes':dataTypes,
	'preparedData':preparedData,
	'duplicatedGenres':duplicatedGenres,
	'filteredGenres':filteredGenres,
	'destinationHTable':destinationHTable,
	'destinationColFamily':destinationColFamily,
	'timeWindowsName':timeWindowsName,
	'useDefaultTopGenres':useDefaultTopGenres,
	'defaultMovies':defaultMovies,
	'defaultMoviesValue':defaultMoviesValue,
	'defaultTV':defaultTV,
	'defaultTVValue':defaultTVValue,
	'defaultSports':defaultSports,
	'defaultSportsValue':defaultSportsValue,
	'rule':rule
	};
		

	#DI Integration
	print '*****************************GETTING BATCHNUMBER***********************************'
	#Load default top genre from properties file
	if useDefaultTopGenres==True:
		subprocess.call(['./top-genre/InsertDefaultGenre.sh', hadoop_home, destinationHTable, destinationColFamily, defaultMovies, defaultMoviesValue, defaultTV, defaultTVValue, defaultSports, defaultSportsValue])
		sys.exit(0);		
	#Generate HTable path
	params['destinationHTable'] = 'hbase://' + params['destinationHTable']
	
	if len(sys.argv)==2: #from oozie
		# check current batch number		
		params['batchNumber_current'] = str(sys.argv[1])
		if (validate_date(params['batchNumber_current']) == False):
			print 'Wrong format for batch number ' + params['batchNumber_current'] + ' (should be ' + params['fullDateTimeFormat'] + ')'
			sys.exit(0)
	
	
		#Generate time window string for 5 days
		parsedDate = datetime.strptime(params['batchNumber_current'], '%Y%m%d%H%M%S')
		dateString = ''
		#delta = timedelta(days = 1)
		hasData = False
		for x in range(0,lastDayNumber):
			delta = timedelta(days = x)
			previousDate = parsedDate - delta
			path = params['preparedData'] + previousDate.strftime('%Y%m%d')
			command = "hadoop fs -ls %s*" % path
			exit_code = subprocess.call(command, shell=True)
			if exit_code != 0:
				continue

			if dateString == '':
				dateString = previousDate.strftime('%Y%m%d') + '*'
			else:
				dateString = dateString + ','+ previousDate.strftime('%Y%m%d') + '*'
		
		if dateString == '':
			print '*************JOB FAILED, PLEASE VIEW LOG FILE IN ' + validation_table + ' KEY ' + params['batchNumber_current']
			utils.updateRjh(rjhTable, validation_columnFamily, params['batchNumber_current'], validation_type, 'validateHDFS', ['message', 'status'], ['No data within the time window (' + str(lastDayNumber) + ' days)', 'FAILED']);
			sys.exit(0);

		params['preparedData'] = params['preparedData'] + '{' + dateString + '}'
		
		print 'LIST OF FOLDERS: ' + params['preparedData']
		
	elif len(sys.argv)==1:
		currentDateTime = datetime.now()
		params['preparedData'] = params['preparedData'] + '*'
		params['batchNumber_current'] = currentDateTime.strftime('%Y%m%d%H%M%S')
		
	#call pig script
	print '*****************************EXECUTING PIG SCRIPT***********************************'			
	stats = pigScriptingExcutor.bind(params).runSingle();
	if not stats.isSuccessful():
		print 'Pig job failed'
		sys.exit(0);

def validate_date(inputDate, formatDate='%Y%m%d%H%M%S'):
	try:
		parsedDate = datetime.strptime(inputDate, formatDate)
		if parsedDate.strftime(formatDate) == inputDate:
			return True
		else:
			return False
	except ValueError:
		return False;
		

if __name__ == '__main__':
	runPig();
