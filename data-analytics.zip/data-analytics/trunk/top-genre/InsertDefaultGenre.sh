export HADOOP_HOME=$1
echo "put '$2', '$4', '$3', '$5'" | hbase shell;
echo "put '$2', '$6', '$3', '$7'" | hbase shell;
echo "put '$2', '$8', '$3', '$9'" | hbase shell;
