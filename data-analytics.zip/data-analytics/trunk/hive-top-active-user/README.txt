How to run script!


Run with encrypt_flag = false
./run.sh

Run with encrypt_flag = true
./run.sh