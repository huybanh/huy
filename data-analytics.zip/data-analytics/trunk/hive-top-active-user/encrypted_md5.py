#!/usr/bin/env python

import hashlib
import sys

for line in sys.stdin:
    line = line.strip()
    accountId,eventcount,flag = line.split('\t')
    m = hashlib.md5()
    m.update(accountId)
    if flag == 'true':
        print '%s\t%s\t%s' % (accountId, m.hexdigest(), eventcount)
    else:
        print '%s\t%s\t%s' % (accountId, accountId, eventcount)
