#impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f top_active_user.sql
. ./conf.properties

if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

# Calculate list active users
hive $hadoopTokenClause -hiveconf database=$database -hiveconf user_table=$user_table -hiveconf uvh_table=$uvh_table -hiveconf location=$location -hiveconf encrypt_flag=$encrypt_flag -f "top_active_user_hive.sql"

status=$?
if [ $status -eq 0 ]; then
    echo "SUCCEED"
    impala-shell -i hdpdn-h3-awsw01.ds.dtveng.net -q "refresh $user_table;"
else
    echo "FAILED"
fi
