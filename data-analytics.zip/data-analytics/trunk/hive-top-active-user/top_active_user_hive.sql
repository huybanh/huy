USE ${hiveconf:database};

ADD FILE ./encrypted_md5.py;

-- create mapping table from accountid to encryptedid
DROP TABLE IF EXISTS ${hiveconf:user_table};
CREATE EXTERNAL TABLE ${hiveconf:user_table} (accountId string, encryptedid string, eventcount double) 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;' 
STORED AS TEXTFILE LOCATION '${hiveconf:location}';

-- calculate eventcount
INSERT OVERWRITE TABLE ${hiveconf:user_table}
SELECT TRANSFORM(accountid, sum(durationviewed/runlength), '${hiveconf:encrypt_flag}')
USING 'encrypted_md5.py' AS accountid, encryptedid, eventcount
FROM ${hiveconf:uvh_table} 
WHERE interpretedeventtype='Watch' and from_unixtime(unix_timestamp(date_sub(to_date(from_unixtime(unix_timestamp())),180),'yyyy-MM-dd'),'yyyyMMddHHmmss') < eventtime
and accountId <> 'INVALID CUST ACCT NUMBER' and runlength > 0
GROUP BY accountid;
