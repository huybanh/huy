package com.directv.uds.utils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IOUtil {
	private static Logger LOGGER = LoggerFactory.getLogger(IOUtil.class);

	public static void write(String pathFile, String content) throws IOException {

		LOGGER.info("Write data to: {}", pathFile);

		Writer writer = new FileWriter(pathFile);
		IOUtils.write(content, writer);
		writer.close();

	}

	public static <T> T read(String pathFile, Class<T> clazz) {
		T result = null;
		try {
			File file = new File(pathFile);
			if (!file.isFile() || !file.exists() || !file.canRead()) {
				return null;
			}
			Reader input = new FileReader(file);
			List<String> values = IOUtils.readLines(input);
			if (values.isEmpty()) {
				return null;
			}

			String value = values.get(0);
			result = JSONUtil.convertJsonToObject(value, clazz);

			input.close();
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
			return null;
		}
		return result;
	}

}
