/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.exceptions.BadRequestException;

public class DateTimeUtil {

	private static Logger LOGGER = LoggerFactory.getLogger(DateTimeUtil.class);

	/**
	 * Normalize requested datetime input value Description
	 * 
	 * @param inputFormat
	 *            : input formatter that is match with requested input value Ex:
	 *            yyyyMMdd HH:mm:ss
	 * @param outputFormat
	 *            : output formatter Ex: yyyyMMdd HH:mm:ss
	 * @param input
	 *            : requested input value
	 * @return
	 * @throws BadRequestException
	 */
	public static String normalizeDateTime(DateTimeFormatter inputFormat, DateTimeFormatter outputFormat, String input)
			throws BadRequestException {
		if (input == null) {
			return null;
		}

		// replace every space character in input value into "+" character
		if (input.contains(" ")) {
			input = input.replace(" ", "+");
		}

		try {
			// return datetime value by outputFormat
			return outputFormat.print(inputFormat.parseDateTime(input));
		} catch (IllegalArgumentException e) {
			LOGGER.error(e.getMessage());
			throw new BadRequestException("Can not parse date time string " + input + "\n" + e.getMessage());
		}
	}

}
