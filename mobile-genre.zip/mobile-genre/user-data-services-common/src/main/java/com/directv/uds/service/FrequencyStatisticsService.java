/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.directv.uds.model.rs.response.UserTasteResponse;
import com.directv.uds.model.rs.response.WhatshotResponse;

public interface FrequencyStatisticsService {
	
	public static final String GENRE_TYPE_DTV = "genre.type.dtv";
	public static final String GENRE_TYPE_TMS = "genre.type.tms";
	public static final String GENRE_TYPE_DEFAULT = "genre.type.default";

	/**
	 * Get the interest genre of the user. The three first genre is main
	 * category: Movies, TV, Sports. The rest is all sub category
	 * 
	 * Description
	 * 
	 * @param limit
	 * @param timeWindow
	 * @param serviceName
	 * @param userId
	 *            : userId of given user that is decrypted from encryptedId
	 *            input
	 * @param groupByWeekday
	 *            : if true then group result by weekday (Monday, Thursday,
	 *            ...), else then group by all days
	 * @param mainCategory
	 *            : requested main category when mainCategory = null, it means
	 *            return last action of all main category
	 * @return
	 * @throws IOException
	 */
	public FrequencyStatisticsResponse getFullFrequencyVector(String userId, boolean groupByWeekday, String mainCategory, String genreAttributeName, int limit, String timeWindow);

	/**
	 * Return only main category statistics
	 * 
	 * Description
	 * 
	 * @param query
	 * @param timeWindow
	 * @param serviceName
	 * @param encryptedId
	 *            : userId of given user that is decrypted from encryptedId
	 *            input
	 * @param percentage
	 *            : indicate if frequency is percentage
	 * @param groupByWeekday
	 *            : if true then group result by weekday (Monday, Thursday,
	 *            ...), else then group by all days
	 * @param mainCategory
	 *            : requested main category when mainCategory = null, it means
	 *            return last action of all main category
	 * @return
	 * @throws IOException
	 */
	public FrequencyStatisticsResponse getMainCategoryFrequencyVector(String userId, boolean percentage, boolean groupByWeekday, String mainCategory, String timeWindow, String genreAttributeName);

	/**
	 * Return sub category statistics
	 * 
	 * Description
	 * 
	 * @param query
	 * @param limit
	 * @param timeWindow
	 * @param serviceName
	 * @param encryptedId
	 *            : userId of given user that is decrypted from encryptedId
	 *            input
	 * @param percentage
	 *            : indicate if frequency is percentage
	 * @param groupByWeekday
	 *            : if true then group result by weekday (Monday, Thursday,
	 *            ...), else then group by all days
	 * @param mainCategory
	 *            : requested main category when mainCategory = null, it means
	 *            return last action of all main category
	 * @return
	 * @throws IOException
	 */
	public FrequencyStatisticsResponse getSubCategoryFrequencyVector(String userId, boolean percentage, boolean groupByWeekday, String mainCategory, int limit, String timeWindow, String genreAttributeName);

	/***
	 * 
	 * @param timeWindow
	 * @param dmaInformation
	 * @param limit
	 * @param mainCategory
	 * @param serviceName
	 * @return
	 */
	public WhatshotResponse getWhatIsHot(String timeWindow, DMAInformation dmaInformation, int limit, String mainCategory);

	/**
	 * Description
	 * 
	 * @param queryString
	 * @param rawUserId
	 * @param percentageBool
	 * @param dateString
	 * @param limit
	 * @param serviceName
	 * @return
	 */
	public Map<String, List<FrequencyElement>> getCbcfByDayVector(String rawUserId, boolean percentageBool, String attribute, String dateString, int limit);
	
	/**
	 * 
	 * @param query
	 * @param userId
	 * @param percentage
	 * @param groupByWeekday
	 * @param otherCategory
	 * @param limit
	 * @param timeWindow
	 * @param serviceName
	 * @return
	 * @throws IOException 
	 */
	public FrequencyStatisticsResponse getOtherSubCategoryFrequencyVector(String userId, boolean percentage, final boolean groupByWeekday, 
			String otherCategory, String mainCategory, int limit, String timeWindow);

	/**
	 * 
	 * @param userId
	 * @param mainCategory
	 * @param serviceName
	 * @param limit TODO
	 * @return
	 * @throws IOException 
	 */
	public UserTasteResponse getUserTaste(String userId, String mainCategory, int limit, String genreAttributeName);
//	public 	Map<String, List<FrequencyElement>> getUserTaste(String userId, String[] mainCategories, String serviceName, int limit);

	/**
	 * 
	 * @param cbcfValues
	 * @param query
	 * @param percentage
	 * @param startIndex
	 * @param limit
	 * @param isOtherCategory
	 * @return
	 * @throws IOException 
	 */
	public FrequencyStatisticsResponse buildFrequencyStatisticsResponse(Map<String, List<String>> cbcfValues, 
			boolean percentage, int startIndex, int limit, String[] mainCategoryNames, Set<String> ignoredSubCategories) throws IOException;

	
	/*public UserTasteResponse getCommonUserTaste(int limit);*/
}
