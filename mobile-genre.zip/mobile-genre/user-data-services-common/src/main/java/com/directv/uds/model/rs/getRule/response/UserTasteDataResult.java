/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.getRule.response;

import java.util.List;

import com.directv.uds.model.FrequencyElement;

/**
 * <H3>UserTasteDataResponse</H3>
 *
 * @author ThanhNN2
 * @since Oct 13, 2014
 */
public class UserTasteDataResult {
	/**
	 * main category (Movies, TV, Sports or AllCategories)
	 */
	private String mainCategory;
	/**
	 * List of user's taste results.
	 */
	private List<FrequencyElement> userTaste;

	/**
	 * @return the mainCategory
	 */
	public String getMainCategory() {
		return mainCategory;
	}

	/**
	 * @param mainCategory
	 *            the mainCategory to set
	 */
	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

	/**
	 * @return the userTaste
	 */
	public List<FrequencyElement> getUserTaste() {
		return userTaste;
	}

	/**
	 * @param userTaste
	 *            the userTaste to set
	 */
	public void setUserTaste(List<FrequencyElement> userTaste) {
		this.userTaste = userTaste;
	}

}
