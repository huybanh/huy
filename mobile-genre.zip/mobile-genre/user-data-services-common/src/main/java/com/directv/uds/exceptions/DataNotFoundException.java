/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.exceptions;

import com.directv.uds.enums.ErrorCode;



/**
 * Base class to handle data not found exception. It create error message based
 * on this context name which is passed as argument. 
 * for example: when context is : Client
 * then error will be generated as 'Client not found'
 * 
 * @author mgiramkar
 */
public class DataNotFoundException extends BaseRuntimeException {

	private static final long serialVersionUID = 6752008039206417340L;

	/**
	 *  It create error message based on this context name.
	 * @param errorCode
	 * @param contextName
	 */
	public DataNotFoundException(ErrorCode errorCode, String contextName) {
		super(errorCode.getCode(), String.format(errorCode.getMessage(), contextName));
		
	}

	
}
