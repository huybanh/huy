package com.directv.uds.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class IndexingStringArray {
	
	private String defaultValue;
	private String[] values;
	private Map<String, Integer> indexs;
	private int size;
	
	private IndexingStringArray() {
		this.defaultValue = null;
		this.values = null;
		this.size = 0;
		this.indexs = new HashMap<String, Integer>();
	}
	
	public static IndexingStringArray createIndexingArray() {
		return new IndexingStringArray();
	}
	
	public boolean containValue(String value) {
		Integer index = getIndex(value);
		
		if(index > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	public void add(String value) {
		this.values[size] = value;
		this.indexs.put(value.toLowerCase(), this.size);
		this.size = this.size + 1;
	}
	
	public void addAll(String[] values) {
		this.values = values;
		if(values != null) {
			this.size = values.length;
			
			for(int i = 0; i < this.size; i++) {
				String normalizedValue = values[i].toLowerCase();
				
				indexs.put(normalizedValue, i);
			}
		}
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	
	public void setDefaultValue(Integer index) {
		this.defaultValue = getValue(index);
	}
	
	public int getDefaultIndex() {
		return getIndex(this.defaultValue);
	}
	
	public String[] getValues() {
		return values;
	}

	public void setValues(String[] values) {
		this.values = values;
	}
	
	public Map<String, Integer> getIndexsMap() {
		return indexs;
	}
	
	public int getSize() {
		return size;
	}

	public Integer getIndex(String value) {
		if(indexs != null && value != null) {
			String normalizedValue = value.toLowerCase();
			
			if(indexs.containsKey(normalizedValue)) { 
				return indexs.get(normalizedValue);
			} else {
				return -1;
			}
		}
		
		return -1;
	}
	
	public String getValue(Integer index) {
		if(values == null || index == null || index.intValue() > this.size) {
			return null;
		}
		
		return values[index.intValue()];
	}
	
	public String getLast() {
		if(size > 0) {
			return values[size - 1];
		} else {
			return null;
		}
	}
	
	public String[] removeLastValue() {
		String[] result = null;
		if(size > 1) {
			int length = size - 1;
			result = new String[length];
			for(int i = 0; i < length; i++) {
				result[i] = values[i];
			}
		} else {
			result = values;
		}
		return result;
	}
	
	@Override
	public String toString() {
		if(values == null) {
			return null;
		} else {
			return Arrays.asList(values).toString();
		}
	}
}
