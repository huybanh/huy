/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.getRule.response;

import java.util.ArrayList;
import java.util.List;

import com.directv.uds.model.ProgramFrequency;

/**
 * <H3>WhatsHotDataResponse</H3>
 *
 * @author ThanhNN2
 * @since Oct 13, 2014
 */
public class WhatsHotDataResult {
	/**
	 * rule name.
	 */
	private String ruleName;
	/**
	 * what's result list.
	 */
	private List<ProgramFrequency> whatshot;

	/**
	 * dma code
	 */
	private String dmaCode;
	/**
	 * dma description
	 */
	private String dmaDescription;

	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}

	/**
	 * @param ruleName
	 *            the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	/**
	 * @return the whatshot
	 */
	public List<ProgramFrequency> getWhatshot() {
		if (whatshot == null) {
			whatshot = new ArrayList<ProgramFrequency>();
		}
		return whatshot;
	}

	/**
	 * @param whatshot
	 *            the whatshot to set
	 */
	public void setWhatshot(List<ProgramFrequency> whatshot) {
		this.whatshot = whatshot;
	}

	/**
	 * @return the dmaCode
	 */
	public String getDmaCode() {
		return dmaCode;
	}

	/**
	 * @param dmaCode
	 *            the dmaCode to set
	 */
	public void setDmaCode(String dmaCode) {
		this.dmaCode = dmaCode;
	}

	/**
	 * @return the dmaDescription
	 */
	public String getDmaDescription() {
		return dmaDescription;
	}

	/**
	 * @param dmaDescription
	 *            the dmaDescription to set
	 */
	public void setDmaDescription(String dmaDescription) {
		this.dmaDescription = dmaDescription;
	}

}
