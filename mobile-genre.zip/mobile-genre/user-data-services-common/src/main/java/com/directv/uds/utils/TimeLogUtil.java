/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import org.slf4j.Logger;

/**
 * <H3>TimeLogUtil</H3>
 * 
 * @author TuTX1
 * @since Jun 20, 2014
 */
public class TimeLogUtil {

	/**
	 * Compute start time Description
	 * 
	 * @param LOG
	 * @param endPoint
	 * @return
	 */
	public static long logStartTime(final Logger LOG, final String endPoint) {
		// log for checking performance will remove when clear code
		long startTime = System.currentTimeMillis();
		LOG.info("Start {}", endPoint);
		return startTime;
	}

	/**
	 * Compute end time by start time Description
	 * 
	 * @param log
	 * @param endPoint
	 * @param startTime
	 * @return
	 */
	public static long logEndTime(final Logger log, final String endPoint, final long startTime) {
		long endTime = System.currentTimeMillis() - startTime;
		log.info("End {} :{} milisecond", endPoint, endTime);
		return endTime;
	}
}
