/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.model.EnumManager.DayOfWeek;
import com.directv.uds.model.EnumManager.MainCategory;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType.Filter;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType.Operator;
import com.dtv.lastaction.listbuilderintegration.dto.LAMatchType.MatchType;
import com.dtv.lastaction.listbuilderintegration.dto.LAStatementType;

/**
 * <H3>FilterUtil</H3>
 * 
 * @author ThanhNN2
 * @since Oct 1, 2014
 */
public class FilterUtil {
	private static Logger LOGGER = LoggerFactory.getLogger(FilterUtil.class);

	/**
	 * @param filterName
	 * @param operation
	 * @param value
	 * @param matchType
	 * @param neighbors
	 */
	public static String buildGenreFilter(Filter filterName, Operator operation, String value, MatchType matchType,
			List<LAStatementType> neighbors, FrequencyStatisticsResponse cbcf) {
		String filter = "";
		String result = "";
		String dbColumnName = filterName.getValue();
		String[] listColumnName = dbColumnName.split(",");
		String genreOperator = "";
		if (operation == Operator.IS) {
			genreOperator = "in";
		} else if (operation == Operator.IS_NOT) {
			genreOperator = "not in";
		} else {
			return result;
		}
		// if genre != userttaste ===> genre1 = '$value' or genre2='$value' or
		// genre3 = '$value'
		if (!value.equals(LAFilterType.USER_TASTE_VALUE)) {

			for (int i = 0; i < listColumnName.length; i++) {
				if (i == 0) {
					filter = String.format("%s %s '%s'", listColumnName[i], operation.getValue(), value);
					result = result + filter;
				} else {
					filter = String.format(" or %s %s '%s'", listColumnName[i], operation.getValue(), value);
					result = result + filter;
				}
			}
		}
		// if genre == user taste ===> genre1 in 'user_taste' or genre2 in
		// 'user_taste' or genre3 in 'user_taste'
		else {
			String mainCategory = getAppropriateMainCategory(matchType, neighbors);
			LOGGER.info("Main category: {}", mainCategory);
			// if mainCategory is supported
			// ('TV','Movies','Sports','AllCategories')
			if (!mainCategory.equalsIgnoreCase(MainCategory.NOT_SUPPORT.getValue())) {
				List<String> genres = getUserTaste(mainCategory, cbcf);
				StringBuffer genresString = new StringBuffer();
				if (genres != null && genres.size() > 0) {
					int size = genres.size();
					for (int i = 0; i < size; i++) {
						genresString.append("'").append(genres.get(i)).append("'");
						if (i != size - 1) {
							genresString.append(",");
						}
					}
					String genreSqlParameterList = String.format("(%s)", genresString);
					LOGGER.info("User taste: {}", genreSqlParameterList);
					for (int i = 0; i < listColumnName.length; i++) {
						if (i == 0) {
							filter = String.format("%s %s %s", listColumnName[i], genreOperator, genreSqlParameterList);
							result = result + filter;
						} else {
							filter = String.format(" or %s %s %s", listColumnName[i], genreOperator, genreSqlParameterList);
							result = result + filter;
						}

					}
				}
			}
		}
		if (!result.isEmpty()) {
			result = String.format("(%s)", result);
		}
		LOGGER.info("GENRE FILTER: {}", result);
		return result;
	}

	public static String buildGenreFilter(Filter filterName, Operator operation, String value, MatchType matchType) {
		String filter = "";
		String result = "";
		String dbColumnName = filterName.getValue();
		String[] listColumnName = dbColumnName.split(",");

		// if genre != userttaste ===> genre1 = '$value' or genre2='$value' or
		// genre3 = '$value'
		// if (!value.equals("User taste")) {

		for (int i = 0; i < listColumnName.length; i++) {
			if (i == 0) {
				filter = String.format("%s %s '%s'", listColumnName[i], operation.getValue(), value);
				result = result + filter;
			} else {
				filter = String.format(" or %s %s '%s'", listColumnName[i], operation.getValue(), value);
				result = result + filter;
			}
		}
		// }
		// if genre == user taste ===> genre1 in 'user_taste' or genre2 in
		// 'user_taste' or genre3 in 'user_taste'

		LOGGER.info("GENRE FILTER: {}", result);
		return result;
	}

	/**
	 * @param matchType
	 * @param neighbors
	 * @return
	 */
	private static String getAppropriateMainCategory(MatchType matchType, List<LAStatementType> neighbors) {
		String mainCategory = MainCategory.NOT_SUPPORT.getValue();
		// int countNumberOfMainCategoryStatementWithMatchTypeAnd = 0;
		Map<String, String> mainCategoryTracking = new HashMap<String, String>();
		if (matchType.equals(MatchType.AND)) {
			for (LAStatementType laStatementType : neighbors) {
				if (laStatementType != null && laStatementType.getFilter() != null) {
					LAFilterType filter = laStatementType.getFilter();
					if (filter.getName() == LAFilterType.Filter.TYPE && filter.getOperation() == LAFilterType.Operator.IS) {
						mainCategory = filter.getValue1();
						mainCategoryTracking.put(mainCategory, mainCategory);
					}
				}
				if (mainCategoryTracking.size() > 1) {
					mainCategory = MainCategory.NOT_SUPPORT.getValue();
					LOGGER.error("There are two main categories with logic AND in neighbors");
					break;
				}
			}
		}
		return mainCategory;
	}

	/**
	 * @param mainCategory
	 * @return
	 */
	private static List<String> getUserTaste(String mainCategory, FrequencyStatisticsResponse cbcf) {
		List<String> userTaste = new ArrayList<String>();
		Map<DayOfWeek, List<FrequencyElement>> allDayCBCF = cbcf.getFrequencyVectorList().get(mainCategory);
		List<FrequencyElement> freqElements = allDayCBCF.get(DayOfWeek.Alldays);
		LOGGER.info("LIST CBCF SIZE: {}", freqElements.size());
		if (freqElements != null && freqElements.size() > 0) {
			userTaste.add(freqElements.get(0).getKey());
		}
		return userTaste;
	}

}
