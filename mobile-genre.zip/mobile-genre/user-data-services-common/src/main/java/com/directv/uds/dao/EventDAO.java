/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.util.List;
import java.util.Map;

import com.directv.uds.model.EventTime;
import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.model.LastAction;

/**
 * EventDAO interface contain methods to get list of events of user.
 * 
 * <H3>EventDAO</H3>
 *
 * @author TuTX1
 * @since Jul 1, 2014
 */
public interface EventDAO extends UDSDao {

	/**
	 * Get user viewing history of user.
	 * 
	 * Description
	 * @param userId : requested userId
	 * @param startTime : requested start time
	 * @param endTime : requested end time
	 * @param removeDuplicates : if true then remove duplicated tmsId  
	 * @param mainCategory : requested main category
	 * @param offset 
	 * @param limit 
	 * @return A map that group user viewing history by main category
	 */
	public Map<String, List<InterpretedEvent>> getUserViewingHistoryImpala(String userId, 
			String mainCategory, int offset, 
			int limit, boolean removeDuplicates, EventTime eventTime);
	
	/**
	 * Get last action of user.
	 * 
	 * Description
	 * @param userId : requested userId
	 * @param mainCategory : requested main category
	 * @param eventType : requested event type
	 * @param groupBySubCategory : if true then result will be grouped by sub-category or return AllSubCategory
	 * @param serviceName 
	 * @return A map that group last action by main category, event type 
	 */
	public Map<String, Map<String, List<LastAction>>> getLastActionGeneric(String userId, 
			String mainCategory, String eventType, boolean groupBySubCategory);
}
