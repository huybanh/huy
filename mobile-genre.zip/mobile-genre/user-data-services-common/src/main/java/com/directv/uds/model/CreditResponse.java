/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright 2015 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
/**
 * 
 */
package com.directv.uds.model;

import java.util.List;

import com.directv.uds.model.rs.getRule.response.CreditDataResponse;

/**
 * @author TungPT6
 * 
 */
public class CreditResponse {
	private List<CreditDataResponse> credit;

	public CreditResponse() {
	}

	/**
	 * @param credit
	 */
	public CreditResponse(List<CreditDataResponse> credit) {
		this.credit = credit;
	}

	/**
	 * @return the credit
	 */
	public List<CreditDataResponse> getCredit() {
		return credit;
	}

	/**
	 * @param credit
	 *            the credit to set
	 */
	public void setCredit(List<CreditDataResponse> credit) {
		this.credit = credit;
	}

}
