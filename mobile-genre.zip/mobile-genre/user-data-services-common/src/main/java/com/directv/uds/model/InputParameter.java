/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * <H3>InputParameter</H3>
 *
 * @author TuTX1
 * @since Jul 3, 2014
 */
public class InputParameter {
	
	private Map<String, String> requestParameters;
	
	public InputParameter() {
		super();
	}
	
	public void addParameter(String parameterName, String parameterValue) {
		if(requestParameters == null) {
			requestParameters = new HashMap<String, String>();
		}
		
		requestParameters.put(parameterName, parameterValue);
	}
	
	public String getQueryString() {
		Set<String> parameterKeys = requestParameters.keySet() ;
		StringBuilder builder = new StringBuilder();
		for(String key : parameterKeys) {
			String value = requestParameters.get(key);
			if(value !=  null) {
				builder.append("&");
				builder.append(key);
				builder.append("=");
				builder.append(value);
			}
		}
		return builder.toString().replaceFirst("&", "");
	}

	/**
	 * <br>
	 * @return  requestParameters
	 */
	
	public Map<String, String> getRequestParameters() {
		return requestParameters;
	}

	/**
	 *<br>
	 * @param requestParameters the requestParameters to set
	 */
	public void setRequestParameters(Map<String, String> requestParameters) {
		this.requestParameters = requestParameters;
	}
	
	
}
