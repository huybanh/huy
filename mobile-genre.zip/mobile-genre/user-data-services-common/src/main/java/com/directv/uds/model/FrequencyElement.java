/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

/**
 * 
 * <H3>FrequencyElement</H3>
 *
 * @author TuTX1
 * @since Jun 17, 2014
 */

public class FrequencyElement implements Comparable<FrequencyElement> {

	private String key;
	private Double value;
	private String name;

	public FrequencyElement() {
		super();
	}

	public FrequencyElement(String key, Double value) {
		super();
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Double getValue() {

		return value;
	}

	public void setValue(Double value) {
		this.value = value;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if (obj instanceof FrequencyElement) {
			FrequencyElement freqObj = (FrequencyElement) obj;
			if (freqObj.value.equals(this.value)
					&& freqObj.key.equals(this.key)) {
				result = true;
			}
		}
		return result;
	}

	@Override
	public int compareTo(FrequencyElement o) {
		return o.getValue() > this.getValue() ? 1 : 0;
	}

}