/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.getRule.request;

import java.util.ArrayList;
import java.util.List;

/**
 * <H3>RuleDataRequest</H3>
 *
 * @author ThanhNN2
 * @since Oct 13, 2014
 */
public class RuleDataRequest {
	private List<LastActionRuleDataRequest> lastActionRequest;
	private List<WhatsHotRuleDataRequest> whatshotRequest;
	private List<UserTasteRuleDataRequest> userTasteRequest;

	/**
	 * @return the lastActionRequest
	 */
	public List<LastActionRuleDataRequest> getLastActionRequest() {
		if(lastActionRequest==null){
			lastActionRequest = new ArrayList<LastActionRuleDataRequest>();
		}
		return lastActionRequest;
	}

	/**
	 * @param lastActionRequest
	 *            the lastActionRequest to set
	 */
	public void setLastActionRequest(List<LastActionRuleDataRequest> lastActionRequest) {
		this.lastActionRequest = lastActionRequest;
	}

	/**
	 * @return the whatshotRequest
	 */
	public List<WhatsHotRuleDataRequest> getWhatshotRequest() {
		if(whatshotRequest==null){
			whatshotRequest = new ArrayList<WhatsHotRuleDataRequest>();
		}
		return whatshotRequest;
	}

	/**
	 * @param whatshotRequest
	 *            the whatshotRequest to set
	 */
	public void setWhatshotRequest(List<WhatsHotRuleDataRequest> whatshotRequest) {
		this.whatshotRequest = whatshotRequest;
	}

	/**
	 * @return the userTasteRequest
	 */
	public List<UserTasteRuleDataRequest> getUserTasteRequest() {
		if(userTasteRequest==null){
			userTasteRequest = new ArrayList<UserTasteRuleDataRequest>();
		}
		return userTasteRequest;
	}

	/**
	 * @param userTasteRequest
	 *            the userTasteRequest to set
	 */
	public void setUserTasteRequest(List<UserTasteRuleDataRequest> userTasteRequest) {
		this.userTasteRequest = userTasteRequest;
	}

}
