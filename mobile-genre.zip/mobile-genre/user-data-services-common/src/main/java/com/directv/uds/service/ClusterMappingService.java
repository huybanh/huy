/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.directv.uds.model.Account;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.EventTime;
import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.model.LastAction;

public interface ClusterMappingService {

	/**
	 * Get the list of users descending ordered by activeness which is measured
	 * by the number of their events. This service support pagination
	 * 
	 * Description
	 * 
	 * @param offset
	 *            : the index of the first item in result
	 * @param limit
	 *            : the number of item to be returned by the service
	 * @param encrypted
	 *            : if true then get encrypted id else get account id
	 * @return
	 */
	public List<String> getUsers(int offset, int limit);

	/**
	 * Get the encrypted id associated with the account id.
	 * 
	 * Description
	 * 
	 * @param userID
	 *            : userId of user
	 * @return
	 * @throws IOException
	 */
	public String getUserEncryptedId(String userID);

	/**
	 * Get the account id from the encrypted id.
	 * 
	 * Description
	 * 
	 * @param userID
	 *            : encrypted id of user
	 * @return
	 */
	public String getUserDecryptedId(String userID);

	/**
	 * Return account id and its associated encrypted id by card id.
	 * 
	 * Description
	 * 
	 * @param cardId
	 *            : card id associated with account id from table
	 *            cardidtoaccountidmapping
	 * @return
	 */
	public Account getAccountFromCardId(String cardId);

	/**
	 * Return viewing history of given user.
	 * 
	 * Description
	 * 
	 * @param encryptedID
	 *            : encrypted id of user
	 * @param startTime
	 *            : start time of program
	 * @param endTime
	 *            : end time of program
	 * @param removeDuplicates
	 *            : if true then remove duplicated tmsId and contrast
	 * @param mainCategory
	 *            : requested main category when mainCategory = null, it means
	 *            return last action of all main category
	 * @param offset
	 * @param limit
	 * @return
	 */
	public Map<String, List<InterpretedEvent>> getUserViewingHistory(String userId, String mainCategory, int offset, int limit, boolean removeDuplicates, boolean isImpala, EventTime eventTime);

	/**
	 * Return the last action of an user on specified main category.
	 * 
	 * Description
	 * 
	 * @param userID
	 *            : requested user Id
	 * @param mainCategory
	 *            : requested main category when mainCategory = null, it means
	 *            return last action of all main category
	 * @param serviceName
	 * @return
	 */
	public Map<String, Map<String, List<LastAction>>> getLastActionGeneric(String userID, String mainCategory, String eventType, boolean groupBySubCategory);

	/**
	 * 
	 * @param accountId
	 * @return
	 */
	public DMAInformation getRegionIdFromAccountId(String accountId);
}
