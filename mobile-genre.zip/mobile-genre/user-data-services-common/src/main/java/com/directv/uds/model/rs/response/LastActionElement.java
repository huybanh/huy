/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.model.rs.response;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import com.directv.uds.utils.Configuration;
/**
 * 
 * <H3>LastActionElement</H3>
 *
 * @author ThanhNN2
 * @since Oct 20, 2014
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LastActionElement {
	
	private String tmsId;
	@JsonProperty
	private String title;
	private String eventTime;
	
	private String tmsConnectorId;
	private String mainCategory;
	private String programType;
	private String interpretedEventType;
	
	private String genre1;
	private String genre2;
	private String genre3;
	
	private String tmsGenre1;
	private String tmsGenre2;
	private String tmsGenre3;

	public LastActionElement(String tmsId, String ruleName, String lastModifiedDate, String title, String eventTime) {
		super();
		this.tmsId = tmsId;
		this.title = title;
		this.eventTime = eventTime;
	}
	
	public void consolidateTmsIdAndConnectorId() {
		if (Configuration.getInstance().getString(Configuration.MAIN_CATEGORY_TV).equals(this.mainCategory)) {
			this.tmsId = this.tmsConnectorId;
		} else if (Configuration.getInstance().getString(Configuration.MAIN_CATEGORY_SPORTS).equals(this.mainCategory)) {
			this.tmsConnectorId = this.tmsId;
		}
	}

	public LastActionElement() {
		super();
	}

	public String getTmsId() {
		return tmsId;
	}

	
	public String getTitle() {
		return title;
	}

	public String getEventTime() {
		return eventTime;
	}

	public void setTmsId(String tmsId) {
		this.tmsId = tmsId;
	}

	@JsonProperty
	public void setProgramTitle(String title) {
		this.title = title;
	}

	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}

	/**
	 * @return the genre1
	 */
	@JsonIgnore
	public String getGenre1() {
		return genre1;
	}

	/**
	 * @param genre1
	 *            the genre1 to set
	 */
	public void setGenre1(String genre1) {
		this.genre1 = genre1;
	}

	/**
	 * @return the genre2
	 */
	@JsonIgnore
	public String getGenre2() {
		return genre2;
	}

	/**
	 * @param genre2
	 *            the genre2 to set
	 */
	public void setGenre2(String genre2) {
		this.genre2 = genre2;
	}

	/**
	 * @return the genre3
	 */
	@JsonIgnore
	public String getGenre3() {
		return genre3;
	}

	/**
	 * @param genre3
	 *            the genre3 to set
	 */
	public void setGenre3(String genre3) {
		this.genre3 = genre3;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UdsResult [tmsId=" + tmsId + ", title=" + title
				+ ", eventTime=" + eventTime + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((tmsId == null) ? 0 : tmsId.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LastActionElement other = (LastActionElement) obj;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (tmsId == null) {
			if (other.tmsId != null)
				return false;
		} else if (!tmsId.equals(other.tmsId))
			return false;
		return true;
	}
	
	public boolean different(LastActionElement lastActionElement){
		boolean result = true;
		if(lastActionElement != null){
			if(this.eventTime.equals(lastActionElement.getEventTime()) && this.genre1.equals(lastActionElement.getGenre1())
					&& this.genre2.equals(lastActionElement.getGenre2()) && this.genre3.equals(lastActionElement.getGenre3())
					&& this.title.equals(lastActionElement.getTitle()) && this.tmsId.equals(lastActionElement.getTmsId())){
				result = false;
			}
					
		}
		return result;
	}

	public String getTmsConnectorId() {
		return tmsConnectorId;
	}

	public void setTmsConnectorId(String tmsConnectorId) {
		this.tmsConnectorId = tmsConnectorId;
	}

	public String getMainCategory() {
		return mainCategory;
	}

	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

	public String getProgramType() {
		return programType;
	}

	public void setProgramType(String programType) {
		this.programType = programType;
	}

	public String getInterpretedEventType() {
		return interpretedEventType;
	}

	public void setInterpretedEventType(String interpretedEventType) {
		this.interpretedEventType = interpretedEventType;
	}

	public String getTmsGenre1() {
		return tmsGenre1;
	}

	public void setTmsGenre1(String tmsGenre1) {
		this.tmsGenre1 = tmsGenre1;
	}

	public String getTmsGenre2() {
		return tmsGenre2;
	}

	public void setTmsGenre2(String tmsGenre2) {
		this.tmsGenre2 = tmsGenre2;
	}

	public String getTmsGenre3() {
		return tmsGenre3;
	}

	public void setTmsGenre3(String tmsGenre3) {
		this.tmsGenre3 = tmsGenre3;
	}

}
