/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.listbuilder.model.ListBuilderDeltaListing;
import com.directv.uds.listbuilder.model.ListBuilderFullListing;
import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.model.CreditResponse;
import com.directv.uds.model.LocationInformation;
import com.directv.uds.model.rs.request.UdsRulePayload;
import com.directv.uds.model.rs.response.LastActionResponse;
import com.directv.uds.model.rs.response.PreviewResponse;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;
//import com.directv.uds.model.DMAInformation;
//import com.directv.uds.model.rs.getRule.request.RuleDataRequest;
//import com.directv.uds.model.rs.getRule.response.RuleDataResponse;

/**
 * 
 * @author mitran
 * 
 */
public interface ListBuilderIntegrationService {
	
	public static final String SEVEN_DAYS_DATA_IMPALA = "7dayDataImpala";
	public static final String SEVEN_DAYS_DATA_IMPALA_SECONDARY_PARTITION_APPLIED = "7dayDataImpala.secondarypartition.applied";
	public static final String SEVEN_DAYS_DATA_IMPALA_SECONDARY_PARTITION_MODULO = "7dayDataImpala.secondarypartition.modulo";
	/**
	 * 
	 * @param rules
	 * @param accountId
	 * @param cbcf
	 * @return
	 * @throws BadRequestException
	 */
	public PreviewResponse getRuleResponse(RuleSet rules, String accountId) throws BadRequestException;

	/**
	 * 
	 * @param fullPayLoad
	 * @return
	 * @throws IOException
	 */
	public String processFullPayLoad(ListBuilderFullListing fullPayLoad, String serverLocation);

	/**
	 * 
	 * @param accountId
	 * @param ruleNames
	 * @param service
	 * @return
	 * @throws IOException
	 */
	public LastActionResponse getLastActionByRule(String accountId, UdsRulePayload[] ruleNames);

	/**
	 * 
	 * @param deltaPayLoad
	 * @return
	 * @throws IOException
	 */
	public List<LARule> processDeltaPayLoad(ListBuilderDeltaListing deltaPayLoad, String serverLocation);

	/**
	 * 
	 * @param rules
	 * @return
	 */
	public List<String> processOozieJob(List<LARule> rules, boolean isPublishJob);

	/**
	 * @param accountId
	 * @param ruleDataRequest
	 * @return
	 * @throws IOException
	 */
	/*
	 * public RuleDataResponse getRuleData(String accountId, DMAInformation
	 * dmaInformation, RuleDataRequest ruleDataRequest);
	 */
	/**
	 * @param ruleSet
	 * @return
	 */
	//public String publishRule(RuleSet ruleSet);

	/**
	 * 
	 * @return
	 */
	public List<LARule> listRules();

	/**
	 * Get DMA information from the input zip code
	 * 
	 * @param zipCode
	 * @return
	 */
	public LocationInformation getLocation(String zipCode);

	/**
	 * Get offset from the input timezone
	 * 
	 * @param zipCode
	 * @return
	 */
	public String getTimezoneOffset(String timezoneId, boolean isTimezoneCorrect);

	public void processLastActionRules();

	public LocationInformation getLocationForHbaseReconnect(String string);

	public String triggerDailySnycRules();

	public CreditResponse getCreditData(String accountId, Set<String> ruleNames, String mainCategory);

}
