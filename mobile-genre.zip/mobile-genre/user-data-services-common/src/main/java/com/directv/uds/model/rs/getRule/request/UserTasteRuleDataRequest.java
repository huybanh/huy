/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.getRule.request;

/**
 * <H3>UserTasteRuleDataRequest</H3>
 *
 * @author ThanhNN2
 * @since Oct 13, 2014
 */
public class UserTasteRuleDataRequest {
	private String mainCategory;

	/**
	 * 
	 */
	public UserTasteRuleDataRequest() {
	}
	/**
	 * @param mainCategory
	 */
	public UserTasteRuleDataRequest(String mainCategory) {
		this.mainCategory = mainCategory;
	}

	/**
	 * @return the mainCategory
	 */
	public String getMainCategory() {
		return mainCategory;
	}

	/**
	 * @param mainCategory
	 *            the mainCategory to set
	 */
	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

}
