/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.util.List;

import com.directv.uds.model.EnumManager.ParentalRatingEnum;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.directv.uds.service.FrequencyStatisticsService;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType.Filter;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType.Operator;
import com.dtv.lastaction.listbuilderintegration.dto.LAMatchType;
import com.dtv.lastaction.listbuilderintegration.dto.LAMatchType.MatchType;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;
import com.dtv.lastaction.listbuilderintegration.dto.LAStatementType;

//import com.dtv.lastaction.listbuilderintegration.dto.LARuleType;

/**
 * 
 * <H3>RuleParserUtil</H3> Parse rule to sql query base on rule's filters Rule
 * <= QueryType <= MatchType <= List Statement Statement <= MatchType || Filter
 * 
 * Process to parse rule: Parse Rule => Parse Query Type => Parse MatchType =>
 * Parse Statement => Parse Filter || Recursive MatchType
 * 
 * @author ThanhNN2
 * @since Sep 26, 2014
 */
public class RuleParserUtil {
	//private static ObjectMapper OBJECT_MAPPER = new ObjectMapper();
	//private static Map<String, Integer> parentalRatingToRank = buildParentalRatingToRank();
	//private static Map<Integer, String> rankToParentalColValue = buildRankToParentalColValue();

	// private static Logger LOG = Logger.getLogger(RuleParserUtil.class);

	/*public String parseXmlToJson(String filePath) throws JAXBException,
			JsonGenerationException, JsonMappingException, IOException {
		String result = null;
		File file = new File(filePath);
		JAXBContext context = JAXBContext.newInstance(RuleSet.class);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		RuleSet rules = (RuleSet) unmarshaller.unmarshal(file);
		result = OBJECT_MAPPER.writeValueAsString(rules);
		return result;
	}*/

	public static String buildQueryFromRule(String accountId, LARule rule, FrequencyStatisticsService freqService, Configuration config/*, FrequencyStatisticsResponse cbcf*/) {
		
		String dtvGenreAttributeName = config.getString(FrequencyStatisticsService.GENRE_TYPE_DTV);
		FrequencyStatisticsResponse cbcfByDtvGenre = freqService.getSubCategoryFrequencyVector(
				accountId, false, false, null, -1, null, dtvGenreAttributeName);
		String tmsGenreAttributeName = config.getString(FrequencyStatisticsService.GENRE_TYPE_DTV);
		FrequencyStatisticsResponse cbcfByTmsGenre = freqService.getSubCategoryFrequencyVector(
				accountId, false, false, null, -1, null, tmsGenreAttributeName);
		
		LAMatchType matchType = rule.getMatch();
		if (matchType != null) {
			return buildQueryRecursively(matchType, cbcfByDtvGenre, cbcfByTmsGenre);
		}
		return "";

	}

	/**
	 * Parse MatchType Based on MatchType AND or OR, build list statements
	 * 
	 * @param matchType
	 * @return
	 */
	private static String buildQueryRecursively(LAMatchType matchType, FrequencyStatisticsResponse cbcfByDtvGenre, FrequencyStatisticsResponse cbcfByTmsGenre) {
		String query = "";
		String listStatementQuery = "";
		if (matchType.getType() == MatchType.AND || matchType.getType() == MatchType.OR) {
			listStatementQuery = buildQueryFromListStatementRecursively(matchType.getStatement(), matchType.getType(), cbcfByDtvGenre, cbcfByTmsGenre);
		}

		if (listStatementQuery != null && listStatementQuery.length() > 0) {
			if (query.length() > 0) {
				query = String.format("%s(%s)", query, listStatementQuery);
			} else {
				query = listStatementQuery;

			}
		}
		return query;
	}

	/**
	 * Build list Statement
	 * 
	 * @param statements
	 * @param matchType
	 * @return
	 */
	private static String buildQueryFromListStatementRecursively(List<LAStatementType> statements, MatchType matchType, 
			FrequencyStatisticsResponse cbcfByDtvGenre, FrequencyStatisticsResponse cbcfByTmsGenre) {
		String query = "";
		// for (StatementType statementType : statements) {
		int size = statements.size();
		// iterate through all statements
		for (int i = 0; i < size; i++) {
			LAStatementType statementType = statements.get(i);
			LAMatchType nextLevelMatchType = statementType.getMatch();

			// Build MatchType
			if (nextLevelMatchType != null
					&& nextLevelMatchType.getStatement() != null
					&& nextLevelMatchType.getStatement().size() > 0) {
				String nextLevelQuery = buildQueryRecursively(nextLevelMatchType, cbcfByDtvGenre, cbcfByTmsGenre);
				// recursive matchType
				if (nextLevelQuery.trim().length() != 0) {
					if (query.trim().length() != 0) {
						query = String.format("%s %s (%s)", query, matchType.name(), nextLevelQuery);
					} else {
						query = nextLevelQuery;
					}
				}
			}
			// Build Filter
			LAFilterType filter = statementType.getFilter();

			if (filter != null) {
				String filterParsed = buildFilter(filter, matchType, statements, cbcfByDtvGenre, cbcfByTmsGenre);
				if (filterParsed.trim().length() != 0 && query.length() > 0) {
					query = String.format("%s %s %s", query, matchType.name(), filterParsed).trim();
				} else if (filterParsed.trim().length() != 0) {
					query = String.format("%s %s", query, filterParsed).trim();
				}
			}
		}
		return query;
	}

	/**
	 * Build Filter
	 * 
	 * @param filter
	 * @param matchType
	 * @return
	 */
	private static String buildFilter(LAFilterType filter, MatchType matchType, List<LAStatementType> neighbors, 
			FrequencyStatisticsResponse cbcfByDtvGenre, FrequencyStatisticsResponse cbcfByTmsGenre) {
		
		Filter filterName = filter.getName();
		if (filterName == null) {
			return "";
		}
		
		LAFilterType.Operator operator = filter.getOperation();
		if (filterName == Filter.RATING && (operator == Operator.IS_GREATER_THAN_OR_EQUAL ||
				operator == Operator.IS_IN_THE_RANGE || operator == Operator.IS_LESS_THAN_OR_EQUAL)) {
			
			return buildFilterRating(filter, matchType, neighbors, cbcfByDtvGenre, cbcfByTmsGenre);
		}
		
		String from = filter.getValue1();
		String to = filter.getValue2();
		if (from != null && to == null) { // normal parameter A is B
			String dbColumnName = filterName.getValue();
			if (dbColumnName != null && dbColumnName.trim().length() > 0) {
				// if there are multiple fields matched with filterName, for
				// example genre filter match genre1,genre2,genre3
				if (dbColumnName.indexOf(",") != -1 && (filterName == Filter.GENRE || filterName == Filter.TMS_GENRE)) {
					FrequencyStatisticsResponse cbcf = filterName == Filter.GENRE ? cbcfByDtvGenre : cbcfByTmsGenre;
					return FilterUtil.buildGenreFilter(filterName, operator, from, matchType, neighbors, cbcf);
				} else {
					return String.format("%s %s '%s'", dbColumnName, operator.getValue(), from);
				}
			}
		}
		return "";
	}
	
	private static String buildFilterRating(LAFilterType filter, MatchType matchType, List<LAStatementType> neighbors, 
			FrequencyStatisticsResponse cbcfByDtvGenre, FrequencyStatisticsResponse cbcfByTmsGenre) {
		
		Filter filterName = filter.getName();
		String from = filter.getValue1();
		String to = filter.getValue2();
		LAFilterType.Operator operator = filter.getOperation();

		// Range parameter A is from B to C
		if (operator == Operator.IS_IN_THE_RANGE) {
			ParentalRatingEnum fromRank = ParentalRatingEnum.valueOf(from);
			ParentalRatingEnum toRank = ParentalRatingEnum.valueOf(to);
			StringBuffer parentalRatingSet = null;
			//for (int i = fromRank; i <= toRank; i++) {
			for (ParentalRatingEnum oneRating : ParentalRatingEnum.values()) {
				if (oneRating.getRank() < fromRank.getRank() || oneRating.getRank() > toRank.getRank()) {
					continue;
				}
				if (parentalRatingSet == null) {
					parentalRatingSet = new StringBuffer();
				} else {
					parentalRatingSet.append(",");
				}
				parentalRatingSet.append("'").append(oneRating.getColValue()).append("'");
			}
			String dbColumnName = filterName.getValue();
			return String.format("%s in (%s)", dbColumnName, parentalRatingSet.toString());
			
		} else if (operator == Operator.IS_GREATER_THAN_OR_EQUAL) {
			ParentalRatingEnum target = ParentalRatingEnum.valueOf(from);
			StringBuffer parentalRatingSet = null;
			for (ParentalRatingEnum oneRating : ParentalRatingEnum.values()) {
				if (oneRating.getRank() < target.getRank()) {
					continue;
				}
				if (parentalRatingSet == null) {
					parentalRatingSet = new StringBuffer();
				} else {
					parentalRatingSet.append(",");
				}
				parentalRatingSet.append("'").append(oneRating.getColValue()).append("'");
			}
			String dbColumnName = filterName.getValue();
			return String.format("%s in (%s)", dbColumnName, parentalRatingSet.toString());
		} else if (operator == Operator.IS_LESS_THAN_OR_EQUAL) {
			ParentalRatingEnum target = ParentalRatingEnum.valueOf(from);
			StringBuffer parentalRatingSet = null;
			for (ParentalRatingEnum oneRating : ParentalRatingEnum.values()) {
				if (oneRating.getRank() > target.getRank()) {
					continue;
				}
				if (parentalRatingSet == null) {
					parentalRatingSet = new StringBuffer();
				} else {
					parentalRatingSet.append(",");
				}
				parentalRatingSet.append("'").append(oneRating.getColValue()).append("'");
			}
			String dbColumnName = filterName.getValue();
			return String.format("%s in (%s)", dbColumnName, parentalRatingSet.toString());
		}
		return "";
	}

	/**
	 * Parental Rating to Rank (List builder parameter to rank) Example: tvy =>
	 * 1
	 * 
	 * @return
	 */
	/*private static Map<String, Integer> buildParentalRatingToRank() {
		Map<String, Integer> parentalRatingToRank = new HashMap<String, Integer>();
		parentalRatingToRank.put(ParentalRatingEnum.TVY.getParentalRating(), ParentalRatingEnum.TVY.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.TVY7.getParentalRating(), ParentalRatingEnum.TVY7.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.TVG.getParentalRating(), ParentalRatingEnum.TVG.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.G.getParentalRating(), ParentalRatingEnum.G.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.TVPG.getParentalRating(), ParentalRatingEnum.TVPG.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.PG.getParentalRating(), ParentalRatingEnum.PG.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.PG_13.getParentalRating(), ParentalRatingEnum.PG_13.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.TV14.getParentalRating(), ParentalRatingEnum.TV14.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.TVMA.getParentalRating(), ParentalRatingEnum.TVMA.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.R.getParentalRating(), ParentalRatingEnum.R.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.NC17.getParentalRating(), ParentalRatingEnum.NC17.getRank());
		parentalRatingToRank.put(ParentalRatingEnum.NR.getParentalRating(), ParentalRatingEnum.NR.getRank());

		return parentalRatingToRank;
	}*/

	/**
	 * rank to parental column value in uvh For example: 1=> TVY 12 => NR (Not
	 * Rated)
	 * 
	 * @return
	 */
	/*private static Map<Integer, String> buildRankToParentalColValue() {
		Map<Integer, String> rankToParentalColValue = new HashMap<Integer, String>();
		rankToParentalColValue.put(ParentalRatingEnum.TVY.getRank(), ParentalRatingEnum.TVY.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.TVY7.getRank(), ParentalRatingEnum.TVY7.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.TVG.getRank(), ParentalRatingEnum.TVG.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.G.getRank(), ParentalRatingEnum.G.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.TVPG.getRank(), ParentalRatingEnum.TVPG.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.PG.getRank(), ParentalRatingEnum.PG.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.PG_13.getRank(), ParentalRatingEnum.PG_13.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.TV14.getRank(), ParentalRatingEnum.TV14.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.TVMA.getRank(), ParentalRatingEnum.TVMA.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.R.getRank(), ParentalRatingEnum.R.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.NC17.getRank(), ParentalRatingEnum.NC17.getColValue());
		rankToParentalColValue.put(ParentalRatingEnum.NR.getRank(), ParentalRatingEnum.NR.getColValue());
		return rankToParentalColValue;
	}*/

	/**
	 * Build List Operator
	 * 
	 * @return
	 */
	/*private static Map<String, String> buildListOperator() {
		Map<String, String> operator = new HashMap<String, String>();

		operator.put(Operator.IS.getValue(), "=");
		operator.put(Operator.IS_NOT.getValue(), "<>");
		operator.put(Operator.ON.getValue(), "=");
		operator.put(Operator.NOT_ON.getValue(), "<>");
		operator.put(Operator.IS_GREATER_THAN_OR_EQUAL.getValue(), ">=");
		operator.put(Operator.IS_LESS_THAN_OR_EQUAL.getValue(), "<=");
		return operator;
	}*/

}
