package com.directv.uds.model;

import java.util.List;

public class EventTime {
	private String startTime;
	private String endTime;
	
	private String minInsertedTime;
	private String maxInsertedTime;
	
	private List<String> datePeriod;
	
	public EventTime(String startTime, String endTime) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
	}
	
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public List<String> getDatePeriod() {
		return datePeriod;
	}
	public void setDatePeriod(List<String> datePeriod) {
		this.datePeriod = datePeriod;
	}

	public String getMaxInsertedTime() {
		return maxInsertedTime;
	}

	public void setMaxInsertedTime(String maxInsertedTime) {
		this.maxInsertedTime = maxInsertedTime;
	}

	public String getMinInsertedTime() {
		return minInsertedTime;
	}

	public void setMinInsertedTime(String minInsertedTime) {
		this.minInsertedTime = minInsertedTime;
	}
}
