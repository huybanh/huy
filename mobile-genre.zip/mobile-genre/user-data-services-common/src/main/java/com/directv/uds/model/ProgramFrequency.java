/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;


/**
 * <H3>ProgramFrequency</H3>
 *
 * @author TuTX1
 * @since Aug 29, 2014
 */
public class ProgramFrequency {
	private String tmsId;
	private String title;
	private double score;

	public ProgramFrequency() {
	}

	/**
	 * Constructor<br>
	 * 
	 * @param tmsId
	 * @param title
	 * @param mainCategory
	 * @param views
	 */
	public ProgramFrequency(String tmsId, String title, Long views, double score) {
		super();
		this.tmsId = tmsId;
		this.title = title;
		this.score = score;
	}

	/**
	 * <br>
	 * 
	 * @return tmsId
	 */

	public String getTmsId() {
		return tmsId;
	}

	/**
	 * <br>
	 * 
	 * @param tmsId
	 *            the tmsId to set
	 */
	public void setTmsId(String tmsId) {
		this.tmsId = tmsId;
	}

	/**
	 * <br>
	 * 
	 * @return title
	 */

	public String getTitle() {
		return title;
	}

	/**
	 * <br>
	 * 
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * @return the score
	 */
	public double getScore() {
		return score;
	}

	/**
	 * @param score
	 *            the score to set
	 */
	public void setScore(double score) {
		this.score = score;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ProgramFrequency [tmsId=" + tmsId + ", title=" + title
				+ ", score=" + score + "]";
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;

		if (obj instanceof ProgramFrequency) {
			ProgramFrequency objProgramFrequency = (ProgramFrequency) obj;
			if (objProgramFrequency.score == this.score
					&& objProgramFrequency.title.equals(this.title)
					&& objProgramFrequency.tmsId.equals(tmsId)) {
				result = true;

			}
		}

		return result;
	}


}
