/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.codehaus.jackson.map.ObjectMapper;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.service.FrequencyStatisticsService;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.IndexingStringArray;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;

/**
 * 
 * 
 * <H3>UserDataConfiguration</H3>
 * 
 * @author TuTX1
 * @since Jun 25, 2014
 */
public class UserDataConfiguration {
	private static Logger LOGGER = LoggerFactory.getLogger(UserDataConfiguration.class);
	public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	public static final String IS_AWS = "isAWS";
	public static final int ZIP_CODE_LENGTH = 5;
	//public static HbaseTableConfiguration ACCOUNT_ID_TO_ENCRYPTED_ID;
	//public static HbaseTableConfiguration ENCRYPTED_ID_TO_ACCOUNT_ID;
	//public static HbaseTableConfiguration CARD_ID_TO_ACCOUNT_ID;
	//public static HbaseTableConfiguration ACCOUNT_ID_TO_REGION_ID;
	//public static HbaseTableConfiguration ZIP_CODE_TO_LOCATION;

	// public static HbaseTableConfiguration CBCF;
	// public static HbaseTableConfiguration CBCF_BY_DAY;
	// public static HbaseTableConfiguration LAST_ACTION;
	// public static HbaseTableConfiguration WHAT_IS_HOT;
	// public static HbaseTableConfiguration USER_VIEWING_HISTORY_HBASE_TABLE;
	//public static HbaseTableConfiguration LOOKUP_TABLE;
	//public static HbaseTableConfiguration RECOMMENDATIONS_JOB_HISTORY_TABLE;

	public static DateTimeFormatter HBASE_DATE_TIME_FORMAT = null;
	public static DateTimeFormatter HBASE_DATE_FORMAT = null;
	public static DateTimeFormatter DTV_DATE_TIME_FORMAT = null;
	public static DateTimeFormatter RJH_INPUT_DATE_TIME_FORMAT = null;

	public static IndexingStringArray MAIN_CATEGORIES = IndexingStringArray.createIndexingArray();
	public static IndexingStringArray EVENT_TYPES = IndexingStringArray.createIndexingArray();
	public static IndexingStringArray CBCF_TIME_WINDOW = IndexingStringArray.createIndexingArray();
	public static IndexingStringArray WIH_TIME_WINDOW = IndexingStringArray.createIndexingArray();
	public static IndexingStringArray ATTRIBUTES = IndexingStringArray.createIndexingArray();

	// public static String DEFAULT_TIME_WINDOW;
	// public static String[] TIME_WINDOW;

	public static String GENRE_ATTRIBUTE;
	// public static List<String> ATTRIBUTES = new ArrayList<String>();
	public static Map<String, Map<String, String[][]>> CBCF_COLUMN_QUALIFIER_MAPPING = new HashMap<String, Map<String, String[][]>>();

	//public static org.apache.hadoop.conf.Configuration CONFIGURATION; // =
																		// HBaseConfiguration.create();
	// public static HConnection hConnection = null;

	/**
	 * Define column qualifier for HBase table.
	 */
	//public static Map<String, String> LOOKUP_TABLE_MAPPING = new HashMap<String, String>();

	public static Set<String> IGNORED_SUB_CATEGORIES_SET = new HashSet<String>();

	public static Map<String, String> RULE_VALUE_MAPPING = new HashMap<String, String>();

	public static void loadRuleValueMapping() {
		String[] valueList = com.directv.uds.utils.Configuration.getInstance().getStringArray("listBuilderValue");
		for (String value : valueList) {
			String[] keyValue = value.split(";");
			if (keyValue.length == 2) {
				RULE_VALUE_MAPPING.put(keyValue[0], keyValue[1]);
			}
		}
	}

	/**
	 * This is for testing purpose only
	 * 
	 * @param file
	 */
	public static void loadRuleValueMapping(File file) {

		BufferedReader reader = null;

		try {
			reader = new BufferedReader(new FileReader(file));
			String line = null;

			while ((line = reader.readLine()) != null) {
				String[] values = line.split(";");
				if (values.length == 2) {
					RULE_VALUE_MAPPING.put(values[0], values[1]);
				}
			}
		} catch (FileNotFoundException e) {
			LOGGER.error(e.getMessage());
		} catch (IOException e) {
			LOGGER.error(e.getMessage());
		} finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		}

	}

	/**
	 * Load all configuration.
	 * 
	 * Description
	 * 
	 * @param conf
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void load() throws IOException {

		// load main categories from properties file and lower case the value
		Configuration config = com.directv.uds.utils.Configuration.getInstance();
		MAIN_CATEGORIES.addAll(config.getStringArray("mainCategories"));
		MAIN_CATEGORIES.setDefaultValue(config.getString("allMainCategories"));

		EVENT_TYPES.addAll(config.getStringArray("eventTypes"));

		CBCF_TIME_WINDOW.addAll(config.getStringArray("cbcfTimeWindow"));
		CBCF_TIME_WINDOW.setDefaultValue(0);
		WIH_TIME_WINDOW.addAll(config.getStringArray("wihTimeWindow"));
		WIH_TIME_WINDOW.setDefaultValue(0);

		// load ignored sub categories (Series...)
		// String[] ignoredGenres = getValue(conf, "ignoredSubCategories",
		// String[].class);
		String[] ignoredGenres = config.getStringArray("ignoredSubCategories");
		for (String ignore : ignoredGenres) {
			IGNORED_SUB_CATEGORIES_SET.add(ignore.toLowerCase());
		}

		// load configuration for getEncryptedIdFromAccountId service
		// contains accountId - encryptedId mapping table's name, column family
		// and column qualifiers
		//ACCOUNT_ID_TO_ENCRYPTED_ID = new HbaseTableConfiguration(config.getString("accountIdToEncryptedIdHbaseTable"), config.getString(
		//		"accountIdToEncryptedIdColumnFamily").getBytes(), config.getString("accountIdToEncryptedIdColumnQualifier").getBytes());

		// load configuration for getAccountIdFromEncryptedId service
		// contains encryptedId - accountId mapping table's name, column family
		// and column qualifiers
		//ENCRYPTED_ID_TO_ACCOUNT_ID = new HbaseTableConfiguration(config.getString("encryptedIdToAccountIdHbaseTable"), config.getString(
		//		"encryptedIdToAccountIdColumnFamily").getBytes(), config.getString("encryptedIdToAccountIdColumnQualifier").getBytes());

		// load configuration for getAccountIdFromCardId service
		// contains cardId - accountId mapping table's name, column family and
		// column qualifiers
		//CARD_ID_TO_ACCOUNT_ID = new HbaseTableConfiguration(config.getString("cardIdToAccountIdHbaseTable"), config.getString(
		//		"cardIdToAccountIdColumnFamily").getBytes(), config.getString("cardIdToAccountIdColumnQualifier").getBytes());
		//ACCOUNT_ID_TO_REGION_ID = new HbaseTableConfiguration(config.getString("accountIdToRegionIdHBaseTable"), config.getString(
		//		"accountIdToRegionIdColumnFamily").getBytes(), config.getStringArray("accountIdToRegionIdColumnQualifier"));
		//ZIP_CODE_TO_LOCATION = new HbaseTableConfiguration(config.getString("zipCodeToLocationHbaseTable"), config.getString(
		//		"zipCodeToLocationColumnFamily").getBytes(), config.getString("zipCodeToLocationColumnQualifier").getBytes());

		// load configuration for get cbcf's vector
		// contains cbcf table's name, column family and column qualifiers
		// CBCF = new
		// HbaseTableConfiguration(config.getString("cbcfHbaseTable"),
		// config.getString("cbcfColumnFamily").getBytes(), "".getBytes());

		// load configuration for get user viewing history service
		// contains userViewingHistory mapping table's name, column family and
		// column qualifiers
		// USER_VIEWING_HISTORY_HBASE_TABLE = new
		// HbaseTableConfiguration(config.getString("userViewingHistoryHbaseTable"),
		// config.getString("userViewingHistoryColumnFamily").getBytes(),
		// "".getBytes());

		//LOOKUP_TABLE = new HbaseTableConfiguration(config.getString("lookupHbaseTable"), config.getString("lookupColumnFamily").getBytes(),
		//		config.getStringArray("lookupColumnQualifier"));

		// LOOKUP_TABLE_MAPPING = getValue(conf, "lookupTableMapping",
		// Map.class);

		//RECOMMENDATIONS_JOB_HISTORY_TABLE = new HbaseTableConfiguration(config.getString("recommendationsJobHistoryTable"), config
		//		.getString("recommendationsJobHistoryColumnFamily").getBytes(), (byte[]) null);

		// CBCF_BY_DAY = new
		// HbaseTableConfiguration(config.getString("cbcfByDayHbaseTable"),
		// config.getString("cbcfByDayColumnFamily").getBytes(), "".getBytes());

		// LAST_ACTION = new
		// HbaseTableConfiguration(config.getString("lastActionHbaseTable"),
		// config.getString("lastActionColumnFamily").getBytes(),
		// "".getBytes());

		// WHAT_IS_HOT = new
		// HbaseTableConfiguration(config.getString("whatIsHotHbaseTable"),
		// config.getString("whatIsHotColumnFamily").getBytes(), "".getBytes());

		HBASE_DATE_TIME_FORMAT = DateTimeFormat.forPattern(config.getString("hbaseDateTimeFormat"));
		HBASE_DATE_FORMAT = DateTimeFormat.forPattern(config.getString("hbaseDateFormat"));
		DateTimeZone.setDefault(DateTimeZone.forID(config.getString("com.directv.uds.common.timezone")));
		DTV_DATE_TIME_FORMAT = ISODateTimeFormat.dateTimeNoMillis();
		RJH_INPUT_DATE_TIME_FORMAT = ISODateTimeFormat.dateTime();
		// set time zone
		HBASE_DATE_TIME_FORMAT.withZone(DateTimeZone.UTC);
		HBASE_DATE_FORMAT.withZone(DateTimeZone.UTC);
		DTV_DATE_TIME_FORMAT.withZone(DateTimeZone.UTC);
		RJH_INPUT_DATE_TIME_FORMAT.withZone(DateTimeZone.UTC);

		//LOOKUP_TABLE_MAPPING
		//		.put(SERVICES.userViewingHistoryService.getKey(), config.getString(SERVICES.userViewingHistoryService.getKey()));
		//LOOKUP_TABLE_MAPPING.put(SERVICES.cbcfByDayService.getKey(), config.getString(SERVICES.cbcfByDayService.getKey()));
		//LOOKUP_TABLE_MAPPING.put(SERVICES.cbcfService.getKey(), config.getString(SERVICES.cbcfService.getKey()));
		//LOOKUP_TABLE_MAPPING.put(SERVICES.lastActionService.getKey(), config.getString(SERVICES.lastActionService.getKey()));
		//LOOKUP_TABLE_MAPPING.put(SERVICES.whatIsHotService.getKey(), config.getString(SERVICES.whatIsHotService.getKey()));
		loadAttributeFrequencyVector();

		loadFilterConfig();

		LOGGER.info("Main categories: {}", Arrays.toString(MAIN_CATEGORIES.getValues()));
		//LOGGER.info("Account to encrypted mapping table configuration is: {}", ACCOUNT_ID_TO_ENCRYPTED_ID);
		//LOGGER.info("Encrypted to account mapping table configuration is: {}", ENCRYPTED_ID_TO_ACCOUNT_ID);
		//LOGGER.info("Card to account mapping table configuration is: {}", CARD_ID_TO_ACCOUNT_ID);
		// LOG.info("CBCF table configuration is: " + CBCF);
		// LOG.info("User viewing history in hbase is: "
		// + USER_VIEWING_HISTORY_HBASE_TABLE);

		LOGGER.info("Hbase date time format is: {}", HBASE_DATE_TIME_FORMAT);
		LOGGER.info("Hbase date format is: {}", HBASE_DATE_FORMAT);
		LOGGER.info("DTV date time format is: {}", DTV_DATE_TIME_FORMAT);
		LOGGER.info("RJH service input date time format is:{}", RJH_INPUT_DATE_TIME_FORMAT);
		//LOGGER.info("key: {}", SERVICES.whatIsHotService.getKey());
		//LOGGER.info("value: {}", config.getString(SERVICES.whatIsHotService.getKey()));
	}

	/**
	 * Load filter config to enum
	 */
	private static void loadFilterConfig() {

		LOGGER.info("Load configuration for List Builder filter names");

		// Delivery filter
		Configuration config = com.directv.uds.utils.Configuration.getInstance();
		LAFilterType.Filter.DELIVERY.setName(config.getString("deliverName"));
		LAFilterType.Filter.DELIVERY.setValue(config.getString("deliverValue"));
		LOGGER.info("{} {}", LAFilterType.Filter.DELIVERY.getName(), LAFilterType.Filter.DELIVERY.getValue());

		// Genre filter
		LAFilterType.Filter.GENRE.setName(config.getString("genreName"));
		LAFilterType.Filter.GENRE.setValue(config.getString("genreValue").replace("-", ","));
		LOGGER.info("{} {}", LAFilterType.Filter.GENRE.getName(), LAFilterType.Filter.GENRE.getValue());

		// Rating filter
		LAFilterType.Filter.RATING.setName(config.getString("ratingName"));
		LAFilterType.Filter.RATING.setValue(config.getString("ratingValue"));
		LOGGER.info("{} {}", LAFilterType.Filter.RATING.getName(), LAFilterType.Filter.RATING.getValue());

		// Pay filter
		LAFilterType.Filter.PAY.setName(config.getString("ppvName"));
		LAFilterType.Filter.PAY.setValue(config.getString("ppvValue"));
		LOGGER.info("{} {}", LAFilterType.Filter.PAY.getName(), LAFilterType.Filter.PAY.getValue());

		// Type filter
		LAFilterType.Filter.TYPE.setName(config.getString("categoryName"));
		LAFilterType.Filter.TYPE.setValue(config.getString("categoryValue"));
		LOGGER.info("{} {}", LAFilterType.Filter.TYPE.getName(), LAFilterType.Filter.TYPE.getValue());

		// Day of week filter
		LAFilterType.Filter.DAY_OF_WEEK.setName(config.getString("dayOfWeekName"));
		LAFilterType.Filter.DAY_OF_WEEK.setValue(config.getString("dayOfWeekValue"));
		LOGGER.info(LAFilterType.Filter.DAY_OF_WEEK.getName() + " " + LAFilterType.Filter.DAY_OF_WEEK.getValue());

		// Device filter
		LAFilterType.Filter.DEVICE.setName(config.getString("deviceName"));
		LAFilterType.Filter.DEVICE.setValue(config.getString("deviceValue"));
		LOGGER.info("{} {}", LAFilterType.Filter.DEVICE.getName(), LAFilterType.Filter.DEVICE.getValue());

		// Time of day filter
		LAFilterType.Filter.TIME_OF_DAY.setName(config.getString("timeOfDayName"));
		LAFilterType.Filter.TIME_OF_DAY.setValue(config.getString("timeOfDayValue"));
		LOGGER.info("{} {}", LAFilterType.Filter.TIME_OF_DAY.getName(), LAFilterType.Filter.TIME_OF_DAY.getValue());
	}

	/**
	 * Load Filter Operator Config to Enum
	 */
	// private static void loadFilterOperatorConfig() {
	// //Operator IS
	// LAFilterType.Operator.IS.setName(config.getString("isOperatorName"));
	// LAFilterType.Operator.IS.setValue(config.getString("isOperatorValue"));
	//
	// //Operator IS NOT
	// LAFilterType.Operator.IS_NOT.setName(config.getString("isNotOperatorName"));
	// LAFilterType.Operator.IS_NOT.setValue(config.getString("isNotOperatorValue"));
	//
	// //Operator IS_GREATER_THAN_OR_EQUAL
	// LAFilterType.Operator.IS_GREATER_THAN_OR_EQUAL.setName(config.getString("isGreaterThanOrEqualOperatorName"));
	// LAFilterType.Operator.IS_GREATER_THAN_OR_EQUAL.setValue(config.getString("isGreaterThanOrEqualOpeartorValue"));
	//
	// //Operator IS_LESS_THAN_OR_EQUAL
	// LAFilterType.Operator.IS_LESS_THAN_OR_EQUAL.setName(config.getString("isLessThanOrEqualOperatorName"));
	// LAFilterType.Operator.IS_LESS_THAN_OR_EQUAL.setValue(config.getString("isLessThanOrEqualOperatorValue"));
	//
	// //Operator IS_IN_THE_RANGE
	// LAFilterType.Operator.IS_IN_THE_RANGE.setName(config.getString("isInTheRangeOperatorName"));
	// LAFilterType.Operator.IS_IN_THE_RANGE.setValue(null);
	//
	// //Operator ON
	// LAFilterType.Operator.ON.setName(config.getString("onOperatorName"));
	// LAFilterType.Operator.ON.setValue(config.getString("onOperatorValue"));
	//
	// //Operator IS
	// LAFilterType.Operator.IS.setName(config.getString("notOnOperatorName"));
	// LAFilterType.Operator.IS.setValue(config.getString("notOnOperatorValue"));
	// }

	/**
	 * 
	 */
	@Deprecated
	private static void loadAttributeFrequencyVector() {
		Configuration config = com.directv.uds.utils.Configuration.getInstance();
		ATTRIBUTES.addAll(config.getStringArray("cbcfAttributes"));
		ATTRIBUTES.setDefaultValue(0);
		
		//we don't want the logic to depend on ordering of names in cbcfAttributes
		//GENRE_ATTRIBUTE = ATTRIBUTES.getDefaultValue();
		GENRE_ATTRIBUTE = config.getString(FrequencyStatisticsService.GENRE_TYPE_DEFAULT);

		String[] daysOfWeek = config.getStringArray("daysOfWeek");
		for (String attribute : ATTRIBUTES.getValues()) {
			Map<String, String[][]> attributeColumnQualifiers = new HashMap<String, String[][]>();
			CBCF_COLUMN_QUALIFIER_MAPPING.put(attribute.toLowerCase(), attributeColumnQualifiers);

			for (int i = 0; i < CBCF_TIME_WINDOW.getSize(); i++) {
				String[][] columnQualifiers = new String[MAIN_CATEGORIES.getSize()][daysOfWeek.length];
				for (int j = 0; j < MAIN_CATEGORIES.getSize(); j++) {
					for (int k = 0; k < daysOfWeek.length; k++) {
						columnQualifiers[j][k] = CBCF_TIME_WINDOW.getValue(i) + "." + attribute + "." + MAIN_CATEGORIES.getValue(j) + "."
								+ daysOfWeek[k];
					}
				}

				attributeColumnQualifiers.put(CBCF_TIME_WINDOW.getValue(i).toLowerCase(), columnQualifiers);
			}
		}

	}
}