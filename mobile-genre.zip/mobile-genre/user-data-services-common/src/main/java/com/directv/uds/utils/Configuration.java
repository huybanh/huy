/**
 * 
 * DIRECTV PROPRIETARY Copyright© 2013 DIRECTV, INC. UNPUBLISHED WORK ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information, in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with DIRECTV providing access to this software.
 */

package com.directv.uds.utils;

import java.io.File;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationConverter;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.DefaultConfigurationBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.stereotype.Component;

@Component
public class Configuration extends PropertyPlaceholderConfigurer {
	
	public static final String MAIN_CATEGORY_TV = "MAIN_CATEGORY_TV";
	public static final String MAIN_CATEGORY_SPORTS = "MAIN_CATEGORY_SPORTS";

	private org.apache.commons.configuration.CombinedConfiguration config;
	private static Configuration configInstance = new Configuration();;
	private static final Logger LOGGER = LoggerFactory.getLogger(Configuration.class);

	protected final DefaultConfigurationBuilder dcb;

	@Override
	protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props) throws BeansException {
		Properties properties = getProps();
		super.processProperties(beanFactory, properties);
	}

	protected Configuration() {
		File file = new File("config.xml");
		dcb = new DefaultConfigurationBuilder(file);
		try {
			config = dcb.getConfiguration(true);
		} catch (ConfigurationException e) {
			LOGGER.error("error while building configuration", e);
			throw new RuntimeException(e);
		}
		configInstance = this;
	}

	public static Configuration getInstance() {
		/*// This may need to be a synchronized lookup
		if (configInstance == null) {
			configInstance = new Configuration();
		}*/
		return configInstance;
	}

	public Properties getProps() {
		return ConfigurationConverter.getProperties(config);
	}

	public org.apache.commons.configuration.Configuration getApacheConfiguration() {
		return config;
	}

	protected void addConfiguration(org.apache.commons.configuration.Configuration configuration) {
		synchronized (config) {
			config.append(configuration);
		}
	}

	public org.apache.commons.configuration.Configuration subset(String prefix) {
		return config.subset(prefix);
	}

	public boolean isEmpty() {
		return config.isEmpty();
	}

	public boolean containsKey(String key) {
		return config.containsKey(key);
	}

	public void addProperty(String key, Object value) {
		config.addProperty(key, value);
	}

	public void setProperty(String key, Object value) {
		config.setProperty(key, value);
	}

	public void clearProperty(String key) {
		config.clearProperty(key);
	}

	public void clear() {
		config.clear();
	}

	public Object getProperty(String key) {
		return config.getProperty(key);
	}

	public Iterator<?> getKeys(String prefix) {
		return config.getKeys(prefix);
	}

	public Iterator<?> getKeys() {
		return config.getKeys();
	}

	public Properties getProperties(String key) {
		return config.getProperties(key);
	}

	public boolean getBoolean(String key) {
		return config.getBoolean(key);
	}

	public boolean getBoolean(String key, boolean defaultValue) {
		return config.getBoolean(key, defaultValue);
	}

	public Boolean getBoolean(String key, Boolean defaultValue) {
		return config.getBoolean(key, defaultValue);
	}

	public byte getByte(String key) {
		return config.getByte(key);
	}

	public byte getByte(String key, byte defaultValue) {
		return config.getByte(key, defaultValue);
	}

	public Byte getByte(String key, Byte defaultValue) {
		return config.getByte(key, defaultValue);
	}

	public double getDouble(String key) {
		return config.getDouble(key);
	}

	public double getDouble(String key, double defaultValue) {
		return config.getDouble(key, defaultValue);
	}

	public Double getDouble(String key, Double defaultValue) {
		return config.getDouble(key, defaultValue);
	}

	public float getFloat(String key) {
		return config.getFloat(key);
	}

	public float getFloat(String key, float defaultValue) {
		return config.getFloat(key, defaultValue);
	}

	public Float getFloat(String key, Float defaultValue) {
		return config.getFloat(key, defaultValue);
	}

	public int getInt(String key) {
		return config.getInt(key);
	}

	public int getInt(String key, int defaultValue) {
		return config.getInt(key, defaultValue);
	}

	public Integer getInteger(String key, Integer defaultValue) {
		return config.getInteger(key, defaultValue);
	}

	public long getLong(String key) {
		return config.getLong(key);
	}

	public long getLong(String key, long defaultValue) {
		return config.getLong(key, defaultValue);
	}

	public Long getLong(String key, Long defaultValue) {
		return config.getLong(key, defaultValue);
	}

	public short getShort(String key) {
		return config.getShort(key);
	}

	public short getShort(String key, short defaultValue) {
		return config.getShort(key, defaultValue);
	}

	public Short getShort(String key, Short defaultValue) {
		return config.getShort(key, defaultValue);
	}

	public BigDecimal getBigDecimal(String key) {
		return config.getBigDecimal(key);
	}

	public BigDecimal getBigDecimal(String key, BigDecimal defaultValue) {
		return config.getBigDecimal(key, defaultValue);
	}

	public BigInteger getBigInteger(String key) {
		return config.getBigInteger(key);
	}

	public BigInteger getBigInteger(String key, BigInteger defaultValue) {
		return config.getBigInteger(key, defaultValue);
	}

	public String getString(String key) {
		return config.getString(key);
	}

	public String getString(String key, String defaultValue) {
		return config.getString(key, defaultValue);
	}

	public String[] getStringArray(String key) {
		return config.getStringArray(key);
	}

	public List<?> getList(String key) {
		return config.getList(key);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<?> getList(String key, List defaultValue) {
		return config.getList(key, defaultValue);
	}
}
