/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import java.util.List;

import com.dtv.hbase.model.Event;

/**
 * <H3>LastActionEvent</H3>
 *
 * @author TuTX1
 * @since Jul 4, 2014
 */
public class LastAction {
	//***** constructor *****
	//***** public method *****
	//***** protected method *****
	//***** private method *****
	//***** call back method *****
	//***** getter and setter *****
	
	private String subCategory;
	private List<Event> events;
	
	/**
	 * Constructor<br>
	 */
	public LastAction() {
		super();
		
	}

	/**
	 * Constructor<br>
	 * @param subCategory
	 * @param events
	 */
	public LastAction(String subCategory, List<Event> events) {
		super();
		this.subCategory = subCategory;
		this.events = events;
	}
	
	/**
	 * <br>
	 * @return  subCategory
	 */
	
	public String getSubCategory() {
		return subCategory;
	}
	/**
	 *<br>
	 * @param subCategory the subCategory to set
	 */
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	/**
	 * <br>
	 * @return  events
	 */
	
	public List<Event> getEvents() {
		return events;
	}
	/**
	 *<br>
	 * @param events the events to set
	 */
	public void setEvents(List<Event> events) {
		this.events = events;
	}
	
	
}
