/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.getRule.response;

import java.util.ArrayList;
import java.util.List;

import com.directv.uds.model.rs.response.LastActionResult;

/**
 * <H3>RuleDataResponse</H3>
 *
 * @author ThanhNN2
 * @since Oct 13, 2014
 */
public class RuleDataResponse {
	/**
	 * List of last action results based on rule name.
	 */
	private List<LastActionResult> lastActionData;
	/**
	 * List of user taste data.
	 */
	private List<UserTasteDataResult> userTastesData;
	/**
	 * List of whats hot data.
	 */
	private List<WhatsHotDataResult> whatshotData;

	/**
	 * @return the lastActionData
	 */
	public List<LastActionResult> getLastActionData() {
		if (lastActionData == null) {
			lastActionData = new ArrayList<LastActionResult>();
		}
		return lastActionData;
	}

	/**
	 * @param lastActionData
	 *            the lastActionData to set
	 */
	public void setLastActionData(List<LastActionResult> lastActionData) {
		this.lastActionData = lastActionData;
	}

	/**
	 * @return the userTastesData
	 */
	public List<UserTasteDataResult> getUserTastesData() {
		if (userTastesData == null) {
			userTastesData = new ArrayList<UserTasteDataResult>();
		}
		return userTastesData;
	}

	/**
	 * @param userTastesData
	 *            the userTastesData to set
	 */
	public void setUserTastesData(List<UserTasteDataResult> userTastesData) {
		this.userTastesData = userTastesData;
	}

	/**
	 * @return the whatshotData
	 */
	public List<WhatsHotDataResult> getWhatshotData() {
		if (whatshotData == null) {
			whatshotData = new ArrayList<WhatsHotDataResult>();
		}
		return whatshotData;
	}

	/**
	 * @param whatshotData
	 *            the whatshotData to set
	 */
	public void setWhatshotData(List<WhatsHotDataResult> whatshotData) {
		this.whatshotData = whatshotData;
	}

}
