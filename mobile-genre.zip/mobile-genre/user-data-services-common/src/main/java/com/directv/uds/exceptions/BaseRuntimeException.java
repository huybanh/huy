/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.exceptions;

import javax.ws.rs.core.Response.StatusType;

import com.directv.uds.model.Errors;

/**
 * Base Runtime Exception class. It will be used as Polymorphism way in the
 * ExceptionHandler to send error response.
 * 
 * @author mgiramkar
 * 
 */
public class BaseRuntimeException extends RuntimeException {

	private static final long serialVersionUID = -1296991171087433939L;
	private String errorMessage;
	private String errorCode;
	/**
	 * contains list of error (code, message).
	 */
	private Errors errors;

	/**
	 * http status type.
	 */
	private StatusType status;

	public BaseRuntimeException(Throwable throwable) {
		super(throwable);
	}

	public BaseRuntimeException(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public BaseRuntimeException(Errors errors, StatusType status) {
//		super();
		this.errors = errors;
		this.status = status;
	}

	public BaseRuntimeException() {
		super();
	}

	public BaseRuntimeException(String errorCode, String errorMessage, Throwable cause) {
		super(cause);
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public Errors getErrors() {
		return errors;
	}

	public void setErrors(Errors errors) {
		this.errors = errors;
	}

	public StatusType getStatus() {
		return status;
	}

	public void setStatus(StatusType status) {
		this.status = status;
	}

}
