/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * <H3>DMAInformation</H3>
 * 
 * @author ThanhNN2
 * @since Nov 11, 2014
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DMAInformation {
	private String dmaDescription;
	private String dma;
	private String timeZone;
	private String zipCode;
	private String countyCode;

	/**
	 * @return the dmaDescription
	 */
	public String getDmaDescription() {
		return dmaDescription;
	}

	/**
	 * @param dmaDescription
	 *            the dmaDescription to set
	 */
	public void setDmaDescription(String dmaDescription) {
		this.dmaDescription = dmaDescription;
	}

	/**
	 * @return the dmaCode
	 */
	public String getDma() {
		return dma;
	}

	/**
	 * @param dmaCode
	 *            the dmaCode to set
	 */
	public void setDma(String dmaCode) {
		this.dma = dmaCode;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone
	 *            the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the zipCode
	 */
	public String getZipCode() {
		return zipCode;
	}

	/**
	 * @param zipCode
	 *            the zipCode to set
	 */
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode
	 *            the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	@Override
	public String toString() {
		return "DMAInformation [timeZone=" + timeZone + ", zipCode=" + zipCode + ", countyCode=" + timeZone + ", dmaDescription="
				+ dmaDescription + ", dma=" + dma + "]";
	}

}
