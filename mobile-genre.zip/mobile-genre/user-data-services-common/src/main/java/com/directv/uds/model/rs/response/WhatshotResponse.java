/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.response;

import java.util.List;

import com.directv.uds.model.ProgramFrequency;

/**
 * <H3>WhatshotResponse</H3>
 *
 * @author ThanhNN2
 * @since Nov 11, 2014
 */
public class WhatshotResponse {
	private List<ProgramFrequency> whatshot;
	private String dmaCode;
	private String dmaDescription;

	/**
	 * @return the whatshot
	 */
	public List<ProgramFrequency> getWhatshot() {
		return whatshot;
	}

	/**
	 * @param whatshot
	 *            the whatshot to set
	 */
	public void setWhatshot(List<ProgramFrequency> whatshot) {
		this.whatshot = whatshot;
	}

	/**
	 * @return the dmaCode
	 */
	public String getDmaCode() {
		return dmaCode;
	}

	/**
	 * @param dmaCode
	 *            the dmaCode to set
	 */
	public void setDmaCode(String dmaCode) {
		this.dmaCode = dmaCode;
	}

	/**
	 * @return the dmaDescription
	 */
	public String getDmaDescription() {
		return dmaDescription;
	}

	/**
	 * @param dmaDescription
	 *            the dmaDescription to set
	 */
	public void setDmaDescription(String dmaDescription) {
		this.dmaDescription = dmaDescription;
	}

}
