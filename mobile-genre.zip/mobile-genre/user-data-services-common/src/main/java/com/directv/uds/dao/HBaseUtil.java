/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.ZooKeeperConnectionException;
import org.apache.hadoop.hbase.client.Delete;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HTableInterface;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.ColumnPrefixFilter;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.PageFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dtv.hbase.model.Event;

/**
 * <H3>HBaseUtil</H3>
 * 
 * @author HuynhNB
 * @since Mar 7, 2014
 */
public class HBaseUtil {
	
	/**
	 * From HBase 0.94 API document: (https://hbase.apache.org/0.94/apidocs/index.html)
		 The simplest way to use this class is by using createConnection(Configuration). 
		 This creates a new HConnection that is managed by the caller. 
		 From this HConnection HTableInterface implementations are retrieved with HConnection.getTable(byte[]). 
		 Example:
		
		 HConnection connection = HConnectionManager.createConnection(config);
		 HTableInterface table = connection.getTable("table1");
		 // use the table as needed, for a single operation and a single thread
		 table.close();
		 connection.close();
	 */
	private static HConnection connection;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HBaseUtil.class);
	
	public static void initialize(HConnection hconnection) throws ZooKeeperConnectionException {
		connection = hconnection;
	}

	/**
	 * Checks if the specified tableName/row/family/qualifier has value of checkValue
	 * If yes, put with given putValue
	 * 
	 * @return true if the new put was executed, false otherwise
	 */
	public static boolean checkAndPut(String tableName, byte[] row, byte[] family, byte[] qualifier, byte[] checkValue, byte[] putValue) throws IOException {

		if (LOGGER.isDebugEnabled()) {
			String checkValueString = checkValue == null ? null : new String(checkValue);
			LOGGER.debug("checkAndPut {} {} {} {}: check for: {} / put: {}", 
					tableName, new String(row), new String(family), new String(qualifier), checkValueString, new String(putValue));
		}
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Put put = new Put(row);
			put.add(family, qualifier, putValue);
			return table.checkAndPut(row, family, qualifier, checkValue, put);
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	/**
	 * Checks if the specified tableName/row/family/qualifier has value of checkValue
	 * If yes, delete that cell
	 * 
	 * @return true if the new delete was executed, false otherwise
	 * 
	 */
	public static boolean checkAndDelete(String tableName, byte[] row, byte[] family, byte[] qualifier, byte[] checkValue) throws IOException {

		if (LOGGER.isDebugEnabled()) {
			String checkValueString = checkValue == null ? null : new String(checkValue);
			LOGGER.debug("checkAndDelete {} {} {} {}: check for: {}", 
					tableName, new String(row), new String(family), new String(qualifier), checkValueString);
		}
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Delete del = new Delete(row);
			del.deleteColumns(family, qualifier);
			return table.checkAndDelete(row, family, qualifier, checkValue, del);
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}
	public static void put(String tableName, byte[] row, byte[] family, byte[] qualifier, byte[] putValue) throws IOException {
		
		//HTable hTable = new HTable(conf, table);
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Put put = new Put(row);
			put.add(family, qualifier, putValue);
			table.put(put);
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	public static String getHbaseValue(String key, String tableName, byte[] columnFamily, byte[] columnQualifier) throws IOException {
		
		//HTable hTable = new HTable(conf, table);
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Get get = new Get(Bytes.toBytes(key));
			get.addColumn(columnFamily, columnQualifier);
			
			Result result = table.get(get);
			byte[] value = result.getValue(columnFamily, columnQualifier);
			if (value == null) {
				return null;
			}
			return new String(value);
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	public static List<KeyValue> getRow(String key, String tableName, byte[] columnFamily, String[] columnQualifiers) throws IOException {
		
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Get get = new Get(key.getBytes());
			for (String oneQualifier : columnQualifiers) {
				get.addColumn(columnFamily, oneQualifier.getBytes());
			}
			Result result = table.get(get);
			return result.list();
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	public static Map<String, List<KeyValue>> getRowsByKeys(String tableName, String[] keys, byte[] columnFamily) throws IOException {
		
		//HTable hTable = new HTable(conf, table);
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			List<Get> batch = new ArrayList<Get>();
			for (String key : keys) {
				Get oneGet = new Get(key.getBytes());
				oneGet.addFamily(columnFamily);
				batch.add(oneGet);
			}
			Result[] results = table.get(batch);
			Map<String, List<KeyValue>> returnRow = new HashMap<String, List<KeyValue>>();
			if (results != null && results.length > 0) {
				for (int i = 0; i < results.length; i++) {
					if (results[i] != null) {
						returnRow.put(keys[i], results[i].list());
					}
				}
			}
			return returnRow;
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	/**
	 * Return an array of value corresponding to arrays of column qualifiers
	 * 
	 * @param conf
	 * @param key
	 * @param table
	 * @param columnFamily
	 * @param columnQualifier
	 * @return
	 * @throws IOException
	 */
	public static String[][] getHbaseValue(String key, String tableName, byte[] columnFamily, String[][] columnQualifiers) throws IOException {

		//HTable hTable = new HTable(conf, table);
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Get get = new Get(Bytes.toBytes(key));
			for (int j = 0; j < columnQualifiers.length; j++) {
				for (int i = 0; i < columnQualifiers[j].length; i++) {
					get.addColumn(columnFamily, columnQualifiers[j][i].getBytes());
				}
			}
			
			LOGGER.debug("GET: " + get);
			Result getResult = table.get(get);
			LOGGER.debug("GET result: " + getResult);
			String[][] result = new String[columnQualifiers.length][];
			for (int j = 0; j < columnQualifiers.length; j++) {
				result[j] = new String[columnQualifiers[j].length];
				for (int i = 0; i < columnQualifiers[j].length; i++) {
					byte[] value = getResult.getValue(columnFamily, columnQualifiers[j][i].getBytes());
					if (value != null) {
						result[j][i] = new String(value);
					}
				}
			}
			return result;
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	public static Map<String, List<KeyValue>> getResultScanner(String tableName, byte[] columnFamily, String startRow, String stopRow, int pageSize) throws IOException {

		HTableInterface table = null;
		Map<String, List<KeyValue>> value = new HashMap<String, List<KeyValue>>();
		try {
			//hTable = new HTable(conf, tableName);
			table = connection.getTable(tableName);
			Scan scan = new Scan();

			if (startRow != null) {
				scan.setStartRow(startRow.getBytes());
			}

			if (stopRow != null) {
				scan.setStopRow(stopRow.getBytes());
			}

			if (pageSize > 0) {
				scan.setFilter(new PageFilter(pageSize));
			}
			
			ResultScanner resultScanner = table.getScanner(scan);
			if (resultScanner != null) {
				for (Result result : resultScanner) {
					value.put(new String(result.getRow()), result.list());
				}
			}
		} finally {
			if (table != null) {
				//try {
					table.close();
				//} catch (IOException e) {
				//	LOG.error(e);
				//}
			}
		}
		return value;
	}

	public static List<Event> getUserViewingHistory(String tableName, byte[] columnFamily, String startRow, String stopRow) throws IOException {

		//HTable hTable = new HTable(conf, table);
		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			Scan scan = new Scan();
			scan.setStartRow(startRow.getBytes());
			scan.setStopRow(stopRow.getBytes());
			ResultScanner resultScanner = table.getScanner(scan);
			List<Event> eventList = new ArrayList<Event>();
			for (Result result : resultScanner) {

				byte[] tmsId = result.getValue(columnFamily, "tmsId".getBytes());
				byte[] eventTime = result.getValue(columnFamily, "eventTime".getBytes());
				byte[] eventType = result.getValue(columnFamily, "eventType".getBytes());
				byte[] source = result.getValue(columnFamily, "source".getBytes());
				byte[] accountId = result.getValue(columnFamily, "accountId".getBytes());

				Event event = new Event();
				if (accountId != null) {
					event.setAccountId(Bytes.toString(accountId));
				}
				if (eventTime != null) {
					event.setEventTime(Bytes.toString(eventTime));
				}
				if (eventType != null) {
					event.setEventType(Bytes.toString(eventType));
				}
				if (tmsId != null) {
					event.setTmsId(Bytes.toString(tmsId));
				}
				if (source != null) {
					event.setSource(Bytes.toString(source));
				}

				eventList.add(event);
			}
			return eventList;
		} finally {
			if (table != null) {
				table.close();
			}
		}
	}

	public static Map<byte[], byte[]> getValuesByColumnQualifiers(
			String key, String tableName, byte[] columnFamily, List<String> columnQualifiers) throws IOException {

		// create column prefix filter list
		if (columnQualifiers == null || columnQualifiers.isEmpty()) {
			return null;
		}

		HTableInterface table = null;
		try {
			table = connection.getTable(tableName);
			if (table == null) {
				return null;
			}
			Get get = new Get(Bytes.toBytes(key));
			for (String oneColumn : columnQualifiers) {
				get.addColumn(columnFamily, oneColumn.getBytes());
			}
			Result result = table.get(get);
			return result.getFamilyMap(columnFamily);
		} finally {
			if (table != null) {
				table.close();
			}
		}

	}

	public static Map<byte[], byte[]> getValuesByColumnQualifierPrefixFilter(
			String key, String tableName, byte[] columnFamily, List<String> columnQualifierPrefix) throws IOException {

		// create column prefix filter list
		FilterList filterList = new FilterList(FilterList.Operator.MUST_PASS_ONE);
		if (columnQualifierPrefix == null || columnQualifierPrefix.isEmpty()) {
			return null;
		}
		for (String prefix : columnQualifierPrefix) {
			filterList.addFilter(new ColumnPrefixFilter(prefix.getBytes()));
		}

		HTableInterface table = null;
		Map<byte[], byte[]> values = null;
		try {
			//table = new HTable(conf, tableName);
			table = connection.getTable(tableName);
			Get get = new Get(Bytes.toBytes(key));
			get.setFilter(filterList);
			if (table != null) {
				Result result = table.get(get);
				// Get a Map<qualifier,value> for Family
				values = result.getFamilyMap(columnFamily);
			}

		} /*catch (IOException e) {
			LOG.error(e);
		}*/ finally {
			//try {
				if (table != null) {
					table.close();
				}
			//} catch (IOException e) {
			//	LOG.error(e);
			//}
		}
		return values;
	}
}