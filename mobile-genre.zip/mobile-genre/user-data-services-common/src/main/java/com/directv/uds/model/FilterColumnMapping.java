/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

/**
 * <H3>FilterColumnMapping</H3>
 *
 * @author ThanhNN2
 * @since Sep 25, 2014
 */
public class FilterColumnMapping {
	private String filterName;
	private String columnMapping;

	/**
	 * 
	 */
	public FilterColumnMapping(String filterName, String columnMapping) {
		this.filterName = filterName;
		this.columnMapping = columnMapping;
	}

	/**
	 * @return the filterName
	 */
	public String getFilterName() {
		return filterName;
	}

	/**
	 * @param filterName
	 *            the filterName to set
	 */
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	/**
	 * @return the columnMapping
	 */
	public String getColumnMapping() {
		return columnMapping;
	}

	/**
	 * @param columnMapping
	 *            the columnMapping to set
	 */
	public void setColumnMapping(String columnMapping) {
		this.columnMapping = columnMapping;
	}

}
