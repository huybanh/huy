/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.enums.ErrorCode;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.listbuilder.model.FilterType;
import com.directv.uds.listbuilder.model.MatchType;
import com.directv.uds.listbuilder.model.RuleType;
import com.directv.uds.listbuilder.model.StatementType;
import com.directv.uds.model.UserDataConfiguration;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType.Filter;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType.Operator;
import com.dtv.lastaction.listbuilderintegration.dto.LAMatchType;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;
import com.dtv.lastaction.listbuilderintegration.dto.LARuleType;
import com.dtv.lastaction.listbuilderintegration.dto.LAStatementType;

/**
 * <H3>RuleConverterUtil</H3>
 * 
 * @author ThanhNN2
 * @since Sep 30, 2014
 */
public class RuleConverterUtil {
	private static Logger LOGGER = LoggerFactory.getLogger(RuleConverterUtil.class);

	public static LAFilterType from(FilterType filterType) {
		if (filterType != null) {
			LAFilterType laFilterType = new LAFilterType();
			Filter name = Filter.fromName(filterType.getName());
			if (name == null) {
				LOGGER.error("Not found filter name {}", filterType.getName());
				throw new BadRequestException(ErrorCode.INVALID_PAYLOAD.getMessage() + " Filter " + filterType.getName() + " is unknown.");
				// return null;
			}
			laFilterType.setName(name);
			laFilterType.setOperation(Operator.from(filterType.getOperation()));
			laFilterType.setValue1(getValueFrom(filterType.getValue1()));
			laFilterType.setValue2(getValueFrom(filterType.getValue2()));
			return laFilterType;
		}
		return null;
	}

	private static String getValueFrom(String lbValue) {
		if (lbValue == null || lbValue.length() == 0) {
			//return null;
			return lbValue;
		}

		String mappedValue = UserDataConfiguration.RULE_VALUE_MAPPING.get(lbValue);
		if (mappedValue == null) {
			return lbValue;
		}
		return mappedValue;
	}

	public static LAStatementType from(StatementType statementType) {
		LAStatementType laStatementType = new LAStatementType();
		LAFilterType filter = from(statementType.getFilter());

		laStatementType.setFilter(filter);
		MatchType matchType = statementType.getMatch();
		LAMatchType laMatchType = from(matchType);
		laStatementType.setMatch(laMatchType);
		return laStatementType;
	}

	public static LAMatchType from(MatchType matchType) {
		LAMatchType laMatchType = new LAMatchType();
		if (matchType != null) {
			laMatchType.setType(LAMatchType.MatchType.from(matchType.getType()));
			List<StatementType> listStatementType = matchType.getStatement();

			List<LAStatementType> listLAStatementType = new ArrayList<LAStatementType>();
			if (listStatementType != null && !listStatementType.isEmpty()) {
				for (StatementType statementType : listStatementType) {
					LAStatementType statement = from(statementType);
					if (statement != null) {
						// listLAStatementType.add(from(statementType));
						listLAStatementType.add(statement);
					}
				}
			}
			laMatchType.setStatement(listLAStatementType);

		}
		return laMatchType;
	}

	private static LARuleType from(String ruleType) {

		try {
			LARuleType laRuleType = LARuleType.valueOf(ruleType);
			/*if (laRuleType == null) {
				throw new BadRequestException(ErrorCode.INVALID_PAYLOAD_RULE_TYPE.getMessage());
			}*/
			return laRuleType;
		} catch (IllegalArgumentException e) {
			LOGGER.error(e.getMessage(), e);
		}

		return null;
	}

	public static LARule from(RuleType rule) {
		LARule laRule = new LARule();
		laRule.setRuleName(rule.getRuleName());
		laRule.setState(rule.getState());
		laRule.setNumberOfEvents(rule.getMaxResult());

		LARuleType laRuleType = from(rule.getTypeOfRule());
		if (laRuleType == null) {
			return null;
		}
		laRule.setRuleType(laRuleType);
		if (rule.getUserBehavior() != null) {
			MatchType matchType = rule.getUserBehavior().getMatch();
			if (matchType == null || matchType.getType() == null) {
				return null;
			}
			laRule.setMatch(from(matchType));
		}

		return laRule;
	}

	public static List<LARule> from(List<RuleType> rules) {
		List<LARule> laRules = new ArrayList<LARule>();
		for (RuleType rule : rules) {
			LARule laRule = from(rule);
			if (laRule != null) {
				laRules.add(laRule);
			}
		}
		return laRules;
	}

}
