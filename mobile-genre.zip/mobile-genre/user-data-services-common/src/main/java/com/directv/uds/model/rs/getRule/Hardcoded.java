/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model.rs.getRule;

/**
 * <H3>Hardcoded</H3>
 *
 * @author ThanhNN2
 * @since Oct 13, 2014
 */
public class Hardcoded {
	public static String WHAT_IS_HOT_LABEL = "whatshot";
	public static String USER_TASTE_LABLE = "userTaste";
	public static String CORRELATION_ID_DEFAULT="default";

	public static final String DTV_CORRELATION_ID_REQUEST_HEADER_NAME="DTV-CorrelationId";
}
