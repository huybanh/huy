/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import java.util.List;

/**
 * <H3>LastActionPreview</H3>
 *
 * @author ThanhNN2
 * @since Oct 2, 2014
 */
public class LastActionPreview {
	private String ruleName;
	private List<InterpretedEvent> events;

	/**
	 * 
	 */
	public LastActionPreview() {
	}

	/**
	 * @param ruleName
	 * @param events
	 */
	public LastActionPreview(String ruleName, List<InterpretedEvent> events) {
		super();
		this.ruleName = ruleName;
		this.events = events;
	}

	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}

	/**
	 * @param ruleName
	 *            the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	/**
	 * @return the events
	 */
	public List<InterpretedEvent> getEvents() {
		return events;
	}

	/**
	 * @param events
	 *            the events to set
	 */
	public void setEvents(List<InterpretedEvent> events) {
		this.events = events;
	}

}
