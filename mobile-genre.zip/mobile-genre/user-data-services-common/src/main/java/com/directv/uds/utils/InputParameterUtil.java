/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.IllegalFieldValueException;
import org.joda.time.format.DateTimeFormatter;

import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.model.EventTime;

/**
 * <H3>InputParameterParser</H3> Utility class for parsing and validating input
 * parameter
 * 
 * @author TuTX1
 * @since Jun 24, 2014
 */
public class InputParameterUtil {

	/**
	 * Validate requested main category Description
	 * 
	 * @param mainCategoriesMapping
	 * @param requested
	 *            main category when mainCategory = null, it means return last
	 *            action of all main category
	 * @return String: validated main category
	 * @throws BadRequestException
	 */
	public static String parseMainCategory(IndexingStringArray mainCategories, String mainCategory)
			throws BadRequestException {

		if (mainCategory == null) {
			return null;
		}

		Integer index = mainCategories.getIndex(mainCategory);
		if (mainCategory != null && index == -1) {
			throw new BadRequestException(mainCategory
					+ " is invalid main category!");
		} else {
			return mainCategories.getValue(index);
		}
	}

	public static String parseEventType(IndexingStringArray eventTypes, String eventType)
			throws BadRequestException {
		if (eventType == null) {
			return null;
		}

		Integer index = eventTypes.getIndex(eventType);
		if (eventTypes != null && index == -1) {
			throw new BadRequestException(eventType
					+ " is invalid main category!");
		} else {
			return eventTypes.getValue(index);
		}
	}

	public static String parseTimeWindow(String[] timeWindowMapping, String timeWindow, String defaultTimeWindow)
			throws BadRequestException {
		if (timeWindow != null) {
			for (String storedTimeWindow : timeWindowMapping) {
				if (storedTimeWindow.equalsIgnoreCase(timeWindow)) {
					return storedTimeWindow;
				}
			}

			throw new BadRequestException(timeWindow
					+ " is invalid time window!");

		} else {
			return defaultTimeWindow;
		}
	}

	/**
	 * Parse and validate input parameter of integer number (such as offset,
	 * limit...) Description
	 * 
	 * @param defaultValue
	 * @param intValue
	 *            : requested parameter
	 * @return integer: real value
	 * @throws BadRequestException
	 */
	public static int parseIntegerValue(String intValue, int defaultValue)
			throws BadRequestException {
		int resultInt = defaultValue;
		try {
			if (intValue != null) {
				resultInt = Integer.parseInt(intValue);
			}
		} catch (NumberFormatException e) {
			throw new BadRequestException(intValue + " should be integer.");
		}
		return resultInt;
	}

	/**
	 * Parse and validate boolean input value Description
	 * 
	 * @param stringValue
	 *            : requested input value
	 * @param defaultValue
	 *            : return defaultValue if stringValue = null
	 * @return
	 * @throws BadRequestException
	 */
	public static boolean parseBooleanValue(String stringValue, boolean defaultValue)
			throws BadRequestException {
		if (stringValue == null) {
			return defaultValue;
		} else if ("false".equalsIgnoreCase(stringValue)) {
			return false;
		} else if ("true".equalsIgnoreCase(stringValue)) {
			return true;
		} else {
			throw new BadRequestException("Wrong format for boolean: "
					+ stringValue);
		}
	}

	public static String parseDateValue(DateTimeFormatter inputFormat, String dateValue)
			throws BadRequestException {
		if (dateValue != null) {
			try {
				inputFormat.parseDateTime(dateValue);
				return dateValue;
			} catch (IllegalFieldValueException e) {
				throw new BadRequestException("Wrong format for date: "
						+ dateValue);
			}
		} else {
			throw new BadRequestException("Date value is required!");
		}
	}

	/*
	 * public static void parseRules(RuleSet rules) throws FunctionException {
	 * if(rules == null){ throw new FunctionException("List rules is null"); } }
	 */

	public static String parseString(String s) throws BadRequestException {
		if (s == null) {
			throw new BadRequestException("String input is null");
		}
		return s;
	}

	/**
	 * @param cBCF_COLUMN_QUALIFIER_MAPPING
	 * @param attribute
	 * @return
	 */
	public static String parseAttribute(List<String> attributeList, String attribute)
			throws BadRequestException {

		if (attribute == null) {
			throw new BadRequestException("Attribute name is mandatory");
		} else {
			for (String storedAttribute : attributeList) {
				if (storedAttribute.equalsIgnoreCase(attribute)) {
					return storedAttribute;
				}
			}
		}
		throw new BadRequestException(attribute + " is invalid attribute name.");
	}

	/**
	 * 
	 * @param dtvDateTimeFormat
	 * @param hbaseDateFormat
	 * @param eventTime
	 * @throws FunctionException
	 */
	public static void parseEventDate(DateTimeFormatter dtvDateTimeFormat, DateTimeFormatter hbaseDateTimeFormat, 
			DateTimeFormatter hbaseDateFormat, EventTime eventTime, int defaultRangeLength) throws BadRequestException {

		// List<String> dates = new ArrayList<String>();

		DateTime startDateTime = null;
		DateTime endDateTime = null;
		try {

			String startTime = eventTime.getStartTime();
			String endTime = eventTime.getEndTime();

			if (startTime != null && endTime != null) {
				startDateTime = dtvDateTimeFormat.parseDateTime(startTime);
				endDateTime = dtvDateTimeFormat.parseDateTime(endTime);
			} else if (startTime == null && endTime == null) {
				endDateTime = new DateTime();
				startDateTime = endDateTime.minusDays(defaultRangeLength);
			} else if (startTime == null) {
				endDateTime = dtvDateTimeFormat.parseDateTime(endTime);
				startDateTime = endDateTime.minusDays(defaultRangeLength);
			} else {
				startDateTime = dtvDateTimeFormat.parseDateTime(startTime);
				endDateTime = new DateTime();
			}

			DateTime startDate = hbaseDateFormat.parseDateTime(startDateTime.toString(hbaseDateFormat));
			DateTime endDate = hbaseDateFormat.parseDateTime(endDateTime.toString(hbaseDateFormat));

			if (endDateTime.isBefore(startDateTime)) {
				throw new BadRequestException("startTime is greater than endTime");
			} else {
				eventTime.setStartTime(startDateTime.toString(hbaseDateTimeFormat));
				eventTime.setEndTime(endDateTime.toString(hbaseDateTimeFormat));

				String minInsertedTime = startDate.minusDays(3).toString(hbaseDateFormat);
				String maxInsertedTime = endDate.toString(hbaseDateFormat);
				eventTime.setMinInsertedTime(minInsertedTime);
				eventTime.setMaxInsertedTime(maxInsertedTime);
			}

		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			throw new BadRequestException("Wrong format for date: "
					+ e.getMessage());
		}
	}

}
