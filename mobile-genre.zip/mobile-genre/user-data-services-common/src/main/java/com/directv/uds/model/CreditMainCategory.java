/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright 2015 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.model;

public enum CreditMainCategory {
	movies("Movies"), tv("Movies"), sports("Sports"), allcategories("AllCategories");

	/**
	 * The true value of the mainCategory
	 */
	private String mainCategory;

	/**
	 * Constructor
	 * 
	 * @param intepretedEventType
	 */
	private CreditMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

	/**
	 * @return the mainCategory
	 */
	public String getMainCategory() {
		return mainCategory;
	}

	/**
	 * @param mainCategory
	 *            the mainCategory to set
	 */
	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

}
