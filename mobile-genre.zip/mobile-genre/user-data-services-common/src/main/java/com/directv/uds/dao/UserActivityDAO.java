/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.List;

import com.directv.uds.model.LocationInformation;
import com.directv.uds.model.rs.getRule.response.CreditDataResult;
import com.directv.uds.model.rs.response.LastActionElement;
import com.directv.uds.model.rs.response.LastActionResponse;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;

/**
 * <H3>ListBuilderIntegrationDAO</H3>
 * 
 * @author ThanhNN2
 * @since Sep 24, 2014
 */
public interface UserActivityDAO extends UDSDao {

	/**
	 * 
	 * @param rule
	 * @param uvhTable
	 * @param accountId
	 * @param offset
	 * @param limit
	 * @param cbcf
	 * @return
	 */
	public List<LastActionElement> getLastAction(LARule rule, String uvhTable, String accountId, int offset, int limit);

	/**
	 * 
	 * @param accountId
	 * @param ruleNames
	 * @param serviceName
	 * @return
	 * @throws IOException
	 */
	public LastActionResponse getLastActionByRule(String accountId, String[] ruleNames);

	/**
	 * Get the DMA descript from the input zip code
	 * 
	 * @param zipCode
	 * @return
	 */
	public LocationInformation getLocation(String zipCode);

	public CreditDataResult[] getCreditByRuleName(String accountId, LARule creditRules, String[] columnQualifiers, String creditType);
}
