/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright 2015 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
/**
 * 
 */
package com.directv.uds.model.rs.getRule.response;

import java.util.ArrayList;
import java.util.List;

/**
 * @author TungPT6
 * 
 */
public class CreditDataResponse {
	private String ruleName;
	private List<CreditDataResult> result = new ArrayList<CreditDataResult>();

	public CreditDataResponse() {
	}

	public CreditDataResponse(List<CreditDataResult> result) {
		this.result = result;
	}

	public CreditDataResponse(List<CreditDataResult> result, String ruleName) {
		this.ruleName = ruleName;
		this.result = result;
	}

	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}

	/**
	 * @param ruleName
	 *            the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	/**
	 * @return the result
	 */
	public List<CreditDataResult> getResult() {
		return result;
	}

	/**
	 * @param result
	 *            the result to set
	 */
	public void setResult(List<CreditDataResult> result) {
		this.result = result;
	}

}
