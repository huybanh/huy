/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.utils;

import java.util.Date;

import javax.validation.ValidationException;
import javax.xml.datatype.XMLGregorianCalendar;
import org.apache.commons.lang.StringUtils;

/**
 * Utility class to parse/print java type value from/to String.
 * <p>
 * 
 * @author ngutq
 * 
 */
public class CustomBinder {

	/**
	 * print string from boolean.
	 * <p>
	 * This is to solve the problem where invalid boolean value is put to xml
	 * payload.
	 * 
	 * @param value
	 * @return
	 */
	public static String printBoolean(Boolean value) {
		if (value == null) {
			return null;
		}
		return value.toString();
	}

	/**
	 * parse string to boolean.
	 * <p>
	 * This is to solve the problem where invalid boolean value is put to xml
	 * payload.
	 * 
	 * @param value
	 * @return
	 */
	public static Boolean parseBoolean(String value) {
		if ("true".equalsIgnoreCase(value) || "false".equalsIgnoreCase(value)) {
			return Boolean.valueOf(value);
		}

		// throw exception so that ValidatingJAXBContex will handle
		throw new ValidationException();
	}

	/**
	 * parse string date time to XMLGregorianCalendar
	 * 
	 * @param strDateTime
	 * @return
	 */
	public static XMLGregorianCalendar parseDateTime(String strDateTime) {
		return DateUtils.stringToXMLGregoCalendar(strDateTime);
	}

	/**
	 * print xmlGregorianCalendar to string
	 * 
	 * @param xgCalendar
	 * @return
	 */
	public static String printDateTime(XMLGregorianCalendar xgCalendar) {
		return DateUtils.gregorianToString(xgCalendar);
	}

	/**
	 * parse string date to Date
	 * 
	 * @param strDate
	 * @return
	 */
	public static Date parseDate(String strDate) {
		return DateUtils.simpleDateStringToDate(strDate);
	}

	/**
	 * print Date to String
	 * 
	 * @param date
	 * @return
	 */
	public static String printDate(Date date) {
		return DateUtils.dateToSimpleDateString(date);
	}

	/**
	 * parse string to Integer
	 * 
	 * @param integer
	 * @return
	 */
	public static Integer parseInteger(String integer) {
		if (StringUtils.isEmpty(integer)) {
			return null;
		}
		return Integer.valueOf(integer);
	}

	/**
	 * print Integer to String
	 * 
	 * @param integer
	 * @return
	 */
	public static String printInteger(Integer integer) {
		if (integer == null) {
			return null;
		}
		return integer.toString();
	}
	
	/**
	 * parse string to Integer
	 * 
	 * @param integer
	 * @return
	 */
	public static Object parseObject(String object) {
		
		return object;
	}

	/**
	 * print Integer to String
	 * 
	 * @param integer
	 * @return
	 */
	public static String printObject(Object object) {
		
		return object.toString();
	}
}
