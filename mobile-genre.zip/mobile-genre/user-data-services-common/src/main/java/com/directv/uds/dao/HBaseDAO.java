/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.KeyValue;

import com.dtv.hbase.model.Event;

/**
 * <H3>HBaseUtil</H3>
 * 
 * @author HuynhNB
 * @since Mar 7, 2014
 */
public interface HBaseDAO {

	//public HbaseTableConfiguration readLookupTable(String service);

	public String getHbaseValue(String key, String tableName, byte[] columnFamily, byte[] columnQualifier)
			throws IOException;

	public List<KeyValue> getRow(String key, String tableName, byte[] columnFamily, String[] columnQualifiers)
			throws IOException;

	public Map<String, List<KeyValue>> getRowsByKeys(String tableName, String[] keys, byte[] columnFamily)
			throws IOException;

	public String[][] getHbaseValue(String key, String tableName, byte[] columnFamily, String[][] columnQualifiers)
			throws IOException;

	public Map<String, List<KeyValue>> getResultScanner(String tableName, byte[] columnFamily, String startRow,
			String stopRow, int pageSize) throws IOException;

	public List<Event> getUserViewingHistory(String tableName, byte[] columnFamily, String startRow, String stopRow)
			throws IOException;

	public Map<byte[], byte[]> getValuesByColumnQualifiers(String key, String tableName, byte[] columnFamily,
			List<String> columnQualifiers) throws IOException;

	public Map<byte[], byte[]> getValuesByColumnQualifierPrefixFilter(String key, String tableName, byte[] columnFamily,
			List<String> columnQualifierPrefix) throws IOException;

}
