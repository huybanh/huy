/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.model.rs.response;

import java.util.ArrayList;
import java.util.List;

import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.ProgramFrequency;
import com.directv.uds.model.rs.getRule.response.CreditDataResult;

/**
 * @author Kietlm
 * 
 */
public class PreviewResult {

	protected String ruleName;
	protected List<LastActionElement> resultLastAction;
	protected List<ProgramFrequency> resultWhatIsHot;
	protected List<FrequencyElement> resultUserTaste;
	protected List<CreditDataResult> resultCredit;

	public String getRuleName() {
		return ruleName;
	}

	public List<LastActionElement> getResultLastAction() {
		if (resultLastAction == null) {
			resultLastAction = new ArrayList<LastActionElement>();
		}
		return resultLastAction;
	}

	public List<ProgramFrequency> getResultWhatIsHot() {
		if (resultWhatIsHot == null) {
			resultWhatIsHot = new ArrayList<ProgramFrequency>();
		}
		return resultWhatIsHot;
	}

	public List<FrequencyElement> getResultUserTaste() {
		if (resultUserTaste == null) {
			resultUserTaste = new ArrayList<FrequencyElement>();
		}
		return resultUserTaste;
	}

	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}

	/**
	 * @param resultLastAction
	 *            the resultLastAction to set
	 */
	public void setResultLastAction(List<LastActionElement> resultLastAction) {
		this.resultLastAction = resultLastAction;
	}

	/**
	 * @param resultWhatIsHot
	 *            the resultWhatIsHot to set
	 */
	public void setResultWhatIsHot(List<ProgramFrequency> resultWhatIsHot) {
		this.resultWhatIsHot = resultWhatIsHot;
	}

	/**
	 * @param resultUserTaste
	 *            the resultUserTaste to set
	 */
	public void setResultUserTaste(List<FrequencyElement> resultUserTaste) {
		this.resultUserTaste = resultUserTaste;
	}

	/**
	 * @return the resultCredit
	 */
	public List<CreditDataResult> getResultCredit() {
		return resultCredit;
	}

	/**
	 * @param resultCredit
	 *            the resultCredit to set
	 */
	public void setResultCredit(List<CreditDataResult> resultCredit) {
		this.resultCredit = resultCredit;
	}

	@Override
	public String toString() {
		return "UdsPreviewRule [ruleName=" + ruleName + ",resultCredit=" + resultCredit + ", resultLastAction=" + resultLastAction
				+ ", resultWhatIsHot=" + resultWhatIsHot + ", resultUserTaste=" + resultUserTaste + "]";
	}

}
