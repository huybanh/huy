/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */

package com.directv.uds.exceptions;

import javax.ws.rs.core.Response.Status;

import com.directv.uds.enums.ErrorCode;
import com.directv.uds.model.Error;
import com.directv.uds.model.Errors;
public class BadRequestException extends BaseRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2233937253302557869L;

	public BadRequestException(String message) {
		super(ErrorCode.BAD_REQUEST.getCode(), message);
	}

	/**
	 * Initializes exception in case multiple errors are given.
	 * 
	 * @param errors
	 *            list of errors.
	 */
	public BadRequestException(Error errors) {
		super(errors.getCode(), errors.getMessage());
	}

	/**
	 * Initializes exception in case multiple errors are given.
	 * 
	 * @param errors
	 *            list of errors.
	 */
	public BadRequestException(Errors errors) {
		super(errors, Status.BAD_REQUEST);
	}
}
