/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */

package com.directv.uds.model;


/**
 * 
 * <H3>EnumManager</H3>
 *
 * @author ThanhNN2
 * @since Sep 26, 2014
 */
public class EnumManager {
	/*public static enum SERVICES {
		cbcfService("uds.cbcf"), 
		cbcfByDayService("uds.cbcfbyday"), 
		//lastActionService("uds.lastaction"), 
		whatIsHotService("uds.whatshot"), 
		userViewingHistoryService("uds.uvh");
		
		private String key;
		
		SERVICES(String key) {
			this.key = key;
		}
		
		public String getKey() {
			return key;
		}
	}*/
	
	public static enum LASTACTION_TOKENS {
		MAIN_CATEGORY(0), EVENT_TYPE(1), SUB_CATEGORY(2);

		private int index;

		LASTACTION_TOKENS(int index) {
			this.setIndex(index);
		}

		public int getIndex() {
			return index;
		}

		public void setIndex(int index) {
			this.index = index;
		}
	}
	
	public enum DayOfWeek {

		Alldays(0), Monday(1), Tuesday(2), Wednesday(3), Thursday(4), Friday(5), Saturday(6), Sunday(7);

		private final int value;

		DayOfWeek(int value) {

			this.value = value;
		}

		public int getValue() {

			return value;
		}

		public static DayOfWeek fromValue(int value) {
			if (value < 0 & value >= DayOfWeek.values().length) {
//				LOG.error("Wrong value for get DayOfWeek:" + value);
				return null;
			}
			return DayOfWeek.values()[value];
		}
	};
	
	public enum TopActiveUsers{
		ENCRYPTED_ID(1), ACCOUNT_ID(2);
		
		private int code;
		
		TopActiveUsers(int code){
			this.code = code;
		}

		public int getCode() {
			return code;
		}

		public void setCode(int code) {
			this.code = code;
		}
	}
	
	public enum UVH {
		TMS_ID(1), 
		EVENT_TIME(2), 
		EVENT_TYPE(3), 
		SOURCE(4), 
		ACCOUNT_ID(5), 
		MAIN_CATEGORY(6),
		INTERPRETED_EVENT(7);

		private int code;

		UVH(int code) {
			this.code = code;
		}

		public int getCode() {
			return code;
		}

		public void setCode(int code) {
			this.code = code;
		}
	}
	
	
	public enum ParentalRatingEnum {
		/**
		 * Contains a pre-defined list of parental rating. 
		 * In list builder view, we will have a filter like parental rating is in the range TVY to TV14
		 * Because in uvh table, we store the value of parental rating, so we need to know which exactly 
		 * the rank of filter one.
		 * For example, if filter is parental rating is in the range TVG to TVPG, it means
		 * parental rating is from 3 to 6, or we must query uvh with rating in ('TVG','G','TVPG')
		 * 
		 */
		  TVY(1,"tvy","TVY"),
		  TVY7(2,"tvy7","TVY7"),
		  TVG(3,"tvg","TVG"),
		  G(4,"g","G"),
		  TVPG(5,"tvpg","TVPG"),
		  PG(6,"pg","PG"),
		  PG_13(7,"pg-13","PG-13"),
		  TV14(8,"tv14","TV14"),
		  TVMA(9,"tvma","TVMA"), 
		  R(10,"r","R"),
		  NC17(11,"nc17","NC17"),
		  NR(12,"nrnotrated","NR");
		  
		  private ParentalRatingEnum(int rank, String parentalRating, String colValue) {
		   this.rank = rank;
		   this.parentalRating = parentalRating;
		   this.colValue = colValue;
		  }
		  	
		   /**
		    * Rank of parental rating.
		    */
		   private int rank;
		   /**
		    * parental rating value on list builder.
		    */
		   private String parentalRating;
		   /**
		    * Column value store in uvh table.
		    */
		   private String colValue;
			/**
			 * @return the rank
			 */
			public int getRank() {
				return rank;
			}
			/**
			 * @param rank the rank to set
			 */
			public void setRank(int rank) {
				this.rank = rank;
			}
			/**
			 * @return the parentalRating
			 */
			public String getParentalRating() {
				return parentalRating;
			}
			/**
			 * @param parentalRating the parentalRating to set
			 */
			public void setParentalRating(String parentalRating) {
				this.parentalRating = parentalRating;
			}
			/**
			 * @return the colValue
			 */
			public String getColValue() {
				return colValue;
			}
			/**
			 * @param colValue the colValue to set
			 */
			public void setColValue(String colValue) {
				this.colValue = colValue;
			}
		   
		   
		 }
	public enum MainCategory{
		GENERIC("AllCategories"),MOVIES("Movies"),TV("TV"),SPORTS("Sports"),NOT_SUPPORT("Not_Support");
		
		private String value;

		/**
		 * 
		 */
		private MainCategory(String value) {
			this.value = value;
		}
		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}

		/**
		 * @param value the value to set
		 */
		public void setValue(String value) {
			this.value = value;
		}
	}
	
	public enum RuleState{
		PUBLISHED,
		UNPUBLISHED
	}
	
	public enum DMAColumnQualifier{
		
		MAPPING(0), DMA(1), DMA_DESCRIPTION(2);
		private int index;

		/**
		 * @param index
		 */
		private DMAColumnQualifier(int index) {
			this.index = index;
		}


		/**
		 * @return the index
		 */
		public int getIndex() {
			return index;
		}

		/**
		 * @param index the index to set
		 */
		public void setIndex(int index) {
			this.index = index;
		}
		
	}
}
