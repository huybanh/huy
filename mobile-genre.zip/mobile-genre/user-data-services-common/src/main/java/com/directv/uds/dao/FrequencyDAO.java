/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.rs.response.WhatshotResponse;

/**
 * FreqencyDAO interface contain methods get cbcf vector and what's hot info.
 * 
 * <H3>FrequencyDAO</H3>
 *
 * @author TuTX1
 * @since Jul 1, 2014
 */
public interface FrequencyDAO extends UDSDao {

	/**
	 * Get cbcf vector of given user.
	 * 
	 * Description
	 * @param userId : requested userId
	 * @param groupByWeekday : if true then cbcf is grouped by week day or not
	 * @param mainCategory : requested main category
	 * @param timeWindow 
	 * @param serviceName 
	 * @return A map that grouped by main category
	 * @throws IOException 
	 */
	public Map<String, List<String>> getFrequencyVector(String userId, final boolean groupByWeekday, String attribute, String mainCategory, String timeWindow);

	/**
	 * 
	 * @param userId : requested userId
	 * @param date
	 * @param percentage
	 * @param attribute
	 * @param startIndex
	 * @param limit
	 * @param serviceName
	 * @return
	 */
	public Map<String, List<FrequencyElement>> getCbcfByDayVector(
			String userId, String date, boolean percentage, String attribute, int startIndex, int limit);
	
	/***
	 * 
	 * @param timeWindow
	 * @param regionId
	 * @param limit
	 * @param mainCategory
	 * @param serviceName
	 * @return
	 * @throws IOException
	 */
	public WhatshotResponse getWhatIsHot(String timeWindow, DMAInformation dmaInformation, int limit, String mainCategory);
	
	/**
	 * 
	 * @param userId
	 * @param mainCategory
	 * @return
	 * @throws IOException 
	 */
	/*public Map<String, List<FrequencyElement>> getCommonUserTaste(String[] mainCategory, int limit);*/
}
