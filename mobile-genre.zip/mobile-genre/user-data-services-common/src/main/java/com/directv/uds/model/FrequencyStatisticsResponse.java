/*
 *****************************************************************************
 * Copyright© 2014 DIRECTV, INC.
 * DIRECTV PROPRIETARY
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.directv.uds.model.EnumManager.DayOfWeek;

/**
 * 
 * <H3>FrequencyStatisticsResponse</H3>
 *
 * @author TuTX1
 * @since Jun 25, 2014
 */
@XmlType(name = "frequencyResponse")
public class FrequencyStatisticsResponse {

	private String query;
	
	//keyed by main category names
	private HashMap<String, Map<DayOfWeek, List<FrequencyElement>>> frequencyVectorList;

	public FrequencyStatisticsResponse() {
		super();
		this.frequencyVectorList = new HashMap<String, Map<DayOfWeek, List<FrequencyElement>>>();
	}

	/*public FrequencyStatisticsResponse(boolean isOtherCategory) {
		super();
		this.frequencyVectorList = new HashMap<String, Map<DayOfWeek, List<FrequencyElement>>>();
		if (!isOtherCategory) {
			for (String mainCategory : UserDataConfiguration.MAIN_CATEGORIES.getValues()) {
				this.frequencyVectorList.put(mainCategory, new HashMap<DayOfWeek, List<FrequencyElement>>());
			}
		}
	}

	public FrequencyStatisticsResponse(String mainCategory) {
		super();
		this.frequencyVectorList = new HashMap<String, Map<DayOfWeek, List<FrequencyElement>>>();
		this.frequencyVectorList.put(mainCategory, new HashMap<DayOfWeek, List<FrequencyElement>>());
	}*/
	
	public FrequencyStatisticsResponse(String[] mainCategories) {
		super();
		this.frequencyVectorList = new HashMap<String, Map<DayOfWeek, List<FrequencyElement>>>();
		if (mainCategories != null) {
			for (String oneMain : mainCategories) {
				this.frequencyVectorList.put(oneMain, new HashMap<DayOfWeek, List<FrequencyElement>>());
			}
		}
	}

	public void add(String mainCategory, DayOfWeek weekday, List<FrequencyElement> vector) {
		if (!this.frequencyVectorList.containsKey(mainCategory)) {
			this.frequencyVectorList.put(mainCategory, new HashMap<DayOfWeek, List<FrequencyElement>>());
		}
		this.frequencyVectorList.get(mainCategory).put(weekday, vector);
	}

	@XmlAttribute
	public String getQuery() {
		return query;
	}

	/*public void setQuery(String query) {
		this.query = query;
	}*/
	
	public void setQuery(Boolean percentage, Boolean groupByWeekday, Integer limit, String timeWindow) {

		boolean appended = false;
		StringBuilder sb = new StringBuilder();
		if (percentage != null) {
			sb.append("percentage=" + percentage);
			appended = true;
		}
		if (groupByWeekday != null) {
			if (appended) {
				sb.append("&");
			}
			sb.append("groupByWeekday=" + groupByWeekday);
			appended = true;
		}
		if (limit != null) {
			if (appended) {
				sb.append("&");
			}
			sb.append("limit=" + limit);
			appended = true;
		}
		if (timeWindow != null) {
			if (appended) {
				sb.append("&");
			}
			sb.append("timeWindow=" + timeWindow);
			appended = true;
		}
		this.query = sb.toString();
	}

    @XmlElement
	public HashMap<String, Map<DayOfWeek, List<FrequencyElement>>> getFrequencyVectorList() {
		return frequencyVectorList;
	}

	public void setFrequencyVectorList(HashMap<String, Map<DayOfWeek, List<FrequencyElement>>> frequencyVectorList) {
		this.frequencyVectorList = frequencyVectorList;
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if (obj instanceof FrequencyStatisticsResponse) {
			FrequencyStatisticsResponse freqObj = new FrequencyStatisticsResponse();
			Map<String, Map<DayOfWeek, List<FrequencyElement>>> freqVectorList = freqObj.getFrequencyVectorList();
			result = compare(freqVectorList, frequencyVectorList);
			if (freqObj.getQuery() != null && this.query != null) {
				result = result && freqObj.getQuery().equals(this.query);
			} else if (freqObj.query == null && this.query == null) {
				result = result && true;
			} else {
				result = false;
			}
		}
		return result;
	}

	private boolean compare(Map<String, Map<DayOfWeek, List<FrequencyElement>>> map1, Map<String, Map<DayOfWeek, List<FrequencyElement>>> map2) {
		boolean result = false;
		if (map1 != null && map2 != null) {
			if (map1.size() == 0 && map2.size() == 0) {
				result = true;
			} else {
				Set<String> keys = map1.keySet();
				if (map1.size() == map2.size()) {
					int count = 1;
					for (String key : keys) {
						Map<DayOfWeek, List<FrequencyElement>> listFreq1 = map1.get(key);
						Map<DayOfWeek, List<FrequencyElement>> listFreq2 = map2.get(key);
						if (compareFrequencyList(listFreq1, listFreq2)) {
							count++;
							continue;
						}
					}
					if (count == map1.size()) {
						result = true;
					}
				}
			}
		}
		return result;
	}

	private boolean compareFrequencyList(Map<DayOfWeek, List<FrequencyElement>> listFreq1, Map<DayOfWeek, List<FrequencyElement>> listFreq2) {
		boolean result = false;

		if (listFreq1 != null && listFreq2 != null) {
			if (listFreq1.size() == 0 && listFreq2.size() == 0) {
				result = true;
			} else {
				Set<DayOfWeek> keys = listFreq1.keySet();
				if (listFreq1.size() == listFreq2.size()) {
					int count = 1;
					for (DayOfWeek key : keys) {
						List<FrequencyElement> list1 = listFreq1.get(key);
						List<FrequencyElement> list2 = listFreq2.get(key);
						if (compareList(list1, list2)) {
							count++;
							continue;
						} else {
							break;
						}

					}
					if (count == listFreq1.size()) {
						result = true;
					}
				}
			}
		}
		return result;
	}

	private boolean compareList(List<FrequencyElement> list1, List<FrequencyElement> list2) {
		boolean result = false;
		if (list1.size() == list2.size()) {
			if (list1.size() == 0 && list2.size() == 0) {
				result = true;
			} else {
				int size = list1.size();
				int i = 0;
				for (i = 0; i < size; i++) {
					if (list1.get(i).equals(list2.get(i))) {
						continue;
					}
				}
				if (i == size - 1) {
					result = true;
				}
			}

		}
		return result;
	}
	

}
