/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.directv.uds.model.rs.response.LastActionElement;
import com.directv.uds.model.rs.response.LastActionResponse;
import com.directv.uds.model.rs.response.LastActionResult;

/**
 * <H3>LastActionUtil</H3>
 *
 * @author ThanhNN2
 * @since Oct 16, 2014
 */
public class LastActionUtil {
	
	
	/**
	 * Normalize last action response
	 * @param response
	 * @return
	 */
	public static LastActionResponse normalizeResponse(LastActionResponse response){

		Set<String> genreTracker = new HashSet<String>();
		Set<LastActionElement> lastActionTracker = new HashSet<LastActionElement>();
		if(response != null){
			//normalize
			List<LastActionResult> lastActionResultList = response.getLastAction();
			if(lastActionResultList != null && lastActionResultList.size() > 0){
				int size = lastActionResultList.size();
				for(int i = 0; i < size ; i++){
					List<LastActionElement> lastActionElementList = normalize(lastActionResultList.get(i).getResult(), -1, genreTracker, lastActionTracker);
					lastActionResultList.get(i).setResult(lastActionElementList);
				}
			}
			
			
		}
		
		return response;
	}
	
	/**
	 * Normalize last action element list by remove results which have the same tmsid, title, seriesId
	 * @param lastActionList
	 * @param limit
	 * @param genreTracker
	 * @param lastActionTracker
	 * @return
	 */
	public static List<LastActionElement> normalize(List<LastActionElement> lastActionList, int limit, 
			Set<String> genreTracker, Set<LastActionElement> lastActionTracker){
		List<LastActionElement> normalizeListForOneRule = new ArrayList<LastActionElement>();
		lastActionList =  removeDuplicate(lastActionList, genreTracker);
		for (LastActionElement lastActionElement : lastActionList) {
			//Don't check if value is null or empty
			if(lastActionElement.getTitle()!=null && !lastActionElement.getTitle().isEmpty()
					&& lastActionElement.getTmsId()!=null && !lastActionElement.getTmsId().isEmpty()){

				if(!lastActionTracker.contains(lastActionElement)){
					lastActionTracker.add(lastActionElement);
					normalizeListForOneRule.add(lastActionElement);
					if (limit > 0 && normalizeListForOneRule.size() >= limit){
						break;
					}
					continue;
				}
			}
		}
		
		return normalizeListForOneRule;
	}
	
	
	/**
	 * remove object which duplicate genre in lastAction object list
	 * 
	 * @param lastAction
	 */
	public static List<LastActionElement> removeDuplicate(List<LastActionElement> lastAction, Set<String> genresTracker) {
		List<LastActionElement> result = new ArrayList<LastActionElement>();

		for (LastActionElement lastActionElement : lastAction) {
			if (contain(lastActionElement.getGenre1(), genresTracker) 
					|| contain(lastActionElement.getGenre2(), genresTracker)
					|| contain(lastActionElement.getGenre3(), genresTracker)){

				continue;
			}

			result.add(lastActionElement);
			push(lastActionElement.getGenre1(), genresTracker);
			push(lastActionElement.getGenre2(), genresTracker);
			push(lastActionElement.getGenre3(), genresTracker);
		}

		return result;
	}

	
	private static void push(String genre, Set<String> genres){
		if (genre != null && !genre.isEmpty()){
			genres.add(genre);
		}
	}

	/**
	 * @param genre1
	 * @param genres
	 * @return
	 */
	private static boolean contain(String genre, Set<String> genres) {

		if(genre != null && !genre.isEmpty()){
			if(genres.contains(genres)){
				return true; 
			}
		}
		return false;
	}
	
	public static List<LastActionResult> getUniqueLastActionResponseData(List<LastActionResult> preProcessingList) {
		List<LastActionResult> result = new ArrayList<LastActionResult>();
		Set<LastActionElement> tracker = new HashSet<LastActionElement>();

		for (LastActionResult preProcessingElement : preProcessingList) {
			result.add(process(preProcessingElement, tracker));
		}

		return result;

	}

	/**
	 * @param preProcessingElement
	 * @param tracker
	 */
	public static LastActionResult process(LastActionResult preProcessingElement, Set<LastActionElement> tracker) {
		LastActionResult result = new LastActionResult();
		if (preProcessingElement != null
				&& preProcessingElement.getResult() != null
				&& !preProcessingElement.getResult().isEmpty()) {
			result.setRuleName(preProcessingElement.getRuleName());
			result.setLastModifiedDate(preProcessingElement.getLastModifiedDate());
			result.setResult(new ArrayList<LastActionElement>());
			List<LastActionElement> laElements = preProcessingElement.getResult();
			LastActionElement elementResult = process(laElements, tracker);
			if(elementResult!=null){
				result.getResult().add(elementResult);
			}
		}
		return result;
	}

	/**
	 * @param laElements
	 * @param tracker
	 */
	public static LastActionElement process(List<LastActionElement> laElements, Set<LastActionElement> tracker) {
		LastActionElement result = null;
		if (laElements != null && !laElements.isEmpty()) {
			for (LastActionElement lastActionElement : laElements) {
				if (!tracker.contains(lastActionElement)) {
					result = lastActionElement;
					tracker.add(lastActionElement);
					break;
				}
			}
		}
		return result;
	}
	
}
