/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import com.directv.recommendation.common.CommonUtil;
import com.directv.uds.model.EventTime;


public class QueryGeneration {
	/**
	 * Build query to get pre-calculated top active user from active user table
	 * Description
	 * 
	 * @param activeUserTable
	 * @param offset
	 * @param limit
	 * @return
	 */
	public static String selectPrecalculatedTopActiveUser(String activeUserTable, int offset, int limit) {
		return "		SELECT accountid, encryptedid, eventcount" + "		FROM "
				+ activeUserTable + " " + "		ORDER BY eventcount DESC "
				+ "		LIMIT " + limit + " " + "		OFFSET " + offset;
	}

	public static String selectUserViewingHistory(String uvhTable, String accountId, String mainCategory, int offset, int limit, EventTime eventTime) {
		StringBuilder whereClause = new StringBuilder("WHERE ");

		String startTime = eventTime.getStartTime();
		String endTime = eventTime.getEndTime();
		String minInsertedTime = eventTime.getMinInsertedTime();
		String maxInsertedTime = eventTime.getMaxInsertedTime();

		if (minInsertedTime != null) {
			whereClause.append("insertedtime > '" + minInsertedTime + "' ");
		}

		if (maxInsertedTime != null) {
			whereClause.append("and insertedtime < '" + maxInsertedTime + "' ");
		}

		whereClause.append("and accountId = '"	+ accountId + "' ");

		if(mainCategory != null) {
			whereClause.append("and mainCategory = '" + mainCategory + "' ");
		}

		if (startTime != null) {
			whereClause.append("and eventtime >= '" + startTime + "' ");
		}

		if (endTime != null) {
			whereClause.append("and eventtime <= '" + endTime + "' ");
		}

		return "SELECT tmsId, eventTime, eventType, source, accountId, mainCategory, interpretedeventtype "
				+ "		FROM "
				+ uvhTable
				+ " "
				+ whereClause.toString()
				+ "     ORDER BY eventtime DESC "
				+ "		LIMIT "
				+ limit
				+ " "
				+ "		OFFSET " + offset;

	}

	/**
	 * @param uvhTable
	 * @param secondaryPartitionModulo null if there is not secondary partitioning
	 * @param accountId
	 * @param eventtype
	 * @param userBehaviour
	 * @param offset
	 * @param limit
	 * @return
	 */
	public static String selectUserLastAction(String uvhTable, Integer secondaryPartitionModulo, String accountId, String eventtype, String userBehaviour, int offset, int limit) {
		String query = String.format("SELECT accountId, tmsId, eventTime, eventType, source, mainCategory, tmsConnectorId, programType, interpretedEventType, "
				+ "genre1, genre2, genre3, tmsgenre1, tmsgenre2, tmsgenre3, rating, delivery, title, duration, runlength FROM %s", uvhTable);

		if (!userBehaviour.isEmpty()) {
			userBehaviour = String.format("and (%s)", userBehaviour);
		}

		String secondaryPartitionTerm;
		if (secondaryPartitionModulo != null) {
			int secondaryPartition = CommonUtil.partitionNumber(secondaryPartitionModulo, accountId);
			secondaryPartitionTerm = "and hashcodepartition=" + secondaryPartition;
		} else {
			secondaryPartitionTerm = "";
		}
		String whereClause = String.format("WHERE accountId='%s' %s and interpretedeventtype='%s' %s", accountId, secondaryPartitionTerm, eventtype, userBehaviour);

		String orderClause = String.format("ORDER BY eventTime DESC limit %s offset %s", limit, offset);

		query = String.format("%s %s %s", query, whereClause, orderClause);
		return query;
	}
}
