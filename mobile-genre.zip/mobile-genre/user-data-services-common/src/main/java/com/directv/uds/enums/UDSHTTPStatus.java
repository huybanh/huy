/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.enums;

import javax.ws.rs.core.Response.Status.Family;
import javax.ws.rs.core.Response.StatusType;

public enum UDSHTTPStatus implements StatusType {

	DOWN_STREAM_SYSTEM_EXCEPTION(590, Family.SERVER_ERROR, "Downstream System Failed"),
	/**
	 * Multi-Status (WebDAV; RFC 4918)
	 */
	MULTI_STATUS(207, Family.SUCCESSFUL, "Partial Success"),
	
	COMPLETE_FAILURE(513, Family.SERVER_ERROR, "Complete Failure"),
	
	FILE_SYSTEM_EXCEPTION(500, Family.SERVER_ERROR, "File System Failed");

	UDSHTTPStatus(int statusCode, Family family, String responsePhrase) {
		this.statusCode = statusCode;
		this.family = family;
		this.responsePhrase = responsePhrase;
	}

	private int statusCode;
	private Family family;
	private String responsePhrase;

	@Override
	public int getStatusCode() {
		return statusCode;
	}

	@Override
	public Family getFamily() {
		return family;
	}

	@Override
	public String getReasonPhrase() {
		return responsePhrase;
	}

}
