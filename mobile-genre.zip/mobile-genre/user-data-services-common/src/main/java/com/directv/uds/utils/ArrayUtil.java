/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import com.directv.uds.model.UserDataConfiguration;



/**
 * <H3>ColumnQualifiersUtil</H3>
 *
 * @author TuTX1
 * @since Jul 16, 2014
 */
public class ArrayUtil {
	
	/**
	 * 
	 * Description
	 * @param rowIndex
	 * @param columnIndex
	 * @param arrays
	 * @return
	 */
	public static List<String> getValuesByIndex(int rowIndex, int columnIndex, String[][] arrays) {
		String[][] results ;
		
		int rowSize = arrays.length;
		int columnSize = arrays[0].length;
		
		if(rowIndex > rowIndex || columnIndex > columnSize) {
			return null;
		}
		
		if(rowIndex == -1 && columnIndex == -1) {
			results = arrays;
		} else if(rowIndex == -1 && columnIndex != -1) {
			results = new String[rowSize][1];
			for(int i = 0; i < rowSize; i++) {
				results[i][0] = arrays[i][columnIndex];
			}
		} else if(rowIndex != -1 && columnIndex == -1) {
			results = new String[][] {arrays[rowIndex]};
		} else {
			results = new String[1][1];
			results[0][0] = arrays[rowIndex][columnIndex] ;
		}
		
		return twoDArrayToList(results);
	}
	
	/**
	 * Search in map.
	 * 
	 * Description
	 * @param key : key (case insensitive)
	 * @param map : map
	 * @return value of key
	 */
	public static int indexOfMap(String key, Map<String, Integer> map) {
		if(key == null) {
			return -1;
		}
		Integer index = map.get(key.toLowerCase());
		if(index == null) {
			return -1;
		}
		return index;
	}
	
	
	public static String convertToRealValue(String inputValue, String[] realValues, Map<String, Integer> map) {
		int index = indexOfMap(inputValue, map);
		if(index == -1) {
			return null;
		}
		
		return realValues[index];
	}
	
	/**
	 * Convert 2D array to List.
	 * 
	 * Description
	 * @param twoDArray : 2D array
	 * @return List
	 */
	public static <T> List<T> twoDArrayToList(T[][] twoDArray) {
	    List<T> list = new ArrayList<T>();
	    for (T[] array : twoDArray) {
	        list.addAll(Arrays.asList(array));
	    }
	    return list;
	}
	

	/**
	 * This method follow generate column qualifiers for properties file.
	 * 
	 * Description
	 * @param rows 
	 * @param columns
	 * @param prefix
	 * @param lowercase
	 * @return
	 */
	public static String[][] generateColumnQualifierForPropertyFile(String[] rows, String[] columns, String prefix, boolean lowercase) {
		StringBuilder builder = new StringBuilder();
		builder.append("[");
		for(String row : rows) {
			builder.append("[");
			for(String column : columns) {
				builder.append("\"");
				
				if(lowercase) {
					row = row.toLowerCase();
					column = column.toLowerCase();
				}
				
				builder.append(row + "." + column);
				if(prefix != null) {
					builder.append("." + prefix);
				}
				
				builder.append("\"");
				builder.append(",");
			}
			builder.deleteCharAt(builder.lastIndexOf(","));
			builder.append("],");
		}
		builder.deleteCharAt(builder.lastIndexOf(","));
		builder.append("]");
		//System.out.println(builder.toString());
		try {
			return UserDataConfiguration.OBJECT_MAPPER.readValue(builder.toString(), String[][].class);
		} catch (IOException e) {
			//e.printStackTrace();
		}
		return null;
	}
}
