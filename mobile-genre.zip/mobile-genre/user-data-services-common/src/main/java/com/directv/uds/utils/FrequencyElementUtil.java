/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * CopyrightÂ© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import com.directv.uds.model.FrequencyElement;

/**
 * 
 * <H3>FrequencyElementUtil</H3>
 * 
 * @author PHUONGHT1
 * @since Jun 19, 2014
 */
public class FrequencyElementUtil {
	
	//private static int PERCENTAGE_RANGE = 100;
	
	/**
	 * 
	 * Description: convert from count frequencies to percentage frequencies 
	 * need to assure that the sum of all percentage frequencies is 10000
	 * @param countVector: count frequencies to be converted
	 * @return 
	 */
	public static List<FrequencyElement> convertToPercentage (List<FrequencyElement> elementList) {
		if (elementList == null || elementList.size() == 0) {
			return elementList;
		}
		
		//List<FrequencyElement> results = new ArrayList<FrequencyElement>();
		BigDecimal sum = BigDecimal.ZERO;
		for (FrequencyElement e : elementList) {
			BigDecimal d = new BigDecimal(e.getValue());
			sum = sum.add(d);
		}
		
		// calculate percentage frequency
		MathContext mc = new MathContext(4, RoundingMode.HALF_UP);
		BigDecimal sumPercentage = BigDecimal.ZERO;
		int i = 0;
		for(FrequencyElement e : elementList) {
			if (i < elementList.size() - 1) {
				BigDecimal d = new BigDecimal(e.getValue());
				BigDecimal percentage = d.divide(sum, mc);
				percentage = percentage.movePointRight(2);
				percentage = percentage.setScale(2, RoundingMode.HALF_UP);
				sumPercentage = sumPercentage.add(percentage);
				e.setValue(percentage.doubleValue());
				i++;
			} else {
				//reaching last element
				BigDecimal percentage = new BigDecimal(100).subtract(sumPercentage);
				e.setValue(percentage.doubleValue());
			}
		}
		return elementList;
	}

	/**
	 * 
	 * Description: remove ignored subcategory from list of 
	 * @param frequencyElements
	 * @return
	 */
	public static List<FrequencyElement> removeIgnoredSubCategory(Set<String> ignoredSubCategories, FrequencyElement[] frequencyElements) {

		if (ignoredSubCategories == null || ignoredSubCategories.isEmpty()) {
			return Arrays.asList(frequencyElements);
		}

		int length = frequencyElements.length;
		List<FrequencyElement> results = new ArrayList<FrequencyElement>();
		for (int i = 0; i < length; i++) {
			FrequencyElement frequencyElement = frequencyElements[i];

			// if sub category does not exist in ignoredSubCategories, add
			// FrequencyElement to result
			if (!ignoredSubCategories.contains(frequencyElement.getKey().toLowerCase())) {
				results.add(frequencyElement);
			}
		}
		return results;
	}
}
