/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.exceptions.DateParsingException;
import com.fasterxml.jackson.databind.util.ISO8601DateFormat;

/**
 * Utilitly class to process date type
 * 
 * @author senthil
 * 
 */
public class DateUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);
	public static final String TIME_ZONE_ID = Configuration.getInstance().getString("com.directv.up.common.timezone", "UTC");
	public static final TimeZone TIMEZONE = TimeZone.getTimeZone(TIME_ZONE_ID);
	

	private static final String DATE_FORMAT = "yyyy-MM-dd";

	private static final Locale LOCALE = Locale.getDefault();
	
	private DateUtils() {
	}

	// ISO 8601 Date format
		private static final ThreadLocal<DateFormat> ISO_DATE_FORMAT = new ThreadLocal<DateFormat>() {
			@Override
			protected DateFormat initialValue() {
				DateFormat dateFormat = new ISO8601DateFormat();
				dateFormat.setTimeZone(TIMEZONE);
				return dateFormat;
			}
		};

		// Simple Date format
		private static final ThreadLocal<DateFormat> SIMPLE_DATE_FORMAT = new ThreadLocal<DateFormat>() {
			@Override
			protected DateFormat initialValue() {
				DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
				dateFormat.setTimeZone(TIMEZONE);
				return dateFormat;
			}
		};
		
		// Data type Factory
		private static final ThreadLocal<DatatypeFactory> DATA_TYPE_FACTOR = new ThreadLocal<DatatypeFactory>() {
			@Override
			protected DatatypeFactory initialValue() {
				try {
					return DatatypeFactory.newInstance();
				} catch (DatatypeConfigurationException configException) {
					throw new RuntimeException("Exception while getting instance of DatatypeFactory", configException);
				}
			}
		};
		
	

	/**
	 * Convert long timestamp to XML Gregorian Calendar. Description
	 * 
	 * @param iTimeinMillis
	 * @return
	 */
	public static XMLGregorianCalendar longToGregorian(Long iTimeinMillis) {
		if (iTimeinMillis == null) {
			return null;
		}
		GregorianCalendar gregCalendar = new GregorianCalendar(TIMEZONE);
		gregCalendar.setTimeInMillis(iTimeinMillis);
		return DATA_TYPE_FACTOR.get().newXMLGregorianCalendar(gregCalendar);
	}

	/**
	 * Convert long timestamp to string date. It will format the date as per ISO
	 * 8601 date time standard.
	 * 
	 * @param longDate
	 * @return
	 */
	public static String longToString(long longDate) {
		Date date = new Date(longDate);
		return dateToString(date);
	}

	/**
	 * Convert long timestamp to date.
	 * 
	 * @param longDate
	 * @return
	 */
	public static Date longToDate(long longDate) {
		Date date = new Date(longDate);
		return date;
	}

	/**
	 * 
	 * Convert XMLGregorianCalendar date to long timestamp.
	 * 
	 * @param calendar
	 * @return
	 */
	public static Long gregorianToLong(XMLGregorianCalendar calendar) {
		if (calendar == null) {
			return null;
		}
		return gregorianToDate(calendar).getTime();
	}

	/**
	 * Convert date object to XML Gregorian Calendar.
	 * 
	 * @param iDate
	 * @return
	 */
	public static XMLGregorianCalendar dateToGregorian(Date iDate) {
		if (iDate == null) {
			return null;
		}
		return longToGregorian(iDate.getTime());
	}

	/**
	 * Convert XMLGregorianCalendar to Date object. Description
	 * 
	 * @param iCalend
	 * @return
	 */
	public static Date gregorianToDate(XMLGregorianCalendar iCalend) {
		if (iCalend == null) {
			return null;
		}
		
		//return iCalend.toGregorianCalendar().getTime();
		return iCalend.toGregorianCalendar(TIMEZONE, LOCALE, iCalend).getTime();
	}

	/**
	 * Convert Description XMLGregorianCalendar to string date. It will format
	 * the date as per ISO 8601 date time standard.
	 * 
	 * @param iCalend
	 * @return
	 */
	public static String gregorianToString(XMLGregorianCalendar iCalend) {
		if (iCalend == null) {
			return null;
		}

		return dateToString(gregorianToDate(iCalend));
	}

	/**
	 * Convert from String to XMLGregorianCalendar
	 * 
	 * @param dateTime
	 *            in String
	 * @return XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar stringToXMLGregoCalendar(String dateTime) {
		XMLGregorianCalendar result = null;

		Date date = stringToDate(dateTime);
		result = dateToGregorian(date);

		return result;
	}

	/**
	 * Creates and returns xmlgregoriancalendar for current time.
	 * 
	 * @return XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar getXMLGregorianCalendarNow() {
		return DATA_TYPE_FACTOR.get().newXMLGregorianCalendar(new GregorianCalendar());
	}

	/**
	 * Get simple date format with default date format & default timezone.
	 * 
	 * @return
	 */
	public static DateFormat getDefaultDateFormat() {
		return ISO_DATE_FORMAT.get();
	}

	/**
	 * Convert Date object to String. It will format the date as per ISO 8601
	 * date time standard. Description
	 * 
	 * @param date
	 * @return
	 */
	public static String dateToString(Date date) {
		// Use the fast date format object in these cases.
		return ISO_DATE_FORMAT.get().format(date);
	}

	/**
	 * Returns true if calendar1 is before calendar2.
	 * 
	 * @param calendar1
	 * @param calendar2
	 * @return boolean
	 */
	public static boolean isCalendarBefore(XMLGregorianCalendar calendar1, XMLGregorianCalendar calendar2) {
		return calendar1.compare(calendar2) < 0;
	}

	/**
	 * Return true if calendar1 is after calendar 2.
	 * 
	 * @param calendar1
	 * @param calendar2
	 * @return boolean.
	 */
	public static boolean isCalendarAfter(XMLGregorianCalendar calendar1, XMLGregorianCalendar calendar2) {
		return calendar1.compare(calendar2) > 0;
	}

	/**
	 * Convert string date to Date Object. If unable to parse string date it
	 * will throw {@link IllegalArgumentException} exception.
	 * 
	 * @param date
	 *            - string date
	 * @return date - Converted Date object.
	 */
	public static Date stringToDate(String date) {
		if (!StringUtils.isEmpty(date)) {
			try {
				return ISO_DATE_FORMAT.get().parse(date);
			} catch (Exception e1) {
				// DateFormat abstract class throw ParseException, while
				// ISO8601DateFormat throws IllegalArgumentException, so we
				// should
				// catch general exception here
				LOGGER.error("cannot parse date time value: {} with ISO 8601 standards", date);
				throw new DateParsingException("cannot parse date time type ", e1);
			}
		} else {
			return null;
		}
	}

	/**
	 * Convert XMLGregorianCalendar object to String with ISO 8601 standards.
	 * 
	 * @param iCalend
	 * @return string
	 */
	public static String gregorianToStringDate(XMLGregorianCalendar iCalend) {
		Date date = iCalend.toGregorianCalendar().getTime();
		Calendar calendar = ISO_DATE_FORMAT.get().getCalendar();
		calendar.setTime(date);
		return DateFormatUtils.ISO_DATE_FORMAT.format(calendar);
	}

	/**
	 * Convert XMLGregorianCalendar object to String with ISO 8601 standards.
	 * 
	 * @param iCalend
	 * @return string
	 */
	public static String dateToSimpleDateString(Date date) {
		//SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		//sdf.setTimeZone(TIMEZONE);
		return SIMPLE_DATE_FORMAT.get().format(date);
	}

	/**
	 * Convert string date to Date Object.
	 * 
	 * @param stringDate
	 * @return date
	 */
	public static Date simpleDateStringToDate(String stringDate) {
		//SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
		//sdf.setTimeZone(TIMEZONE);
		Date date = null;
		try {
			date = SIMPLE_DATE_FORMAT.get().parse(stringDate);
			return date;
		} catch (ParseException e) {
			LOGGER.error("cannot parse date value: {} ", date);
			throw new DateParsingException("cannot parse date type ", e);
		}

	}

	
}
