/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv;


import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author uday
 *
 */

/**
 * A package attribute that captures the version of PGSearch that was compiled.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.PACKAGE)
public @interface ClusterVersionAnnotation {
 
  /**
   * Get the Cluster version.
   * @return the version string "0.6.3-dev"
   */
  String version();
  
  /**
   * Get the username that compiled Cluster.
   */
  String user();
  
  /**
   * Get the date when Cluster was compiled.
   * @return the date in unix 'date' format
   */
  String date();
  
  /**
   * Get the url for the cvs repository.
   */
  String url();
  
  /**
   * Get the svn revision.
   * @return the revision number as a string (eg. "451451")
   */
  String revision();
  
  /**
   * Get the checksum of the source files from which Cluster was
   * built.
   **/
  String srcChecksum();
}

