/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

/**
 * Account.
 * 
 * <H3>Account</H3>
 *
 * @author TuTX1
 * @since Jun 26, 2014
 */
public class Account {
	private String accountId ;
	private String encryptedId ;
	
	/**
	 * Account constructor.
	 * 
	 * Constructor<br>
	 * @param accountId : accountId
	 * @param encryptedId : encryptedId
	 */
	public Account(String accountId, String encryptedId) {
		super();
		this.accountId = accountId;
		this.encryptedId = encryptedId;
	}

	/**
	 * <br>
	 * @return  accountId
	 */
	
	public String getAccountId() {
		return accountId;
	}

	/**
	 *<br>
	 * @param accountId the accountId to set
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	/**
	 * <br>
	 * @return  encryptedId
	 */
	
	public String getEncryptedId() {
		return encryptedId;
	}

	/**
	 *<br>
	 * @param encryptedId the encryptedId to set
	 */
	public void setEncryptedId(String encryptedId) {
		this.encryptedId = encryptedId;
	}
	
	
	
}
