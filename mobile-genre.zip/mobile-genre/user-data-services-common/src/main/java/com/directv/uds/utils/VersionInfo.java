/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.utils;

import com.directv.ClusterVersionAnnotation;

/**
 * @author uday
 *
 */

/**
 * This class finds the package info for Plugins and the ClusterVersionAnnotation
 * information.
 */
public class VersionInfo {
  private static Package myPackage;
  private static ClusterVersionAnnotation version;
  
  static {
    myPackage = ClusterVersionAnnotation.class.getPackage();
    version = myPackage.getAnnotation(ClusterVersionAnnotation.class);
  }

  /**
   * Get the meta-data for the package.
   * @return
   */
  static Package getPackage() {
    return myPackage;
  }
  
  /**
   * Get the version.
   * @return the version string, eg. "0.6.3-dev"
   */
  public static String getVersion() {
    return version != null ? "0.2.1" : "Unknown";
  }
  
  /**
   * Get the subversion revision number for the root directory
   * @return the revision number, eg. "451451"
   */
  public static String getRevision() {
    return version != null ? version.revision() : "Unknown";
  }
  
  /**
   * The date compiled.
   * @return the compilation date in unix date format
   */
  public static String getDate() {
    return version != null ? version.date() : "Unknown";
  }
  
  /**
   * The user that compiled
   * @return the username of the user
   */
  public static String getUser() {
    return version != null ? version.user() : "Unknown";
  }
  
  /**
   * Get the subversion URL for the root directory
   */
  public static String getUrl() {
    return version != null ? version.url() : "Unknown";
  }
  
  /**
   * Get the checksum of the source files from which Plugins was
   * built.
   **/
  public static String getSrcChecksum() {
    return version != null ? version.srcChecksum() : "Unknown";
  }
  
  public static void main(String[] args) {
	  System.out.println("version: "+ getVersion());
	    System.out.println("Cluster " + getVersion());
	    System.out.println("Subversion " + getUrl() + " -r " + getRevision());
	    System.out.println("Compiled by " + getUser() + " on " + getDate());
	    System.out.println("From source with checksum " + getSrcChecksum());
	    System.out.println("This command was run using " + 
	        org.apache.hadoop.util.ClassUtil.findContainingJar(VersionInfo.class));
	  }
}
