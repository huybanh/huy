/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.List;

import com.directv.uds.model.Account;
import com.directv.uds.model.DMAInformation;


/**
 * Account Interface contain methods to get account info.
 * <H3>AccountDAO</H3>
 *
 * @author TuTX1
 * @since Jul 1, 2014
 */
public interface AccountDAO extends UDSDao {
	
	/**
	 * Get encrytedId from userId.
	 * 
	 * Description
	 * @param userId : requested userId
	 * @return encryptedId
	 */
	public String getEncryptedId(String userId);
	
	/**
	 * Get userId from encryptedId. 
	 * It mean de-crypt an id to userId.
	 * 
	 * Description
	 * @param encryptedId : requested id
	 * @return userId
	 */
	public String getUserId(String encryptedId);
	
	/**
	 * Get Account from cardId.
	 * 
	 * Description
	 * @param cardId : requested cardId
	 * @return Account object (contain a pair: userId and encryptedId)
	 */
	public Account getAccountByCardId(String cardId);
	
	/**
	 * Get list active user by offset and limit.
	 * 
	 * Description
	 * @param offset : start with offset
	 * @param limit  : return limit of records
	 * @return List of active users
	 */
	public List<String> getUsers(int offset, int limit);

	/**
	 * 
	 * @param accountId
	 * @return dma information includes dmaCode and dmaDescription
	 * @throws IOException 
	 */
	public DMAInformation getRegionIdFromAccountId(String accountId) throws IOException;
}
