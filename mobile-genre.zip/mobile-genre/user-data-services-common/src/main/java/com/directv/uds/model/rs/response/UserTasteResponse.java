package com.directv.uds.model.rs.response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.directv.uds.model.FrequencyElement;

public class UserTasteResponse {
	private Map<String, List<FrequencyElement>> userTaste;

	public UserTasteResponse() {
		userTaste = new HashMap<String, List<FrequencyElement>>();
	}

	public Map<String, List<FrequencyElement>> getUserTaste() {
		return userTaste;
	}

	public void setUserTaste(Map<String, List<FrequencyElement>> userTaste) {
		this.userTaste = userTaste;
	}
 
	
}
