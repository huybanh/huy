/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.enums;

public enum ErrorCode {

	BAD_REQUEST("400", "Bad request."), MISSING_INVALID_PAYLOAD("400", "Missing or Invalid payload."), INVALID_PAYLOAD("400",
			"Invalid payload."), INVALID_PAYLOAD_RULE_TYPE("400", "Rule type is not supported."), NOT_FOUND("404", "%s is not found"), DOWN_STREAM_SYSTEM_EXCEPTION(
			"590", "Downstream System Failed"), INVALID_DATE_FORMAT("591",
			"Invalid Date format. Date format should be yyyy-MM-ddTHH:mm:ssZ"), INVALID_CLIENTSECRET("400",
			"Client Secret must be valid pattern  %s ");

	private String code;
	private String message;

	private ErrorCode(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return this.code;
	}

	public String getMessage() {
		return this.message;
	}
}
