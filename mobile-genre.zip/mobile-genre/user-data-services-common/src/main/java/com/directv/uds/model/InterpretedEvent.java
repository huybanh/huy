/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.directv.uds.utils.JSONUtil;
import com.dtv.hbase.model.Event;

/**
 * 
 * <H3>InterpretedEvent</H3>
 *
 * @author TuTX1
 * @since Jun 25, 2014
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class InterpretedEvent extends Event {

	private String interpretedEvent;
	private String programTitle;
	private String mainCategory;
	
	public InterpretedEvent(){
	}
	
	public Event toEvent() {
		Event event = new Event();
		event.setAccountId(this.accountId);
		event.setDurationViewed(this.getDurationViewed());
		event.setEventTime(this.getEventTime());
		event.setEventType(this.eventType);
		event.setRunLength(this.getRunLength());
		event.setProgramTitle(this.getProgramTitle());
		event.setTmsId(this.getTmsId());
		event.setSource(this.getSource());
		return event;
	}
	
	public static List<Event> toEvents(InterpretedEvent[] events) {
		List<Event> result = new ArrayList<Event>();
		
		for(InterpretedEvent e : events) {
			
			Event event = e.toEvent();
			
			result.add(event);
		}
		return result;
	}
	
	//@JsonProperty("interpretedEventType")
	public String getInterpretedEvent() {
		return interpretedEvent;
	}

	public void setInterpretedEvent(String interpretedEvent) {
		this.interpretedEvent = interpretedEvent;
	}

	public String getProgramTitle() {
		return programTitle;
	}

	public void setProgramTitle(String programTitle) {
		this.programTitle = programTitle;
	}
	@com.fasterxml.jackson.annotation.JsonIgnore
	public String getMainCategory() {
		return mainCategory;
	}

	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}
}
