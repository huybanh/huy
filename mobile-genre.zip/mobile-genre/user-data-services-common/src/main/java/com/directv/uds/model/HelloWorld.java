/**
 * 
 * DIRECTV PROPRIETARY Copyright© 2013 DIRECTV, INC. UNPUBLISHED WORK ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information, in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with DIRECTV providing access to this software.
 */

package com.directv.uds.model;

public class HelloWorld {

	private String message;
	private String world;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getWorld() {
		return world;
	}

	public void setWorld(String world) {
		this.world = world;
	}

}
