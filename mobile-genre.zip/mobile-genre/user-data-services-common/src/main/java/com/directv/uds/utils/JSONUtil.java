/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc("Proprietary Information")Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software
 *****************************************************************************
 */
package com.directv.uds.utils;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.JsonToken;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <H3>JSONUtil</H3>
 * 
 * @author TuTX1
 * @since Aug 11, 2014
 */
public class JSONUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(JSONUtil.class);
	public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	public static String[][] get2DArray(byte[] src) {
		ObjectMapper mapper = new ObjectMapper();

		String[][] result = null;
		try {
			result = mapper.readValue(src, String[][].class);
		} catch (JsonParseException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (JsonMappingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}

		return result;
	}

	public static String convertObjectToJson(Object obj) throws IOException {
		String result = null;
		try {
			result = OBJECT_MAPPER.writeValueAsString(obj);
		} catch (JsonGenerationException e) {
			LOGGER.error(e.getMessage(), e);
			throw e;
		} catch (JsonMappingException e) {
			LOGGER.error(e.getMessage(), e);
			throw e;
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw e;
		}
		return result;
	}

	public static <T> T convertJsonToObject(String json, Class<T> clazz) {
		T result = null;
		try {
			result = OBJECT_MAPPER.readValue(json.getBytes(), clazz);
		} catch (JsonGenerationException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (JsonMappingException e) {
			LOGGER.error(e.getMessage(), e);
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		return result;
	}

	public static void parseFileJson(String path) throws JsonProcessingException, IOException {
		JsonFactory jsonFactory = new JsonFactory();
		JsonParser parser = jsonFactory.createJsonParser(new File(path));

		// Map where to store your field-value pairs per object
		Map<String, String> fields = new java.util.HashMap<String, String>();
		JsonToken token;
		while ((token = parser.nextToken()) != JsonToken.END_ARRAY) {
			switch (token) {

			// Starts a new object, clear the map
			case START_OBJECT:
				fields.clear();
				break;

			// For each field-value pair, store it in the map 'fields'
			case FIELD_NAME:
				String field = parser.getCurrentName();
				token = parser.nextToken();
				String value = parser.getText();
				fields.put(field, value);
				System.out.println(value);
				break;

			// Do something with the field-value pairs
			case END_OBJECT:
				break;
			case END_ARRAY:
				break;
			case NOT_AVAILABLE:
				break;
			case START_ARRAY:
				break;
			case VALUE_EMBEDDED_OBJECT:
				break;
			case VALUE_FALSE:
				break;
			case VALUE_NULL:
				break;
			case VALUE_NUMBER_FLOAT:
				break;
			case VALUE_NUMBER_INT:
				break;
			case VALUE_STRING:
				break;
			case VALUE_TRUE:
				break;
			default:
				break;
			}
		}
		parser.close();
	}

}