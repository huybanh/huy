package com.directv.uds.service;

import java.util.List;
import java.util.Map;

import com.directv.uds.model.RecommendationJobHistory;

public interface HistoryLogService {

	/***
	 * Return json String, which contains information about job history
	 * @param startTime : starting point for searching
	 * @param endTime: end point for searching
	 * @param latest: choose to get the latest job history or a list of job history from startTime to endTime
	 * @return
	 */
	public Map<String, List<RecommendationJobHistory>> getRecommendationJobHistory(String startTime, String endTime, boolean latest);

}
