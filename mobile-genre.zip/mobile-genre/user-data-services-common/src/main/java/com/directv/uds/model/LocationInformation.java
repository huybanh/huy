/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.model;

public class LocationInformation {
	private String dma;
	private String dmaDescription;
	private String timeZone;
	private String timeZoneOffset;

	private String countyCode;

	public LocationInformation(String dma, String dmaDescription, String timeZone, String countyCode) {
		super();
		this.dma = dma;
		this.dmaDescription = dmaDescription;
		this.timeZone = timeZone;
		this.countyCode = countyCode;
	}
	
	public LocationInformation() {
		super();
		
	}

	public String getDma() {
		return dma;
	}

	public void setDma(String dma) {
		this.dma = dma;
	}

	public String getDmaDescription() {
		return dmaDescription;
	}

	public void setDmaDescription(String dmaDescription) {
		this.dmaDescription = dmaDescription;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	
	public String getTimeZoneOffset() {
		return timeZoneOffset;
	}

	public void setTimeZoneOffset(String timeZoneOffset) {
		this.timeZoneOffset = timeZoneOffset;
	}

}
