package com.directv.uds.model;

public class Uds {
	
	public static String uvh;
	public static String cbcfbyday;
	public static String cbcf;
	public static String lastaction;
	public static String whatshot;

}
