/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.model;

import static org.apache.hadoop.metrics2.impl.MsInfo.ProcessName;
import static org.apache.hadoop.metrics2.impl.MsInfo.SessionId;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.metrics2.MetricsSystem;
import org.apache.hadoop.metrics2.annotation.Metric;
import org.apache.hadoop.metrics2.annotation.Metrics;
import org.apache.hadoop.metrics2.lib.DefaultMetricsSystem;
import org.apache.hadoop.metrics2.lib.MetricsRegistry;
import org.apache.hadoop.metrics2.lib.MutableCounterInt;
import org.apache.hadoop.metrics2.source.JvmMetrics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author uday
 * 
 *         Nov 13, 2013 12:08:24 PM
 */
@Metrics(name = "ClusterLoaderActivity", about = "cluster loader activity", context = "cspmetrics")
public class ClusterLoaderMetrics {
	static final Logger LOGGER = LoggerFactory.getLogger(ClusterLoaderMetrics.class);
	final MetricsRegistry registry = new MetricsRegistry("clusterloader");
	public static String sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
	@Metric("Number of request")
	MutableCounterInt requestNumber;

	ClusterLoaderMetrics(String processName, String sessionId) {
		registry.tag(ProcessName, processName).tag(SessionId, sessionId);
	}

	public static ClusterLoaderMetrics create() {

		sessionId = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		String processName = "load";

		// metrics system init is really init & start.
		// It's more test friendly to put it here.
		DefaultMetricsSystem.initialize("clusterLoader");

		MetricsSystem ms = DefaultMetricsSystem.instance();
		JvmMetrics.create(processName, sessionId, ms);

		return ms.register(processName, sessionId, new ClusterLoaderMetrics(processName, sessionId));
	}

	public void incrRequestNumber() {
		requestNumber.incr();
	}

}
