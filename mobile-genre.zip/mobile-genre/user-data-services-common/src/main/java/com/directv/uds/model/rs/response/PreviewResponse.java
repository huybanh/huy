/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.model.rs.response;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Kietlm
 * 
 */
public class PreviewResponse {

	private List<PreviewResult> preview;

	/**
	 * @return the preview
	 */
	public List<PreviewResult> getPreview() {
		if(preview==null){
			preview = new ArrayList<PreviewResult>();
		}
		return preview;
	}

	/**
	 * @param preview the preview to set
	 */
	public void setPreview(List<PreviewResult> preview) {
		this.preview = preview;
	}

	
}
