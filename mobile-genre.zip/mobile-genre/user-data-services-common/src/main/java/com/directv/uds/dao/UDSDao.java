package com.directv.uds.dao;

public interface UDSDao {

	public static final String LAST_ACTION_BY_RULE_COLUMN_FAMILY = "lastActionByRuleColumnFamily";
	public static final String LAST_ACTION_BY_RULE_HBASE_TABLE = "lastActionByRuleHbaseTable";

	public static final String LAST_ACTION_GENERIC_COLUMN_FAMILY = "lastActionGenericColumnFamily";
	public static final String LAST_ACTION_GENERIC_HBASE_TABLE = "lastActionGenericHbaseTable";
	
	//public static final String CREDIT_BY_RULE_HBASE_TABLE = "creditByRuleHbaseTable";
	//public static final String CREDIT_BY_RULE_COLUMN_FAMILY = "creditByRuleColumnFamily";
	
	public static final String CBCF_HBASE_TABLE = "cbcfHbaseTable";
	public static final String CBCF_COLUMN_FAMILY = "cbcfColumnFamily";
	
	public static final String CBCFBYDAY_HBASE_TABLE = "cbcfbydayHbaseTable";
	public static final String CBCFBYDAY_COLUMN_FAMILY = "cbcfbydayColumnFamily";
	
	public static final String WIH_HBASE_TABLE = "wihHbaseTable";
	public static final String WIH_COLUMN_FAMILY = "wihColumnFamily";
	
	public static final String RJH_TABLE = "recommendationsJobHistoryTable";
	public static final String RJH_FAMILY = "recommendationsJobHistoryColumnFamily";

	//ACCOUNT_ID_TO_ENCRYPTED_ID = new HbaseTableConfiguration(config.getString("accountIdToEncryptedIdHbaseTable"), config.getString(
	//		"accountIdToEncryptedIdColumnFamily").getBytes(), config.getString("accountIdToEncryptedIdColumnQualifier").getBytes());
	public static final String ACCOUNT_TO_ENCRYPTED_TABLE = "accountIdToEncryptedIdHbaseTable";
	public static final String ACCOUNT_TO_ENCRYPTED_FAMILY = "accountIdToEncryptedIdColumnFamily";
	public static final String ACCOUNT_TO_ENCRYPTED_QUALIFIER = "accountIdToEncryptedIdColumnQualifier";
	
	//ENCRYPTED_ID_TO_ACCOUNT_ID = new HbaseTableConfiguration(config.getString("encryptedIdToAccountIdHbaseTable"), config.getString(
	//		"encryptedIdToAccountIdColumnFamily").getBytes(), config.getString("encryptedIdToAccountIdColumnQualifier").getBytes());
	public static final String ENCRYPTED_TO_ACCOUNT_TABLE = "encryptedIdToAccountIdHbaseTable";
	public static final String ENCRYPTED_TO_ACCOUNT_FAMILY = "encryptedIdToAccountIdColumnFamily";
	public static final String ENCRYPTED_TO_ACCOUNT_QUALIFIER = "encryptedIdToAccountIdColumnQualifier";
	
	//CARD_ID_TO_ACCOUNT_ID = new HbaseTableConfiguration(config.getString("cardIdToAccountIdHbaseTable"), config.getString(
	//		"cardIdToAccountIdColumnFamily").getBytes(), config.getString("cardIdToAccountIdColumnQualifier").getBytes());
	public static final String CARD_TO_ACCOUNT_TABLE = "cardIdToAccountIdHbaseTable";
	public static final String CARD_TO_ACCOUNT_FAMILY = "cardIdToAccountIdColumnFamily";
	public static final String CARD_TO_ACCOUNT_QUALIFIER = "cardIdToAccountIdColumnQualifier";
	
	//ACCOUNT_ID_TO_REGION_ID = new HbaseTableConfiguration(config.getString("accountIdToRegionIdHBaseTable"), config.getString(
	//		"accountIdToRegionIdColumnFamily").getBytes(), config.getStringArray("accountIdToRegionIdColumnQualifier"));
	public static final String ACCOUNT_TO_REGION_TABLE = "accountIdToRegionIdHBaseTable";
	public static final String ACCOUNT_TO_REGION_FAMILY = "accountIdToRegionIdColumnFamily";
	public static final String ACCOUNT_TO_REGION_QUALIFIER = "accountIdToRegionIdColumnQualifier";
	
	//ZIP_CODE_TO_LOCATION = new HbaseTableConfiguration(config.getString("zipCodeToLocationHbaseTable"), config.getString(
	//		"zipCodeToLocationColumnFamily").getBytes(), config.getString("zipCodeToLocationColumnQualifier").getBytes());
	public static final String ZIPCODE_TO_LOCATION_TABLE = "zipCodeToLocationHbaseTable";
	public static final String ZIPCODE_TO_LOCATION_FAMILY = "zipCodeToLocationColumnFamily";
	public static final String ZIPCODE_TO_LOCATION_QUALIFIER = "zipCodeToLocationColumnQualifier";
}
