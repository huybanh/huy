/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.util.List;
import java.util.Map;

import com.directv.uds.model.RecommendationJobHistory;

/**
 * 
 * @author ThanhNN2
 *
 */
public interface HistoryLogDAO extends UDSDao {
	
	/**
	 * get Recommendation job history from startTime to endTime or 
	 * the latest Recommendation job history from this period of time.
	 * @param startTime: start point to search
	 * @param endTime: end point to search
	 * @param latest
	 * @return
	 */
	public Map<String, List<RecommendationJobHistory>> getRecommendationJobHistory(String startTime, String endTime, boolean latest);
}
