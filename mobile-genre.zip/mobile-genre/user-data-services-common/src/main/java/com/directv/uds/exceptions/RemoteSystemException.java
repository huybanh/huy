/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.exceptions;

import com.directv.uds.enums.UDSHTTPStatus;




/**
 * exception thrown when an error is received talking to a remote system.
 * 
 * @author mgiramkar
 * 
 */
public class RemoteSystemException extends BaseRuntimeException {

	private static final long serialVersionUID = 1L;
	private static final String DEFAULT_ERROR_CODE = String
			.valueOf(UDSHTTPStatus.DOWN_STREAM_SYSTEM_EXCEPTION.getStatusCode());
	private static final String DEFAULT_ERROR_TEXT = UDSHTTPStatus.DOWN_STREAM_SYSTEM_EXCEPTION.getReasonPhrase();

	public enum SystemName {
		HBASE, IMPALA, OOZIE, HDFS;
	}

	private final SystemName systemName;

	
	/**
	 * exception used when there are issues with a downstream system
	 * 
	 * @param sysname
	 * @param errorText
	 *            text describing the exception.
	 * @param errorCode
	 *            this should only be set if provided by the remote system.
	 *            otherwise leave it null
	 */
	public RemoteSystemException(SystemName sysname, String errorText, String errorCode) {
		this(sysname, errorText, errorCode, null);
	}

	public RemoteSystemException(SystemName sysname, String errorText) {
		this(sysname, errorText, DEFAULT_ERROR_CODE);
	}

	public RemoteSystemException(SystemName sysname) {
		this(sysname, DEFAULT_ERROR_TEXT, DEFAULT_ERROR_CODE);
	}

	public RemoteSystemException(SystemName sysname, Throwable throwable) {
		super(throwable);
		this.systemName = sysname;
		setErrorMessage(throwable.getMessage());
		setErrorCode(DEFAULT_ERROR_CODE);
	}

	public RemoteSystemException(SystemName sysname, String errorText, String errorCode, Throwable t) {
		super(t);

		this.systemName = sysname;

		if (errorText == null) {
			setErrorMessage(DEFAULT_ERROR_TEXT);
		} else {
			setErrorMessage(errorText);
		}

		if (errorCode == null) {
			setErrorCode(DEFAULT_ERROR_CODE);
		} else {
			setErrorCode(errorCode);
		}
	}

	public SystemName getSystemName() {
		return systemName;
	}

	@Override
	public String getErrorMessage() {
		return systemName + " Service Error: " + super.getErrorMessage();
	}
	
}
