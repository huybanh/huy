/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;

import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.listbuilder.model.RuleType;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.RuleConverterUtil;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;

/**
 * <H3>TestRuleConverterUtil</H3>
 *
 * @author ThanhNN2
 * @since Oct 27, 2014
 */
public class TestRuleConverterUtil {
	ObjectMapper mapper = new ObjectMapper();

	private void loadRuleFile() throws JsonGenerationException,
			JsonMappingException, IOException {
		// Phuong: Please check this method clearly (Because we shouldn't do
		// something like this for production)
		String ruleValueMappingFile = "src/test/resources/ruleValueMapping.txt";
		@SuppressWarnings("unused")
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(ruleValueMappingFile);
		UserDataConfiguration.loadRuleValueMapping(file);
		System.out.println(mapper
				.writeValueAsString(UserDataConfiguration.RULE_VALUE_MAPPING));
		;
	}

	@Test
	public void crParser() throws JsonGenerationException,
			JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		String input = "{\"rule\":[{\"state\":\"UNPUBLISHED\",\"query\":{\"match\":{\"type\":\"OR\",\"statement\":[{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"is\",\"value1\":\"Movies\",\"value2\":null}}]}},\"inclusion\":[\"TMSID1235\"],\"exclusion\":[\"TMSID1579\"],\"platform\":[{\"deviceType\":\"ios table\",\"displayTitle\":\"Because you have watch on \"}],\"typeOfRule\":\"LAST_WATCH\",\"maxResult\":12,\"ruleName\":\"LASTWATCH_YESTERDAY\",\"collapseSeries\":true,\"suppressResult\":null,\"defaultLabel\":null,\"useEpisodeTitle\":null,\"manualPosition\":[],\"userBehavior\":{\"match\":{\"type\":\"AND\",\"statement\":[{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"EQUAL\",\"value1\":\"tv\",\"value2\":null}},{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"NOT_EQUAL\",\"value1\":\"movies\",\"value2\":null}},{\"match\":{\"type\":\"AND\",\"statement\":[{\"match\":null,\"filter\":{\"name\":\"subcategory\",\"operation\":\"EQUAL\",\"value1\":\"user taste\",\"value2\":null}}]},\"filter\":null}]}},\"dtv\":null,\"ottSources\":null,\"sort\":[{\"sortSeq\":1,\"sortBy\":\"DESC\",\"sortField\":\"rating\"}]}]}";
		loadRuleFile();
		// Delivery filter
		LAFilterType.Filter.DELIVERY.setName("deliveryType");
		LAFilterType.Filter.DELIVERY.setValue("delivery");

		// Genre filter
		LAFilterType.Filter.GENRE.setName("subcategory");
		LAFilterType.Filter.GENRE.setValue("genre1,genre2,genre3");

		// Rating filter
		LAFilterType.Filter.RATING.setName("rating");
		LAFilterType.Filter.RATING.setValue("rating");

		// Pay filter
		LAFilterType.Filter.PAY.setName("ppv");
		LAFilterType.Filter.PAY.setValue("pay");

		// Type filter
		LAFilterType.Filter.TYPE.setName("category");
		LAFilterType.Filter.TYPE.setValue("maincategory");

		// Day of week filter
		LAFilterType.Filter.DAY_OF_WEEK.setName("dayOfWeek");
		LAFilterType.Filter.DAY_OF_WEEK.setValue("dayofweek");

		// Device filter
		LAFilterType.Filter.DEVICE.setName("device");
		LAFilterType.Filter.DEVICE.setValue("devicetype");

		// Time of day filter
		LAFilterType.Filter.TIME_OF_DAY.setName("timeOfDay");
		LAFilterType.Filter.TIME_OF_DAY.setValue("timeofday");
		RuleSet set = JSONUtil.convertJsonToObject(input, RuleSet.class);
		System.out.println(set.getRule().size());
		for (RuleType x : set.getRule()) {
			LARule rule = RuleConverterUtil.from(x);
			System.out.println(mapper.writeValueAsString(rule));
			//System.out.println(RuleParserUtil.buildQueryFromRule(rule, null));
		}

	}

	// @Test
	// public void ruleParser() throws JAXBException, IOException {
	// File folder = new File("src/test/resources/LB-sample-files");
	//
	// File[] files = folder.listFiles();
	//
	// ObjectMapper mapper = new ObjectMapper();
	//
	// for (File file : files) {
	// ListbuilderConfig lbConfig = mapper.readValue(file,
	// ListbuilderConfig.class);
	//
	// ListBuilderDeltaListing delta = lbConfig.getListBuilderDeltaListing();
	// ListBuilderFullListing full = lbConfig.getListBuilderFullListing();
	//
	// RuleSet ruleSet = null;
	//
	// if (delta != null) {
	// ruleSet = delta.getRuleSet();
	//
	// for (RuleType rule : ruleSet.getRule()) {
	// LARule laRule = RuleConverterUtil.from(rule);
	// if (laRule != null) {
	// String userBehaviour = RuleParserUtil.buildQueryFromRule(laRule, null);
	// String query = QueryGeneration.selectUserLastAction("uvhTable",
	// "accountId", "eventtype", userBehaviour, 0, 1);
	// System.out.println(mapper.writeValueAsString(laRule));
	// System.out.println(mapper.writeValueAsString(query));
	// }
	// }
	// }
	//
	// if (full != null) {
	// ruleSet = full.getRuleSet();
	//
	// for (RuleType rule : ruleSet.getRule()) {
	// LARule laRule = RuleConverterUtil.from(rule);
	// if (laRule != null) {
	// String userBehaviour = RuleParserUtil.buildQueryFromRule(laRule, null);
	// String query = QueryGeneration.selectUserLastAction("uvhTable",
	// "accountId", "eventtype", userBehaviour, 0, 1);
	// System.out.println(mapper.writeValueAsString(laRule));
	// System.out.println(mapper.writeValueAsString(query));
	// }
	// }
	// }
	// }
	//
	// }
	//
	// @Test
	// public void generateJSONPreviewResult() throws JsonGenerationException,
	// JsonMappingException, IOException {
	// PreviewResponse udsPreviewRules = new PreviewResponse();
	// PreviewResult result = new PreviewResult();
	// List<LastActionElement> lastAction = null;
	// result.setRuleName("Lastwatch_rule1");
	// result.setResultLastAction(lastAction);
	// udsPreviewRules.getPreview().add(result);
	// System.out.println(JSONUtil.convertObjectToJson(udsPreviewRules));
	// }
	//
	// @Test
	// public void parseNullResponse(){
	// String json = "{\"preview\":[{\"ruleName\":\"LASTWATCH_YESTERDAY\"}]}";
	// PreviewResponse response = JSONUtil.convertJsonToObject(json,
	// PreviewResponse.class);
	// System.out.println(JSONUtil.convertObjectToJson(response));
	// }
}
