package com.directv;

import java.io.IOException;

import org.junit.Test;

import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.utils.JSONUtil;

public class TestJSONConvert {
	@Test
	public void convertInterpretedEvent() throws IOException{
		String json = "[{\"eventTime\":\"20141124\",\"tmsId\":\"EP012483920173\",\"eventType\":\"LiveViewEvent\",\"source\":\"1\",\"accountId\":\"76303618\",\"interpretedEvent\":\"Watch\",\"mainCategory\":\"TV\"},{\"eventTime\":\"20141124\",\"tmsId\":\"EP000169160118\",\"eventType\":\"LiveViewEvent\",\"source\":\"1\",\"accountId\":\"76303618\",\"interpretedEvent\":\"Watch\",\"mainCategory\":\"TV\"},{\"eventTime\":\"20141123\",\"tmsId\":\"EP001151270168\",\"eventType\":\"LiveViewEvent\",\"source\":\"1\",\"accountId\":\"76303618\",\"interpretedEvent\":\"Watch\",\"mainCategory\":\"TV\"}]";
		InterpretedEvent[] events = JSONUtil.convertJsonToObject(json, InterpretedEvent[].class);
		System.out.println(JSONUtil.convertObjectToJson(events));
	}
}
