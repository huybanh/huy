/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv;

import static org.junit.Assert.*;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.junit.Test;

import com.directv.uds.model.EventTime;
import com.directv.uds.utils.InputParameterUtil;

/**
 * <H3>TestInputParameterUtil</H3>
 *
 * @author ThanhNN2
 * @since Oct 29, 2014
 */
public class TestInputParameterUtil {
	
	@Test
	public void testParseEventDate(){
		
		DateTimeFormatter dtvDateTimeFormat = ISODateTimeFormat.dateTimeNoMillis();
		DateTimeFormatter hbaseDateTimeFormat = DateTimeFormat.forPattern("yyyyMMddHHmmss");
		DateTimeFormatter hbaseDateFormat = DateTimeFormat.forPattern("yyyyMMdd");
		
		try {
			EventTime eventTime = new EventTime(null, null);
			InputParameterUtil.parseEventDate(dtvDateTimeFormat, hbaseDateTimeFormat, hbaseDateFormat, eventTime, 4);
			System.out.println(new ObjectMapper().writeValueAsString(eventTime));
			
			eventTime = new EventTime("2014-10-26T23:00:00Z", null);
			InputParameterUtil.parseEventDate(dtvDateTimeFormat, hbaseDateTimeFormat, hbaseDateFormat, eventTime, 4);
			System.out.println(new ObjectMapper().writeValueAsString(eventTime));
			
			eventTime = new EventTime("2014-10-26T23:00:00Z", "2014-10-29T23:00:00Z");
			InputParameterUtil.parseEventDate(dtvDateTimeFormat, hbaseDateTimeFormat, hbaseDateFormat, eventTime, 4);
			System.out.println(new ObjectMapper().writeValueAsString(eventTime));
			
			eventTime = new EventTime(null, "2014-10-26T23:00:00Z");
			InputParameterUtil.parseEventDate(dtvDateTimeFormat, hbaseDateTimeFormat, hbaseDateFormat, eventTime, 4);
			System.out.println(new ObjectMapper().writeValueAsString(eventTime));
			
		} catch (Exception e){
			fail("Can not parse normally");
		}
		
		try {
			EventTime eventTime = new EventTime("2014-10-26T23:00:00Z", "2014-10-23T23:00:00Z");
			InputParameterUtil.parseEventDate(dtvDateTimeFormat, hbaseDateTimeFormat, hbaseDateFormat, eventTime, 4);
			System.out.println(new ObjectMapper().writeValueAsString(eventTime));
			fail("Can not parse normally");
		} catch (Exception e){
			
		}
		
	}
	
	@Test
	public void testHbaseDateFormat() throws JsonGenerationException, JsonMappingException, IOException {
		long yourmilliseconds = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");

        Date resultdate = new Date(yourmilliseconds);
        System.out.println(sdf.format(resultdate));	
    }
		
}
