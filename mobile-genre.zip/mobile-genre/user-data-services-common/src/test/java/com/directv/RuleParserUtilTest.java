package com.directv;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.listbuilder.model.RuleType;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.QueryGeneration;
import com.directv.uds.utils.RuleConverterUtil;
import com.directv.uds.utils.RuleParserUtil;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;
import com.dtv.lastaction.listbuilderintegration.dto.LAMatchType;
import com.dtv.lastaction.listbuilderintegration.dto.LAMatchType.MatchType;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;

@SuppressWarnings("unused")
public class RuleParserUtilTest {

	ObjectMapper mapper = new ObjectMapper();

	private void loadRuleFile() throws JsonGenerationException,
			JsonMappingException, IOException {
		// Phuong: Please check this method clearly (Because we shouldn't do
		// something like this for production)
		String ruleValueMappingFile = "src/test/resources/ruleValueMapping.txt";
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(ruleValueMappingFile);
		UserDataConfiguration.loadRuleValueMapping(file);
		System.out.println(mapper
				.writeValueAsString(UserDataConfiguration.RULE_VALUE_MAPPING));
		;
	}

	@Test
	@Ignore
	public void testParseRule() throws JsonGenerationException, JsonMappingException, IOException {
		loadRuleFile();
		// Delivery filter
		LAFilterType.Filter.DELIVERY.setName("deliveryType");
		LAFilterType.Filter.DELIVERY.setValue("delivery");

		// Genre filter
		LAFilterType.Filter.GENRE.setName("subcategory");
		LAFilterType.Filter.GENRE.setValue("genre1,genre2,genre3");

		// Rating filter
		LAFilterType.Filter.RATING.setName("rating");
		LAFilterType.Filter.RATING.setValue("rating");

		// Pay filter
		LAFilterType.Filter.PAY.setName("ppv");
		LAFilterType.Filter.PAY.setValue("pay");

		// Type filter
		LAFilterType.Filter.TYPE.setName("category");
		LAFilterType.Filter.TYPE.setValue("maincategory");

		// Day of week filter
		LAFilterType.Filter.DAY_OF_WEEK.setName("dayOfWeek");
		LAFilterType.Filter.DAY_OF_WEEK.setValue("dayofweek");

		// Device filter
		LAFilterType.Filter.DEVICE.setName("device");
		LAFilterType.Filter.DEVICE.setValue("devicetype");

		// Time of day filter
		LAFilterType.Filter.TIME_OF_DAY.setName("timeOfDay");
		LAFilterType.Filter.TIME_OF_DAY.setValue("timeofday");

		String rule = "{\"rule\":[{\"state\":\"UNPUBLISHED\",\"query\":{\"match\":{\"type\":\"OR\",\"statement\":[{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"is\",\"value1\":\"Movies\",\"value2\":null}}]}},\"inclusion\":[\"TMSID1235\"],\"exclusion\":[\"TMSID1579\"],\"platform\":[{\"deviceType\":\"ios table\",\"displayTitle\":\"Because you have watch on \"}],\"typeOfRule\":\"LAST_WATCH\",\"maxResult\":12,\"ruleName\":\"LASTWATCH_YESTERDAY\",\"collapseSeries\":true,\"suppressResult\":null,\"defaultLabel\":null,\"useEpisodeTitle\":null,\"manualPosition\":[],\"userBehavior\":{\"match\":{\"type\":\"OR\",\"statement\":[{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"EQUAL\",\"value1\":\"tv\",\"value2\":null}},{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"NOT_EQUAL\",\"value1\":\"movies\",\"value2\":null}},{\"match\":{\"type\":\"AND\",\"statement\":[{\"match\":null,\"filter\":{\"name\":\"category\",\"operation\":\"EQUAL\",\"value1\":\"tv\",\"value2\":null}},{\"match\":null,\"filter\":{\"name\":\"subcategory\",\"operation\":\"EQUAL\",\"value1\":\"user taste\",\"value2\":null}}]},\"filter\":null}]}},\"whatsHotByRegion\":null,\"dtv\":null,\"ottSources\":null,\"sort\":[{\"sortSeq\":1,\"sortBy\":\"DESC\",\"sortField\":\"rating\"}]}]}";
		String cbcf = "{\"frequencyVectorList\":{\"Movies\":{\"Alldays\":[{\"value\":116.93590833309248,\"key\":\"Comedy\"},{\"value\":75.8437057364954,\"key\":\"Action/Adventure\"},{\"value\":69.32027367326819,\"key\":\"Drama\"},{\"value\":37.673974787244745,\"key\":\"Romance\"},{\"value\":27.113713189262832,\"key\":\"Fantasy\"},{\"value\":26.030925948173188,\"key\":\"Sci-Fi\"},{\"value\":15.402681719371035,\"key\":\"Mystery/Crime\"},{\"value\":14.502120606281196,\"key\":\"Suspense\"},{\"value\":11.456596364105032,\"key\":\"Horror\"},{\"value\":9.535287044296915,\"key\":\"Kids & Family\"},{\"value\":9.146410899275065,\"key\":\"Documentary\"},{\"value\":8.826435667829156,\"key\":\"Kids\"},{\"value\":6.532798561928929,\"key\":\"Biography\"},{\"value\":6.196406602591879,\"key\":\"Animation\"},{\"value\":4.985632183908046,\"key\":\"Entertainment\"},{\"value\":4.150651493851512,\"key\":\"Docudrama\"},{\"value\":2.4874684299949488,\"key\":\"History\"},{\"value\":2.3530016945788117,\"key\":\"Musical\"},{\"value\":2.037037037037037,\"key\":\"Science Fiction\"},{\"value\":1.2129870129870128,\"key\":\"Military/War\"},{\"value\":1.015625,\"key\":\"Western\"},{\"value\":0.980858036645315,\"key\":\"Music\"}]},\"AllCategories\":{\"Alldays\":[{\"value\":583.7337121332536,\"key\":\"Comedy\"},{\"value\":430.6797662735922,\"key\":\"Animation\"},{\"value\":393.59102427392435,\"key\":\"Kids\"},{\"value\":217.49700728537164,\"key\":\"Reality\"},{\"value\":175.24900697189952,\"key\":\"Kids & Family\"},{\"value\":170.86154671415835,\"key\":\"Talk\"},{\"value\":121.77117166871837,\"key\":\"Fantasy\"},{\"value\":109.58091088187284,\"key\":\"Drama\"},{\"value\":109.39582995186879,\"key\":\"Mystery/Crime\"},{\"value\":102.16645299145297,\"key\":\"Religion\"},{\"value\":93.10084949160778,\"key\":\"Action/Adventure\"},{\"value\":81.8719140475347,\"key\":\"Football\"},{\"value\":62.570189549313575,\"key\":\"Entertainment\"},{\"value\":55.63374124240984,\"key\":\"Sci-Fi\"},{\"value\":54.08166834175025,\"key\":\"Special\"},{\"value\":49.29927122993251,\"key\":\"Romance\"},{\"value\":48.289070787346645,\"key\":\"Game Show\"},{\"value\":44.75658914728683,\"key\":\"House/Garden\"},{\"value\":37.53191094095459,\"key\":\"Documentary\"},{\"value\":34.430461739495954,\"key\":\"Educational\"},{\"value\":33.568895306065066,\"key\":\"Suspense\"},{\"value\":33.113732004429686,\"key\":\"Home Repair\"},{\"value\":30.07619727047146,\"key\":\"Interview\"},{\"value\":26.459739952718675,\"key\":\"Politics\"},{\"value\":26.366666666666667,\"key\":\"Law\"},{\"value\":24.53333333333333,\"key\":\"How-To\"},{\"value\":22.167909629947307,\"key\":\"Cooking\"},{\"value\":21.262140417249693,\"key\":\"Music\"},{\"value\":20.400981266726138,\"key\":\"Soap Opera\"},{\"value\":17.530007368370583,\"key\":\"Auto\"},{\"value\":15.460947568456241,\"key\":\"Horror\"},{\"value\":15.414482291209131,\"key\":\"Animals\"},{\"value\":14.725793650793653,\"key\":\"Art\"},{\"value\":14.033333333333333,\"key\":\"Product Info\"},{\"value\":13.80555555555556,\"key\":\"Weather\"},{\"value\":12.085958802575654,\"key\":\"Interests\"},{\"value\":11.00994535519125,\"key\":\"Science/Nature\"},{\"value\":10.889999999999993,\"key\":\"Basketball\"},{\"value\":10.05,\"key\":\"Medical\"},{\"value\":9.353987174613339,\"key\":\"Business/Financial\"},{\"value\":7.741071428571429,\"key\":\"Travel\"},{\"value\":7.305555555555555,\"key\":\"Racing\"},{\"value\":6.823594666473869,\"key\":\"Standup\"},{\"value\":6.607401497241922,\"key\":\"Golf\"},{\"value\":6.549465228595595,\"key\":\"Biography\"},{\"value\":5.150651493851513,\"key\":\"Docudrama\"},{\"value\":4.626666666666668,\"key\":\"Soccer\"},{\"value\":4.353001694578812,\"key\":\"Musical\"},{\"value\":4.347345823575331,\"key\":\"Paranormal\"},{\"value\":4.0,\"key\":\"Self-Help\"},{\"value\":3.930284521948972,\"key\":\"History\"},{\"value\":3.8972222222222213,\"key\":\"Baseball\"},{\"value\":3.738621229925578,\"key\":\"Wrestling\"},{\"value\":3.441666666666667,\"key\":\"Martial Arts\"},{\"value\":3.3666666666666663,\"key\":\"Health/Medicine\"},{\"value\":3.231031746031746,\"key\":\"Tennis\"},{\"value\":2.7066666666666666,\"key\":\"Science\"},{\"value\":2.583333333333333,\"key\":\"Poker\"},{\"value\":2.5792075588939456,\"key\":\"Outdoors\"},{\"value\":2.3391479732388825,\"key\":\"Dance\"},{\"value\":2.0662749633435933,\"key\":\"Military/War\"},{\"value\":2.05,\"key\":\"Rodeo\"},{\"value\":2.047222222222222,\"key\":\"Fashion/Style\"},{\"value\":2.037037037037037,\"key\":\"Science Fiction\"},{\"value\":1.6,\"key\":\"Exercise/Fitness\"},{\"value\":1.3043478260869565,\"key\":\"Extreme\"},{\"value\":1.0612244897959184,\"key\":\"Horse\"},{\"value\":1.0564413265306123,\"key\":\"Western\"},{\"value\":1.0333333333333334,\"key\":\"Local\"},{\"value\":1.0166666666666666,\"key\":\"Cycling\"},{\"value\":1.0083333333333333,\"key\":\"Fundraiser\"},{\"value\":1.0,\"key\":\"Boarding\"},{\"value\":0.8391853862540164,\"key\":\"Mini-Series\"},{\"value\":0.8057004830917873,\"key\":\"Hockey\"},{\"value\":0.3333333333333333,\"key\":\"Motorcycle\"},{\"value\":0.23333333333333334,\"key\":\"Family\"},{\"value\":0.20277777777777778,\"key\":\"Award Ceremony\"},{\"value\":0.15,\"key\":\"Volleyball\"},{\"value\":0.05114942528735632,\"key\":\"Boxing\"},{\"value\":0.05,\"key\":\"Collectibles\"},{\"value\":0.041666666666666664,\"key\":\"Bodybuilding\"},{\"value\":0.03333333333333333,\"key\":\"Fishing\"},{\"value\":0.03333333333333333,\"key\":\"Performing Arts\"},{\"value\":0.03333333333333333,\"key\":\"Water Sports\"},{\"value\":0.019444444444444445,\"key\":\"Playoff\"},{\"value\":0.008333333333333333,\"key\":\"Gymnastics\"},{\"value\":0.008333333333333333,\"key\":\"Olympics\"}]},\"Sports\":{\"Alldays\":[{\"value\":81.8719140475347,\"key\":\"Football\"},{\"value\":17.530007368370583,\"key\":\"Auto\"},{\"value\":10.889999999999993,\"key\":\"Basketball\"},{\"value\":7.305555555555555,\"key\":\"Racing\"},{\"value\":6.607401497241922,\"key\":\"Golf\"},{\"value\":4.626666666666668,\"key\":\"Soccer\"},{\"value\":3.8972222222222213,\"key\":\"Baseball\"},{\"value\":3.738621229925578,\"key\":\"Wrestling\"},{\"value\":3.441666666666667,\"key\":\"Martial Arts\"},{\"value\":3.231031746031746,\"key\":\"Tennis\"},{\"value\":2.583333333333333,\"key\":\"Poker\"},{\"value\":2.05,\"key\":\"Rodeo\"},{\"value\":1.3043478260869565,\"key\":\"Extreme\"},{\"value\":1.0612244897959184,\"key\":\"Horse\"},{\"value\":1.0166666666666666,\"key\":\"Cycling\"},{\"value\":1.0,\"key\":\"Boarding\"},{\"value\":0.8057004830917873,\"key\":\"Hockey\"},{\"value\":0.3333333333333333,\"key\":\"Motorcycle\"},{\"value\":0.15,\"key\":\"Volleyball\"},{\"value\":0.05114942528735632,\"key\":\"Boxing\"},{\"value\":0.041666666666666664,\"key\":\"Bodybuilding\"},{\"value\":0.03333333333333333,\"key\":\"Fishing\"},{\"value\":0.03333333333333333,\"key\":\"Water Sports\"},{\"value\":0.019444444444444445,\"key\":\"Playoff\"},{\"value\":0.008333333333333333,\"key\":\"Gymnastics\"},{\"value\":0.008333333333333333,\"key\":\"Olympics\"}]},\"TV\":{\"Alldays\":[{\"value\":466.79780380016314,\"key\":\"Comedy\"},{\"value\":424.4833596710002,\"key\":\"Animation\"},{\"value\":384.7645886060952,\"key\":\"Kids\"},{\"value\":217.49700728537164,\"key\":\"Reality\"},{\"value\":170.86154671415835,\"key\":\"Talk\"},{\"value\":165.7137199276026,\"key\":\"Kids & Family\"},{\"value\":102.16645299145297,\"key\":\"Religion\"},{\"value\":94.65745847945556,\"key\":\"Fantasy\"},{\"value\":93.99314823249772,\"key\":\"Mystery/Crime\"},{\"value\":57.58455736540552,\"key\":\"Entertainment\"},{\"value\":54.08166834175025,\"key\":\"Special\"},{\"value\":48.289070787346645,\"key\":\"Game Show\"},{\"value\":44.75658914728683,\"key\":\"House/Garden\"},{\"value\":40.26063720860472,\"key\":\"Drama\"},{\"value\":34.430461739495954,\"key\":\"Educational\"},{\"value\":33.113732004429686,\"key\":\"Home Repair\"},{\"value\":30.07619727047146,\"key\":\"Interview\"},{\"value\":29.60281529423665,\"key\":\"Sci-Fi\"},{\"value\":28.385500041679503,\"key\":\"Documentary\"},{\"value\":26.459739952718675,\"key\":\"Politics\"},{\"value\":26.366666666666667,\"key\":\"Law\"},{\"value\":24.53333333333333,\"key\":\"How-To\"},{\"value\":22.167909629947307,\"key\":\"Cooking\"},{\"value\":20.400981266726138,\"key\":\"Soap Opera\"},{\"value\":20.281282380604377,\"key\":\"Music\"},{\"value\":19.066774699783874,\"key\":\"Suspense\"},{\"value\":17.25714375511239,\"key\":\"Action/Adventure\"},{\"value\":15.414482291209131,\"key\":\"Animals\"},{\"value\":14.725793650793653,\"key\":\"Art\"},{\"value\":14.033333333333333,\"key\":\"Product Info\"},{\"value\":13.80555555555556,\"key\":\"Weather\"},{\"value\":12.085958802575654,\"key\":\"Interests\"},{\"value\":11.625296442687748,\"key\":\"Romance\"},{\"value\":11.00994535519125,\"key\":\"Science/Nature\"},{\"value\":10.05,\"key\":\"Medical\"},{\"value\":9.353987174613339,\"key\":\"Business/Financial\"},{\"value\":7.741071428571429,\"key\":\"Travel\"},{\"value\":6.823594666473869,\"key\":\"Standup\"},{\"value\":4.347345823575331,\"key\":\"Paranormal\"},{\"value\":4.004351204351204,\"key\":\"Horror\"},{\"value\":4.0,\"key\":\"Self-Help\"},{\"value\":3.3666666666666663,\"key\":\"Health/Medicine\"},{\"value\":2.7066666666666666,\"key\":\"Science\"},{\"value\":2.5792075588939456,\"key\":\"Outdoors\"},{\"value\":2.3391479732388825,\"key\":\"Dance\"},{\"value\":2.047222222222222,\"key\":\"Fashion/Style\"},{\"value\":2.0,\"key\":\"Musical\"},{\"value\":1.6,\"key\":\"Exercise/Fitness\"},{\"value\":1.442816091954023,\"key\":\"History\"},{\"value\":1.0333333333333334,\"key\":\"Local\"},{\"value\":1.0083333333333333,\"key\":\"Fundraiser\"},{\"value\":1.0,\"key\":\"Docudrama\"},{\"value\":0.8532879503565806,\"key\":\"Military/War\"},{\"value\":0.8391853862540164,\"key\":\"Mini-Series\"},{\"value\":0.23333333333333334,\"key\":\"Family\"},{\"value\":0.20277777777777778,\"key\":\"Award Ceremony\"},{\"value\":0.05,\"key\":\"Collectibles\"},{\"value\":0.04081632653061224,\"key\":\"Western\"},{\"value\":0.03333333333333333,\"key\":\"Performing Arts\"},{\"value\":0.016666666666666666,\"key\":\"Biography\"}]}},\"query\":\"\"}";
		String[] mainCategories = { "Movies", "TV", "Sports", "AllCategories" };
		UserDataConfiguration.MAIN_CATEGORIES.addAll(mainCategories);
		FrequencyStatisticsResponse frequencyStatisticResponse = JSONUtil
				.convertJsonToObject(cbcf, FrequencyStatisticsResponse.class);
		RuleSet ruleSet = JSONUtil.convertJsonToObject(rule, RuleSet.class);
		List<RuleType> ruleList = ruleSet.getRule();
		for (RuleType ruleType : ruleList) {
			LARule laRule = RuleConverterUtil.from(ruleType);
			System.out.println(JSONUtil.convertObjectToJson(laRule));
			/*System.out.println(QueryGeneration.selectUserLastAction("cloudrec.sevendaysdata", "88052220", "Watch", RuleParserUtil.buildQueryFromRule(laRule,
					frequencyStatisticResponse), 0, 1));*/
		}
		Assert.assertEquals(LAMatchType.MatchType.from("OR"), MatchType.OR);
	}

}
