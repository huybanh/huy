package com.directv;

import java.io.IOException;

import org.junit.Test;

import com.directv.uds.model.rs.response.LastActionResponse;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.LastActionUtil;

public class LastActionUtilTest {
	@Test
	public void testNormalizeRule() throws IOException{
		String json = "{\"lastAction\":[{\"ruleName\":\"TestAutoLB25 06geMPeah1\",\"result\":[{\"tmsId\":\"EP017330700042\",\"title\":\"Sanjay and Craig\",\"eventTime\":\"20141125233000\"}]},{\"ruleName\":\"TestAutoLB25 9Y1K4ARgRv\",\"result\":[{\"tmsId\":\"EP017330700042\",\"title\":\"Sanjay and Craig\",\"eventTime\":\"20141125233000\"}]},{\"ruleName\":\"linhbui1\",\"result\":[{\"tmsId\":\"EP017330700042\",\"title\":\"Sanjay and Craig\",\"eventTime\":\"20141125233000\"}]},{\"ruleName\":\"tt_rec_1\",\"result\":[{\"tmsId\":\"EP009556790025\",\"title\":\"iCarly\",\"eventTime\":\"20141125223003\"}]}]}";
		LastActionResponse response = JSONUtil.convertJsonToObject(json, LastActionResponse.class);
		response = LastActionUtil.normalizeResponse(response);
		System.out.println(JSONUtil.convertObjectToJson(response));
	}
}
