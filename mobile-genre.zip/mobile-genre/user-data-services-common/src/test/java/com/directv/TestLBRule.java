/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.junit.Ignore;
import org.junit.Test;

import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.listbuilder.model.RuleType;
import com.directv.uds.utils.QueryGeneration;
import com.directv.uds.utils.RuleConverterUtil;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * <H3>TestRuleConverterUtil</H3>
 *
 * @author ThanhNN2
 * @since Oct 27, 2014
 */
public class TestLBRule {

	@Test
	@Ignore
	public void ruleParser() throws JAXBException, IOException {
		File file = new File("src/test/resources/larule.txt");

		ObjectMapper mapper = new ObjectMapper();
		RuleSet ruleSet = mapper.readValue(file, RuleSet.class);
				
		for (RuleType rule : ruleSet.getRule()) {
			LARule laRule = RuleConverterUtil.from(rule);
			//System.out.println(mapper.writeValueAsString(rule));
			//System.out.println(mapper.writeValueAsString(laRule));
			
			if (laRule != null){
				String userBehaviour = null; //RuleParserUtil.buildQueryFromRule(laRule, null);
				String query = QueryGeneration.selectUserLastAction("uvhTable", 30, "accountId", "eventtype", userBehaviour, 0, 1);
				System.out.println(mapper.writeValueAsString(laRule));
				System.out.println(mapper.writeValueAsString(query));
			}
		}
	}
}
