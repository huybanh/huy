package com.directv.uds.service;

import java.util.List;
import java.util.Map;

import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.directv.uds.dao.HistoryLogDAO;
import com.directv.uds.model.RecommendationJobHistory;

@Service
public class HistoryLogServiceImpl implements HistoryLogService {

	@Autowired
	private HistoryLogDAO historyLogDAO;

	@Override
	@Profiled
	public Map<String, List<RecommendationJobHistory>> getRecommendationJobHistory(String startTime, String endTime, boolean latest) {
		return historyLogDAO.getRecommendationJobHistory(startTime, endTime, latest);
	}

	/**
	 * @return the historyLogDAO
	 */
	public HistoryLogDAO getHistoryLogDAO() {
		return historyLogDAO;
	}

	/**
	 * @param historyLogDAO the historyLogDAO to set
	 */
	public void setHistoryLogDAO(HistoryLogDAO historyLogDAO) {
		this.historyLogDAO = historyLogDAO;
	}
	
	
}
