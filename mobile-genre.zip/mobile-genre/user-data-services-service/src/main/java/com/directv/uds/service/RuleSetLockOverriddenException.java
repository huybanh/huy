package com.directv.uds.service;

import com.directv.uds.exceptions.BaseRuntimeException;

public class RuleSetLockOverriddenException extends BaseRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6230414593782871667L;

	public RuleSetLockOverriddenException(String msg) {
		super("RulesetLock", msg);
	}

}
