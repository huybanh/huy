package com.directv.uds.service;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.IOUtils;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.dao.HBaseUtil;
import com.directv.uds.exceptions.InvalidFileSystemException;
import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.JSONUtil;

/**
 * RuleSetManager is single threaded (not thread-safe)
 * 
 * An instance of RuleSetManager is required for each thread.
 * 
 * Ruleset locking mechanism:
 * 
 * We have to use checkAndPut method to use for locking and unlocking.
	We will use hbase table for this.
	Rule file will be store in HDFS only
	here are the steps for locking
	1. initally value for lock key will be null/empty
	2. suppose Tomcat1 and Tomcat2 want to update rule then they will call checkAndPut ('null', IP of tomcat server) on hbase table
	3. CheckAndPut method follow ACID methodlogy. Only one call get access to check and Put at a time.
	4. Suppose Tomcat1 got access, so he will put his IP address as value in the Hbase table and return true and same time tomcat2 will get return value is false
	5. so Tomcat2 will continuesly call checkAndPut method in loop for max 2 min and if it is cross that 2 min time then it will override the value with tomcat2 IP and update the rule
	6. let assume tomcat1 got lock then he will update rule and delete the IP value i.e. insert null value, so that other tomcat get lock
	
	 the steps at different scenarios. This assumes that both lock and ruleset are in hbase:
		1/ scenario1: One tomcat
		a. Tomcat1 locks rulset by calling checkAndPut (lock=='null', lock:=tomcat1IP)
		b. Above checkAndPut() returns true, Tomcat1 got the lock
		c. Tomcat1 loads ruleset, does its task
		d. Tomcat1 completes task: checks lock and writes rules atomically, by calling checkAndPut(lock==tomcat1IP, ruleset:=newRuleset)
		e. Tomcat1 unlocks by calling checkAndPut(lock==tomcat1IP, null)
		
		2/ Scenario2: Two tomcats, both success
		a. Tomcat1 locks ruleset by calling checkAndPut (lock=='null', lock:=tomcat1IP)
		b. Above checkAndPut() returns true, Tomcat1 got the lock
		c. Tomcat2 also comes at the same time, but tomcat2 got false at its checkAndPut(lock==null, lock:=tomcat2IP).
		d. Tomcat2 enters its two-minute retry
		e. Tomcat1 loads ruleset, complete and unlock as scenario1
		f. Tomcat2 got the lock. It continues step remaining steps (c,d of scenario 1)
		
		3/ Scenario3: Two tomcats, tomcat1 get dead while having the lock
		a. Tomcat1 wants to update rule then it will call checkAndPut ('null', IP of tomcat1) on hbase table
		b. Above checkAndPut() returns true, Tomcat1 got the lock (Tomcat1's IP address is already in the lock)
		c. Tomcat2 also comes at the same time, but tomcat2 got false at its checkAndPut().
		d. Tomcat2 enters its two-minute retry
		e. Tomcat1 gets dead
		f. Tomcat2 crosses the retry-loop. It override the lock. Now tomcat2 got the lock. It continues step remaining steps (c,d of scenario 1)
		
		4/ Scenario4: Two tomcats, tomcat1 is too slow, both success
		a. Tomcat1 locks rulset by calling checkAndPut (lock=='null', lock:=tomcat1IP)
		b. Above checkAndPut() returns true, Tomcat1 got the lock
		c. Tomcat2 also comes at the same time, but tomcat2 got false at its checkAndPut().
		d. Tomcat2 enters its two-minute retry
		e. Tomcat1 gets slow
		f. Tomcat2 crosses the retry-loop. It overrides the lock. Now tomcat2 got the lock. It continues step remaining steps (c,d of scenario 1)
		g. Tomcat1 completes its task. It sees lock has been overridden -> fails itself and reports to user
		
	JIRA related ticket: http://10.23.144.131/jira/browse/CR-3847
 * 
 * @author HuyBA
 *
 */
class RuleSetManager {
	
	//private static final String RULE_FILE_PATH = "ruleFilePath";
	private static final String RULE_PATH = "lastaction.ruleset.hdfs";
	
	private static final String RULE_LOCK_TABLE = "lastaction.ruleset.lock.tablename";
	private static final String RULE_LOCK_ROW = "lastaction.ruleset.lock.key";
	private static final String RULE_LOCK_FAMILY = "lastaction.ruleset.lock.familyname";
	private static final String RULE_LOCK_QUALIFIER = "lastaction.ruleset.lock.qualifier";

	private static final String RULE_LOCK_CHECK_INTERVAL = "lastaction.ruleset.lock.check_interval";
	private static final String RULE_LOCK_OVERRIDE_THRESHOLD = "lastaction.ruleset.lock.override_threshold";
	
	private static final String DAILYSYNC_OVERLAPGUARD_QUALIFIER = "lastaction.dailysync.overlap_guard.qualifier";
	private static final String DAILYSYNC_OVERLAPGUARD_MINUTES = "lastaction.dailysync.overlap_guard.minutes";

	private static Logger LOGGER = LoggerFactory.getLogger(RuleSetManager.class);
	
	/**
	 * The ruleset data loaded from hdfs.
	 * If ruleset is not null:
	 * 
	 * 		- The ruleset is loaded into memory
	 * 		- The lock is already set with this ip/port of this instance.
	 * 			However, it's not certain if the lock is overridden by another instance.
	 */
	private RuleSet ruleset = null;
	private boolean lockPerformed = false;
	
	private Configuration config;
	
	private byte[] serverId;
	
	RuleSetManager(Configuration config, String serverLocation) {
		this.config = config;
		if (serverLocation != null) {
			this.serverId = serverLocation.getBytes();
		}
	}

	/**
	 * If ruleset is already loaded, return to caller
	 * If not:
	 * 		locks ruleset
	 * 		loads ruleset from hdfs
	 * 
	 * @return ruleset
	 */
	RuleSet getRuleSet() {
		if (ruleset != null) {
			return ruleset;
		}
		lock(config, serverId);
		lockPerformed = true;
		ruleset = load(config);
		return ruleset;
	}

	/**
	 * If ruleset is already loaded, return to caller
	 * If not:
	 * 		no locking
	 * 		loads ruleset from hdfs
	 * 
	 * @return ruleset
	 */
	RuleSet getRuleSetReadonly() {
		if (ruleset != null) {
			return ruleset;
		}
		
		//no locking & not keeping the loaded ruleset in this.ruleset
		return load(config);
	}
	
	/**
	 * Checks if ruleset is already loaded:
	 * 		If loaded: check if the lock is overridden -> ends with RuleSetLockOverriddenException 
	 * 		If not loaded: performs lock operation
	 * 
	 * Stores ruleData into hdfs
	 * 
	 * @param ruleSet
	 */
	void updateRuleSet(RuleSet newRuleSet) throws RuleSetLockOverriddenException {
		if (lockPerformed) {
			//check for overridding: may end here with RuleSetLockOverriddenException
			checkLockOverridding(config, serverId);
		} else {
			//lock ruleset: this is always success
			lock(config, serverId);
			lockPerformed = true;
		}
		
		//store to hdfs
		store(config, newRuleSet);
		
		//dispose the loaded ruleset, so that subsequent manipulation on the ruleset 
		//will cause the data re-loaded (for more changes from other processes)
		this.ruleset = null;
	}
	
	/**
	 * If we have not loaded the ruleset -> have not lock it -> nothing to do
	 * If we loaded ruleset -> do unlock
	 */
	void releaseRuleSet() {
		if (!lockPerformed) {
			//we haven't locked ruleset, nothing to do
			LOGGER.info("Ruleset-lock had not been performed, ignored unlocking request");
			return;
		}
		
		//we have locked the ruleset, do unlock now
		//unlock may do nothing, if the lock is overridden by another process
		unlock(config, serverId);
		lockPerformed = false;
	}
	
	/**
	 * @return true if the sync should be proceed
	 */
	boolean prepareDailySync() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
		boolean syncExecuted = isDailySyncExecuted(dateFormat);
		if (syncExecuted) {
			return false;
		}
		
		String timestamp = dateFormat.format(new Date());
		try {
			HBaseUtil.put(config.getString(RULE_LOCK_TABLE), config.getString(RULE_LOCK_ROW).getBytes(),
					config.getString(RULE_LOCK_FAMILY).getBytes(), config.getString(DAILYSYNC_OVERLAPGUARD_QUALIFIER).getBytes(), timestamp.getBytes());
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE);
		}
		return true;
	}
	
	private boolean isDailySyncExecuted(SimpleDateFormat dateFormat) {
		try {
			String lastSync = HBaseUtil.getHbaseValue(config.getString(RULE_LOCK_ROW), config.getString(RULE_LOCK_TABLE),
					config.getString(RULE_LOCK_FAMILY).getBytes(), config.getString(DAILYSYNC_OVERLAPGUARD_QUALIFIER).getBytes());
			if (lastSync == null || "".equals(lastSync)) {
				return false;
			}
			Date lastSyncTime;
			try {
				lastSyncTime = dateFormat.parse(lastSync);
			} catch (ParseException e) {
				LOGGER.error("Failed to parse ruleset last sync", e);
				//just return false so the sync job can start
				return false;
			}
			int overlapGuardMinutes = config.getInt(DAILYSYNC_OVERLAPGUARD_MINUTES);
			if (System.currentTimeMillis() - lastSyncTime.getTime() < 1000 * 60 * overlapGuardMinutes) {
				//not do the job if we have already started within 3 hours
				return true;
			}
			return false;
			
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE);
		}
	}
	
	/**
	 * Check if lock is open -> lock it
	 * If lock is already in used by another process -> entry retry loop
	 * At the end of retry loop, if the lock is still not available -> override the lock -> this lock() is always success
	 */
	private static void lock(Configuration config, byte[] myid) {
		
		int lockCheckIntervalMillis = config.getInt(RULE_LOCK_CHECK_INTERVAL, 200);
		int lockOverrideThresholdMillis = config.getInt(RULE_LOCK_OVERRIDE_THRESHOLD, 2000);
		long start = System.currentTimeMillis();
		boolean enteredRetry = false;
		while (true) {
			try {
				boolean gotLocked = HBaseUtil.checkAndPut(config.getString(RULE_LOCK_TABLE), config.getString(RULE_LOCK_ROW).getBytes(), 
						config.getString(RULE_LOCK_FAMILY).getBytes(), config.getString(RULE_LOCK_QUALIFIER).getBytes(), null, myid);
				if (gotLocked) {
					LOGGER.info("Ruleset is locked by {}", new String(myid));
					return;
				}
				if (!enteredRetry) {
					LOGGER.info("{}: Ruleset is already locked by another process. Waiting for the lock...", new String(myid));
					enteredRetry = true;
				}
				try {
					Thread.sleep(lockCheckIntervalMillis);
				} catch (InterruptedException e) {
					LOGGER.info("InterruptedException during lock checking");
				}
				
				if (System.currentTimeMillis() - start > lockOverrideThresholdMillis) {
					//crosses the threshold -> override locking
					HBaseUtil.put(config.getString(RULE_LOCK_TABLE), config.getString(RULE_LOCK_ROW).getBytes(), 
							config.getString(RULE_LOCK_FAMILY).getBytes(), config.getString(RULE_LOCK_QUALIFIER).getBytes(), myid);
					LOGGER.info("{}: Overridding ruleset-lock now", new String(myid));
					return;
				}
			} catch (IOException e) {
				throw new RemoteSystemException(SystemName.HBASE);
			}
		}
	}
	
	/**
	 * Checks if the lock is still valid. If not, the lock is already overridden by another process
	 * 
	 * @throws RuleSetLockOverriddenException if lock has been overridden by another process
	 */
	private static void checkLockOverridding(Configuration config, byte[] myid) throws RuleSetLockOverriddenException {
		
		try {
			boolean lockValid = HBaseUtil.checkAndPut(config.getString(RULE_LOCK_TABLE), config.getString(RULE_LOCK_ROW).getBytes(), 
					config.getString(RULE_LOCK_FAMILY).getBytes(), config.getString(RULE_LOCK_QUALIFIER).getBytes(), myid, myid);
			if (!lockValid) {
				//lock has been overridden by another process
				LOGGER.info("{}: Checking for ruleset-lock before updating: FAILURE: "
						+ "Ruleset-lock had been overridden by someone else", new String(myid));
				throw new RuleSetLockOverriddenException(new String(myid));
			}
			LOGGER.info("{}: Checking for ruleset-lock before updating: GOOD (not overridden by someone else)", new String(myid));
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE);
		}
	}
	
	/**
	 * Checks if the lock is still valid. If yes, unlock the ruleset by deleting the lock cell in hbase
	 * If not, the lock is already overridden by another process -> nothing to do, it's safe to ignore
	 * 
	 */
	private static void unlock(Configuration config, byte[] myid) {
		try {
			
			//discards returned result from HBaseUtil.checkAndDelete()
			if (HBaseUtil.checkAndDelete(config.getString(RULE_LOCK_TABLE), config.getString(RULE_LOCK_ROW).getBytes(), 
					config.getString(RULE_LOCK_FAMILY).getBytes(), config.getString(RULE_LOCK_QUALIFIER).getBytes(), myid)) {
				
				LOGGER.info("Ruleset is unlocked by {}", new String(myid));
			} else {
				LOGGER.info("{}: Can't delete ruleset-lock. Someone else had overriden the lock already. It is still safe to continue.", new String(myid));
			}
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE);
		}
	}
	
	/**
	 * Load rule data and parsing to objects
	 * This assumes that the lock is already obtained and valid
	 */
	private static RuleSet load(Configuration udsConfig) {
		org.apache.hadoop.conf.Configuration hdfsConfig = new org.apache.hadoop.conf.Configuration();
		FileSystem fs = null;
		FSDataInputStream inputStream = null;
		String ruleData;
        try {
    		fs = FileSystem.get(hdfsConfig);
    		String rulesetPath = udsConfig.getString(RULE_PATH);
	        Path ruleDataPath = new Path(rulesetPath);
	        if (!fs.exists(ruleDataPath)) {
	    		LOGGER.info("Ruleset file is not found at {}", rulesetPath);
	        	return null;
	        }
			inputStream = fs.open(ruleDataPath);
			ruleData = IOUtils.toString(inputStream);
			LOGGER.info("Ruleset is loaded from {}", rulesetPath);
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HDFS);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					throw new RemoteSystemException(SystemName.HDFS);
				}
			}
			if (fs != null) {
				try {
					fs.close();
				} catch (IOException e) {
					throw new RemoteSystemException(SystemName.HDFS);
				}
			}
		}
        
		return JSONUtil.convertJsonToObject(ruleData, RuleSet.class);
	}
	
	/**
	 * Store ruleData into hdfs path
	 * This assumes that the lock is already obtained and valid
	 * 
	 * @param ruleData
	 */
	private static void store(Configuration udsConfig, RuleSet newRuleSet) {

		String ruleData;
		try {
			ruleData = JSONUtil.convertObjectToJson(newRuleSet);
		} catch (IOException e) {
			throw new InvalidFileSystemException(e);
		}
		
		org.apache.hadoop.conf.Configuration hdfsConfig = new org.apache.hadoop.conf.Configuration();
		FileSystem fs = null;
		FSDataOutputStream outputStream = null;
        try {
    		fs = FileSystem.get(hdfsConfig);
	        Path ruleDataPath = new Path(udsConfig.getString(RULE_PATH));
			outputStream = fs.create(ruleDataPath, true/*overwrite*/);
			IOUtils.write(ruleData, outputStream);
			LOGGER.info("Ruleset is written to {}", ruleDataPath);
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HDFS);
		} finally {
			if (outputStream != null) {
				try {
					outputStream.close();
				} catch (IOException e) {
					throw new RemoteSystemException(SystemName.HDFS);
				}
			}
			if (fs != null) {
				try {
					fs.close();
				} catch (IOException e) {
					throw new RemoteSystemException(SystemName.HDFS);
				}
			}
		}
	}
}
