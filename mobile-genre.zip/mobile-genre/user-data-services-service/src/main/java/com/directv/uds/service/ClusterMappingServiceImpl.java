/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.perf4j.aop.Profiled;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.directv.uds.dao.AccountDAO;
import com.directv.uds.dao.EventDAO;
import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.model.Account;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.EventTime;
import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.model.LastAction;
@Service
public class ClusterMappingServiceImpl implements ClusterMappingService {

	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private EventDAO eventDAO;

	/**
	 * 
	 * @see com.directv.clustermapping.server.service.ClusterMappingService#getUserEncryptedId(java.lang.String)
	 */
	@Cacheable("AccountIdToEncryptedIdCache")
	@Profiled
	public String getUserEncryptedId(String userId) {
		String encryptedId = accountDAO.getEncryptedId(userId);
		return encryptedId;
	}

	/**
	 * 
	 * @see com.directv.clustermapping.server.service.ClusterMappingService#getUserDecryptedId(java.lang.String)
	 */
	@Cacheable("EncryptedIdToAccountIdCache")
	@Profiled
	public String getUserDecryptedId(String encryptedId) {
		String userId = accountDAO.getUserId(encryptedId);
		return userId;
	}

	/**
	 * 
	 * @see com.directv.clustermapping.server.service.ClusterMappingService#getAccountFromCardId(java.lang.String)
	 */
	@Profiled
	public Account getAccountFromCardId(String cardId) {
		return accountDAO.getAccountByCardId(cardId);
	}

	/**
	 * 
	 * @see com.directv.clustermapping.server.service.ClusterMappingService#getUsers(int,
	 *      int)
	 */
	@Profiled
	public List<String> getUsers(int offset, int limit) {
		return accountDAO.getUsers(offset, limit);
	}

	/**
	 * @see com.directv.clustermapping.server.service.ClusterMappingService#getUserRecommendation(java.lang.String,
	 *      java.lang.String, java.lang.String)
	 */
	@Profiled
	public Map<String, List<InterpretedEvent>> getUserViewingHistory(String userId, String mainCategory, int offset, int limit, boolean removeDuplicates, boolean isImpala, EventTime eventTime) {
		Map<String, List<InterpretedEvent>> results = null;

		results = eventDAO.getUserViewingHistoryImpala(userId, mainCategory, offset, limit, removeDuplicates, eventTime);

		return results;
	}

	/**
	 * @see com.directv.clustermapping.server.service.ClusterMappingService#getLastAction(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String, String)
	 */
	@Profiled
	public Map<String, Map<String, List<LastAction>>> getLastActionGeneric(String userID, String mainCategory, String eventType, boolean groupBySubCategory) {
		return eventDAO.getLastActionGeneric(userID, mainCategory, eventType, groupBySubCategory);
	}

	@Override
	@Cacheable("DmaCache")
	@Profiled
	public DMAInformation getRegionIdFromAccountId(String accountId) {
		DMAInformation dmaInformation = null;
		try {
			dmaInformation = accountDAO.getRegionIdFromAccountId(accountId);
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
		return dmaInformation;
	}

	/**
	 * @return the accountDAO
	 */
	public AccountDAO getAccountDAO() {
		return accountDAO;
	}

	/**
	 * @param accountDAO
	 *            the accountDAO to set
	 */
	public void setAccountDAO(AccountDAO accountDAO) {
		this.accountDAO = accountDAO;
	}

	/**
	 * @return the eventDAO
	 */
	public EventDAO getEventDAO() {
		return eventDAO;
	}

	/**
	 * @param eventDAO
	 *            the eventDAO to set
	 */
	public void setEventDAO(EventDAO eventDAO) {
		this.eventDAO = eventDAO;
	}

}
