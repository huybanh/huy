/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * CopyrightÂ© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.directv.uds.dao.FrequencyDAO;
import com.directv.uds.exceptions.InvalidFileSystemException;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.EnumManager.DayOfWeek;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.model.rs.response.UserTasteResponse;
import com.directv.uds.model.rs.response.WhatshotResponse;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.FrequencyElementUtil;

/**
 * 
 * <H3>FrequencyStatisticsServiceImpl</H3>
 * <html>
 * <p>Service implementation to achieve statistics data</p>
 * </html>
 * @author TuTX1
 * @since Jun 17, 2014
 */
@Service
public class FrequencyStatisticsServiceImpl implements FrequencyStatisticsService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(FrequencyStatisticsServiceImpl.class);
	
	@Autowired
	private FrequencyDAO freqDAO;
	
	@Autowired
	private Configuration config;

	/*@Override
	public FrequencyStatisticsResponse getFrequencyStatisticsResponse(
			Map<String, List<String>> cbcfValues, boolean percentage, int startIndex, int limit) {
		
		return buildFrequencyStatisticsResponse(cbcfValues, percentage, startIndex, limit,  
				UserDataConfiguration.MAIN_CATEGORIES.getValues(), UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET);
	}*/
	
	@Profiled
	@Override
	public FrequencyStatisticsResponse buildFrequencyStatisticsResponse(Map<String, List<String>> cbcfValues, 
			boolean percentage, int startIndex, int limit, String[] mainCategoryNames, Set<String> ignoredSubCategories) {
		
		LOGGER.debug("Build response: {} {} {} {} {} {}", cbcfValues, percentage, startIndex, limit, mainCategoryNames, ignoredSubCategories);
		if (cbcfValues == null) {
			return null;
		}
		
		FrequencyStatisticsResponse response = new FrequencyStatisticsResponse(mainCategoryNames);
		for (String mainCategory : cbcfValues.keySet()) {

			List<String> currentStringList = cbcfValues.get(mainCategory);
			if (currentStringList.size() == 0) {
				continue;
			}

			for (int i = 0; i < currentStringList.size(); i++) {

				if (currentStringList.get(i) == null) {
					continue;
				}

				FrequencyElement[] items;
				try {
					items = UserDataConfiguration.OBJECT_MAPPER.readValue(currentStringList.get(i), FrequencyElement[].class);
				} catch (IOException e) {
					throw new InvalidFileSystemException(e);
				}
				if (items == null) {
					continue;
				}
				
				// remove ignored sub category
				//Set<String> ignoredSubCategories = UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET;
				List<FrequencyElement> vector;
				if (ignoredSubCategories == null) {
					vector = Arrays.asList(items);
				} else {
					vector = FrequencyElementUtil.removeIgnoredSubCategory(ignoredSubCategories, items);
				}
				int size = vector.size();
				if (size <= 0) {
					continue;
				}
				
				if (startIndex > 0 && startIndex <= size) {
					vector = vector.subList(startIndex, size);
				}
				if (limit > 0 && limit < size) {
					vector = vector.subList(0, limit);
				}

				size = vector.size();
				// size = size - UserDataConfiguration.MAIN_CATEGORIES.length;
				if (limit > 0 && limit < size) {
					vector = vector.subList(0, limit);
				}
				
				if (percentage) {
					vector = FrequencyElementUtil.convertToPercentage(vector);
				}

				response.add(mainCategory, DayOfWeek.fromValue(i), vector);
			}
		}
		LOGGER.debug("Build response: {}", response);
		return response;
	}

	/**
	 * 
	 * @throws IOException 
	 * @see com.directv.clustermapping.server.service.FrequencyStatisticsService#getFullFrequencyVector(java.lang.String,
	 *      boolean, java.lang.String, int)
	 */
	@Override
	@Profiled
	public FrequencyStatisticsResponse getFullFrequencyVector(String userId, final boolean groupByWeekday, String mainCategory, String genreAttributeName, int limit, String timeWindow) {

		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, groupByWeekday, genreAttributeName, mainCategory, timeWindow);
		if (cbcfValues == null) {
			return null;
		}

		boolean percentage = false;
		String[] targetMainCategories;
		if (mainCategory == null) {
			targetMainCategories = UserDataConfiguration.MAIN_CATEGORIES.getValues();
		} else {
			targetMainCategories = new String[] {mainCategory};
		}
		FrequencyStatisticsResponse response = buildFrequencyStatisticsResponse(
				cbcfValues, percentage, 0, limit, targetMainCategories, UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET);
		response.setQuery(percentage, groupByWeekday, limit, timeWindow);
		return response;
	}

	/**
	 * 
	 * @throws IOException 
	 * @see com.directv.clustermapping.server.service.FrequencyStatisticsService#getMainCategoryFrequencyVector(String,
	 *      java.lang.String, boolean, boolean, java.lang.String, int)
	 */
	@Override
	@Profiled
	public FrequencyStatisticsResponse getMainCategoryFrequencyVector(/*String query,*/ String userId, boolean percentage, final boolean groupByWeekday, String mainCategory, String timeWindow, String genreAttributeName) {

		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, groupByWeekday, genreAttributeName, mainCategory, timeWindow);

		int limit = UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1;
		FrequencyStatisticsResponse response = buildFrequencyStatisticsResponse(
				cbcfValues, percentage, 0, limit, UserDataConfiguration.MAIN_CATEGORIES.getValues(), UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET);
		response.setQuery(percentage, groupByWeekday, limit, timeWindow);
		return response;
	}

	/**
	 * 
	 * @throws IOException 
	 * @see com.directv.clustermapping.server.service.FrequencyStatisticsService#getSubCategoryFrequencyVector(java.lang.String,
	 *      java.lang.String, boolean, boolean, java.lang.String, int, String,
	 *      String)
	 */
	@Override
	@Profiled
	public FrequencyStatisticsResponse getSubCategoryFrequencyVector(
			String userId, boolean percentage, final boolean groupByWeekday, String mainCategory, int limit, String timeWindow, String genreAttributeName) {

		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, groupByWeekday, genreAttributeName, mainCategory, timeWindow);
		if (cbcfValues == null) {
			return null;
		}

		int startIndex;
		if (config.getString(GENRE_TYPE_DTV).equals(genreAttributeName)) {
			//ignore 4 first data entries: They are for main categories, not sub categories
			//int startIndex = UserDataConfiguration.MAIN_CATEGORIES.getSize();
			
			//ignore 3 first data entries: They are for main categories, not sub categories
			startIndex = UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1;
		} else {
			startIndex = 0;
		}
		
		FrequencyStatisticsResponse response = buildFrequencyStatisticsResponse(cbcfValues, percentage, 
				startIndex, limit, UserDataConfiguration.MAIN_CATEGORIES.getValues(), UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET);
		response.setQuery(percentage, groupByWeekday, limit, timeWindow);
		return response;
	}

	@Override
	@Profiled
	public FrequencyStatisticsResponse getOtherSubCategoryFrequencyVector(String userId, boolean percentage, final boolean groupByWeekday, 
			String attributeName, String mainCategory, int limit, String timeWindow) {

		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, groupByWeekday, attributeName, mainCategory, timeWindow);
		if (cbcfValues == null) {
			return null;
		}

		FrequencyStatisticsResponse response = buildFrequencyStatisticsResponse(cbcfValues, percentage, 0, limit, null, null);
		response.setQuery(percentage, groupByWeekday, limit, timeWindow);
		return response;
	}

	/**
	 * 
	 * @throws IOException
	 * @see com.directv.clustermapping.server.service.FrequencyStatisticsService#getWhatIsHot(java.lang.String)
	 */
	@Override
	@Profiled
	public WhatshotResponse getWhatIsHot(String timeWindow, DMAInformation dmaInformation, int limit, String mainCategory) {

		return freqDAO.getWhatIsHot(timeWindow, dmaInformation, limit, mainCategory);
	}

	/**
	 * @see com.directv.clustermapping.server.service.FrequencyStatisticsService#getCbcfByDayVector(java.lang.String,
	 *      java.lang.String, boolean, java.lang.String, int, String)
	 */
	@Override
	@Profiled
	public Map<String, List<FrequencyElement>> getCbcfByDayVector(String rawUserId, boolean percentageBool, String attribute, String dateString, int limit) {

		int start = 0;
		if (attribute.equals(UserDataConfiguration.GENRE_ATTRIBUTE)){
			start = UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1;
		}
		return freqDAO.getCbcfByDayVector(rawUserId, dateString, percentageBool, attribute, start, limit);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.directv.clustermapping.server.service.FrequencyStatisticsService#
	 * getUserTaste(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	@Profiled
	public UserTasteResponse getUserTaste(String userId, String mainCategory, int limit, String genreAttributeName) {
		
		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, false, genreAttributeName, mainCategory, null);
		//HashMap<String, Map<DayOfWeek, List<FrequencyElement>>> userFrequencyStatistics = 
			//getFrequencyStatisticMap(cbcfValues, false, UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1, limit);
		
		//ignore 3 first data entries: They are for main categories, not genres
		int startIndex;
		if (config.getString(GENRE_TYPE_DTV).equals(genreAttributeName)) {
			startIndex = UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1;
		} else {
			startIndex = 0;
		}
		
		FrequencyStatisticsResponse stats = buildFrequencyStatisticsResponse(
				cbcfValues, false, startIndex, -1/*limit*/, UserDataConfiguration.MAIN_CATEGORIES.getValues(), UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET);
		if (stats == null) {
			return null;
		}
		HashMap<String, Map<DayOfWeek, List<FrequencyElement>>> userFrequencyStatistics = stats.getFrequencyVectorList();
		if (userFrequencyStatistics == null) {
			return null;
		}

		// if main category is specified, return the vector for this main category
		UserTasteResponse response = new UserTasteResponse();
		if (mainCategory != null) {
			List<FrequencyElement> frequencyElements = userFrequencyStatistics.get(mainCategory).get(DayOfWeek.Alldays);
			if (frequencyElements != null && !frequencyElements.isEmpty()) {
				if (limit > -1 && frequencyElements.size() > limit) {
					frequencyElements = frequencyElements.subList(0, limit);
				}
				response.getUserTaste().put(mainCategory, frequencyElements);
				return response;
			}
			
			/*//take common user taste as response
			response.setUserTaste(freqDAO.getCommonUserTaste(new String[] { mainCategory }, limit));
			return response;*/
		}

		// main category is NOT specified, return the vectors of all categories
		//List<String> empties = new ArrayList<String>();
		for (String key : userFrequencyStatistics.keySet()) {
			List<FrequencyElement> frequencyElements = userFrequencyStatistics.get(key).get(DayOfWeek.Alldays);
			/*if (frequencyElements == null || frequencyElements.isEmpty()) {
				empties.add(key);
				continue;
			}*/
			if (limit > -1 && frequencyElements.size() > limit) {
				frequencyElements = frequencyElements.subList(0, limit);
			}
			response.getUserTaste().put(key, frequencyElements);
		}

		/*if (!empties.isEmpty()) {
			Map<String, List<FrequencyElement>> topGenres = freqDAO.getCommonUserTaste(empties.toArray(new String[0]), limit);
			for (String empty : empties) {
				response.getUserTaste().put(empty, topGenres.get(empty));
			}
		}*/
		return response;
	}
	
	/*@Override
	@Profiled
	public UserTasteResponse getCommonUserTaste(int limit) {
		UserTasteResponse response = new UserTasteResponse();
			Map<String, List<FrequencyElement>> topGenres = freqDAO.getCommonUserTaste(null, limit);
			
			response.getUserTaste().putAll(topGenres);
			
		
		return response;
	}
*/
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.directv.clustermapping.server.service.FrequencyStatisticsService#
	 * getUserTaste(java.lang.String, java.lang.String, java.lang.String)
	 */
	/*public UserTasteResponse getUserTaste(String userId, String[] mainCategories, String serviceName, int limit) throws IOException {
		
		//CR-2819: This call to getFrequencyVector() is not neccessarily, as the returned value is not being used.
		//The check of frequencyStatisticsResponse == null is also not needed. frequencyStatisticsResponse goes null ONLY in case of
		//wrong mapping configuration. We would rather get InternalError in this case, than an incorrect DATA_NOT_FOUND message.
		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, false, UserDataConfiguration.GENRE_ATTRIBUTE, null, null, serviceName);
		FrequencyStatisticsResponse frequencyStatisticsResponse = getFrequencyStatisticsResponse(cbcfValues, "", false, UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1, limit, false);
		if (frequencyStatisticsResponse == null) {
			return null;
		}
		
		UserTasteResponse response = new UserTasteResponse();
		response.setUserTaste(freqDAO.getCommonUserTaste(userId, mainCategories));
		return response;
		
		if(isEmptyFrequencyStatisticsResponse(frequencyStatisticsResponse)){
			response.setUserTaste(freqDAO.getCommonUserTaste(userId, mainCategories));
		} else{
		
			Map<String, Map<DayOfWeek, List<FrequencyElement>>> responseMapWithMainCategoryKey = frequencyStatisticsResponse.getFrequencyVectorList();
			// if main category is specified, return the vector for this main category
			//if not, return the vectors of all categories
			if (mainCategories != null){
				for (String mainCategory : mainCategories) {
					List<FrequencyElement> frequencyElements = responseMapWithMainCategoryKey.get(mainCategory).get(DayOfWeek.Alldays);
					response.getUserTaste().put(mainCategory, frequencyElements);
				}
				
			} else {
				for (String key: responseMapWithMainCategoryKey.keySet()){
					List<FrequencyElement> frequencyElements = responseMapWithMainCategoryKey.get(key).get(DayOfWeek.Alldays);
					response.getUserTaste().put(key, frequencyElements);
				}
			}
		}
		
		return response;
	}*/
	
	/*@Override
	public Map<String, List<FrequencyElement>> getUserTaste(String userId, String[] mainCategories, String serviceName, int limit) {
		if(mainCategories==null){
			mainCategories = new String[]{ UserDataConfiguration.MAIN_CATEGORIES.getLast()};
		}
		Map<String, List<FrequencyElement>> response = new HashMap<String, List<FrequencyElement>>();

		Map<String, List<String>> cbcfValues = freqDAO.getFrequencyVector(userId, false, UserDataConfiguration.GENRE_ATTRIBUTE, mainCategory, null, serviceName);

		FrequencyStatisticsResponse frequencyStatisticsResponse = getFrequencyStatisticsResponse(cbcfValues, "", false, UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1, limit, false);
		if (frequencyStatisticsResponse == null) {
			return null;
		}

		Map<String, Map<DayOfWeek, List<FrequencyElement>>> responseMapWithMainCategoryKey = frequencyStatisticsResponse.getFrequencyVectorList();
		List<FrequencyElement> frequencyElements = responseMapWithMainCategoryKey.get(mainCategory).get(DayOfWeek.Alldays);
		response.put(Hardcoded.USER_TASTE_LABLE, frequencyElements);

		return response;
	}*/
	
	/*private boolean isEmptyFrequencyStatisticsResponse(
			FrequencyStatisticsResponse frequencyStatisticsResponse) {
		List<Boolean> checkList = new ArrayList<Boolean>();
		boolean result = true;
		boolean isEmpty = true;
		for (String mainCategory : UserDataConfiguration.MAIN_CATEGORIES.getValues()) {
			List<FrequencyElement>  frequencyElementList = frequencyStatisticsResponse.getFrequencyVectorList().get(mainCategory).get(DayOfWeek.Alldays);
			if(frequencyElementList==null || frequencyElementList.isEmpty()){
				checkList.add(isEmpty);
			}
		}
		for (Boolean flag : checkList) {
			result = result && flag;
		}
		return result;
	}*/
	
	/**
	 * @return the freqDAO
	 */
	public FrequencyDAO getFreqDAO() {
		return freqDAO;
	}

	/**
	 * @param freqDAO
	 *            the freqDAO to set
	 */
	public void setFreqDAO(FrequencyDAO freqDAO) {
		this.freqDAO = freqDAO;
	}
}