package com.directv.uds.service;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;

import org.apache.oozie.client.AuthOozieClient;
import org.apache.oozie.client.OozieClientException;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.directv.uds.dao.FrequencyDAO;
import com.directv.uds.dao.UserActivityDAO;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.exceptions.InvalidFileSystemException;
import com.directv.uds.listbuilder.model.ListBuilderDeltaListing;
import com.directv.uds.listbuilder.model.ListBuilderFullListing;
import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.listbuilder.model.RuleType;
import com.directv.uds.model.CreditResponse;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.EnumManager.DayOfWeek;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.directv.uds.model.LocationInformation;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.model.rs.getRule.request.LastActionRuleDataRequest;
import com.directv.uds.model.rs.getRule.request.UserTasteRuleDataRequest;
import com.directv.uds.model.rs.getRule.request.WhatsHotRuleDataRequest;
import com.directv.uds.model.rs.getRule.response.CreditDataResponse;
import com.directv.uds.model.rs.getRule.response.CreditDataResult;
import com.directv.uds.model.rs.getRule.response.UserTasteDataResult;
import com.directv.uds.model.rs.getRule.response.WhatsHotDataResult;
import com.directv.uds.model.rs.request.UdsRulePayload;
import com.directv.uds.model.rs.response.LastActionElement;
import com.directv.uds.model.rs.response.LastActionResponse;
import com.directv.uds.model.rs.response.LastActionResult;
import com.directv.uds.model.rs.response.PreviewResponse;
import com.directv.uds.model.rs.response.PreviewResult;
import com.directv.uds.model.rs.response.WhatshotResponse;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.RuleConverterUtil;
import com.dtv.lastaction.listbuilderintegration.dto.LAFilterType;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;
import com.dtv.lastaction.listbuilderintegration.dto.LARuleType;
import com.dtv.lastaction.listbuilderintegration.dto.LAStatementType;
//import com.directv.uds.model.rs.getRule.request.RuleDataRequest;
//import com.directv.uds.model.rs.getRule.response.RuleDataResponse;
//import com.directv.uds.utils.LastActionUtil;

@Service
public class ListBuilderIntegrationServiceImpl implements ListBuilderIntegrationService {

	//private static final String RULE_FILE_PATH = "ruleFilePath";
	private static final String HBASE_DATE_TIME_FORMAT_PROPERTY = "hbaseDateTimeFormat";
	private static final String CREDIT_TIME_WINDOW = "creditTimeWindow";
	private static final String CREDIT_DAY_OF_WEEK = "creditDayOfWeek";
	private static final String CREDIT_MAIN_CATEGORY = "creditMainCategory";
	private static final int GET_TOP = 0;

	private static Logger LOGGER = LoggerFactory.getLogger(ListBuilderIntegrationServiceImpl.class);

	@Autowired
	private UserActivityDAO listBuilderIntegrationDAO;
	@Autowired
	private FrequencyDAO frequencyDAO;
	@Autowired
	private FrequencyStatisticsService frequencyService;

	@Autowired
	private Configuration config;

	private final String OOZIE_URL_KEY = "oozie.url";
	private final String OOZIE_LIBPATH_KEY = "oozie.libpath";
	private final String OOZIE_APPLICATION_PATH_KEY = "oozie.wf.application.path";
	private final String OOZIE_LASTACTION_PUBLISH_PATH = "oozie.wf.lastactionpublish.path";
	private final String OOZIE_LASTACTION_DAILYSYNC_PATH = "oozie.wf.lastactiondailysync.path";
	private final String OOZIE_USE_LIBPATH_KEY = "oozie.use.system.libpath";
	private final String QUEUE_NAME_KEY = "queueName";
	private final String QUEUE_JOB_TRACKER_KEY = "jobTracker";
	private final String NAME_NODE_KEY = "nameNode";
	private final String OOZIE_REC_COMMON_JAR_KEY = "recommendationscommonsJar";
	private final String OOZIE_ANALYTICS_UDF_KEY = "analyticsUDF";

	@Override
	@Profiled
	public PreviewResponse getRuleResponse(RuleSet rules, String accountId) throws BadRequestException {
		PreviewResponse udsPreviewRules = new PreviewResponse();
		List<RuleType> ruleList = rules.getRule();
		List<PreviewResult> preview = new ArrayList<PreviewResult>();
		for (RuleType rule : ruleList) {
			LARule laRule = RuleConverterUtil.from(rule);

			if (laRule == null) {
				continue;
			}

			// LOG.info(laRule.getRuleName()+"="+JSONUtil.convertObjectToJson(laRule));
			LARuleType ruleType = laRule.getRuleType();

			if (ruleType == LARuleType.GENERIC) {
				// throw new
				// BadRequestException("Doesn't support for previewing of Generic rule type!");
			} else if (ruleType == LARuleType.WHATSHOT || ruleType == LARuleType.LIST_BUILDER) {
				// TODO 1. Find user region first if region = true 2.
				// Retrieve WIH based on region parameter.
				// result = getWhatsHotRuleResponse(null);
			} else if (ruleType == LARuleType.CREDIT) {
				LARule creditRule = RuleConverterUtil.from(rule);
				boolean getCredit = false;
				// false - due do not apply only for preview
				CreditDataResult[] creditDataResult = getCreditDataResult(accountId, creditRule, getCredit, null, null);
				// CreditDataResult[] creditDataResult = null;
				if (creditDataResult != null) {
					PreviewResult previewResult = new PreviewResult();
					previewResult.setResultCredit(Arrays.asList(creditDataResult));
					previewResult.setRuleName(creditRule.getRuleName());

					preview.add(previewResult);
				} else {
					LOGGER.error("{} rules not found", creditRule.getRuleName());
				}

			} else {
				try {
					udsPreviewRules.getPreview().add(getLastActionRuleResponse(laRule, config.getString(SEVEN_DAYS_DATA_IMPALA), accountId, 0, 1));
				} catch (IOException e) {
					throw new InvalidFileSystemException(e);
				}
			}
		}

		// check preview of CREDIT
		if (preview.size() > 0) {
			udsPreviewRules.setPreview(preview);
		}
		return udsPreviewRules;
	}

	private PreviewResult getLastActionRuleResponse(LARule lastActionRule, String uvhTable, String accountId, int offset, int limit) throws IOException {
		// String jsonResult = null;
		PreviewResult result = new PreviewResult();
		List<LastActionElement> lastAction = listBuilderIntegrationDAO.getLastAction(lastActionRule, uvhTable, accountId, offset, limit);
		result.setRuleName(lastActionRule.getRuleName());
		String json = JSONUtil.convertObjectToJson(lastAction);
		lastAction = Arrays.asList(JSONUtil.convertJsonToObject(json, LastActionElement[].class));
		result.setResultLastAction(lastAction);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.directv.uds.service.ListBuilderIntegrationService#getLastActionByRule
	 * (java.lang.String, com.directv.uds.model.rs.response.UdsRulePayload[])
	 */
	@Override
	@Profiled
	public LastActionResponse getLastActionByRule(String accountId, UdsRulePayload[] ruleNames) {
		List<String> colList = new ArrayList<String>();
		for (UdsRulePayload ruleName : ruleNames) {
			colList.add(ruleName.getRuleName().trim());
		}
		String[] columnQualifiers = colList.toArray(new String[0]);

		LastActionResponse lastActions = listBuilderIntegrationDAO.getLastActionByRule(accountId, columnQualifiers);
		lastActions.consolidateTmsIdAndConnectorId();
		return lastActions;
	}

	// Need to implement for releasing next week
	/*
	 * private String getWhatsHotRuleResponse(LARule whatsHotRule) { return
	 * null; }
	 */

	@Profiled
	public String processFullPayLoad(ListBuilderFullListing fullPayLoad, String serverLocation) {

		RuleSetManager ruleManager = null;
		try {
			RuleSet ruleSet = fullPayLoad.getRuleSet();
			ruleManager = new RuleSetManager(config, serverLocation);
			ruleManager.updateRuleSet(ruleSet);
			/*String ruleSetString = JSONUtil.convertObjectToJson(ruleSet);
	
			try {
				IOUtil.write(config.getString(RULE_FILE_PATH), ruleSetString);
			} catch (IOException e) {
				throw new InvalidFileSystemException(e);
			}*/
	
			return null;
		} finally {
			if (ruleManager != null) {
				ruleManager.releaseRuleSet();
			}
		}
	}

	@Override
	@Profiled
	public List<LARule> processDeltaPayLoad(ListBuilderDeltaListing deltaLoad, String serverLocation) {

		RuleSetManager ruleManager = null;
		try {
			ruleManager = new RuleSetManager(config, serverLocation);
			return processDeltaPayLoad(deltaLoad, ruleManager);
		} finally {
			if (ruleManager != null) {
				ruleManager.releaseRuleSet();
			}
		}
	}
	
	private List<LARule> processDeltaPayLoad(ListBuilderDeltaListing deltaLoad, RuleSetManager ruleManager) {

		RuleSet deltaRuleSet = deltaLoad.getRuleSet();
		//RuleSet fullRuleSet = IOUtil.read(config.getString(RULE_FILE_PATH), RuleSet.class);
		RuleSet fullRuleSet = ruleManager.getRuleSet();
		if (fullRuleSet == null) {
			fullRuleSet = new RuleSet();
		}

		// Loop through the list of provided rules:
		// - If a new rule found -> add to the new list
		// - If an existing rule found -> replace existing rule
		List<RuleType> newRuleList = new ArrayList<RuleType>();
		if (deltaRuleSet != null && deltaRuleSet.getRule() != null) {

			for (RuleType delta : deltaRuleSet.getRule()) {
				String deltaRuleName = delta.getRuleName();
				boolean isFound = false;
				// Traverse through full rule set to modify delta rule
				for (int count = 0; count < fullRuleSet.getRule().size(); count++) {
					String ruleName = fullRuleSet.getRule().get(count).getRuleName();
					// Check if rule need to be modified
					if (ruleName.equals(deltaRuleName)) {
						isFound = true;
						fullRuleSet.getRule().set(count, delta);
						break;
					}
				}
				if (isFound == false) {
					newRuleList.add(delta);
				}
			}
		}
		fullRuleSet.getRule().addAll(newRuleList);

		// Loop through the list of removing rules: remove it from the rule
		// store
		List<String> removeRuleNames = deltaLoad.getRemoveRuleName();
		if (removeRuleNames != null & !removeRuleNames.isEmpty()) {
			Iterator<RuleType> it = fullRuleSet.getRule().iterator();
			while (it.hasNext()) {
				String ruleName = it.next().getRuleName();
				if (removeRuleNames.contains(ruleName)) {
					it.remove();
				}
			}
		}

		/*try {
			IOUtil.write(config.getString(RULE_FILE_PATH), JSONUtil.convertObjectToJson(fullRuleSet));
		} catch (IOException e) {
			throw new InvalidFileSystemException(e);
		}*/
		ruleManager.updateRuleSet(fullRuleSet);

		List<LARule> deltaRuleMapping = null;
		if (deltaRuleSet == null || deltaRuleSet.getRule() == null || deltaRuleSet.getRule().isEmpty()) {
			deltaRuleMapping = new ArrayList<LARule>();
		} else {
			// new rule set
			deltaRuleMapping = RuleConverterUtil.from(deltaRuleSet.getRule());
		}
		return deltaRuleMapping;
	}

	@Override
	@Profiled
	public List<String> processOozieJob(List<LARule> rules, boolean isPublishJob) {
		AuthOozieClient wc = new AuthOozieClient(config.getString(OOZIE_URL_KEY));
		wc.setDebugMode(1);
		List<String> jobIds = new ArrayList<String>();
		Properties conf = wc.createConfiguration();
		conf.setProperty(OOZIE_LIBPATH_KEY, config.getString(OOZIE_LIBPATH_KEY));
		conf.setProperty(OOZIE_USE_LIBPATH_KEY, config.getString(OOZIE_USE_LIBPATH_KEY));
		conf.setProperty(QUEUE_NAME_KEY, config.getString(QUEUE_NAME_KEY));
		conf.setProperty(QUEUE_JOB_TRACKER_KEY, config.getString(QUEUE_JOB_TRACKER_KEY));
		conf.setProperty(NAME_NODE_KEY, config.getString(NAME_NODE_KEY));
		conf.setProperty(OOZIE_ANALYTICS_UDF_KEY, config.getString(OOZIE_ANALYTICS_UDF_KEY));
		conf.setProperty(OOZIE_REC_COMMON_JAR_KEY, config.getString(OOZIE_REC_COMMON_JAR_KEY));

		// for (LARule larule : rules) {

		String param;
		try {
			param = JSONUtil.convertObjectToJson(rules);
		} catch (IOException e1) {
			throw new InvalidFileSystemException(e1);
		}
		if (isPublishJob) {
			conf.setProperty(OOZIE_APPLICATION_PATH_KEY, config.getString(OOZIE_LASTACTION_PUBLISH_PATH));
		} else {
			conf.setProperty(OOZIE_APPLICATION_PATH_KEY, config.getString(OOZIE_LASTACTION_DAILYSYNC_PATH));
		}
		conf.setProperty("rule", param);
		conf.setProperty("batchnumber", parseCurrentDate(config.getString(HBASE_DATE_TIME_FORMAT_PROPERTY)));
		String jobId = null;
		try {
			jobId = wc.run(conf);
			LOGGER.info("Workflow job submitted");
			LOGGER.info(wc.getJobInfo(jobId).toString());
			jobIds.add(jobId);

		} catch (OozieClientException e) {
			LOGGER.error("Error while submitting oozie job", e);
		}

		// }
		return jobIds;
	}

	/**
	 * @param userTasteRequest
	 * @throws IOException
	 */
	@Profiled
	private List<UserTasteDataResult> getUserTasteResponse(List<UserTasteRuleDataRequest> userTasteRequest, String accountId)
			throws IOException {
		List<UserTasteDataResult> userTasteResponses = new ArrayList<UserTasteDataResult>();
		UserTasteDataResult userTasteResponse = null;
		for (UserTasteRuleDataRequest userTasteRuleDataRequest : userTasteRequest) {
			Map<String, List<String>> cbcfValues = frequencyDAO.getFrequencyVector(
					accountId, false, UserDataConfiguration.GENRE_ATTRIBUTE, userTasteRuleDataRequest.getMainCategory(), null);
			FrequencyStatisticsResponse frequencyStatisticsResponse = frequencyService.buildFrequencyStatisticsResponse(cbcfValues, false,
					UserDataConfiguration.MAIN_CATEGORIES.getSize() - 1, -1, UserDataConfiguration.MAIN_CATEGORIES.getValues(), UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET);
			if (frequencyStatisticsResponse == null) {
				return null;
			}

			Map<String, Map<DayOfWeek, List<FrequencyElement>>> responseMapWithMainCategoryKey = frequencyStatisticsResponse.getFrequencyVectorList();
			List<FrequencyElement> frequencyElements = responseMapWithMainCategoryKey.get(userTasteRuleDataRequest.getMainCategory()).get(DayOfWeek.Alldays);
			userTasteResponse = new UserTasteDataResult();
			userTasteResponse.setMainCategory(userTasteRuleDataRequest.getMainCategory());
			userTasteResponse.setUserTaste(frequencyElements);
			userTasteResponses.add(userTasteResponse);

		}
		return userTasteResponses;
	}

	/**
	 * @param whatshotRequest
	 * @return
	 * @throws IOException
	 */
	@Profiled
	private List<WhatsHotDataResult> getWhatsHotResponse(List<WhatsHotRuleDataRequest> whatshotRequest, DMAInformation dmaInformation)
			throws IOException {
		List<WhatsHotDataResult> whatsHotResponses = new ArrayList<WhatsHotDataResult>();
		WhatshotResponse whatIsHot = null;
		WhatsHotDataResult whatsHotResponse = null;
		if (whatshotRequest != null && whatshotRequest.size() > 0) {
			for (WhatsHotRuleDataRequest whatsHotRuleDataRequest : whatshotRequest) {
				if (whatsHotRuleDataRequest.isRegion()) {
					whatIsHot = frequencyDAO.getWhatIsHot(null, dmaInformation, 10, null);
				} else {
					whatIsHot = frequencyDAO.getWhatIsHot(null, null, 10, null);

				}
				if (whatIsHot != null) {
					whatsHotResponse = new WhatsHotDataResult();
					whatsHotResponse.setRuleName(whatsHotRuleDataRequest.getRuleName());
					whatsHotResponse.setWhatshot(whatIsHot.getWhatshot());
					whatsHotResponse.setDmaCode(dmaInformation.getDma());
					whatsHotResponse.setDmaDescription(dmaInformation.getDmaDescription());
					whatsHotResponses.add(whatsHotResponse);
				}
			}

		}
		return whatsHotResponses;

	}

	/**
	 * @param lastActionRequest
	 * @return
	 * @throws IOException
	 */
	@Profiled
	private List<LastActionResult> getLastActionResponse(String accountId, List<LastActionRuleDataRequest> lastActionRequest)
			throws IOException {
		LastActionResponse udsLastActions = new LastActionResponse();
		String[] columnQualifiers = null;
		List<String> colList = new ArrayList<String>();
		if (lastActionRequest != null && lastActionRequest.size() > 0) {
			for (LastActionRuleDataRequest laRuleDataRequest : lastActionRequest) {
				colList.add(laRuleDataRequest.getRuleName());
			}

			columnQualifiers = colList.toArray(new String[0]);
			udsLastActions = listBuilderIntegrationDAO.getLastActionByRule(accountId, columnQualifiers);
		}
		return udsLastActions.getLastAction();
	}

	/*@Override
	public String publishRule(RuleSet ruleSet) {
		return null;
	}*/

	/**
	 * @return the listBuilderIntegrationDAO
	 */
	public UserActivityDAO getListBuilderIntegrationDAO() {
		return listBuilderIntegrationDAO;
	}

	/**
	 * @param listBuilderIntegrationDAO
	 *            the listBuilderIntegrationDAO to set
	 */
	public void setListBuilderIntegrationDAO(UserActivityDAO listBuilderIntegrationDAO) {
		this.listBuilderIntegrationDAO = listBuilderIntegrationDAO;
	}

	@Profiled
	private List<LARule> prepareDailySync(String serverLocation) {
		/*RuleSet fullRuleSet = IOUtil.read(
				Configuration.getInstance().getString(RULE_FILE_PATH, "/home/d458737/dev_tomcat3/rule"), RuleSet.class);*/
		
		RuleSetManager ruleManager = null;
		try {
			ruleManager = new RuleSetManager(config, serverLocation);
			RuleSet fullRuleSet = ruleManager.getRuleSet();
			
			//got the ruleset, it is locked for processing already
			//now check its lastsync
			if (!ruleManager.prepareDailySync()) {
				return null;
			}
			
			List<LARule> ruleMapping = null;
			if (fullRuleSet != null) {
				ruleMapping = RuleConverterUtil.from(fullRuleSet.getRule());
			} else {
				ruleMapping = new ArrayList<LARule>();
			}
			return ruleMapping;
		} finally {
			if (ruleManager != null) {
				ruleManager.releaseRuleSet();
			}
		}
	}

	@Override
	public List<LARule> listRules() {
		
		/*RuleSet fullRuleSet = IOUtil.read(
				Configuration.getInstance().getString(RULE_FILE_PATH, "/home/d458737/dev_tomcat3/rule"), RuleSet.class);*/
		RuleSet fullRuleSet = new RuleSetManager(config, null).getRuleSetReadonly();
		
		List<LARule> ruleMapping = null;
		if (fullRuleSet != null) {
			ruleMapping = RuleConverterUtil.from(fullRuleSet.getRule());
		} else {
			ruleMapping = new ArrayList<LARule>();
		}
		return ruleMapping;
	}

	@Override
	@Cacheable("LocationCache")
	@Profiled
	public LocationInformation getLocation(String zipCode) {
		// FIX: zipCode more then 5 digits
		if (zipCode.length() == UserDataConfiguration.ZIP_CODE_LENGTH + 1 /*flips code*/) {
			//we have zipcode appended with flips code (CR-4138) 
			zipCode = zipCode.substring(0, UserDataConfiguration.ZIP_CODE_LENGTH);
		}
		LocationInformation loc = listBuilderIntegrationDAO.getLocation(zipCode);
		/*
		 * String timezoneOffset = getTimezoneOffset(loc.getTimeZone());
		 * loc.setTimeZoneOffset(timezoneOffset);
		 */
		return loc;
	}

	/**
	 * This service is only hbase reconnect for every 4 minute. as we are using
	 * hbase.ipc.client.connection.maxidletime = 5 min. The goal is keep
	 * Hconnection object always alive.
	 * 
	 * 
	 * Note: Dont apply EHCache annotation to this method.
	 */

	@Override
	public LocationInformation getLocationForHbaseReconnect(String zipCode) {
		LocationInformation loc = listBuilderIntegrationDAO.getLocation(zipCode);
		/*
		 * String timezoneOffset = getTimezoneOffset(loc.getTimeZone());
		 * loc.setTimeZoneOffset(timezoneOffset);
		 */
		return loc;
	}

	public static void main(String[] args) {
		ListBuilderIntegrationServiceImpl obj = new ListBuilderIntegrationServiceImpl();
		String offset = obj.getTimezoneOffset("Central", false);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("GMT+7:00", true);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("GMT+7", true);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("GMT+7:30", true);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("GMT-7", true);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("GMT-7:00", true);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("GMT-7:30", true);
		System.out.println(offset);
		offset = obj.getTimezoneOffset("Unknown", true);
		System.out.println(offset);
	}

	/**
	 * Description copied from {@link TimeZone.getTimeZone(String)}
	 * 
	 * @param timezoneId
	 *            timezoneId - the timezoneId for a TimeZone, either an
	 *            abbreviation such as "PST", a full name such as
	 *            "America/Los_Angeles", or a custom ID such as "GMT-8:00". Note
	 *            that the support of abbreviations is for JDK 1.1.x
	 *            compatibility only and full names should be used.
	 * 
	 * @return timezone offset number in string formatted as +/-xx:xx, or +00:00
	 *         if timezoneId is not understood by @TimeZone.getTimeZone(String)
	 */
	@Cacheable("TimezoneOffsetCache")
	@Override
	public String getTimezoneOffset(String timezoneId, boolean isTimezoneCorrect) {

		if (timezoneId == null) {
			return "+0000";
		}

		// Currently timezone field dont have correct timezoneId. Hence we are
		// adding "US/xxxx"
		if (!isTimezoneCorrect) {
			// FIXME: fix here when input source has proper timezoneId.
			timezoneId = "US/" + timezoneId;
		}

		TimeZone tz = TimeZone.getTimeZone(timezoneId);
		Calendar cal = GregorianCalendar.getInstance(tz);
		int offsetInMillis = tz.getOffset(cal.getTimeInMillis());

		String offset = String.format("%02d%02d", Math.abs(offsetInMillis / 3600000), Math.abs((offsetInMillis / 60000) % 60));
		offset = (offsetInMillis >= 0 ? "+" : "-") + offset;
		return offset;
	}

	public String parseCurrentDate(String format) {
		long currentMilliSeconds = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat(format);

		Date resultdate = new Date(currentMilliSeconds);
		String result = sdf.format(resultdate);
		LOGGER.info("batchNumber: {}", result);
		return result;
	}

	/**
	 * Corn job every 6 hours
	 */
	@Scheduled(cron = "${com.directv.uds.lastaction.rerun.cron}")
	public void processLastActionRules() {
		
		String jobids = runLastActionJob();
		LOGGER.debug("processed LastAction Rules : {}", jobids);
	}

	private String runLastActionJob() {

		LOGGER.debug("in processLastActionRules()");
		String serverId = null;
		try {
			InetAddress address = InetAddress.getLocalHost();
			if (!address.isLoopbackAddress()) {
				serverId = address.getHostAddress();
			} else {
				LOGGER.warn("Can't build up server id based on host address (got loopback), use timestamp instead");
			}
		} catch (UnknownHostException e) {
			LOGGER.warn("Can't build up server id based on host address, use timestamp instead", e);
		}
		if (serverId == null) {
			serverId = String.valueOf(System.currentTimeMillis());
		}
		List<LARule> rules = this.prepareDailySync(serverId);
		List<LARule> larules = new ArrayList<LARule>();
		if (rules != null) {
			Iterator<LARule> iterator = rules.iterator();
			LOGGER.info("Size rules: {}", larules.size());
			while (iterator.hasNext()) {
				LARule laRule = (LARule) iterator.next();
				LARuleType type = laRule.getRuleType();
				LOGGER.info("Type rule: {}", laRule.getRuleType().getIntepretedEventType());
				if (laRule.getRuleType() == LARuleType.LAST_PURCHASE) {
					larules.add(laRule);
				} else if (laRule.getRuleType() == LARuleType.LAST_WATCH) {
					larules.add(laRule);
				} else if (laRule.getRuleType() == LARuleType.LAST_RECORD) {
					larules.add(laRule);
				} else if (laRule.getRuleType() == LARuleType.LAST_RATE) {
					larules.add(laRule);
				} else {
					LOGGER.debug("Ingnored other than last action rule: {}", type);
				}

			}

		}
		rules = null;
		List<String> jobIds = new ArrayList<String>();
		if (larules.size() > 0) {
			jobIds = this.processOozieJob(larules, false);
			LOGGER.debug("'jobs ids: {}", jobIds);
		} 
		return jobIds.toString();
	}

	@Override
	public String triggerDailySnycRules() {
		String jobids = runLastActionJob();
		return jobids;
	}

	@Override
	public CreditResponse getCreditData(String accountId, Set<String> creditType, String mainCategory) {
		return new CreditResponse(getCreditDataResponse(accountId, mainCategory, creditType));
	}

	private List<CreditDataResponse> getCreditDataResponse(String accountId, String mainCategory, Set<String> creditTypes) {
		List<CreditDataResponse> creditDataResponses = new ArrayList<CreditDataResponse>();
		CreditDataResponse creditDataResponse = new CreditDataResponse();
		creditDataResponses.add(creditDataResponse);
		for (String creditType : creditTypes) {
			getCreditDataResponses(accountId, creditDataResponses, null, mainCategory, creditType, creditDataResponse);
		}
		return creditDataResponses;
	}

	private void getCreditDataResponses(String accountId, List<CreditDataResponse> creditDataResponses, LARule laRule, String mainCategory,
			String creditType, CreditDataResponse creditDataResponse) {
		CreditDataResult[] creditDataResult = null;
		boolean getCredit = true;
		creditDataResult = getCreditDataResult(accountId, laRule, getCredit, mainCategory, creditType);
		if (creditDataResult != null) {
			if (getCredit) {
				creditDataResponses.get(GET_TOP).getResult().add(creditDataResult[GET_TOP]);
			} else {
				creditDataResponse = new CreditDataResponse(Arrays.asList(creditDataResult), laRule.getRuleName());
				creditDataResponses.add(creditDataResponse);
			}
		} else {
			LOGGER.error("{}: rules not found.", accountId);
		}
	}

	private CreditDataResult[] getCreditDataResult(String accountId, LARule laRule, boolean getCredit, String mainCategory,
			String creditType) {
		CreditDataResult[] creditDataResult;
		String timeWindow = null, dayOfWeek = null;
		if (!getCredit) {
			creditType = null;
			mainCategory = null;
			List<LAStatementType> statements = laRule.getMatch().getStatement();
			for (LAStatementType laStatementType : statements) {
				String value = laStatementType.getFilter().getValue1();
				if (laStatementType.getFilter().getName().equals(LAFilterType.Filter.CAST)) {
					creditType = value;
				} else if (laStatementType.getFilter().getName().equals(LAFilterType.Filter.DAY_OF_WEEK)) {
					dayOfWeek = value;
				} else if (laStatementType.getFilter().getName().equals(LAFilterType.Filter.TIME_WINDOW)) {
					timeWindow = value;
				} else if (laStatementType.getFilter().getName().equals(LAFilterType.Filter.TYPE)) {
					mainCategory = value;
				} else {
					LOGGER.error("Ingnored other than credit rule: {}", laStatementType);
				}
			}
		}

		String[] queries = buildColumnQualifiers(timeWindow, mainCategory, dayOfWeek, creditType);
		creditDataResult = listBuilderIntegrationDAO.getCreditByRuleName(accountId, laRule, queries, creditType);
		return creditDataResult;
	}

	private String[] buildColumnQualifiers(String timeWindow, String mainCategory, String dayOfWeek, String creditType) {
		boolean appended = false;
		StringBuilder sb = new StringBuilder();
		// if (timeWindow != null) {
		sb.append(Configuration.getInstance().getString(CREDIT_TIME_WINDOW));
		appended = true;
		// }
		if (creditType != null) {
			if (appended) {
				sb.append(".");
			}
			sb.append(creditType);
			appended = true;
		}
		if (mainCategory != null) {
			if (appended) {
				sb.append(".");
			}
			sb.append(mainCategory);
			appended = true;
		}
		if (mainCategory == null) {
			if (appended) {
				sb.append(".");
			}
			sb.append(Configuration.getInstance().getString(CREDIT_MAIN_CATEGORY));
			appended = true;
		}
		// if (dayOfWeek != null) {
		if (appended) {
			sb.append(".");
		}
		sb.append(Configuration.getInstance().getString(CREDIT_DAY_OF_WEEK));
		appended = true;
		// }

		String[] queries = { sb.toString() };
		return queries;
	}
}
