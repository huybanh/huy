/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.directv.uds.dao.AccountDAO;
import com.directv.uds.dao.EventDAO;
import com.directv.uds.model.Account;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.EventTime;
import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.model.LastAction;

/**
 * @author TungPT6
 * 
 */
@ContextConfiguration(loader = AnnotationConfigContextLoader.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class ClusterMappingServiceImplTest {

	@Configuration
	static class ContextConfiguration {
		@Bean
		AccountDAO getAccountDAO() {
			return mock(AccountDAO.class);
		}

		@Bean
		EventDAO getEventDAO() {
			return mock(EventDAO.class);
		}

		@Bean
		ClusterMappingServiceImpl getClusterMappingServiceImpl() {
			return new ClusterMappingServiceImpl();
		}
	}

	@Autowired
	private EventDAO eventDAO;

	@Autowired
	private AccountDAO accountDAO;

	@Autowired
	private ClusterMappingServiceImpl clusterMappingServiceImpl;

	/**
	 * ENCRYPTED_ID String
	 */
	private static final String ENCRYPTED_ID = "f893882dfeea5458a4b7a30a6f5c8d7d";

	/**
	 * USER_ID String
	 */
	private static final String USER_ID = "80977746";

	/**
	 * CARD_ID String
	 */
	private static final String CARD_ID = "2912076318";

	/**
	 * OFF_SET int
	 */
	private static final int OFF_SET = 0;

	/**
	 * LIMIT int
	 */
	private static final int LIMIT = 10;

	/**
	 * INDEX_ZERO int
	 */
	private static final int INDEX_ZERO = 0;

	/**
	 * SIZE int
	 */
	private static final int SIZE = 10;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * test GetUserEncryptedId
	 * 
	 * Input: userId : anyString()
	 * 
	 * Output expect: encryptedIdActual String
	 */
	@Test
	public void testGetUserEncryptedId() {
		// String userId = "50458969";
		when(accountDAO.getEncryptedId(anyString())).thenReturn(ENCRYPTED_ID);

		String encryptedIdActual = clusterMappingServiceImpl.getUserEncryptedId(anyString());

		assertNotNull(encryptedIdActual);
		assertEquals(encryptedIdActual, ENCRYPTED_ID);

	}

	/**
	 * test GetUserDecryptedId
	 * 
	 * Input: encryptedId : anyString()
	 * 
	 * Output expect: userIdActual String
	 */
	@Test
	public void testGetUserDecryptedId() {
		when(accountDAO.getUserId(anyString())).thenReturn(USER_ID);

		String userIdActual = clusterMappingServiceImpl.getUserDecryptedId(anyString());

		assertNotNull(userIdActual);
		assertEquals(userIdActual, USER_ID);
	}

	/**
	 * test GetAccountFromCardId
	 * 
	 * Input: cardId : anyString()
	 * 
	 * Output expect: accountActual Account
	 */
	@Test
	public void testGetAccountFromCardId() {
		Account account = new Account(USER_ID, ENCRYPTED_ID);
		when(accountDAO.getAccountByCardId(CARD_ID)).thenReturn(account);

		Account accountActual = clusterMappingServiceImpl.getAccountFromCardId(CARD_ID);

		assertNotNull(accountActual);
		assertEquals(account, accountActual);

	}

	/**
	 * test GetUsers
	 * 
	 * Input: offset int, LIMIT int
	 * 
	 * Output expect: lstUsersActual List<String>
	 */
	@Test
	public void testGetUsers() {
		List<String> lstUsers = buildListUserString();

		when(accountDAO.getUsers(OFF_SET, LIMIT)).thenReturn(lstUsers);

		List<String> lstUsersActual = clusterMappingServiceImpl.getUsers(OFF_SET, LIMIT);
		assertNotNull(lstUsersActual);
		assertNotNull(lstUsersActual.get(INDEX_ZERO));

		assertEquals(SIZE, lstUsersActual.size());
	}

	/**
	 * test GetUserViewingHistory
	 * 
	 * Input: String userId, String mainCategory, int offset, int limit, boolean
	 * removeDuplicates, boolean isImpala, EventTime eventTime
	 * 
	 * Output expect: resultsActual Map<String, List<InterpretedEvent>>
	 */
	@Test
	public void testGetUserViewingHistory() {
		Map<String, List<InterpretedEvent>> results = buildMapInterpretedEvent();

		String mainCategory = null;
		boolean removeDuplicates = true;
		boolean isImpala = true;
		EventTime eventTime = new EventTime("2014-04-07T00:00:00Z", "2014-04-08T00:00:00Z");

		when(eventDAO.getUserViewingHistoryImpala(USER_ID, mainCategory, OFF_SET, LIMIT, removeDuplicates, eventTime)).thenReturn(results);

		Map<String, List<InterpretedEvent>> resultsActual = clusterMappingServiceImpl.getUserViewingHistory(USER_ID, mainCategory, OFF_SET,
				LIMIT, removeDuplicates, isImpala, eventTime);

		assertNotNull(resultsActual);
	}

	@Test
	public void testGetLastAction() {
		Map<String, Map<String, List<LastAction>>> results = new HashMap<String, Map<String, List<LastAction>>>();

		String mainCategory = null;
		boolean groupBySubCategory = true;
		//String serviceName = "Movies";
		String eventType = "LiveViewEvent";

		when(eventDAO.getLastActionGeneric(USER_ID, mainCategory, eventType, groupBySubCategory)).thenReturn(results);

		Map<String, Map<String, List<LastAction>>> resultsActual = clusterMappingServiceImpl.getLastActionGeneric(USER_ID, mainCategory,
				eventType, groupBySubCategory);

		assertNotNull(resultsActual);

	}

	/**
	 * test GetRegionIdFromAccountId
	 * 
	 * Input: accountId String
	 * 
	 * Output expect: dmaInformationActual DMAInformation
	 * @throws IOException 
	 */
	@Test
	public void testGetRegionIdFromAccountId() throws IOException {
		DMAInformation dmaInformation = new DMAInformation();
		dmaInformation.setDmaDescription("Las Vegas NV");
		dmaInformation.setDma("839");

		when(accountDAO.getRegionIdFromAccountId(USER_ID)).thenReturn(dmaInformation);

		DMAInformation dmaInformationActual = clusterMappingServiceImpl.getRegionIdFromAccountId(USER_ID);
		assertNotNull(dmaInformationActual);
	}

	private List<String> buildListUserString() {
		List<String> lstUsers = new ArrayList<String>();
		lstUsers.add("80977746");
		lstUsers.add("76801341");
		lstUsers.add("63284413");
		lstUsers.add("46465681");
		lstUsers.add("76303618");
		lstUsers.add("6035491");
		lstUsers.add("26230589");
		lstUsers.add("51462965");
		lstUsers.add("75947571");
		lstUsers.add("39802421");
		return lstUsers;
	}

	private Map<String, List<InterpretedEvent>> buildMapInterpretedEvent() {
		Map<String, List<InterpretedEvent>> results = new HashMap<String, List<InterpretedEvent>>();

		List<InterpretedEvent> listInterpretedEvent = new ArrayList<InterpretedEvent>();
		InterpretedEvent interpretedEvent_1 = new InterpretedEvent();
		interpretedEvent_1.setInterpretedEvent("Watch");
		interpretedEvent_1.setAccountId("77643869");
		interpretedEvent_1.setEventTime("20140407092445");
		interpretedEvent_1.setTmsId("MV003918940000");
		interpretedEvent_1.setSource("AMS");
		interpretedEvent_1.setEventType("LiveViewEvent");

		InterpretedEvent interpretedEvent_2 = new InterpretedEvent();
		interpretedEvent_2.setInterpretedEvent("Watch");
		interpretedEvent_2.setAccountId("77643869");
		interpretedEvent_2.setEventTime("20140407122318");
		interpretedEvent_2.setTmsId("MV000041860000");
		interpretedEvent_2.setSource("AMS");
		interpretedEvent_2.setEventType("LiveViewEvent");

		listInterpretedEvent.add(interpretedEvent_1);
		listInterpretedEvent.add(interpretedEvent_2);

		results.put("Movies", listInterpretedEvent);
		return results;
	}
}
