/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.service;

import java.io.IOException;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.model.rs.getRule.response.RuleDataResponse;
import com.directv.uds.model.rs.response.LastActionResult;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.LastActionUtil;

/**
 * <H3>ListBuilderIntegrationServiceImplTest</H3>
 * 
 * @author ThanhNN2
 * @since Oct 16, 2014
 */
public class ListBuilderIntegrationServiceImplTest {
	private static Logger LOGGER = LoggerFactory.getLogger(ListBuilderIntegrationServiceImplTest.class);

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.directv.uds.service.ListBuilderIntegrationServiceImpl#getUniqueLastActionResponseData(java.util.List)}.
	 * @throws IOException 
	 */
	@Test
	@Ignore
	public void testGetUniqueLastActionResponseData() throws IOException {
		String expected = "[{\"ruleName\":\"TV.Watch.Animation\",\"lastModifiedDate\":null,\"result\":[{\"tmsId\":\"EP003077660274\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907233000\"}]},{\"ruleName\":\"TV.Watch.Kids & Family\",\"lastModifiedDate\":null,\"result\":[{\"tmsId\":\"EP016710500033\",\"title\":\"Pokemon: BW Adventures in Unova\",\"eventTime\":\"20140827110000\"}]},{\"ruleName\":\"TV.Watch.Reality\",\"lastModifiedDate\":null,\"result\":[{\"tmsId\":\"SH003481170000\",\"title\":\"Supermax Prisons\",\"eventTime\":\"20140909110000\"}]}]";
		String result = "{\"lastActionData\":[{\"ruleName\":\"TV.Watch.Animation\",\"lastModifiedDate\":null,\"result\":[{\"tmsId\":\"EP003077660274\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907233000\"},{\"tmsId\":\"EP003077660406\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907230000\"},{\"tmsId\":\"SH019787570000\",\"title\":\"Lalaloopsy Girls: Welcome to L.A.L.A. Prep School!\",\"eventTime\":\"20140907190000\"},{\"tmsId\":\"EP003077660298\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907173000\"},{\"tmsId\":\"EP003077660488\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907170000\"},{\"tmsId\":\"EP003077660383\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907163000\"},{\"tmsId\":\"EP003077660447\",\"title\":\"SpongeBob SquarePants\",\"eventTime\":\"20140907160227\"},{\"tmsId\":\"EP007753700042\",\"title\":\"Johnny Test\",\"eventTime\":\"20140827120000\"},{\"tmsId\":\"EP007753700041\",\"title\":\"Johnny Test\",\"eventTime\":\"20140827113000\"},{\"tmsId\":\"EP016710500033\",\"title\":\"Pokemon: BW Adventures in Unova\",\"eventTime\":\"20140827110000\"}]},{\"ruleName\":\"TV.Watch.Kids & Family\",\"lastModifiedDate\":null,\"result\":[{\"tmsId\":\"EP016710500033\",\"title\":\"Pokemon: BW Adventures in Unova\",\"eventTime\":\"20140827110000\"}]},{\"ruleName\":\"TV.Watch.Reality\",\"lastModifiedDate\":null,\"result\":[{\"tmsId\":\"SH003481170000\",\"title\":\"Supermax Prisons\",\"eventTime\":\"20140909110000\"}]}],\"userTastesData\":[{\"mainCategory\":\"TV\",\"userTaste\":[{\"key\":\"Talk\",\"value\":392.3698332636315},{\"key\":\"Mystery/Crime\",\"value\":290.6088032353765},{\"key\":\"Reality\",\"value\":277.27375103430916},{\"key\":\"Comedy\",\"value\":204.52917726178384},{\"key\":\"Politics\",\"value\":157.39596371882084},{\"key\":\"Law\",\"value\":110.01353605849116},{\"key\":\"Interview\",\"value\":107.20913686302003},{\"key\":\"Drama\",\"value\":102.06920805723277},{\"key\":\"Documentary\",\"value\":88.43941534959343},{\"key\":\"Special\",\"value\":56.03462616014748},{\"key\":\"Animation\",\"value\":46.05881949980828},{\"key\":\"Kids\",\"value\":42.03554604310417},{\"key\":\"House/Garden\",\"value\":41.24967132350853},{\"key\":\"Entertainment\",\"value\":35.96072004780079},{\"key\":\"Suspense\",\"value\":33.78853691595576},{\"key\":\"History\",\"value\":32.12149393350005},{\"key\":\"Kids & Family\",\"value\":21.220598006644515},{\"key\":\"Music\",\"value\":20.73240015620713},{\"key\":\"Cooking\",\"value\":20.534022704282364},{\"key\":\"Travel\",\"value\":20.256935215946854},{\"key\":\"Religion\",\"value\":19.051363636363643},{\"key\":\"Fantasy\",\"value\":16.690306534424185},{\"key\":\"Home Repair\",\"value\":16.40290697674419},{\"key\":\"Science/Nature\",\"value\":16.123846391703527},{\"key\":\"Military/War\",\"value\":15.858333333333336},{\"key\":\"Medical\",\"value\":15.790052175163495},{\"key\":\"Soap Opera\",\"value\":14.64437720503733},{\"key\":\"Business/Financial\",\"value\":12.98888888888889},{\"key\":\"Animals\",\"value\":12.871456005909861},{\"key\":\"Game Show\",\"value\":12.488674388674388},{\"key\":\"Romance\",\"value\":8.936591208527965},{\"key\":\"Action/Adventure\",\"value\":7.50368309758549},{\"key\":\"Science\",\"value\":7.351923076923077},{\"key\":\"Art\",\"value\":6.903174603174603},{\"key\":\"Family\",\"value\":5.816666666666666},{\"key\":\"Musical\",\"value\":5.65},{\"key\":\"Fashion/Style\",\"value\":5.56666666666667},{\"key\":\"Sci-Fi\",\"value\":4.869832783549121},{\"key\":\"Paranormal\",\"value\":4.839999999999999},{\"key\":\"Product Info\",\"value\":4.066666666666666},{\"key\":\"Health/Medicine\",\"value\":3.6583333333333328},{\"key\":\"Interests\",\"value\":3.15326170031021},{\"key\":\"Standup\",\"value\":3.1018954729481045},{\"key\":\"Outdoors\",\"value\":3.0621651295564347},{\"key\":\"Educational\",\"value\":2.7122448979591844},{\"key\":\"Award Ceremony\",\"value\":2.401858813700919},{\"key\":\"Biography\",\"value\":2.1380416825517856},{\"key\":\"Weather\",\"value\":2.1111111111111107},{\"key\":\"Nature\",\"value\":2.0515151515151513},{\"key\":\"Self-Help\",\"value\":2.0},{\"key\":\"Aviation\",\"value\":1.9836065573770492},{\"key\":\"Performing Arts\",\"value\":1.6333333333333333},{\"key\":\"How-To\",\"value\":0.9000000000000004},{\"key\":\"Horror\",\"value\":0.3550724637681159},{\"key\":\"Dance\",\"value\":0.2833333333333333},{\"key\":\"Collectibles\",\"value\":0.25},{\"key\":\"Local\",\"value\":0.15},{\"key\":\"Western\",\"value\":0.13040816326530613},{\"key\":\"Videos\",\"value\":0.09523809523809523},{\"key\":\"Docudrama\",\"value\":0.03333333333333333},{\"key\":\"Arts/Crafts\",\"value\":0.03333333333333333},{\"key\":\"Racing\",\"value\":0.017241379310344827}]}],\"whatshotData\":[{\"ruleName\":\"whatshot3\",\"whatshot\":[{\"tmsId\":\"Tom Green Live\",\"title\":\"EP018041190035\",\"score\":124696.0},{\"tmsId\":\"Project Runway\",\"title\":\"EP007055290224\",\"score\":119927.0},{\"tmsId\":\"Today\",\"title\":\"EP019152140047\",\"score\":72328.0},{\"tmsId\":\"So You Think You Can Dance\",\"title\":\"EP007517000270\",\"score\":24269.0},{\"tmsId\":\"Peter, Paul & Mary: Carry It On: A Musical Legacy\",\"title\":\"SH006306730000\",\"score\":23150.0},{\"tmsId\":\"EVB Live\",\"title\":\"SH014406070000\",\"score\":22634.0},{\"tmsId\":\"America's Got Talent\",\"title\":\"EP008298780269\",\"score\":22125.0},{\"tmsId\":\"Windy City Live\",\"title\":\"EP014124050292\",\"score\":21747.0},{\"tmsId\":\"America's Got Talent\",\"title\":\"EP008298780268\",\"score\":20994.0},{\"tmsId\":\"The Late Late Show With Craig Ferguson\",\"title\":\"EP007151232053\",\"score\":20510.0}]},{\"ruleName\":\"whatshot1\",\"whatshot\":[{\"tmsId\":\"Tom Green Live\",\"title\":\"EP018041190035\",\"score\":124696.0},{\"tmsId\":\"Project Runway\",\"title\":\"EP007055290224\",\"score\":119927.0},{\"tmsId\":\"Today\",\"title\":\"EP019152140047\",\"score\":72328.0},{\"tmsId\":\"So You Think You Can Dance\",\"title\":\"EP007517000270\",\"score\":24269.0},{\"tmsId\":\"Peter, Paul & Mary: Carry It On: A Musical Legacy\",\"title\":\"SH006306730000\",\"score\":23150.0},{\"tmsId\":\"EVB Live\",\"title\":\"SH014406070000\",\"score\":22634.0},{\"tmsId\":\"America's Got Talent\",\"title\":\"EP008298780269\",\"score\":22125.0},{\"tmsId\":\"Windy City Live\",\"title\":\"EP014124050292\",\"score\":21747.0},{\"tmsId\":\"America's Got Talent\",\"title\":\"EP008298780268\",\"score\":20994.0},{\"tmsId\":\"The Late Late Show With Craig Ferguson\",\"title\":\"EP007151232053\",\"score\":20510.0}]}]}";
		RuleDataResponse response = JSONUtil.convertJsonToObject(result, RuleDataResponse.class);
		List<LastActionResult> lastActionResultList = response.getLastActionData();
		List<LastActionResult> postProcessing = LastActionUtil.getUniqueLastActionResponseData(lastActionResultList);
		response.setLastActionData(postProcessing);
		LOGGER.info(JSONUtil.convertObjectToJson(response));
		Assert.assertEquals(expected, JSONUtil.convertObjectToJson(postProcessing));
	}

	/**
	 * Test method for {@link com.directv.uds.service.ListBuilderIntegrationServiceImpl#getUniqueLastActionResponseData(java.util.List)}.
	 */
	@Test
	public void testTimezoneOffset() {
		/*Assert.assertEquals("-06:00", ListBuilderIntegrationServiceImpl.getTimezoneOffset("US/Central"));
		Assert.assertEquals("+07:00", ListBuilderIntegrationServiceImpl.getTimezoneOffset("GMT+7:00"));
		Assert.assertEquals("+07:00", ListBuilderIntegrationServiceImpl.getTimezoneOffset("GMT+7"));
		Assert.assertEquals("+07:30", ListBuilderIntegrationServiceImpl.getTimezoneOffset("GMT+7:30"));
		Assert.assertEquals("-07:00", ListBuilderIntegrationServiceImpl.getTimezoneOffset("GMT-7"));
		Assert.assertEquals("-07:00", ListBuilderIntegrationServiceImpl.getTimezoneOffset("GMT-7:00"));
		Assert.assertEquals("-07:30", ListBuilderIntegrationServiceImpl.getTimezoneOffset("GMT-7:30"));*/
	}

}
