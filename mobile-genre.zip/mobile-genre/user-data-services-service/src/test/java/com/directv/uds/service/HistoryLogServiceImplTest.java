/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.directv.uds.dao.HistoryLogDAO;
import com.directv.uds.model.RecommendationJobHistory;

/**
 * @author TungPT6
 * 
 */
@ContextConfiguration(loader = AnnotationConfigContextLoader.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class HistoryLogServiceImplTest {

	@Configuration
	static class ContextConfiguration {
		@Bean
		HistoryLogDAO getHistoryLogDAO() {
			return mock(HistoryLogDAO.class);
		}

		@Bean
		HistoryLogServiceImpl getHistoryLogServiceImpl() {
			return new HistoryLogServiceImpl();
		}
	}

	@Autowired
	HistoryLogServiceImpl historyLogServiceImpl;

	@Autowired
	HistoryLogDAO historyLogDAO;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * test GetRecommendationJobHistory
	 * 
	 * Input: String startTime, String endTime, boolean latest
	 * 
	 * Output: recommendationJobHistoryActual Map<String,
	 * List<RecommendationJobHistory>>
	 */
	@Test
	public void testGetRecommendationJobHistory() {
		String startTime = "2014-09-10T00:00:00Z";
		String endTime = "2014-09-11T00:00:00Z";
		boolean latest = true;
		Map<String, List<RecommendationJobHistory>> map = new HashMap<String, List<RecommendationJobHistory>>();
		List<RecommendationJobHistory> listRecommendationJobHistory = new ArrayList<RecommendationJobHistory>();
		RecommendationJobHistory recommendationJobHistory_1 = new RecommendationJobHistory();
		recommendationJobHistory_1.setKey("cdnZip1_lastBatch_endTime");
		recommendationJobHistory_1.setValue("2014-09-11 10:13:56");

		RecommendationJobHistory recommendationJobHistory_2 = new RecommendationJobHistory();
		recommendationJobHistory_1.setKey("cdnZip1_lastBatch_message");
		recommendationJobHistory_1.setValue("20140909170500");

		listRecommendationJobHistory.add(recommendationJobHistory_1);
		listRecommendationJobHistory.add(recommendationJobHistory_2);

		map.put("20140911", listRecommendationJobHistory);

		when(historyLogDAO.getRecommendationJobHistory(startTime, endTime, latest)).thenReturn(map);

		Map<String, List<RecommendationJobHistory>> recommendationJobHistoryActual = historyLogServiceImpl.getRecommendationJobHistory(
				startTime, endTime, latest);
		assertNotNull(recommendationJobHistoryActual);
	}

}
