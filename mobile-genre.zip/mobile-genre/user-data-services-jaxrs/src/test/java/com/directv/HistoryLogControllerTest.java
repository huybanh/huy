/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv;

import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 * <H3>HistoryLogControllerTest</H3>
 *
 * @author ThanhNN2
 * @since Oct 30, 2014
 */
public class HistoryLogControllerTest {
	@org.junit.Test
	public void testConvertDateTime() {
		String time = "2012-10-01T09:45:00.000+02:00";
		DateTimeFormatter format = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		format.withZone(DateTimeZone.forTimeZone(TimeZone.getDefault()));

		DateTime parsedDate = format.parseDateTime(time);
		System.out.println(parsedDate);
		DateTimeFormatter format1 = DateTimeFormat.forPattern("yyyyMMddHHmmss");
		format1.withZone(DateTimeZone.forTimeZone(TimeZone.getDefault()));
		time = parsedDate.toString(format1);
		System.out.println(time);

	}
}
