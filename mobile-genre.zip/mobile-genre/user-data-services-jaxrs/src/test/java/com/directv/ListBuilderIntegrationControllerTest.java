package com.directv;

import org.junit.Test;

import com.directv.uds.listbuilder.model.ListbuilderConfig;
import com.directv.uds.utils.JSONUtil;

public class ListBuilderIntegrationControllerTest {
	@Test
	public void parsePayload() {
		String json = "{\"listBuilderFullListing\":{\"ruleSet\":{\"rule\":[{\"state\":\"Published\",\"query\":{\"match\":{\"type\":\"AND\",\"statement\":[{\"filter\":{\"name\":\"category\",\"operation\":\"EQUAL\",\"value1\":\"tv\",\"value2\":null},\"match\":null}]}},\"ruleName\":\"Test_lastwatch 2\",\"collapseSeries\":false,\"suppressResult\":false,\"useEpisodeTitle\":false,\"defaultLabel\":\"Test_lastwatch\",\"sort\":[{\"sortSeq\":1,\"sortBy\":\"DESC\",\"sortField\":\"starRating\"}],\"typeOfRule\":\"LAST_WATCH\",\"maxResult\":25,\"userBehavior\":null,\"updatedDate\":null,\"platform\":[{\"displayTitle\":\"web\",\"deviceType\":\"web\"},{\"displayTitle\":\"1\",\"deviceType\":\"stb\"}],\"inclusion\":[],\"exclusion\":[],\"manualPosition\":[],\"ottSources\":null,\"dtv\":null,\"whatsHotByRegion\":false}]}}}";
		ListbuilderConfig listBuilderConfig = JSONUtil.convertJsonToObject(
				json, ListbuilderConfig.class);
	}
}
