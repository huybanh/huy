/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.common;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Common implementation for controllers.
 * <p>
 * 
 * Oauth only supports Accept = application/json, so we can set this restriction
 * in this common class. Every new controller should inherit this one to apply
 * this restriction.
 * 
 * @author NguTQ
 * 
 */
@RequestMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
public class BaseController {

	/**
	 * Contains the HttpHeaders have correlationId return the client
	 * 
	 * @param correlationId
	 */
//	protected HttpHeaders responseHeaders(String correlationId) {
//		HttpHeaders responseHeaders = new HttpHeaders();
//		responseHeaders.set(DTV_CORRELATION_ID, correlationId);
//		return responseHeaders;
//	}

}
