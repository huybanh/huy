package com.directv.uds.request;

import javax.validation.constraints.DecimalMin;

import com.directv.uds.utils.Configuration;

public class UserMappingRequest {

	private static final String LIMIT_DEFAULT_CONFIG_NAME = "defaultUserNumbers";

	@DecimalMin(value = "0", message = "{com.directv.uds.message.error.offset}")
	private int offset = 0;
	@DecimalMin(value = "1", message = "{com.directv.uds.message.error.limit}")
	private Integer limit = null; // unset

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		if (limit == null /* LIMIT_UNSET */) {
			limit = Configuration.getInstance().getInt(LIMIT_DEFAULT_CONFIG_NAME, 100);
		}
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

}
