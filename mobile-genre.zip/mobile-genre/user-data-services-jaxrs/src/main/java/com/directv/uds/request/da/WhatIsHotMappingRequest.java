package com.directv.uds.request.da;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.DecimalMin;

import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.request.CommonMappingRequest;

public class WhatIsHotMappingRequest extends CommonMappingRequest {

	private String timeWindow;
	private String regionId;
	@DecimalMin(value = "-1", message = "{com.directv.uds.message.error.limit}")
	private int limit = -1;

	// @AssertTrue(message = "Time window must be one of [FiveDays]")
	@AssertTrue(message = "{com.directv.uds.message.error.timeWindow.day}")
	public boolean isTimeWindowValid() {
		if (timeWindow == null) {
			this.timeWindow = UserDataConfiguration.WIH_TIME_WINDOW.getDefaultValue();
			return true;
		}

		int index = UserDataConfiguration.WIH_TIME_WINDOW.getIndex(timeWindow);

		if (timeWindow != null && index == -1) {
			return false;
		} else {
			this.timeWindow = UserDataConfiguration.WIH_TIME_WINDOW.getValue(index);
			return true;
		}
	}

	public String getTimeWindow() {
		return timeWindow;
	}

	public void setTimeWindow(String timeWindow) {
		this.timeWindow = timeWindow;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	/**
	 * @return the regionId
	 */
	public String getRegionId() {
		return regionId;
	}

	/**
	 * @param regionId
	 *            the regionId to set
	 */
	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}
}
