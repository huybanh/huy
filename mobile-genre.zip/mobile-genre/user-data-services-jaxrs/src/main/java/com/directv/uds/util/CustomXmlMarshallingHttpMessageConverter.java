/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.util;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.MediaType;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;

public class CustomXmlMarshallingHttpMessageConverter extends MarshallingHttpMessageConverter{

	
	@Override
	public boolean canWrite(Class<?> clazz, MediaType mediaType) {
		boolean canWrite = AnnotationUtils.findAnnotation(clazz, XmlRootElement.class) != null && canWrite(mediaType);
		if(canWrite) {
			return canWrite;
		}
		return AnnotationUtils.findAnnotation(clazz, XmlType.class) != null && canWrite(mediaType);
	}
}
