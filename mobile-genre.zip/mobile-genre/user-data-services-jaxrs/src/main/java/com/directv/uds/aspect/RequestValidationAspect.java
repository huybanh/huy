/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.aspect;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import com.directv.uds.validate.RequestValidator;

import java.lang.annotation.Annotation;

import javax.validation.Valid;

/**
 * Aspect for handling method parameters annotated with {@link Valid}. any
 * method parameter under the com.directv..* package annotated with that
 * annotation will be automatically validated using a jsr-303 validator
 * 
 * @author TungPT6
 * 
 */
public class RequestValidationAspect {
	/**
	 * 
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(RequestValidationAspect.class);

	/**
	 * request validator.
	 */
	private RequestValidator requestValidator;

	/**
	 * initializes request validator.
	 * 
	 * @param requestValidator
	 *            validator.
	 */
	public RequestValidationAspect(RequestValidator requestValidator) {
		super();
		this.requestValidator = requestValidator;
	}

	/**
	 * Validate endpoint which has @Valid in method signature.
	 * 
	 * @param joinPoint
	 *            join point
	 * 
	 */
	public void validateRequest(JoinPoint joinPoint) {

		/**
		 * using the method signature we are looking for the location of the @valid
		 * annotation. once we find it we get the argument in that position and
		 * then validate it
		 */

		MethodSignature signature = (MethodSignature) joinPoint.getSignature();
		int pos = -1;
		for (Annotation[] outerAnnotation : signature.getMethod().getParameterAnnotations()) {
			pos++;
			for (Annotation annotation2 : outerAnnotation) {
				if (annotation2 instanceof Valid) {
					Object argumentWithValidAnnotation = joinPoint.getArgs()[pos];

					LOGGER.debug(" found a parameter which needs to be validated: {} , at position: {}", argumentWithValidAnnotation, pos);
					requestValidator.validate(argumentWithValidAnnotation);
				}
			}
		}
	}
}
