/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.handler;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.directv.uds.enums.ErrorCode;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.exceptions.BaseRuntimeException;
import com.directv.uds.exceptions.DataNotFoundException;
import com.directv.uds.exceptions.DateParsingException;
import com.directv.uds.exceptions.InvalidFileSystemException;
import com.directv.uds.exceptions.InvalidRequestException;
import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.model.Errors;

/**
 * A CustomExceptionHandler class which provide centralized exception handling
 * across all @RequestMapping methods through @ExceptionHandler methods.
 * 
 * If there is no need to write error content to the response body, or if using
 * view resolution, e.g. ContentNegotiatingViewResolver, then use
 * DefaultHandlerExceptionResolver instead.
 * 
 * 
 * @author mgiramkar
 * 
 */
@ControllerAdvice
@Order(value = 1)
public class CustomAdviceHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomAdviceHandler.class);

	@ExceptionHandler({ MethodArgumentNotValidException.class })
	protected ResponseEntity<Errors> handleMethodArgumentNotValid(MethodArgumentNotValidException e, WebRequest request) {
		List<com.directv.uds.model.Error> errorList = new ArrayList<com.directv.uds.model.Error>();
		BindingResult result = e.getBindingResult();
		List<FieldError> fieldErrors = result.getFieldErrors();

		for (FieldError fieldError : fieldErrors) {
			com.directv.uds.model.Error error = new com.directv.uds.model.Error();
			error.setCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
			error.setMessage(fieldError.getDefaultMessage());
			errorList.add(error);
		}

		Errors errors = new Errors();
		errors.getError().addAll(errorList);
		return new ResponseEntity<Errors>(errors, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ InvalidRequestException.class })
	protected ResponseEntity<Errors> handleMethodArgumentNotValid(InvalidRequestException e, WebRequest request) {
		List<com.directv.uds.model.Error> errorList = new ArrayList<com.directv.uds.model.Error>();

		org.springframework.validation.Errors fieldsErrors = e.getErrors();

		for (ObjectError fieldError : fieldsErrors.getAllErrors()) {
			com.directv.uds.model.Error error = new com.directv.uds.model.Error();
			error.setCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
			error.setMessage(fieldError.getDefaultMessage());
			errorList.add(error);
		}

		Errors errors = new Errors();
		errors.getError().addAll(errorList);
		return new ResponseEntity<Errors>(errors, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ HttpMessageNotReadableException.class, HttpRequestMethodNotSupportedException.class,
			HttpMediaTypeNotSupportedException.class, MissingServletRequestParameterException.class,
			HttpMediaTypeNotAcceptableException.class, })
	protected ResponseEntity<Errors> handleException(Exception ex, WebRequest request) {

		LOGGER.warn("Unexpected exception", ex);
		HttpHeaders headers = new HttpHeaders();

		if (ex instanceof HttpRequestMethodNotSupportedException) {

			HttpStatus status = HttpStatus.METHOD_NOT_ALLOWED;
			return generateErrorResponseEntity(String.valueOf(HttpStatus.METHOD_NOT_ALLOWED.value()),
					HttpStatus.METHOD_NOT_ALLOWED.getReasonPhrase(), headers, status, request);

		} else if (ex instanceof HttpMediaTypeNotSupportedException) {

			HttpStatus status = HttpStatus.UNSUPPORTED_MEDIA_TYPE;
			return generateErrorResponseEntity(String.valueOf(status.value()), status.getReasonPhrase(), headers, status, request);

		} else if (ex instanceof HttpMediaTypeNotAcceptableException) {
			HttpStatus status = HttpStatus.NOT_ACCEPTABLE;
			return generateErrorResponseEntity(String.valueOf(status.value()), status.getReasonPhrase(), headers, status, request);

		} else if (ex instanceof HttpMessageNotReadableException) {
			HttpStatus status = HttpStatus.BAD_REQUEST;
			return generateErrorResponseEntity(ErrorCode.MISSING_INVALID_PAYLOAD.getCode(), ErrorCode.MISSING_INVALID_PAYLOAD.getMessage(),
					headers, status, request);

		} else if (ex instanceof MissingServletRequestParameterException) {
			HttpStatus status = HttpStatus.BAD_REQUEST;
			return generateErrorResponseEntity(ErrorCode.BAD_REQUEST.getCode(), ErrorCode.BAD_REQUEST.getMessage(), headers, status,
					request);
		} else {
			HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
			return generateErrorResponseEntity(String.valueOf(status.value()), status.getReasonPhrase(), headers, status, request);
		}

	}

	@ExceptionHandler({ DateParsingException.class, TypeMismatchException.class })
	protected ResponseEntity<Errors> handleDateParsingException(BaseRuntimeException e, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.BAD_REQUEST;
		return generateErrorResponseEntity(e, headers, status, request);
	}

	@ExceptionHandler({ NumberFormatException.class, IllegalArgumentException.class })
	protected ResponseEntity<Errors> handleNumberParsingException(RuntimeException e, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.BAD_REQUEST;
		LOGGER.warn("Unexpected exception", e);
		return generateErrorResponseEntity("", e.getMessage(), headers, status, request);
	}

	@ExceptionHandler({ RemoteSystemException.class })
	protected ResponseEntity<Errors> handleRemoteSystemException(BaseRuntimeException e, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		return generateErrorResponseEntity(e, headers, status, request);
	}

	@ExceptionHandler({ InvalidFileSystemException.class })
	protected ResponseEntity<Errors> handleInvalidFileSystemException(BaseRuntimeException e, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		return generateErrorResponseEntity(e, headers, status, request);
	}

	@ExceptionHandler({ DataNotFoundException.class })
	protected ResponseEntity<Errors> handleDataNotFoundException(BaseRuntimeException e, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.NOT_FOUND;
		return generateErrorResponseEntity(e, headers, status, request);
	}

	@ExceptionHandler({ BadRequestException.class })
	protected ResponseEntity<Errors> handleBadRequestException(BaseRuntimeException e, WebRequest request) {
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.BAD_REQUEST;
		return generateErrorResponseEntity(e, headers, status, request);
	}

	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<Errors> handleGeneralError(Exception ex, WebRequest request) {
		LOGGER.warn("Unexpected exception", ex);
		HttpHeaders headers = new HttpHeaders();
		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
		return generateErrorResponseEntity(String.valueOf(status.value()), status.getReasonPhrase(), headers, status, request);
	}

	private ResponseEntity<Errors> generateErrorResponseEntity(BaseRuntimeException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		LOGGER.warn("Unexpected exception", ex);
		if (ex.getErrors() != null && ex.getErrors().getError().size() > 0) {
			return generateErrorResponseEntity(ex.getErrors(), headers, status, request);
		}
		return generateErrorResponseEntity(ex.getErrorCode(), ex.getErrorMessage(), headers, status, request);
	}

	private ResponseEntity<com.directv.uds.model.Errors> generateErrorResponseEntity(Errors errors, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		return new ResponseEntity<Errors>(errors, headers, status);
	}

	private ResponseEntity<com.directv.uds.model.Errors> generateErrorResponseEntity(String errorCode, String errorMessage,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		Errors errorResponse = new Errors();
		com.directv.uds.model.Error error = new com.directv.uds.model.Error();
		errorResponse.getError().add(error);
		error.setCode(errorCode);
		error.setMessage(errorMessage);

		return new ResponseEntity<Errors>(errorResponse, headers, status);
	}
}
