package com.directv.uds.request.da;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

import com.directv.uds.model.UserDataConfiguration;

public class CbcfByDayMappingRequest {
	private static final String HBASE_DATE_FORMAT = "hbaseDateFormat";

	public final String DATE_FORMAT_PATTERN = com.directv.uds.utils.Configuration.getInstance().getString(HBASE_DATE_FORMAT);

	@DecimalMin(value = "-1", message = "{com.directv.uds.message.error.limit}")
	private int limit = -1;
	@NotNull(message = "{com.directv.uds.message.error.attribute.mandatory}")
	private String attribute;

	@NotNull(message = "{com.directv.uds.message.error.date.mandatory}")
	@DateTimeFormat(pattern = "yyyyMMdd")
	private DateTime date;

	@AssertTrue(message = "{com.directv.uds.message.error.attribute.value}")
	public boolean isAttributeValid() {
		if (attribute == null) {
			return false;
		}

		int index = UserDataConfiguration.ATTRIBUTES.getIndex(attribute);

		if (attribute != null && index == -1) {
			return false;
		} else {
			this.attribute = UserDataConfiguration.ATTRIBUTES.getValue(index);
			return true;
		}
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public DateTime getDate() {
		return date;
	}

	public void setDate(DateTime date) {
		this.date = date;
	}

	public String getDateString() {
		return date.toString(org.joda.time.format.DateTimeFormat.forPattern(DATE_FORMAT_PATTERN));
	}
}
