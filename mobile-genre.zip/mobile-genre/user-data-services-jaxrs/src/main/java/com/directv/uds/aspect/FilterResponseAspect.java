/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.aspect;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;

import com.directv.uds.aspect.listbuilder.integration.annotation.FilterResponseCaching;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.HttpCacheUtil;

/**
 * @author TungPT6
 */
@Aspect
public class FilterResponseAspect implements Ordered {

	@Autowired
	Configuration config;

	// private static final long TIME_MAX_AGE_DEFAULT = 10800000;
	private static final String SHORT_MAX_AGE_KEY = "shortMaxAge";

	/*
	 * Control the precedence of aspect. Aspect with higher precedence will come
	 * on first and come out last.
	 */
	private int order = 1;

	/**
	 * @param order
	 */
	public void setOrder(int order) {
		this.order = order;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.core.Ordered#getOrder()
	 */
	public int getOrder() {
		return order;
	}

	@Pointcut("execution(* *.*(..))&&" + "@annotation(org.springframework.web.bind.annotation.RequestMapping)")
	private void filterResponse() {
	}

	/**
	 * @param joinPoint
	 *            after go through End point, using filer response for add
	 *            Cache-Control
	 */
	@AfterReturning("filterResponse()")
	public void filterResponseCaching(JoinPoint joinPoint) {
		MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
		Method method = methodSignature.getMethod();
		Object[] args = joinPoint.getArgs();
		HttpServletResponse response = null;
		for (Object object : args) {
			if (object instanceof HttpServletResponse) {
				response = (HttpServletResponse) object;
			}
		}
		Annotation[][] pa = method.getParameterAnnotations();
		for (Annotation[] parameterAnnotations : pa) {
			for (Annotation annotation : parameterAnnotations) {
				if (annotation instanceof FilterResponseCaching) {
					if (response.getStatus() == HttpServletResponse.SC_OK) {
						long timeMaxAge = ((FilterResponseCaching) annotation).maxage();
						if (timeMaxAge != 0) {
							HttpCacheUtil.caching(response, timeMaxAge);
						} else {
							// HttpCacheUtil.caching(response,
							// config.getLong(SHORT_MAX_AGE_KEY,
							// TIME_MAX_AGE_DEFAULT));
							HttpCacheUtil.caching(response, config.getLong(SHORT_MAX_AGE_KEY));
						}
					}
				}
			}
		}
	}
}
