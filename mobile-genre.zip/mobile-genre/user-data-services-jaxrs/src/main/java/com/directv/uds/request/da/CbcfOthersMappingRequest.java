package com.directv.uds.request.da;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

import com.directv.uds.model.UserDataConfiguration;

public class CbcfOthersMappingRequest extends CbcfMappingRequest {
	@NotNull(message = "{com.directv.uds.message.error.attribute.mandatory}")
	private String attribute;

	@AssertTrue(message = "{com.directv.uds.message.error.attribute.value}")
	public boolean isAttributeValid() {
		if (attribute == null) {
			return false;
		}

		int index = UserDataConfiguration.ATTRIBUTES.getIndex(attribute);

		if (attribute != null && index == -1) {
			return false;
		} else {
			this.attribute = UserDataConfiguration.ATTRIBUTES.getValue(index);
			return true;
		}
	}

	public String getAttribute() {
		return attribute;
	}

	public void setAttribute(String attribute) {
		this.attribute = attribute;
	}
}
