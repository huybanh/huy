/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.aspect.listbuilder.integration.annotation;

import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * using annotations with spring aop for mark which End point want to response
 * include Cache-Control
 * 
 * @author TungPT6
 */
@Target(value = { FIELD, CONSTRUCTOR, METHOD, PARAMETER, TYPE })
@Retention(RetentionPolicy.RUNTIME)
public @interface FilterResponseCaching {
	public static final long TIME_MAX_AGE_DEFAULT = 0L;

	public long maxage() default TIME_MAX_AGE_DEFAULT;

}