package com.directv.uds.listener;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HConnection;
import org.apache.hadoop.hbase.client.HConnectionManager;
import org.apache.hadoop.security.UserGroupInformation;
import org.mortbay.log.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.directv.uds.dao.HBaseUtil;
import com.directv.uds.model.LocationInformation;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.service.ListBuilderIntegrationService;

@Component
public class UDSBeanProcessor {

	public static org.apache.hadoop.conf.Configuration CONFIGURATION;

	private static Logger LOGGER = LoggerFactory.getLogger(UDSBeanProcessor.class);

	private static final String JAVA_SECURITY_KRB5_REALM = "java.security.krb5.realm";
	private static final String JAVA_SECURITY_KRB5_KDC = "java.security.krb5.kdc";
	private static final String SUN_SECURITY_KRB5_DEBUG = "sun.security.krb5.debug";
	private static final String AUTHENTICATOR_CLASS = "authenticator.class";

	// Hbase details
	private static final String HBASE_ZOOKEEPER_QUORUM = "hbase.zookeeper.quorum";
	private static final String HBASE_ZOOKEEPER_QUORUM_CLIENTPORT = "hbase.zookeeper.property.clientPort";

	private UserGroupInformation ugi = null;

	private Configuration conf = null;
//	private HConnection conn = null;
//	private PoolMonitor monitor = null;
//	private ThreadPoolExecutor threadPool = null;

//	@Value("${com.directv.uds.hbase.pool.corePoolSize}")
//	private int corePoolSize;
//	@Value("${com.directv.uds.hbase.pool.maxPoolSize}")
//	private int maxPoolSize;
//	@Value("${com.directv.uds.hbase.pool.keepAliveTime}")
//	private int keepAliveTime;
//	@Value("${com.directv.uds.hbase.pool.monitorInterval}")
//	private int monitorInterval;

	@Value("${com.directv.uds.kerberos.keytab}")
	private String kerberosKeyTab;

	@Value("${com.directv.uds.kerberos.principal}")
	private String kerberosPrincipal;

	@Value("${com.directv.uds.hbase.client.maxidletime}")
	private int hbaseClientMaxIdleTime;

	@Autowired
	ServletContext servletContext;

	@Autowired
	private com.directv.uds.utils.Configuration config;

	@Autowired
	private ListBuilderIntegrationService listBuilderIntegrationService;

	@PostConstruct
	public void init() throws IOException {
		LOGGER.info("[init] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		//initKerberos();
		//kerberosKeytabLoginUsingKinit();

		conf = HBaseConfiguration.create();
		conf.setStrings(HBASE_ZOOKEEPER_QUORUM, config.getString(HBASE_ZOOKEEPER_QUORUM));
		conf.setStrings(HBASE_ZOOKEEPER_QUORUM_CLIENTPORT, config.getString(HBASE_ZOOKEEPER_QUORUM_CLIENTPORT));
		conf.setInt("hbase.ipc.client.connection.maxidletime", hbaseClientMaxIdleTime);

		// corePoolSize, maxPoolSize, keepAliveTime, TimeUnit, Queue
//		threadPool = new ThreadPoolExecutor(corePoolSize, maxPoolSize, keepAliveTime, TimeUnit.SECONDS,
//				new LinkedBlockingQueue<Runnable>(), Executors.defaultThreadFactory());
//		monitor = new PoolMonitor(threadPool, monitorInterval);
//		Thread t = new Thread(monitor);
//		t.setDaemon(true);
//		t.start();
		//UserDataConfiguration.CONFIGURATION = conf;
		HConnection hConnection = HConnectionManager.createConnection(conf);
		HBaseUtil.initialize(hConnection);

		try {
			UserDataConfiguration.load();
			UserDataConfiguration.loadRuleValueMapping();
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
	}

//	@PreDestroy
//	public void destroy() {
//		LOGGER.info("[destroy] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
//		if (conn != null)
//			try {
//				conn.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		if (threadPool != null)
//			threadPool.shutdown();
//		if (monitor != null)
//			monitor.shutdown();
//	}

	// private String systemPropertiyFile = "/myapp-system.properties";
	// private String ruleValueMappingFile = "/ruleValueMapping.txt";

	/*@Deprecated
	private void loadRuleFile() {
		// Phuong: Please check this method clearly (Because we shouldn't do
		// something like this for production)
		UserDataConfiguration.loadRuleValueMapping();
	}*/

	protected void initKerberos() throws IOException {
		LOGGER.debug("::::: Authenticating using UserGroupInformation.loginUserFromKeytab");
		// System.getProperties().load(getClass().getResourceAsStream(systemPropertiyFile));
		System.getProperties().setProperty(JAVA_SECURITY_KRB5_REALM, config.getString(JAVA_SECURITY_KRB5_REALM));
		System.getProperties().setProperty(JAVA_SECURITY_KRB5_KDC, config.getString(JAVA_SECURITY_KRB5_KDC));
		System.getProperties().setProperty(SUN_SECURITY_KRB5_DEBUG, config.getString(SUN_SECURITY_KRB5_DEBUG));
		System.getProperties().setProperty(AUTHENTICATOR_CLASS, config.getString(AUTHENTICATOR_CLASS));

		// String keytabPath = servletContext.getRealPath(kerberosKeyTab);
		Log.debug("keytabPath:" + kerberosKeyTab);

		UserGroupInformation.loginUserFromKeytab(kerberosPrincipal, kerberosKeyTab);
		ugi = UserGroupInformation.getLoginUser();
		LOGGER.debug("::::: Login successful using UserGroupInformation.loginUserFromKeytab: {}", ugi.toString());
	}

	public int kerberosKeytabLoginUsingKinit() {
		LOGGER.debug("::::: Authenticating using kerberosKeytabLoginUsingKinit");
		// String keytabPath = servletContext.getRealPath(kerberosKeyTab);
		String line = " kinit -k -t " + kerberosKeyTab + " " + kerberosPrincipal;
		CommandLine cmdLine = CommandLine.parse(line);
		DefaultExecutor executor = new DefaultExecutor();
		int exitValue = 0;

		try {
			exitValue = executor.execute(cmdLine);
			LOGGER.debug("::::: Login successful using kerberosKeytabLoginUsingKinit: {}", exitValue);
			return exitValue;
		} catch (IOException e) {
			LOGGER.debug("::::: failed Login using kerberosKeytabLoginUsingKinit: {}", exitValue);
			e.printStackTrace();
		}

		return exitValue;

	}

	/**
	 * every hours
	 */
	@Scheduled(fixedDelayString = "${com.directv.uds.kerberos.keytab.relogin.interval}")
	public void checkAndRelogin() {
		LOGGER.debug("[checkAndRelogin] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		if (ugi != null) {
			try {
				ugi.checkTGTAndReloginFromKeytab();
			} catch (IOException e) {
				LOGGER.error(e.getMessage());
			}
		}
		renewKerberosKeytabLoginUsingKinit();
	}

	/**
	 * every 4 minute
	 */
	@Scheduled(fixedDelayString = "${com.directv.uds.hbase.client.reconnect.interval}")
	public void reconnecthbase() {
		LOGGER.debug("[reconnecthbase] %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
		long startTime = System.currentTimeMillis();
		LocationInformation result = listBuilderIntegrationService.getLocationForHbaseReconnect("90503");
		LOGGER.debug("Total response time for hbase call is: {}", (System.currentTimeMillis() - startTime));
		if (result != null) {
			LOGGER.debug("reconnecthbase: DMA Description for zip code: 90503 is: {}", result.getDmaDescription());
		} else {
			LOGGER.debug("reconnecthbase: No Result Found");
		}
	}

	public int renewKerberosKeytabLoginUsingKinit() {
		String line = " kinit -R";

		CommandLine cmdLine = CommandLine.parse(line);

		DefaultExecutor executor = new DefaultExecutor();

		int exitValue = 0;

		try {

			exitValue = executor.execute(cmdLine);

		} catch (IOException e) {

			e.printStackTrace();

		}

		return exitValue;

	}

}
