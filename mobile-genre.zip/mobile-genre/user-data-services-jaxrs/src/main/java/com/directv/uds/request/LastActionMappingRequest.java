package com.directv.uds.request;

import javax.validation.constraints.AssertTrue;

import com.directv.uds.model.UserDataConfiguration;

public class LastActionMappingRequest extends CommonMappingRequest {

	private boolean groupBySubCategory = false;
	private String eventType;

	@AssertTrue(message = "{com.directv.uds.message.error.event.type}")
	public boolean isEventTypeValid() {

		if (eventType == null) {
			return true;
		}

		int index = UserDataConfiguration.EVENT_TYPES.getIndex(eventType);

		if (eventType != null && index == -1) {
			return false;
		} else {
			this.eventType = UserDataConfiguration.EVENT_TYPES.getValue(index);
			return true;
		}
	}

	public boolean isGroupBySubCategory() {
		return groupBySubCategory;
	}

	public void setGroupBySubCategory(boolean groupBySubCategory) {
		this.groupBySubCategory = groupBySubCategory;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
}
