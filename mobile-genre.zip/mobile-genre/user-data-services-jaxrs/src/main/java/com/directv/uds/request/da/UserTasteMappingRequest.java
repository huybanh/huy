package com.directv.uds.request.da;

import javax.validation.constraints.DecimalMin;

import com.directv.uds.request.CommonMappingRequest;

public class UserTasteMappingRequest extends CommonMappingRequest {

	@DecimalMin(value = "-1", message = "{com.directv.uds.message.error.limit}")
	private int limit = -1;
	
	private String platform;

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}
}
