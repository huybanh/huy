package com.directv.uds.aspect;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.core.Ordered;

import com.directv.uds.aspect.listbuilder.integration.annotation.CorrelationId;
import com.directv.uds.model.rs.getRule.Hardcoded;

@Aspect
public class CorrelationIdLoggerAspect implements Ordered {
	/*
	 * Control the precedence of aspect. Aspect with higher precedence will come
	 * on first and come out last.
	 */
	private int order = 1;

	/**
	 * @param order
	 */
	public void setOrder(int order) {
		this.order = order;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.core.Ordered#getOrder()
	 */
	public int getOrder() {
		return order;
	}

	//private Logger LOGGER;

	@Pointcut("execution(* *.*(..))&&" + "@annotation(com.directv.uds.aspect.listbuilder.integration.annotation.Loggable)")
	private void lbIntegrationService() {
	}

	@Before("lbIntegrationService()")
	public void logIntegrationId(JoinPoint joinPoint) {
		String correlationId = Hardcoded.CORRELATION_ID_DEFAULT;
		//LOGGER = LoggerFactory.getLogger(joinPoint.getTarget().getClass().getName());
		MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
		Method method = methodSignature.getMethod();
		Object[] args = joinPoint.getArgs();
		HttpServletResponse response = null;
		for (Object object : args) {
			if (object instanceof HttpServletResponse) {
				response = (HttpServletResponse) object;
			}
		}
		
		//do nothing if don't see response
		//we don't want to force all endpoints to this aspect
		if (response == null) {
			return;
		}
		
		Annotation[][] pa = method.getParameterAnnotations();
		int i = -1;
		for (Annotation[] parameterAnnotations : pa) {
			i++;
			for (Annotation annotation : parameterAnnotations) {
				if (annotation instanceof CorrelationId) {
					correlationId = joinPoint.getArgs()[i].toString();
				}
			}

		}

		MDC.put("transLogger", "DTV-CorrelationId : " + correlationId);
		response.addHeader("DTV-CorrelationId", correlationId);

	}

}
