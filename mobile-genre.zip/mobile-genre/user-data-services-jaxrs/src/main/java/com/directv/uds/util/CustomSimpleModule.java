/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.util;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.directv.uds.utils.DateUtils;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.StdScalarSerializer;

public class CustomSimpleModule extends SimpleModule {

	private static final long serialVersionUID = 2159610215889222596L;

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomSimpleModule.class);

	/**
	 * register serializers
	 */
	public CustomSimpleModule() {
		
		super("customized-simple-module");
		// enum serializer
		//addSerializer(Enum.class, new EnumSerializer(Enum.class));

		// Date serializer
		addSerializer(Date.class, new DateSerializer(Date.class));

		// Date Deserializer
		addDeserializer(Date.class, new DateDeserializer(Date.class));

		// XmlGregorianCalendar Serializer
		addSerializer(XMLGregorianCalendar.class, new XMLGregorianCalendarSerializer(XMLGregorianCalendar.class));

		// XmlGregorianCalendar Deserializer
		addDeserializer(XMLGregorianCalendar.class, new XMLGregorianCalendarDeserializer(XMLGregorianCalendar.class));

	}

	/**
	 * 
	 * class serializes enum by value() method instead of toString().
	 * <p>
	 * note that this only works with enum having value() method.
	 * 
	 */
	@SuppressWarnings("rawtypes")
	class EnumSerializer extends StdScalarSerializer<Enum> {

		protected EnumSerializer(Class<Enum> t) {
			super(t);
		}

		@Override
		public void serialize(Enum value, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonGenerationException {
			Method method;
			try {
				method = value.getClass().getMethod("value", new Class[] {});
				String enumValue = (String) method.invoke(value, new Object[] {});
				jgen.writeString(enumValue);
			} catch (Exception e) {
				LOGGER.error("Cannot serialize enum object: {}, error: {}", value, e);
				throw new IllegalArgumentException("Cannot serialize enum " + value.getClass());
			}
		}
	}

	/**
	 * 
	 * class serializes Date object based on XmlSchemaType.
	 * <p>
	 * if XmlSchemaType is datetime, date time format is used. <br>
	 * if XmlSchemaType is date, full date format is used.
	 * 
	 * @see http://tools.ietf.org/html/rfc3339#section-5.6
	 * 
	 */
	class DateSerializer extends StdScalarSerializer<Date> {

		protected DateSerializer(Class<Date> t) {
			super(t);
		}

		@Override
		public void serialize(Date date, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonGenerationException {
			jgen.writeString(DateUtils.dateToSimpleDateString(date));

		}

	}

	/**
	 * 
	 * class serializes Date object based on XmlSchemaType.
	 * <p>
	 * if XmlSchemaType is datetime, date time format is used. <br>
	 * if XmlSchemaType is date, full date format is used.
	 * 
	 * @see http://tools.ietf.org/html/rfc3339#section-5.6
	 * 
	 */
	class DateDeserializer extends StdScalarDeserializer<Date> {

		/**
		 * 
		 */
		private static final long serialVersionUID = -6571183492943852462L;

		protected DateDeserializer(Class<Date> t) {
			super(t);
		}

		@Override
		public Date deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
			String strDate = jp.getText();
			LOGGER.debug("deserialze date {} ", strDate);
			return DateUtils.simpleDateStringToDate(strDate);
		}

	}

	/**
	 * 
	 * class serializes for XMLGregorianCalendar
	 * 
	 */
	class XMLGregorianCalendarSerializer extends StdScalarSerializer<XMLGregorianCalendar> {

		protected XMLGregorianCalendarSerializer(Class<XMLGregorianCalendar> t) {
			super(t);
		}

		@Override
		public void serialize(XMLGregorianCalendar date, JsonGenerator jgen, SerializerProvider provider) throws IOException,
				JsonGenerationException {
			jgen.writeString(DateUtils.gregorianToString(date));

		}

	}

	/**
	 * 
	 * class Deserializer for XMLGregorianCalendar object.
	 * 
	 */
	class XMLGregorianCalendarDeserializer extends StdScalarDeserializer<XMLGregorianCalendar> {

		private static final long serialVersionUID = 5050154200652525716L;

		protected XMLGregorianCalendarDeserializer(Class<XMLGregorianCalendar> t) {
			super(t);
		}

		@Override
		public XMLGregorianCalendar deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
			String strDate = jp.getText();
			LOGGER.debug("deserialze date {} ", strDate);
			return DateUtils.stringToXMLGregoCalendar(strDate);
		}

	}

}
