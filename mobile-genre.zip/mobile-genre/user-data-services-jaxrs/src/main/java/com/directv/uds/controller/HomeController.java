/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.controller;

import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.directv.uds.common.BaseController;
import com.directv.uds.model.VersionUDS;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController extends BaseController {
	private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private ServletContext servletContext;

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		LOGGER.info("Welcome home! The client locale is {}." + locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	/**
	 * get version UDS
	 * 
	 * @return versionUDS
	 */
	@RequestMapping(value = "/version", method = RequestMethod.GET)
	public @ResponseBody
	VersionUDS getVersion() {
		VersionUDS versionUDS = null;
		if (versionUDS == null) {
			versionUDS = getPomVersion(servletContext, "/META-INF/maven/com.directv/user-data-services-jaxrs/pom.properties");
		}
		return versionUDS;
	}

	private static VersionUDS getPomVersion(ServletContext servletContext, String pomFile) {
		InputStream inputStream = servletContext.getResourceAsStream(pomFile);
		VersionUDS versionUDS = new VersionUDS();
		try {
			Properties prop = new Properties();
			prop.load(inputStream);
			versionUDS.setName(prop.getProperty("artifactId"));
			versionUDS.setVersion(prop.getProperty("version"));

		} catch (Exception e) {
			throw new RuntimeException("Cannot get app version", e);
		}
		return versionUDS;
	}

}
