/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.directv.uds.aspect.listbuilder.integration.annotation.CorrelationId;
import com.directv.uds.aspect.listbuilder.integration.annotation.FilterResponseCaching;
import com.directv.uds.aspect.listbuilder.integration.annotation.Loggable;
import com.directv.uds.common.BaseController;
import com.directv.uds.enums.ErrorCode;
import com.directv.uds.exceptions.DataNotFoundException;
import com.directv.uds.exceptions.InvalidRequestException;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.FrequencyStatisticsResponse;
import com.directv.uds.model.rs.response.UserTasteResponse;
import com.directv.uds.model.rs.response.WhatshotResponse;
import com.directv.uds.request.da.CbcfByDayMappingRequest;
import com.directv.uds.request.da.CbcfMappingRequest;
import com.directv.uds.request.da.CbcfOthersMappingRequest;
import com.directv.uds.request.da.RegionalWhatIsHotMappingRequest;
import com.directv.uds.request.da.UserTasteMappingRequest;
import com.directv.uds.request.da.WhatIsHotMappingRequest;
import com.directv.uds.service.ClusterMappingService;
import com.directv.uds.service.FrequencyStatisticsService;
import com.directv.uds.utils.Configuration;

@Controller
public class FrequencyStatisticsController extends BaseController {
	
	//private static final String CBCF_ATTRIBUTENAME_MOBILEGENRE = "MobileGenre";

	private static final String PLATFORM_MOBILE = "mobile";

	private static final Logger LOGGER = LoggerFactory.getLogger(FrequencyStatisticsController.class);

	@Autowired
	private ClusterMappingService clusterService;
	@Autowired
	private FrequencyStatisticsService freqService;
	
	@Autowired
	private Configuration config;

	/**
	 * Get the interest genre of the user. The three first genre is main
	 * category: Movies, TV, Sports. The rest is all sub category
	 * 
	 * Description
	 * 
	 */
	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/uvh/stats", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FrequencyStatisticsResponse> getFullFrequencyVector(@PathVariable String encryptedId,
			@Valid CbcfMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		String timeWindow = request.getTimeWindow();
		String mainCategory = request.getMainCategory();
		int limit = request.getLimit();
		boolean groupByWeekDay = request.isGroupByWeekday();
		String genreAttributeName = request.getGenreTypeConvertedToAttributeName(config);
		String rawUserId = getAccountId(encryptedId);

		FrequencyStatisticsResponse cbcfVector = freqService.getFullFrequencyVector(rawUserId, groupByWeekDay, mainCategory, genreAttributeName, limit, timeWindow);

		if (cbcfVector == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Cbcf values");
		}

		return new ResponseEntity<FrequencyStatisticsResponse>(cbcfVector, HttpStatus.OK);
	}

	/**
	 * Return only main category statistics
	 * 
	 * Description
	 * 
	 */
	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/uvh/stats/maincategory", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FrequencyStatisticsResponse> getMainCategoryFrequencyVector(@PathVariable String encryptedId,
			@Valid CbcfMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		String timeWindow = request.getTimeWindow();
		String mainCategory = request.getMainCategory();
		boolean groupByWeekDay = request.isGroupByWeekday();
		boolean percentage = request.isPercentage();
		String genreAttributeName = request.getGenreTypeConvertedToAttributeName(config);
		// get user id of given encryptedId
		String rawUserId = getAccountId(encryptedId);

		FrequencyStatisticsResponse cbcfVector = freqService.getMainCategoryFrequencyVector(
				rawUserId, percentage, groupByWeekDay, mainCategory, timeWindow, genreAttributeName);

		if (cbcfVector == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Cbcf of maincategory");
		}
		return new ResponseEntity<FrequencyStatisticsResponse>(cbcfVector, HttpStatus.OK);
	}

	/**
	 * Return sub category statistics.
	 * 
	 * Description
	 * 
	 */
	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/uvh/stats/subcategory", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FrequencyStatisticsResponse> getSubCategoryFrequencyVector(@PathVariable String encryptedId,
			@Valid CbcfMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		String timeWindow = request.getTimeWindow();
		String mainCategory = request.getMainCategory();
		int limit = request.getLimit();
		boolean groupByWeekDayBool = request.isGroupByWeekday();
		boolean percentageBool = request.isPercentage();
		String genreAttributeName = request.getGenreTypeConvertedToAttributeName(config);
		// get user id of given encrypted id
		String rawUserId = getAccountId(encryptedId);

		FrequencyStatisticsResponse cbcfVector = freqService.getSubCategoryFrequencyVector(
				rawUserId, percentageBool, groupByWeekDayBool, mainCategory, limit, timeWindow, genreAttributeName);

		if (cbcfVector == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Cbcf of genre");
		}

		return new ResponseEntity<FrequencyStatisticsResponse>(cbcfVector, HttpStatus.OK);
	}

	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/uvh/stats/others", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<FrequencyStatisticsResponse> getOthersSubCategoryFrequencyVector(@PathVariable String encryptedId,
			@Valid CbcfOthersMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		String mainCategory = request.getMainCategory();
		String timeWindow = request.getTimeWindow();
		String attribute = request.getAttribute();
		int limit = request.getLimit();
		boolean groupByWeekDayBool = request.isGroupByWeekday();
		boolean percentageBool = request.isPercentage();

		// get user id of given encrypted id
		String rawUserId = getAccountId(encryptedId);

		FrequencyStatisticsResponse cbcfVector = freqService.getOtherSubCategoryFrequencyVector(
				rawUserId, percentageBool, groupByWeekDayBool, attribute, mainCategory, limit, timeWindow);

		if (cbcfVector == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Cbcf of other attributes");
		}

		return new ResponseEntity<FrequencyStatisticsResponse>(cbcfVector, HttpStatus.OK);
	}

	/**
	 * Return sub category statistics.
	 * 
	 * Description
	 * 
	 */
	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/uvh/stats/cbcfbyday", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, List<FrequencyElement>>> getCbcfByDayVector(@PathVariable String encryptedId,
			@Valid CbcfByDayMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		String attribute = request.getAttribute();
		String dateString = request.getDateString();
		int limit = request.getLimit();

		// get user id of given encrypted id
		String rawUserId = getAccountId(encryptedId);

		Map<String, List<FrequencyElement>> cbcfVector = freqService.getCbcfByDayVector(rawUserId, false, attribute, dateString, limit);

		if (cbcfVector == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Cbcf-by-day");
		}

		return new ResponseEntity<Map<String, List<FrequencyElement>>>(cbcfVector, HttpStatus.OK);
	}

	@Loggable
	@ResponseBody
	@RequestMapping(value = "/users/usertaste/{encryptedId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<UserTasteResponse> getUserTaste(HttpServletRequest resquest, @FilterResponseCaching HttpServletResponse response,
			@PathVariable String encryptedId,
			@RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") @CorrelationId String correlationId,
			@Valid UserTasteMappingRequest request, BindingResult bindingResult) {

		// LOG.info("DTV-CorrelationId:"+correlationId);
		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		// parse and validate requested main category
		String mainCategory = request.getMainCategory();
		LOGGER.info("mainCategory: {}", mainCategory);
		int limit = request.getLimit();
		
		//attributeName
		String attributeName;
		String platform = request.getPlatform();
		if (platform != null && PLATFORM_MOBILE.equals(platform)) {
			attributeName = config.getString("genre.type.mobile");
		} else {
			attributeName = request.getGenreTypeConvertedToAttributeName(config);
		} 

		// get user id of given encrypted id
		String rawUserId = getAccountId(encryptedId);
		UserTasteResponse cbcfVector = freqService.getUserTaste(rawUserId, mainCategory, limit, attributeName);
		if (cbcfVector == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "User taste");
		}

		// HttpHeaders responseHeaders = new HttpHeaders();
		// responseHeaders.set("DTV-CorrelationId", correlationId);
		return new ResponseEntity<UserTasteResponse>(cbcfVector, HttpStatus.OK);
	}

	@Loggable
	@ResponseBody
	@RequestMapping(value = "/users/profile/{encryptedId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getProfile(@PathVariable String encryptedId) {
		return "{\"profile\": \"profileB\"}";
	}

	/*
	 * @Loggable
	 * 
	 * @ResponseBody
	 * 
	 * @RequestMapping(value = "/users/commonusertaste", method =
	 * RequestMethod.GET, produces = "application/json") public
	 * ResponseEntity<UserTasteResponse> getCommonTaste(HttpServletRequest
	 * resquest, HttpServletResponse response,
	 * 
	 * @RequestHeader(value = "DTV-CorrelationId", defaultValue = "default")
	 * 
	 * @CorrelationId String correlationId,
	 * 
	 * @Valid UserTasteMappingRequest request, BindingResult bindingResult) {
	 * 
	 * // LOG.info("DTV-CorrelationId:"+correlationId); if
	 * (bindingResult.hasErrors()) { throw new InvalidRequestException(null,
	 * bindingResult); }
	 * 
	 * int limit = request.getLimit();
	 * 
	 * UserTasteResponse cbcfVector = freqService.getCommonUserTaste(limit);
	 * 
	 * if (cbcfVector == null) {
	 * 
	 * throw new DataNotFoundException(ErrorCode.NOT_FOUND,
	 * "common user taste"); }
	 * 
	 * // HttpHeaders responseHeaders = new HttpHeaders(); //
	 * responseHeaders.set("DTV-CorrelationId", correlationId); return new
	 * ResponseEntity<UserTasteResponse>(cbcfVector, HttpStatus.OK); }
	 */

	/**
	 * 
	 * @param request
	 * @param response
	 * @param timeWindow
	 * @param regionId
	 * @param limit
	 * @param mainCategory
	 * @return
	 * @throws ParseException
	 */
	@ResponseBody
	@RequestMapping(value = "/users/whatishot", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<WhatshotResponse> getWhatIsHot(@FilterResponseCaching HttpServletResponse response,
			@Valid WhatIsHotMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		int limit = request.getLimit();
		String mainCategory = request.getMainCategory();
		String timeWindow = request.getTimeWindow();
		String regionId = request.getRegionId();
		DMAInformation dmaInformation = new DMAInformation();
		dmaInformation.setDma(regionId);
		// query hbase to get what-is-hot value of given mainCategory
		// build JSON response body from returned result
		WhatshotResponse wihResponse = freqService.getWhatIsHot(timeWindow, dmaInformation, limit, mainCategory);

		if (wihResponse == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "What'shot");
		}

		return new ResponseEntity<WhatshotResponse>(wihResponse, HttpStatus.OK);
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @param timeWindow
	 * @param regionId
	 * @param limit
	 * @param mainCategory
	 * @return
	 * @throws ParseException
	 */
	@Loggable
	@ResponseBody
	@RequestMapping(value = "/users/whatishot/{encryptedId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<WhatshotResponse> getWhatIsHotByRegion(HttpServletRequest resquest,
			@FilterResponseCaching HttpServletResponse response, @PathVariable String encryptedId,
			@RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") @CorrelationId String correlationId,
			@Valid RegionalWhatIsHotMappingRequest request, BindingResult bindingResult) {
		// LOG.info("DTV-CorrelationId:"+correlationId);
		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		DMAInformation dmaInformation = null;
		int limit = request.getLimit();
		String mainCategory = request.getMainCategory();
		boolean region = request.isRegion();
		String timeWindow = request.getTimeWindow();

		if (region == true) {
			dmaInformation = clusterService.getRegionIdFromAccountId(encryptedId);

			if (dmaInformation == null) {
				throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Region id");
			}
		}
		WhatshotResponse wihResponse = freqService.getWhatIsHot(timeWindow, dmaInformation, limit, mainCategory);

		if (wihResponse == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "What'shot");
		}
		// HttpHeaders responseHeaders = new HttpHeaders();
		// responseHeaders.set("DTV-CorrelationId", correlationId);
		return new ResponseEntity<WhatshotResponse>(wihResponse, HttpStatus.OK);
	}

	private String getAccountId(String encryptedId) {
		String accountId = clusterService.getUserDecryptedId(encryptedId);
		if (accountId == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Encrypted Id");

		}
		return accountId;
	}

	/**
	 * @return the clusterService
	 */
	public ClusterMappingService getClusterService() {
		return clusterService;
	}

	/**
	 * @param clusterService
	 *            the clusterService to set
	 */
	public void setClusterService(ClusterMappingService clusterService) {
		this.clusterService = clusterService;
	}

	/**
	 * @return the freqService
	 */
	public FrequencyStatisticsService getFreqService() {
		return freqService;
	}

	/**
	 * @param freqService
	 *            the freqService to set
	 */
	public void setFreqService(FrequencyStatisticsService freqService) {
		this.freqService = freqService;
	}

}
