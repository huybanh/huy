package com.directv.uds.aspect.listbuilder.integration.annotation;

public @interface Loggable {

}
