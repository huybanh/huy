/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.directv.uds.aspect.listbuilder.integration.annotation.FilterResponseCaching;
import com.directv.uds.common.BaseController;
import com.directv.uds.enums.ErrorCode;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.exceptions.DataNotFoundException;
import com.directv.uds.exceptions.InvalidRequestException;
import com.directv.uds.model.Account;
import com.directv.uds.model.EventTime;
import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.model.LastAction;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.request.LastActionMappingRequest;
import com.directv.uds.request.UserMappingRequest;
import com.directv.uds.request.UvhMappingRequest;
import com.directv.uds.service.ClusterMappingService;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.InputParameterUtil;

/**
 * 
 * <H3>ClusterResultController</H3>. <html>
 * <p>
 * Controller which listen to request from users corresponding to all Get users'
 * encrypted id and behavior APIs
 * </p>
 * </html>
 * 
 * @author TuTX1
 * @since Jun 17, 2014
 */
@Controller
public class ClusterResultController extends BaseController {
	private static final Logger LOG = LoggerFactory.getLogger(ClusterResultController.class);

	@Autowired
	private ClusterMappingService clusterService;

	@Autowired
	private Configuration config;

	/**
	 * Get the list of users descending ordered by activeness which is measured
	 * by the number of their events. This service support pagination
	 * 
	 * Description
	 * 
	 * @param request
	 * @param response
	 * @param offset
	 *            : the index of the first item in result
	 * @param limit
	 *            : the number of item to be returned by the service
	 * @return String
	 * @throws ParseException
	 */
	@ResponseBody
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public ResponseEntity<List<String>> getUsers(@FilterResponseCaching HttpServletResponse response, @Valid UserMappingRequest request,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		// create a ClusterMappingService to get users
		int resultStartInt = request.getOffset();
		int resultEndInt = request.getLimit();

		List<String> accounts = clusterService.getUsers(resultStartInt, resultEndInt);
		if (accounts == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Account list");
		}

		return new ResponseEntity<List<String>>(accounts, HttpStatus.OK);
	}

	/**
	 * Get the encrypted id associated with the account id.
	 * 
	 * Description
	 * 
	 * @param request
	 * @param response
	 * @param accountId
	 *            : userId of user
	 * @return String: json response
	 * @throws ParseException
	 */
	@ResponseBody
	@RequestMapping(value = "/users/encrypt/{accountId}", method = RequestMethod.GET)
	public ResponseEntity<String> getUserEncryptedId(@FilterResponseCaching HttpServletResponse response, @PathVariable String accountId) {
		LOG.info("requested for getUserEncryptedId: {}", accountId);

		// get encrypted id of given user id
		String encryptedValue = clusterService.getUserEncryptedId(accountId);
		if (encryptedValue == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Account Id");
		}

		return new ResponseEntity<String>(encryptedValue, HttpStatus.OK);

	}

	/**
	 * Get the account id from the encrypted id.
	 * 
	 * Description
	 * 
	 * @param request
	 * @param response
	 * @param encryptedId
	 *            : encrypted id of user
	 * @return
	 * @throws ParseException
	 */
	@ResponseBody
	@RequestMapping(value = "/users/decrypt/{encryptedId}", method = RequestMethod.GET)
	public ResponseEntity<String> getUserDecryptedId(@FilterResponseCaching HttpServletResponse response, @PathVariable String encryptedId) {
		LOG.info("requested for getUserDecryptedId: {} ", encryptedId);

		// get account id of given user id
		String accountId = getAccountId(encryptedId);
		return new ResponseEntity<String>(accountId, HttpStatus.OK);
	}

	/**
	 * Return account id and its associated encrypted id by card id.
	 * 
	 * Description
	 * 
	 * @param request
	 * @param response
	 * @param cardId
	 *            : card id associated with account id from table
	 *            cardidtoaccountidmapping
	 * @return
	 * @throws ParseException
	 */
	@ResponseBody
	@RequestMapping(value = "/cards/{cardId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Account> getAccountIdFromCardId(@PathVariable String cardId, @FilterResponseCaching HttpServletResponse response) {
		LOG.info("requested for getAccountIdFromCardId: {}", cardId);

		// get account object of given card id
		Account account = clusterService.getAccountFromCardId(cardId);
		if (account == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Card id");
		}

		return new ResponseEntity<Account>(account, HttpStatus.OK);
	}

	/**
	 * Return viewing history of given user
	 * 
	 * Description
	 * 
	 * @param request
	 * @param response
	 * @param encryptedId
	 *            : encrypted id of user
	 * @param startTime
	 *            : start time of program
	 * @param endTime
	 *            : end time of program
	 * @param removeDuplicates
	 *            : if true then remove duplicated tmsId and contrast
	 * @param mainCategory
	 *            : requested main category when mainCategory = null, it means
	 *            return last action of all main category
	 * @return responseBody string in json format
	 * @throws ParseException
	 * @throws BadRequestException
	 */
	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/uvh", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, List<InterpretedEvent>>> getUserViewingHistory(@FilterResponseCaching HttpServletResponse response,
			@PathVariable String encryptedId, @Valid UvhMappingRequest request, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		EventTime eventTime = new EventTime(request.getStartTime(), request.getEndTime());
		int defaultRangeLength = config.getInt("uvh.rangelength.default", 7);
		InputParameterUtil.parseEventDate(UserDataConfiguration.DTV_DATE_TIME_FORMAT, UserDataConfiguration.HBASE_DATE_TIME_FORMAT,
				UserDataConfiguration.HBASE_DATE_FORMAT, eventTime, defaultRangeLength);

		int offsetInt = request.getOffset();
		int limitInt = request.getLimit();
		boolean duplicatesValue = request.getRemoveDuplicates();
		String mainCategory = request.getMainCategory();
		String rawUserId = getAccountId(encryptedId);

		Map<String, List<InterpretedEvent>> viewingHistory = clusterService.getUserViewingHistory(rawUserId, mainCategory, offsetInt,
				limitInt, duplicatesValue, true, eventTime);

		if (viewingHistory == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Viewing history");
		}

		return new ResponseEntity<Map<String, List<InterpretedEvent>>>(viewingHistory, HttpStatus.OK);

	}

	@ResponseBody
	@RequestMapping(value = "/users/{encryptedId}/lastaction", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, Map<String, List<LastAction>>>> getLastAction(@FilterResponseCaching HttpServletResponse response,
			@PathVariable String encryptedId, @Valid LastActionMappingRequest request, BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		// parse and validate mainCategory
		String mainCategory = request.getMainCategory();
		String eventType = request.getEventType();
		boolean groupBySubCategoryBool = request.isGroupBySubCategory();

		// get user id of give encryptedId
		String rawUserId = getAccountId(encryptedId);

		Map<String, Map<String, List<LastAction>>> lastAction = clusterService.getLastActionGeneric(rawUserId, mainCategory, eventType, groupBySubCategoryBool);
		if (lastAction == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Last action");
		}

		return new ResponseEntity<Map<String, Map<String, List<LastAction>>>>(lastAction, HttpStatus.OK);
	}

	private String getAccountId(String encryptedId) {
		String accountId = clusterService.getUserDecryptedId(encryptedId);
		if (accountId == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Encrypted Id");

		}
		return accountId;
	}

	/**
	 * @return the service
	 */
	public ClusterMappingService getService() {
		return clusterService;
	}

	/**
	 * @param service
	 *            the service to set
	 */
	public void setService(ClusterMappingService service) {
		this.clusterService = service;
	}

}
