/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.validate;

import java.util.Set;

import javax.validation.Configuration;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpStatus;

import com.directv.common.validation.CustomResourceBundleInterpolator;
import com.directv.common.validation.CustomTraversableResolver;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.model.Error;
import com.directv.uds.model.Errors;

/**
 * 
 * wrapper of jsr 303 validator, used to validate request object (bean).
 * 
 * @author TungPT6
 * 
 */
public class RequestValidator {
	/**
	 * validator.
	 */
	private javax.validation.Validator validator;

	/**
	 * Default constructor, initialized validator.
	 */
	RequestValidator() {
		/**
		 * use custom resource bundle to allow reading message from properties
		 * file using configuration util.
		 * <p>
		 * Call the dummy CustomTraversableResolver, so that JPA won't be
		 * loaded.
		 */
		Configuration<?> config = Validation.byDefaultProvider().configure().messageInterpolator(new CustomResourceBundleInterpolator())
				.traversableResolver(new CustomTraversableResolver());

		ValidatorFactory fact = config.buildValidatorFactory();
		validator = fact.getValidator();
	};

	/**
	 * validate object.
	 * 
	 * @param reqParamObj
	 *            object to be validated.
	 */
	public void validate(Object reqParamObj) {
		Set<ConstraintViolation<Object>> errorSet = validator.validate(reqParamObj);
		if (CollectionUtils.isEmpty(errorSet)) {
			return;
		}

		Errors errors = new Errors();
		for (ConstraintViolation<?> violation : errorSet) {
			String message = violation.getMessage() != null ? violation.getMessage() : HttpStatus.BAD_REQUEST.toString();
			Error error = new Error();
			error.setCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
			error.setMessage(message);
			errors.getError().add(error);
		}
		throw new BadRequestException(errors);
	}
}
