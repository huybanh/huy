package com.directv.uds.request;

import javax.validation.constraints.AssertTrue;

import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.service.FrequencyStatisticsService;
import com.directv.uds.utils.Configuration;

public class CommonMappingRequest {
	
	private static final String GENRETYPE_DTV = "dtv";
	private static final String GENRETYPE_TMS = "tms";

	private String mainCategory;
	
	private String genreType;

	@AssertTrue(message = "{com.directv.uds.message.error.main.category}")
	public boolean isMainCategoryValid() {

		if (mainCategory == null) {
			return true;
		}

		int index = UserDataConfiguration.MAIN_CATEGORIES.getIndex(mainCategory);

		if (mainCategory != null && index == -1) {
			return false;
		} else {
			this.mainCategory = UserDataConfiguration.MAIN_CATEGORIES.getValue(index);
			return true;
		}
	}

	public String getMainCategory() {
		return mainCategory;
	}

	public void setMainCategory(String mainCategory) {
		this.mainCategory = mainCategory;
	}

	public String getGenreType() {
		return genreType;
	}

	public void setGenreType(String genreType) {
		this.genreType = genreType;
	}

	@AssertTrue(message = "Invalid genreType")
	public boolean isGenreTypeValid() {
		
		return this.genreType == null || this.genreType.equals("") ||
				GENRETYPE_DTV.equals(this.genreType) || GENRETYPE_TMS.equals(this.genreType);
	}

	public String getGenreTypeConvertedToAttributeName(Configuration config) {
		if (this.genreType == null || "".equals(genreType)) {
			//return null;
			return config.getString(FrequencyStatisticsService.GENRE_TYPE_DEFAULT);
		}
		
		if (GENRETYPE_DTV.equals(this.genreType)) {
			return config.getString(FrequencyStatisticsService.GENRE_TYPE_DTV);
		} else if (GENRETYPE_TMS.equals(this.genreType)) {
			return config.getString(FrequencyStatisticsService.GENRE_TYPE_TMS);
		} else {
			throw new BadRequestException("Unknown genre type: " + this.genreType);
		}
	}
}
