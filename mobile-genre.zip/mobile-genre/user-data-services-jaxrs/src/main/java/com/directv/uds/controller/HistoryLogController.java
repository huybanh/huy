/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc("Proprietary Information")Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software
 *****************************************************************************
 */
package com.directv.uds.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.directv.uds.aspect.listbuilder.integration.annotation.FilterResponseCaching;
import com.directv.uds.common.BaseController;
import com.directv.uds.enums.ErrorCode;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.exceptions.DataNotFoundException;
import com.directv.uds.model.RecommendationJobHistory;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.service.HistoryLogService;
import com.directv.uds.utils.InputParameterUtil;

@Controller
public class HistoryLogController extends BaseController {

	@Autowired
	private HistoryLogService historyLogService;

	/***
	 * Get job history from startTime to endTime. If latest == true then get the
	 * latest job history from startTime to endTime
	 * 
	 * @param resquest
	 * @param response
	 * @param startTime
	 * @param endTime
	 * @param latest
	 *            : choose to get latest job history or a list of job history
	 *            from a period of time.If latest == true then get the latest
	 *            job history from startTime to endTime
	 * @return
	 * @throws ParseException
	 * @throws BadRequestException
	 */
	@ResponseBody
	@RequestMapping(value = "/rjh/getJob", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Map<String, List<RecommendationJobHistory>>> getRecommendationJobHistory(HttpServletRequest resquest,
			@FilterResponseCaching HttpServletResponse response, @RequestParam(value = "startTime", required = true) String startTime,
			@RequestParam(value = "endTime", required = true) String endTime,
			@RequestParam(value = "latest", required = false) String latest) {

		// HttpCacheUtil.caching(response, UserDataConfiguration.SHORT_MAX_AGE);
		boolean doLatest = true;
		// validate input parameter
		InputParameterUtil.parseDateValue(UserDataConfiguration.RJH_INPUT_DATE_TIME_FORMAT, startTime);
		InputParameterUtil.parseDateValue(UserDataConfiguration.RJH_INPUT_DATE_TIME_FORMAT, endTime);

		DateTime start = UserDataConfiguration.RJH_INPUT_DATE_TIME_FORMAT.parseDateTime(startTime);
		DateTime end = UserDataConfiguration.RJH_INPUT_DATE_TIME_FORMAT.parseDateTime(endTime);

		startTime = start.toString(UserDataConfiguration.HBASE_DATE_TIME_FORMAT);
		endTime = end.toString(UserDataConfiguration.HBASE_DATE_TIME_FORMAT);
		doLatest = InputParameterUtil.parseBooleanValue(latest, true);

		// get Job history from HBASE
		Map<String, List<RecommendationJobHistory>> result = historyLogService.getRecommendationJobHistory(startTime, endTime, doLatest);
		if (result == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "recommendation job history");
		}

		return new ResponseEntity<Map<String, List<RecommendationJobHistory>>>(result, HttpStatus.OK);
	}

	/**
	 * @return the historyLogService
	 */
	public HistoryLogService getHistoryLogService() {
		return historyLogService;
	}

	/**
	 * @param historyLogService
	 *            the historyLogService to set
	 */
	public void setHistoryLogService(HistoryLogService historyLogService) {
		this.historyLogService = historyLogService;
	}

}