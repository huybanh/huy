package com.directv.uds.request;

import javax.validation.constraints.DecimalMin;

public class UvhMappingRequest extends CommonMappingRequest {

	private String startTime;
	private String endTime;
	private boolean removeDuplicates = true;

	@DecimalMin(value = "0", message = "{com.directv.uds.message.error.offset}")
	private int offset = 0;
	@DecimalMin(value = "1", message = "{com.directv.uds.message.error.limit}")
	private int limit = 10;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public boolean getRemoveDuplicates() {
		return removeDuplicates;
	}

	public void setRemoveDuplicates(boolean removeDuplicates) {
		this.removeDuplicates = removeDuplicates;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}
}
