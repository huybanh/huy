/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2013 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.uds.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.directv.uds.utils.DateUtils;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationConfig;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;

public class CustomJackson2ObjectMapper extends ObjectMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomJackson2ObjectMapper.class);

	private static final long serialVersionUID = 2871273829940847847L;

	public CustomJackson2ObjectMapper() {
		super();
		SerializationConfig serializationConfig = getSerializationConfig();
		setSerializationInclusion(Include.NON_NULL);
		/**
		 * Not enabled WRAP_ROOT_VALUE value because it is causing issue in client
		 * side i.e. OAuth2RestTemplate.
		 * 
		 */
		// enable(SerializationFeature.WRAP_ROOT_VALUE);
		disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		setDateFormat(DateUtils.getDefaultDateFormat());
		AnnotationIntrospector secondary = new JaxbAnnotationIntrospector();
		getDeserializationConfig().withAppendedAnnotationIntrospector(secondary);
		serializationConfig.withAppendedAnnotationIntrospector(secondary);

		registerModule(new CustomSimpleModule());
		LOGGER.debug("instantiate new object mapper to filter empty json field, apply ISO8601 date format, wrap root value, serialize enum");
	}

}