package com.directv.uds.interceptor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class RequestProcessingInterceptor extends HandlerInterceptorAdapter {

	private static final Logger LOGGER = LoggerFactory.getLogger(RequestProcessingInterceptor.class);
	private static final String REGEX = "[\\r\\n]+\\s+";

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		long startTime = System.currentTimeMillis();
		LOGGER.info("Request URL::{}:: Start Time={}", request.getRequestURL().toString(), System.currentTimeMillis());
		request.setAttribute("startTime", startTime);

		// Add payload in Log.
		/*String payload = getPayload(request).toString().replaceAll(REGEX, StringUtils.EMPTY);
		if (!payload.isEmpty()) {
			LOGGER.debug("Payload: {}", payload);
		}*/

		// if returned false, we need to make sure 'response' is sent
		return true;
	}

	private static StringBuilder getPayload(HttpServletRequest request) throws IOException {
		StringBuilder stringBuilder = new StringBuilder();
		BufferedReader bufferedReader = null;

		try {
			InputStream inputStream = request.getInputStream();
			if (inputStream != null) {
				bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
				char[] charBuffer = new char[128];
				int bytesRead = -1;
				while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
					stringBuilder.append(charBuffer, 0, bytesRead);
				}
			} else {
				stringBuilder.append(StringUtils.EMPTY);
			}
		} catch (IOException ex) {
			throw ex;
		} finally {
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException ex) {
					throw ex;
				}
			}
		}
		return stringBuilder;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		long startTime = (Long) request.getAttribute("startTime");
		LOGGER.info("Request URL::{}:: Time Taken={}", request.getRequestURL().toString(), (System.currentTimeMillis() - startTime));
		LOGGER.info("Response: {}", response.getStatus());
	}

}