package com.directv.uds.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.directv.uds.aspect.listbuilder.integration.annotation.CorrelationId;
import com.directv.uds.aspect.listbuilder.integration.annotation.FilterResponseCaching;
import com.directv.uds.aspect.listbuilder.integration.annotation.Loggable;
import com.directv.uds.common.BaseController;
import com.directv.uds.enums.ErrorCode;
import com.directv.uds.exceptions.BadRequestException;
import com.directv.uds.exceptions.DataNotFoundException;
import com.directv.uds.exceptions.InjectException;
import com.directv.uds.exceptions.InvalidRequestException;
import com.directv.uds.listbuilder.model.ListBuilderDeltaListing;
import com.directv.uds.listbuilder.model.ListBuilderFullListing;
import com.directv.uds.listbuilder.model.ListbuilderConfig;
import com.directv.uds.listbuilder.model.RuleSet;
import com.directv.uds.model.CreditResponse;
import com.directv.uds.model.LocationInformation;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.model.rs.request.UdsRulePayload;
import com.directv.uds.model.rs.response.LastActionResponse;
import com.directv.uds.model.rs.response.PreviewResponse;
import com.directv.uds.request.UserMappingRequest;
import com.directv.uds.service.ClusterMappingService;
import com.directv.uds.service.FrequencyStatisticsService;
import com.directv.uds.service.ListBuilderIntegrationService;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.InputParameterUtil;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;
import com.dtv.lastaction.listbuilderintegration.dto.LARuleType;
//import com.directv.uds.model.DMAInformation;
//import com.directv.uds.model.rs.getRule.request.RuleDataRequest;
//import com.directv.uds.model.rs.getRule.response.RuleDataResponse;
//import com.directv.uds.utils.JSONUtil;

/***
 * 
 * @author ThanhNN2
 * 
 */
@Controller
public class ListBuilderIntegrationController extends BaseController {
	private static final Logger LOGGER = LoggerFactory.getLogger(ListBuilderIntegrationController.class);

	private static final String MAIN_CATEGORY = "mainCategory";
	private static final String CREDIT_TYPE = "creditType";
	private final String IS_VALID_TIMEZONE_FORMAT = "com.directv.uds.valid.timezone.format";

	@Autowired
	private ListBuilderIntegrationService listBuilderIntegrationService;

	@Autowired
	private ClusterMappingService accountService;

	@Autowired
	private FrequencyStatisticsService freqService;

	@Autowired
	private ApplicationContext appContext;

	@Autowired
	private Configuration config;

	/**
	 * 
	 * @param resquest
	 * @param response
	 * @param jsonRules
	 * @param encryptedId
	 * @param correlationId
	 * @return
	 * @throws InjectException
	 * @throws BadRequestException
	 */
	@Loggable
	@ResponseBody
	@RequestMapping(value = "/rules/preview/{encryptedId}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<PreviewResponse> previewRule(HttpServletRequest resquest, @FilterResponseCaching HttpServletResponse response,
			@RequestBody RuleSet rules, @PathVariable String encryptedId,
			@CorrelationId @RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") String correlationId,
			BindingResult bindingResult) {

		// LOG.info("DTV-CorrelationId:"+correlationId);

		// validate input parameters
		// ListBuilderDeltaListing deltaPayLoad =
		// listBuilderRoot.getListBuilderDeltaListing();
		// ListBuilderFullListing fullPayLoad =
		// listBuilderRoot.getListBuilderFullListing();

		if (rules == null) {
			throw new InvalidRequestException(null, bindingResult);
		}

		String accountId = accountService.getUserDecryptedId(encryptedId);
		if (accountId == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Account");
		}

		PreviewResponse result = listBuilderIntegrationService.getRuleResponse(rules, accountId);

		if (result == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Rule result");
		}

		return new ResponseEntity<PreviewResponse>(result, HttpStatus.OK);
	}

	/**
	 * Publish service.
	 * 
	 * @param resquest
	 * @param response
	 * @param jsonRules
	 * @param correlationId
	 * @return
	 * @throws InjectException
	 * @throws BadRequestException
	 */
	@Loggable
	@ResponseBody
	@RequestMapping(value = "/rules/publish", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> publishRule(HttpServletRequest request, @FilterResponseCaching HttpServletResponse response,
			@RequestBody ListbuilderConfig listBuilderRoot,
			@CorrelationId @RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") String correlationId) {
		// LOG.info("DTV-CorrelationId:"+correlationId);

		if (listBuilderRoot == null) {
			throw new BadRequestException("Bad request body.");
		}
		ListBuilderDeltaListing deltaPayLoad = listBuilderRoot.getListBuilderDeltaListing();
		ListBuilderFullListing fullPayLoad = listBuilderRoot.getListBuilderFullListing();
		String serverLocation = request.getLocalAddr() + ":" + request.getLocalPort();

		if (deltaPayLoad == null && fullPayLoad == null) {
			throw new BadRequestException("Bad request body.");
		} else if (deltaPayLoad == null && fullPayLoad != null) {
			listBuilderIntegrationService.processFullPayLoad(fullPayLoad, serverLocation);
		} else if (deltaPayLoad != null) {
			List<LARule> rules = listBuilderIntegrationService.processDeltaPayLoad(deltaPayLoad, serverLocation);
			// List<String> jobIds =
			// listBuilderIntegrationService.processOozieJob(rules);
			// LOG.debug("'jobs ids: " + jobIds);
			List<LARule> larules = new ArrayList<LARule>();
			if (rules != null) {
				Iterator<LARule> iterator = rules.iterator();
				while (iterator.hasNext()) {
					LARule laRule = (LARule) iterator.next();
					LARuleType type = laRule.getRuleType();

					if (laRule.getRuleType() == LARuleType.LAST_PURCHASE) {
						larules.add(laRule);
					} else if (laRule.getRuleType() == LARuleType.LAST_WATCH) {
						larules.add(laRule);
					} else if (laRule.getRuleType() == LARuleType.LAST_RECORD) {
						larules.add(laRule);
					} else if (laRule.getRuleType() == LARuleType.LAST_RATE) {
						larules.add(laRule);
					} else if (laRule.getRuleType() == LARuleType.CREDIT) {
						// check if ruleType=CREDIT Not to submit Oozie job
						LOGGER.debug("Not to submit Oozie job on publishing CREDIT rule: {}", type);
					} else {
						LOGGER.debug("Ingnored other than LAST_ACTION rule: {}", type);
					}

				}

			}
			rules = null;
			if (larules.size() > 0) {
				List<String> jobIds = listBuilderIntegrationService.processOozieJob(larules, true);
				LOGGER.debug("'jobs ids: {}", jobIds);
			} else {
				LOGGER.debug("No rules found in rule file");
			}
		}

		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

	/**
	 * List Rules service.
	 * 
	 * @param resquest
	 * @param response
	 * @return String: json response
	 * @throws ParseException
	 */
	@Loggable
	@ResponseBody
	@RequestMapping(value = "/rules/listRules", method = RequestMethod.GET)
	public ResponseEntity<List<LARule>> listRule(@FilterResponseCaching HttpServletResponse response, @Valid UserMappingRequest request,
			BindingResult bindingResult) {

		if (bindingResult.hasErrors()) {
			throw new InvalidRequestException(null, bindingResult);
		}

		List<LARule> rules = listBuilderIntegrationService.listRules();

		if (rules == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "rule list");
		}

		return new ResponseEntity<List<LARule>>(rules, HttpStatus.OK);
	}

	/**
	 * 
	 * @param resquest
	 * @param response
	 * @param correlationId
	 * @param encryptedId
	 * @param ruleName
	 * @return
	 * @throws InjectException
	 * @throws BadRequestException
	 */
	@Loggable
	@ResponseBody
	@RequestMapping(value = "/users/lastaction/{encryptedId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<LastActionResponse> lastActionForOneRule(HttpServletRequest resquest,
			@FilterResponseCaching HttpServletResponse response,
			@RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") @CorrelationId String correlationId,
			@PathVariable String encryptedId, @RequestParam(value = "ruleName", required = true) String[] ruleName)
			throws BadRequestException {
		// LOG.info("DTV-CorrelationId:"+correlationId);

		// validate input parameters
		List<UdsRulePayload> udsRulePayload = new ArrayList<UdsRulePayload>();
		for (String rule : ruleName) {
			InputParameterUtil.parseString(rule);
			udsRulePayload.add(new UdsRulePayload(rule));
		}

		InputParameterUtil.parseString(encryptedId);
		UdsRulePayload[] payload = udsRulePayload.toArray(new UdsRulePayload[0]);

		// get account id of given user id
		String accountId = accountService.getUserDecryptedId(encryptedId);
		if (accountId == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Token");
		}

		LastActionResponse result = listBuilderIntegrationService.getLastActionByRule(accountId, payload);

		if (result == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Last action for " + encryptedId);
		} else if (result.getLastAction().size() == ruleName.length) {
			return new ResponseEntity<LastActionResponse>(result, HttpStatus.OK);
		} else {
			return new ResponseEntity<LastActionResponse>(result, HttpStatus.ACCEPTED);
		}
	}

	/**
	 * 
	 * @param resquest
	 * @param response
	 * @param correlationId
	 * @param tokenId
	 * @param creditType
	 * @return
	 * @throws InjectException
	 * @throws BadRequestException
	 */
	@Loggable
	@ResponseBody
	@RequestMapping(value = "/users/credit/{tokenId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CreditResponse> fanOfActorForRule(HttpServletRequest resquest,
			@FilterResponseCaching HttpServletResponse response,
			@RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") @CorrelationId String correlationId,
			@PathVariable String tokenId) throws BadRequestException {

		String creditType = resquest.getParameter(CREDIT_TYPE);
		Set<String> creditTypePayload = new HashSet<String>();
		if (creditType == null) {
			creditTypePayload = new HashSet<String>(Arrays.asList(config.getStringArray(CREDIT_TYPE)));
		} else {
			// validate input parameters
			InputParameterUtil.parseString(creditType);
			creditTypePayload.add(creditType);
		}

		// get account id of given user id
		String accountId = accountService.getUserDecryptedId(tokenId);
		if (accountId == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Token");
		}
		InputParameterUtil.parseString(tokenId);

		CreditResponse result = listBuilderIntegrationService.getCreditData(accountId, creditTypePayload,
				resquest.getParameter(MAIN_CATEGORY));

		if (result == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Credit for " + tokenId);
		} else {
			return new ResponseEntity<CreditResponse>(result, HttpStatus.OK);
		}
	}

	@Loggable
	@ResponseBody
	@RequestMapping(value = "/location/{zipCode}", method = RequestMethod.GET)
	public ResponseEntity<LocationInformation> getLocation(HttpServletRequest resquest,
			@FilterResponseCaching HttpServletResponse response,
			@CorrelationId @RequestHeader(value = "DTV-CorrelationId", defaultValue = "default") String correlationId,
			@PathVariable String zipCode) throws BadRequestException {

		// LOG.info("DTV-CorrelationId: {}", correlationId);
		if(zipCode.length() > UserDataConfiguration.ZIP_CODE_LENGTH + 1 /*flips code*/) {
			throw new BadRequestException("Zipcode is too long.");
		}
		LocationInformation result = listBuilderIntegrationService.getLocation(zipCode);

		if (result == null) {
			throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Location for the zipcode " + zipCode);
		}

		result.setTimeZoneOffset(listBuilderIntegrationService.getTimezoneOffset(result.getTimeZone(),
				config.getBoolean(IS_VALID_TIMEZONE_FORMAT)));

		return new ResponseEntity<LocationInformation>(result, HttpStatus.OK);
	}

	/**
	 * get combination result from last action, user taste and what's hot
	 * 
	 * @param resquest
	 * @param response
	 * @param correlationId
	 * @param encryptedId
	 * @param jsonPayload
	 * @return
	 * @throws InjectException
	 * @throws BadRequestException
	 */
	/*
	 * @Loggable
	 * 
	 * @ResponseBody
	 * 
	 * @RequestMapping(value = "/users/ruledata/{encryptedId}", method =
	 * RequestMethod.POST) public ResponseEntity<RuleDataResponse>
	 * getRuleData(HttpServletRequest resquest, @FilterResponseCaching
	 * HttpServletResponse response,
	 * 
	 * @CorrelationId @RequestHeader(value
	 * =http://10.26.75.89:8300/recommendation/location/90503
	 * "DTV-CorrelationId", defaultValue = "default") String correlationId,
	 * 
	 * @PathVariable String encryptedId, @RequestBody String jsonPayload) {
	 * 
	 * // LOG.info("DTV-CorrelationId:"+correlationId);
	 * 
	 * // validate input parameters InputParameterUtil.parseString(jsonPayload);
	 * InputParameterUtil.parseString(encryptedId); RuleDataRequest
	 * ruleDataRequest = JSONUtil.convertJsonToObject(jsonPayload,
	 * RuleDataRequest.class); // get account id of given user id String
	 * accountId = accountService.getUserDecryptedId(encryptedId); if (accountId
	 * == null) { throw new DataNotFoundException(ErrorCode.NOT_FOUND, "Token");
	 * }
	 * 
	 * DMAInformation dmaInformation =
	 * accountService.getRegionIdFromAccountId(encryptedId); if
	 * (dmaInformation.getDmaCode() == null) { // throw new
	 * DataNotFoundException(ErrorCode.NOT_FOUND, "Region"); throw new
	 * DataNotFoundException(ErrorCode.NOT_FOUND, "region id for " +
	 * encryptedId); }
	 * 
	 * RuleDataResponse result =
	 * listBuilderIntegrationService.getRuleData(accountId, dmaInformation,
	 * ruleDataRequest);
	 * 
	 * if (result == null) { throw new
	 * DataNotFoundException(ErrorCode.NOT_FOUND, "ruledata response values"); }
	 * return new ResponseEntity<RuleDataResponse>(result, HttpStatus.OK); }
	 */

	/**
	 * @return the service
	 */
	/*
	 * public ListBuilderIntegrationService getService() { return
	 * listBuilderIntegrationService; }
	 *//**
	 * @param service
	 *            the service to set
	 */
	/*
	 * public void setService(ListBuilderIntegrationService service) {
	 * this.listBuilderIntegrationService = service; }
	 */

	/**
	 * Publish service.
	 * 
	 * @param resquest
	 * @param response
	 * @param jsonRules
	 * @param correlationId
	 * @return
	 * @throws InjectException
	 * @throws BadRequestException
	 */

	@ResponseBody
	@RequestMapping(value = "/rules/trigger", method = RequestMethod.GET)
	public ResponseEntity<Void> triggerDailySnycRules(HttpServletRequest resquest, HttpServletResponse response,
			@RequestParam(value = "job", required = true) String job) {

		LOGGER.debug(" triggerDailySnycRules() job={}", job);
		if ("run".equals(job)) {
			String jobId = listBuilderIntegrationService.triggerDailySnycRules();
			LOGGER.debug("'jobs ids: {}", jobId);

		} else {
			LOGGER.debug("Daily Snyc Rules job: " + job + " not understood.");
		}

		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}

}
