package com.directv.uds.aspect.listbuilder.integration.annotation;

import static java.lang.annotation.ElementType.*;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(value={FIELD,CONSTRUCTOR,METHOD,PARAMETER,TYPE})
// can use in method only.
public @interface CorrelationId {

}