/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.KeyValue;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.dtv.hbase.model.Event;

/**
 * HBaseDAOImpl
 * 
 * @author mgiramkar
 *
 */
@Service
public class HBaseDAOImpl implements HBaseDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(HBaseDAOImpl.class);
	
	@Profiled
	public String getHbaseValue(String key, String tableName, byte[] columnFamily, byte[] columnQualifier)
			throws IOException {

		LOGGER.debug("GET {} {} {} {}", tableName, key, columnFamily, columnQualifier);
		return HBaseUtil.getHbaseValue(key, tableName, columnFamily, columnQualifier);
	}

	@Profiled
	public List<KeyValue> getRow(String key, String tableName, byte[] columnFamily, String[] columnQualifiers)
			throws IOException {

		LOGGER.debug("GET {} {} {} {}", tableName, key, columnFamily, columnQualifiers);
		return HBaseUtil.getRow(key, tableName, columnFamily, columnQualifiers);
	}

	@Profiled
	public Map<String, List<KeyValue>> getRowsByKeys(String tableName, String[] keys, byte[] columnFamily)
			throws IOException {

		LOGGER.debug("GET (all columns) {} {} {} {}", tableName, keys, columnFamily);
		return HBaseUtil.getRowsByKeys(tableName, keys, columnFamily);

	}

	/**
	 * Return an array of value corresponding to arrays of column qualifiers
	 * 
	 * @param conf
	 * @param key
	 * @param table
	 * @param columnFamily
	 * @param columnQualifier
	 * @return
	 * @throws IOException
	 */
	@Profiled
	public String[][] getHbaseValue(String key, String tableName, byte[] columnFamily, String[][] columnQualifiers)
			throws IOException {
		
		LOGGER.debug("GET {} {} {} {}", tableName, key, columnFamily, columnQualifiers);
		return HBaseUtil.getHbaseValue(key, tableName, columnFamily, columnQualifiers);
	}

	@Profiled
	public Map<String, List<KeyValue>> getResultScanner(String tableName, byte[] columnFamily, String startRow,
			String stopRow, int pageSize) throws IOException {

		LOGGER.debug("SCAN {} start->{} stop->{} {}", tableName, startRow, stopRow, columnFamily);
		return HBaseUtil.getResultScanner(tableName, columnFamily, startRow, stopRow, pageSize);
	}

	@Profiled
	public List<Event> getUserViewingHistory(String tableName, byte[] columnFamily, String startRow, String stopRow)
			throws IOException {

		LOGGER.debug("SCAN {} start->{} stop->{} {}", tableName, startRow, stopRow, columnFamily);
		return HBaseUtil.getUserViewingHistory(tableName, columnFamily, startRow, stopRow);
	}

	@Profiled
	public Map<byte[], byte[]> getValuesByColumnQualifiers(String key, String tableName, byte[] columnFamily,
			List<String> columnQualifiers) throws IOException {

		LOGGER.debug("GET {} {} {} {}", tableName, key, columnFamily, columnQualifiers);
		return HBaseUtil.getValuesByColumnQualifiers(key, tableName, columnFamily, columnQualifiers);

	}

	@Profiled
	public Map<byte[], byte[]> getValuesByColumnQualifierPrefixFilter(String key, String tableName, byte[] columnFamily,
			List<String> columnQualifierPrefix) throws IOException {

		LOGGER.debug("GET (with column prefix)  {} {} {} {}", tableName, key, columnFamily, columnQualifierPrefix);
		return HBaseUtil.getValuesByColumnQualifierPrefixFilter(key, tableName, columnFamily, columnQualifierPrefix);

	}

}
