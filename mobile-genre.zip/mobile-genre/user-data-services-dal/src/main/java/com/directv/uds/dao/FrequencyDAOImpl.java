/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyrightï¿½ 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.util.Bytes;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.FrequencyElement;
import com.directv.uds.model.ProgramFrequency;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.model.rs.response.WhatshotResponse;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.FrequencyElementUtil;
import com.directv.uds.utils.JSONUtil;

/**
 * A implementation of FrequencyDAO.
 * 
 * <H3>HBaseFrequencyDAOImpl</H3>
 * 
 * @author TuTX1
 * @since Jul 1, 2014
 */
@Service
public class FrequencyDAOImpl implements FrequencyDAO {
	// private static final String TOP_GENRE_COLUMN_FAMILY =
	// "topGenreColumnFamily";
	// private static final String TOP_GENRE_TABLE = "topGenreTable";

	private static final Logger LOGGER = LoggerFactory.getLogger(FrequencyDAOImpl.class);

	@Autowired
	private HBaseDAO hbaseDAO;
	
	@Autowired
	private Configuration config;
	
	/**
	 * @see com.directv.clustermapping.dao.FrequencyDAO#getFrequencyVector(java.lang.String,
	 *      boolean, boolean, java.lang.String, int)
	 * @param userId
	 *            : requested userId
	 * @param groupByWeekday
	 *            : if true then cbcf is grouped by week day
	 * @param mainCategory
	 *            : requested main category i.e. Movies,TV,Sports,AllCategories
	 * @param timewindow
	 *            : timewindow for cbcf i.e. Last6Months,Week,Month. default is
	 *            Last6Months
	 * @param attribute
	 *            : different attribute for cbcf filters i.e.
	 *            Genre,Actor,Director,Theme,Mood,Tone
	 * @param ServiceName
	 *            : ServiceName will be used get table and column from lookup
	 *            table.
	 * @return A map that grouped by main category
	 * @throws IOException
	 */
	@Override
	@Profiled
	public Map<String, List<String>> getFrequencyVector(String userId, boolean groupByWeekday, String attribute, String mainCategory, String timeWindow) {

		LOGGER.debug("getFrequencyVector: {}, {}, {}, {}, {}", userId, groupByWeekday, attribute, mainCategory, timeWindow);
		Map<String, String[][]> qualifiersByTimeWindowMap = UserDataConfiguration.CBCF_COLUMN_QUALIFIER_MAPPING.get(attribute.toLowerCase());

		String[][] allQualifiersOfOneTimeWindow = null;
		if (timeWindow != null) {
			allQualifiersOfOneTimeWindow = qualifiersByTimeWindowMap.get(timeWindow.toLowerCase());
		} else {
			allQualifiersOfOneTimeWindow = qualifiersByTimeWindowMap.get(UserDataConfiguration.CBCF_TIME_WINDOW.getDefaultValue().toLowerCase());
		}

		// get the hbaseMainCategoryIndex corresponding to the input parameter
		// mainCategory
		// if mainCategory is null then hbaseMainCategoryIndex = -1
		int hbaseMainCategoryIndex = UserDataConfiguration.MAIN_CATEGORIES.getIndex(mainCategory);

		// base on mainCategoryIndex, calculate start end
		// if mainCategory is validate, get only mainCategory statistic
		// else return all statistics (3 first vector arrays)
		int start = 0;
		int end = UserDataConfiguration.MAIN_CATEGORIES.getSize();
		if (hbaseMainCategoryIndex != -1) {
			start = hbaseMainCategoryIndex;
			end = start + 1;
		}
		// build columnQualifer array
		// note that each column qualifier corresponding to one combination
		// All.Weekday.MainCategory
		String[][] columnQualifiers = buildColumnQualifierArray(groupByWeekday, allQualifiersOfOneTimeWindow, start, end);
		String[][] hbaseResult = null;
		try {
			// fill values array corresponding to column qualifier array
			hbaseResult = hbaseDAO.getHbaseValue(userId, 
					config.getString(CBCF_HBASE_TABLE), config.getString(CBCF_COLUMN_FAMILY).getBytes(), columnQualifiers);
			LOGGER.debug("hbase data: {}", hbaseResult);
		} catch (IOException e) {
			LOGGER.error("Exception while fetching Hbase records: {}", e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		} catch (Throwable e) {
			LOGGER.error("Exception while fetching Hbase records: {}", e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
		// build result
		// each values[k] corresponding to MAIN_CATEGORIES[k]
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		for (int i = start; i < end; i++) {
			result.put(UserDataConfiguration.MAIN_CATEGORIES.getValue(i), Arrays.asList(hbaseResult[i - start]));
		}
		LOGGER.debug("getFrequencyVector returns: {}", result);
		return result;
	}

	private static String[][] buildColumnQualifierArray(boolean groupByWeekday, String[][] defaultQualifiers, int start, int end) {
		String[][] columnQualifier = new String[end - start][];
		for (int i = start; i < end; i++) {
			if (groupByWeekday) {
				columnQualifier[i - start] = defaultQualifiers[i];
			} else {

				columnQualifier[i - start] = new String[] { defaultQualifiers[i][0] };
			}
		}
		return columnQualifier;
	}

	/**
	 * 
	 */
	@Profiled
	public WhatshotResponse getWhatIsHot(String timeWindow, DMAInformation dmaInformation, int limit, String mainCategory) {
		WhatshotResponse cols = new WhatshotResponse();

		String regionId = null;
		// DMA information includes dmaCode and dmaDescription
		if (dmaInformation != null) {
			regionId = dmaInformation.getDma();
		} else {
			dmaInformation = new DMAInformation();
		}

		String[] columnQualifiers = null;

		// Parameter 1 check
		if (timeWindow == null) {
			timeWindow = UserDataConfiguration.WIH_TIME_WINDOW.getDefaultValue();
		}
		// Parameter 2 check
		if (regionId == null) {
			regionId = "AllRegion";
		}

		// Get all predefined main categories
		// if mainCategory != null, just get column which has column qualifier
		// equals to mainCategory
		if (mainCategory != null) {
			columnQualifiers = new String[] { mainCategory };
		} else {
			columnQualifiers = new String[] { UserDataConfiguration.MAIN_CATEGORIES.getDefaultValue() };
		}
		String key = String.format("%s.%s", timeWindow, regionId);
		//LOGGER.debug("KEY: {}", key);
		// get table information from lookup table
		/*HbaseTableConfiguration conf = hbaseDAO.readLookupTable(serviceName);
		if (conf == null) {
			LOGGER.debug("Table name not found in lookup-table for service: {}", serviceName);
			return null;
		}*/
		// LOG.info(String.format("%s %s %s", key, conf.getTableName(), new
		// String(conf.getColumnFamily())));
		List<KeyValue> row = null;
		String colValue = null;
		String columQualifier = null;

		// Get one row by time window and regionId
		try {
			row = hbaseDAO.getRow(key, 
					config.getString(WIH_HBASE_TABLE), config.getString(WIH_COLUMN_FAMILY).getBytes(), columnQualifiers);
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}

		if (row != null) {
			for (KeyValue col : row) {
				colValue = new String(col.getValue());
				columQualifier = new String(col.getQualifier());
				convertColumnDataToList(limit, cols, colValue, columQualifier);
				cols.setDmaCode(dmaInformation.getDma());
				cols.setDmaDescription(dmaInformation.getDmaDescription());
			}
		}

		return cols;
	}

	/**
	 * convert column value of what is hot table to a list of ProgramFrequency
	 * Object
	 * 
	 * @param limit
	 * @param cols
	 * @param colValue
	 * @param columQualifier
	 */
	private static void convertColumnDataToList(int limit, WhatshotResponse cols, String colValue, String columQualifier) {

		ProgramFrequency[] temps = JSONUtil.convertJsonToObject(colValue, ProgramFrequency[].class);
		List<ProgramFrequency> programFrequencyList = new ArrayList<ProgramFrequency>();
		if (temps != null && temps.length > 0) {
			
			//CR-2825: Have to validate ProgramFrequency: tms id must not be null
			/*if (limit > 0 && temps.length > limit) {
				LOG.info("Limit:" + limit);
				for (int i = 0; i < limit; i++) {
					programFrequencyList.add(temps[i]);
				}
			} else {
				programFrequencyList = Arrays.asList(temps);
				LOG.info(String.format(" %s", programFrequencyList.size()));
			}*/
			
			//validate ProgramFrequency: tmsid must not be null
			int count = 0;
			for (ProgramFrequency pf : temps) {
				if (limit > 0 && count >= limit) {
					break;
				}
				if (pf.getTmsId() == null || "null".equals(pf.getTmsId())) {
					continue;
				}
				programFrequencyList.add(pf);
				count++;
			}
		}
		cols.setWhatshot(programFrequencyList);
	}

	/**
	 * @throws IOException
	 * @see com.directv.clustermapping.dao.FrequencyDAO#getCbcfByDayVector(java.lang.String,
	 *      java.lang.String)
	 */
	@Override
	@Profiled
	public Map<String, List<FrequencyElement>> getCbcfByDayVector(String userId, String date, boolean percentage, String attribute, int startIndex, int limit) {

		LOGGER.debug("Get cbcf by day from hbase {}", userId);

		Map<String, List<FrequencyElement>> result = new HashMap<String, List<FrequencyElement>>();

		List<String> columnQualifiers = new ArrayList<String>();
		for (String mainCategory : UserDataConfiguration.MAIN_CATEGORIES.getValues()) {
			String column = date + "." + attribute + "." + mainCategory;
			columnQualifiers.add(column);
			// result.put(mainCategory, new ArrayList<String>());
		}

		/*HbaseTableConfiguration conf = hbaseDAO.readLookupTable(serviceName);
		if (conf == null) {
			return null;
		}*/
		Map<byte[], byte[]> hbaseResult;
		try {
			hbaseResult = hbaseDAO.getValuesByColumnQualifiers(userId, 
					config.getString(CBCFBYDAY_HBASE_TABLE), config.getString(CBCFBYDAY_COLUMN_FAMILY).getBytes(), columnQualifiers);
		} catch (IOException e) {
			LOGGER.error("Exception while fetching Hbase records from {}", config.getString(CBCFBYDAY_HBASE_TABLE), e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}

		if (hbaseResult == null) {
			return null;
		}

		for (Map.Entry<byte[], byte[]> entry : hbaseResult.entrySet()) {
			String qualifier = Bytes.toString(entry.getKey());
			String value = Bytes.toString(entry.getValue());

			if (value.isEmpty()) {
				continue;
			}

			String mainCategory = qualifier.substring(qualifier.lastIndexOf(".") + 1);
			FrequencyElement[] items = null;
			try {
				items = UserDataConfiguration.OBJECT_MAPPER.readValue(value, FrequencyElement[].class);
			} catch (IOException e) {
				LOGGER.error(e.getMessage(), e);
				continue;
			}

			// remove ignored sub category
			List<FrequencyElement> vector = FrequencyElementUtil.removeIgnoredSubCategory(UserDataConfiguration.IGNORED_SUB_CATEGORIES_SET, items);
			int size = vector.size();
			if (size > 0) {

				if (startIndex > 0 && startIndex <= size) {
					vector = vector.subList(startIndex, size);
					size = vector.size();
				}

				// size = size - UserDataConfiguration.MAIN_CATEGORIES.length;
				if (limit > 0 && limit < size) {
					vector = vector.subList(0, limit);
				}
				if (percentage) {
					vector = FrequencyElementUtil.convertToPercentage(vector);
				}

				result.put(mainCategory, vector);
			}

		}

		return result;
	}

//	@Override
//	@Cacheable("topGenre")
//	@Profiled
//	public Map<String, List<FrequencyElement>> getCommonUserTaste(String[] mainCategories, int limit) throws IOException {
//		
//		if (mainCategories == null || mainCategories.length == 0) {
//			mainCategories = UserDataConfiguration.MAIN_CATEGORIES.getValues();
//		}
//		
//		// Create result template
//		Map<String, List<FrequencyElement>> topCbcf = new HashMap<String, List<FrequencyElement>>();
//		for (String mainCategory : mainCategories) {
//			topCbcf.put(mainCategory, new ArrayList<FrequencyElement>());
//		}
//
//		//try {
//		Configuration udsConfig = Configuration.getInstance();
//		Map<String, List<KeyValue>> rowMap = HBaseUtil.getRowsByKeys(
//				udsConfig.getString(TOP_GENRE_TABLE), mainCategories, udsConfig.getString(TOP_GENRE_COLUMN_FAMILY).getBytes());
//		//} catch (IOException e) {
//		//	LOG.error(e, e.getCause());
//		//	return topCbcf;
//		//}
//		
//		Set<String> keys = rowMap.keySet();
//		for (String key : keys) {
//			List<KeyValue> row = rowMap.get(key);
//			if (row != null) {
//				List<FrequencyElement> frequencyElementList = new ArrayList<FrequencyElement>();
//
//				for (KeyValue column : row) {
//					frequencyElementList.add(new FrequencyElement(
//							new String(column.getQualifier()), Double.parseDouble(new String(column.getValue()))));
//				}
//				Collections.sort(frequencyElementList);
//				if (limit < 0) {
//					//max 10 entries if no limit 
//					limit = 10;
//				}
//				if (frequencyElementList.size() > limit) {
//					frequencyElementList = frequencyElementList.subList(0, limit);
//				}
//				topCbcf.get(key).addAll(frequencyElementList);
//			}
//		}
//
//		return topCbcf;
//	}
	/*@Override
	@Cacheable("topGenre")
	@Profiled
	public Map<String, List<FrequencyElement>> getCommonUserTaste(String[] mainCategories, int limit) {
		
		if (mainCategories == null || mainCategories.length == 0) {
			mainCategories = UserDataConfiguration.MAIN_CATEGORIES.getValues();
		}
		
		// Create result template
		Map<String, List<FrequencyElement>> topCbcf = new HashMap<String, List<FrequencyElement>>();
		for (String mainCategory : mainCategories) {
			topCbcf.put(mainCategory, new ArrayList<FrequencyElement>());
		}

		Map<String, List<KeyValue>> rowMap;
		try {
			Configuration udsConfig = Configuration.getInstance();
			rowMap = HBaseUtil.getRowsByKeys(
				udsConfig.getString(TOP_GENRE_TABLE), mainCategories, udsConfig.getString(TOP_GENRE_COLUMN_FAMILY).getBytes());
		} catch (IOException e) {
			LOG.error("Exception while fetching Hbase records: ", e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
		Set<String> keys = rowMap.keySet();
		for (String key : keys) {
			List<KeyValue> row = rowMap.get(key);
			if (row != null) {
				List<FrequencyElement> frequencyElementList = new ArrayList<FrequencyElement>();

				for (KeyValue column : row) {
					FrequencyElement[] frequencyElements = JSONUtil.convertJsonToObject(new String(column.getValue()), FrequencyElement[].class);
					if(frequencyElements!=null && frequencyElements.length!=0){
						frequencyElementList.addAll(Arrays.asList(frequencyElements));
					}
				}
				Collections.sort(frequencyElementList);
				if (limit < 0) {
					//max 10 entries if no limit 
					limit = 10;
				}
				if (frequencyElementList.size() > limit) {
					frequencyElementList = frequencyElementList.subList(0, limit);
				}
				topCbcf.get(key).addAll(frequencyElementList);
			}
		}

		return topCbcf;
	}*/
}
