package com.directv.uds.dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.hadoop.hbase.KeyValue;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.model.LocationInformation;
import com.directv.uds.model.rs.getRule.response.CreditDataResult;
import com.directv.uds.model.rs.response.LastActionElement;
import com.directv.uds.model.rs.response.LastActionResponse;
import com.directv.uds.model.rs.response.LastActionResult;
import com.directv.uds.service.FrequencyStatisticsService;
import com.directv.uds.service.ListBuilderIntegrationService;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.QueryGeneration;
import com.directv.uds.utils.RuleParserUtil;
import com.dtv.lastaction.listbuilderintegration.dto.LARule;

@Service
public class UserActivityDAOImpl implements UserActivityDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserActivityDAOImpl.class);

	private JdbcTemplate jdbcTemplate;

	@Autowired
	private HBaseDAO hbaseDAO;

	@Autowired
	private FrequencyStatisticsService freqService;

	@Autowired
	private Configuration config;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * Get last action from impala
	 */
	@Override
	@Profiled
	public List<LastActionElement> getLastAction(LARule rule, String uvhTable, String accountId, int offset, int limit) {
		// List<LastActionElement> lastAction = new
		// ArrayList<LastActionElement>();

		// convert rule type to eventMapping
		String eventtype = rule.getRuleType().getIntepretedEventType();
		// build query
		String userBehaviour = RuleParserUtil.buildQueryFromRule(accountId, rule, freqService, config);
		// generate full query
		Integer secondaryPartitionModulo;
		if (config.getBoolean(ListBuilderIntegrationService.SEVEN_DAYS_DATA_IMPALA_SECONDARY_PARTITION_APPLIED)) {
			secondaryPartitionModulo = config.getInt(ListBuilderIntegrationService.SEVEN_DAYS_DATA_IMPALA_SECONDARY_PARTITION_MODULO);
		} else {
			secondaryPartitionModulo = null;
		}
		String query = QueryGeneration.selectUserLastAction(uvhTable, secondaryPartitionModulo, accountId, eventtype, userBehaviour, offset, limit);
		LOGGER.info("query: {}", query);

		List<LastActionElement> lastAction;
		try {
			lastAction = this.jdbcTemplate.query(query, new RowMapper<LastActionElement>() {
				public LastActionElement mapRow(ResultSet rs, int rowNum) throws SQLException {
					LastActionElement lastActionElement = new LastActionElement();
					String tmsId = rs.getString("tmsid");
					String tmsConnectorId = rs.getString("tmsConnectorId");
					String programType = rs.getString("programType");
					String interpretedEventType = rs.getString("interpretedEventType");
					String mainCategory = rs.getString("mainCategory");
					//CR-3664: eventtime is in yyyymmdd format, not epoch timestamp
					//String eventTime = Integer.toString(rs.getInt("eventtime"));
					String eventTime = rs.getString("eventtime");
					String title = rs.getString("title");
					String genre1 = rs.getString("genre1");
					String genre2 = rs.getString("genre2");
					String genre3 = rs.getString("genre3");
					/*String tmsGenre1 = rs.getString("tmsgenre1");
					String tmsGenre2 = rs.getString("tmsgenre2");
					String tmsGenre3 = rs.getString("tmsgenre3");*/
					if (tmsId != null) {
						lastActionElement.setTmsId(tmsId);
					}
					if (eventTime != null) {
						lastActionElement.setEventTime(eventTime);
					}
					if (title != null) {
						lastActionElement.setProgramTitle(title);
					}
					lastActionElement.setMainCategory(mainCategory);
					lastActionElement.setTmsConnectorId(tmsConnectorId);
					lastActionElement.setProgramType(programType);
					lastActionElement.setInterpretedEventType(interpretedEventType);
					lastActionElement.setGenre1(genre1);
					lastActionElement.setGenre2(genre2);
					lastActionElement.setGenre3(genre3);
					/*lastActionElement.setTmsGenre1(tmsGenre1);
					lastActionElement.setTmsGenre2(tmsGenre2);
					lastActionElement.setTmsGenre3(tmsGenre3);*/
					lastActionElement.consolidateTmsIdAndConnectorId();
					return lastActionElement;
				}
			});
		} catch (DataAccessException e) {
			throw new RemoteSystemException(SystemName.IMPALA, e);
		}
		// openConection(UserDataConfiguration.JDBC_DRIVER_NAME,
		// UserDataConfiguration.IMPALA_HOST,
		// UserDataConfiguration.IMPALA_PORT);
		// lastAction = runQuery(query);

		// closeConection();
		return lastAction;

	}

	/**
	 * get LastAction result from HBase (result of rule publish)
	 */
	@Override
	@Profiled
	public LastActionResponse getLastActionByRule(String accountId, String[] ruleNames) {

		// Configuration udsConfig = Configuration.getInstance();
		List<KeyValue> row;
		try {
			row = hbaseDAO.getRow(accountId, config.getString(LAST_ACTION_BY_RULE_HBASE_TABLE),
					config.getString(LAST_ACTION_BY_RULE_COLUMN_FAMILY).getBytes(), ruleNames);
		} catch (IOException e) {
			LOGGER.error("Exception while fetching Hbase records: {}", e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}

		LastActionResponse lastActions = new LastActionResponse();
		String colValue = null;
		LastActionResult lastAction = null;
		if (row != null) {
			for (KeyValue col : row) {
				colValue = new String(col.getValue());
				LastActionElement[] events = JSONUtil.convertJsonToObject(colValue, LastActionElement[].class);

				lastAction = new LastActionResult();
				//CR-4163 send all lastaction events to CS (no filter in UDS).
				if (events != null /*&& events.length > 0*/) {
					//lastAction.add(events[0]);
					for (LastActionElement e : events) {
						lastAction.add(e);
					}
				}
				lastAction.setRuleName(new String(col.getQualifier()));
				lastActions.getLastAction().add(lastAction);
			}
		}

		return lastActions;
	}

	@Override
	@Profiled
	public LocationInformation getLocation(String zipCode) {
		try {
			// query Hbase table
			String locationString = hbaseDAO.getHbaseValue(zipCode, config.getString(ZIPCODE_TO_LOCATION_TABLE),
					config.getString(ZIPCODE_TO_LOCATION_FAMILY).getBytes(), config.getString(ZIPCODE_TO_LOCATION_QUALIFIER).getBytes());
			// LOG.debug("location String " + locationString);
			// build and return JSON
			if (locationString != null) {
				return JSONUtil.convertJsonToObject(locationString, LocationInformation.class);
			}
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE, e);
		}

		return null;
	}

	@Override
	public CreditDataResult[] getCreditByRuleName(String accountId, LARule creditRules, String[] columnQualifiers, String creditType) {
		CreditDataResult[] creditDataResults = null;
		try {
			List<KeyValue> row = hbaseDAO.getRow(accountId, Configuration.getInstance().getString(CBCF_HBASE_TABLE), Configuration
					.getInstance().getString(CBCF_COLUMN_FAMILY).getBytes(), columnQualifiers);
			if (row == null) {
				return null;
			}

			String colValue = null;
			if (row != null) {
				for (KeyValue col : row) {
					colValue = new String(col.getValue());
					creditDataResults = JSONUtil.convertJsonToObject(colValue, CreditDataResult[].class);
					for (CreditDataResult keyValue : creditDataResults) {
						keyValue.setCreditType(creditType);
					}
				}
			}

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("creditInformation: {}", row);
			}
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
		return creditDataResults;
	}

}
