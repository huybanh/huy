/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.hadoop.hbase.KeyValue;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.model.Account;
import com.directv.uds.model.DMAInformation;
import com.directv.uds.model.EnumManager.DMAColumnQualifier;
import com.directv.uds.model.EnumManager.TopActiveUsers;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.QueryGeneration;


/**
 * A real class implement AccountDAO interface. <H3>HBaseAccountDAOImpl</H3>
 * 
 * @author TuTX1
 * @since Jul 1, 2014
 */
@Service
public class AccountDAOImpl implements AccountDAO {

	private static final String TOP_ACTIVE_USER_HIVE_TABLE = "topActiveUserHiveTable";

	private static final Logger LOGGER = LoggerFactory.getLogger(AccountDAOImpl.class);

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private Configuration config;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Autowired
	private HBaseDAO hbaseDAO;

	/**
	 * @see com.directv.clustermapping.dao.AccountDAO#getAccountByCardId(String)
	 * @param cardId
	 *            : requested card Id
	 * @return Account object (contain a pair: userId and encryptedId)
	 */
	@Override
	@Profiled
	public Account getAccountByCardId(String cardId) {
		try {
			// query Hbase table to get accountId of given cardId
			String accountId = hbaseDAO.getHbaseValue(cardId,
					config.getString(CARD_TO_ACCOUNT_TABLE),
					config.getString(CARD_TO_ACCOUNT_FAMILY).getBytes(),
					config.getString(CARD_TO_ACCOUNT_QUALIFIER).getBytes());

			if (accountId == null) {
				return null;
			}

			if (com.directv.uds.utils.Configuration.getInstance().getBoolean(UserDataConfiguration.IS_AWS)) {
				// build and return JSON of object with pair-value (accountId ->
				// encryptedId)
				return new Account(accountId, accountId);
			} else {
				// query Hbase table to get encryptedId of above accountId
				String encryptedId = hbaseDAO.getHbaseValue(accountId,
						config.getString(ACCOUNT_TO_ENCRYPTED_TABLE),
						config.getString(ACCOUNT_TO_ENCRYPTED_FAMILY).getBytes(),
						config.getString(ACCOUNT_TO_ENCRYPTED_QUALIFIER).getBytes());

				// build and return JSON of object with pair-value (accountId ->
				// encryptedId)
				return new Account(accountId, encryptedId);
			}
		} catch (IOException e) {
			LOGGER.error("Hbase data access issue ", e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
	}

	/**
	 * @see com.directv.clustermapping.dao.AccountDAO#getUsers(int, int)
	 * @param offset
	 *            : start with offset
	 * @param limit
	 *            : return limit of records
	 * @return List of active users
	 */
	@Override
	@Profiled
	public List<String> getUsers(int offset, int limit) {
		// validate offset and limit value
		// if offset < 0 then query will start from first row by default
		if (offset < 0) {
			offset = 0;
		}

		// if limit < 0 then limit = DEFAULT_USER_NUMBER (by default)
		// CR-3135: handling of default limit should be at service layer, not
		// DAO
		/*
		 * if (limit < 0) { limit =
		 * com.directv.uds.utils.Configuration.getInstance
		 * ().getInt(DEFAULT_USER_NUMBERS, 100); }
		 */

		int code = 0;

		code = TopActiveUsers.ENCRYPTED_ID.getCode();

		// ImpalaUtil<List<String>> util = initImapaUtil(code);

		// create query to hive table
		String sql = QueryGeneration.selectPrecalculatedTopActiveUser(
				com.directv.uds.utils.Configuration.getInstance().getString(TOP_ACTIVE_USER_HIVE_TABLE), offset, limit);

		LOGGER.info("Query: {}", sql);

		List<String> result = getValues(sql, code);

		return result;
	}

	private List<String> getValues(final String sql, final int columnIndex) {
		try {
			return this.jdbcTemplate.query(sql, new ResultSetExtractor<List<String>>() {

				@Override
				public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {

					List<String> result = new ArrayList<String>();

					while (rs.next()) {
						result.add(rs.getString(columnIndex));
					}

					return result;
				}

			});
		} catch (DataAccessException e) {
			LOGGER.error("Impala connection issue", e);
			throw new RemoteSystemException(SystemName.IMPALA, e);
		}
	}

	/**
	 * @see com.directv.clustermapping.dao.AccountDAO#getEncryptedId(String)
	 * @param userId
	 *            : requested userId
	 * @return encryptedId
	 */
	@Override
	@Profiled
	public String getEncryptedId(String userId) {
		// query Hbase table to get encryptedId of given userId
		try {
			// LOGGER.info(com.directv.uds.utils.Configuration.getInstance().getBoolean(UserDataConfiguration.IS_AWS));
			if (com.directv.uds.utils.Configuration.getInstance().getBoolean(UserDataConfiguration.IS_AWS)) {
				return userId;
			} else {
				return hbaseDAO.getHbaseValue(userId,
						config.getString(ACCOUNT_TO_ENCRYPTED_TABLE),
						config.getString(ACCOUNT_TO_ENCRYPTED_FAMILY).getBytes(),
						config.getString(ACCOUNT_TO_ENCRYPTED_QUALIFIER).getBytes());
			}
		} catch (IOException e) {
			LOGGER.error("Hbase data access issue", e);
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
	}

	/**
	 * @see com.directv.clustermapping.dao.AccountDAO#getUserId(java.lang.String)
	 * @param encryptedId
	 *            : requested id
	 * @return userId
	 */
	@Override
	@Profiled
	public String getUserId(String encryptedId) {
		// query Hbase table to get decryptedId of given userId
		if (com.directv.uds.utils.Configuration.getInstance().getBoolean(UserDataConfiguration.IS_AWS)) {
			return encryptedId;
		} else {
			try {
				return hbaseDAO.getHbaseValue(encryptedId,
						config.getString(ENCRYPTED_TO_ACCOUNT_TABLE),
						config.getString(ENCRYPTED_TO_ACCOUNT_FAMILY).getBytes(),
						config.getString(ENCRYPTED_TO_ACCOUNT_QUALIFIER).getBytes());
			} catch (IOException e) {
				throw new RemoteSystemException(SystemName.HBASE, e);
			}
		}
	}

	/**
	 * Get user region Id from account Id
	 * 
	 * @throws IOException
	 */
	@Override
	@Profiled
	public DMAInformation getRegionIdFromAccountId(String accountId) throws IOException {
		LOGGER.info("AccountId: {}", accountId);
		String[] columnQualifiers = new String[] {config.getString(ACCOUNT_TO_REGION_QUALIFIER)};
		List<KeyValue> row = hbaseDAO.getRow(accountId,
				config.getString(ACCOUNT_TO_REGION_TABLE),
				config.getString(ACCOUNT_TO_REGION_FAMILY).getBytes(), columnQualifiers);
		if (row == null) {
			return null;
		}
		DMAInformation dmaInformation = new DMAInformation();
		for (KeyValue col : row) {
			String columnQualifier = new String(col.getQualifier());
			if (columnQualifier.equalsIgnoreCase(columnQualifiers[DMAColumnQualifier.MAPPING.getIndex()])) {
				dmaInformation = JSONUtil.convertJsonToObject(new String(col.getValue()), DMAInformation.class);
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("dmaInformation: {}", dmaInformation);
		}
		return dmaInformation;
	}

}
