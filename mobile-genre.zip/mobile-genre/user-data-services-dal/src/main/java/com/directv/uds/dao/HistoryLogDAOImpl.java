/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.hbase.KeyValue;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.model.RecommendationJobHistory;
import com.directv.uds.utils.Configuration;

/**
 * 
 * @author ThanhNN2
 *
 */
@Service
public class HistoryLogDAOImpl implements HistoryLogDAO {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(HistoryLogDAOImpl.class);
	
	@Autowired
	private HBaseDAO hbaseDAO;
	
	@Autowired
	private Configuration config;

	@Override
	@Profiled
	public Map<String, List<RecommendationJobHistory>> getRecommendationJobHistory(String startTime, String endTime, boolean doLatest) {

		Map<String, List<RecommendationJobHistory>> result = null;

		//RECOMMENDATIONS_JOB_HISTORY_TABLE = new HbaseTableConfiguration(config.getString("recommendationsJobHistoryTable"), config
		//		.getString("recommendationsJobHistoryColumnFamily").getBytes(), (byte[]) null);
		//HbaseTableConfiguration conf = UserDataConfiguration.RECOMMENDATIONS_JOB_HISTORY_TABLE;
		// Get all recommendation job history from startTime to endTime
		Map<String, List<KeyValue>> rows;
		try {
			rows = hbaseDAO.getResultScanner(
					config.getString(RJH_TABLE), config.getString(RJH_FAMILY).getBytes(), startTime, endTime, -1);
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE, e);
		}
		if (rows != null) {
			// iterate through ResultScanner to get information
			result = iterateResultScanner(rows);
			if (doLatest) {
				// Get just latest job history record if doLatest = true
				LOGGER.debug("DO LATEST!!!!!");
				if (result.size() > 0) {
					Set<String> listKey = result.keySet();
					Iterator<String> keyIterator = listKey.iterator();
					String latestKey = keyIterator.next();
					List<RecommendationJobHistory> latestValue = result.get(latestKey);
					result = new TreeMap<String, List<RecommendationJobHistory>>();
					result.put(latestKey, latestValue);
					return result;
				}
			}
		}

		return result;
	}

	/***
	 * Iterate through ResultScanner and extract data to a Map with key is row
	 * key and value is a list of column information.
	 * 
	 * @param resultScanner
	 * @return Map of data
	 */
	private Map<String, List<RecommendationJobHistory>> iterateResultScanner(Map<String, List<KeyValue>> rows) {
		// Use TreeMap with defined comparator to sort record key descending
		Map<String, List<RecommendationJobHistory>> resultList = new TreeMap<String, List<RecommendationJobHistory>>(new Descending());
		Set<String> keys = rows.keySet();
		for (String key : keys) {
			List<KeyValue> rowTemp = rows.get(key);
			List<RecommendationJobHistory> row = new ArrayList<RecommendationJobHistory>();
			// Get Value of col and add to a list
			for (KeyValue col : rowTemp) {
				RecommendationJobHistory rjh = new RecommendationJobHistory();
				rjh.setKey(new String(col.getQualifier()));
				rjh.setValue(new String(col.getValue()));
				row.add(rjh);
			}
			// Put list of column information to map with key is row key
			resultList.put(key, row);
			LOGGER.debug("Successfully get row {} ", key);
		}

		return resultList;
	}

}

/***
 * . Comparator to sort TreeMap by descending order
 */
class Descending implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		return o2.compareTo(o1);
	}

}
