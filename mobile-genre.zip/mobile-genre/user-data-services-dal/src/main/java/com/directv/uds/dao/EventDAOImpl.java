/*
 *****************************************************************************
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK, ALL RIGHTS RESERVED
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information"). Any use, reproduction,
 * distribution or disclosure of the software or Proprietary Information,
 * in whole or in part, must comply with the terms of the license
 * agreement, nondisclosure agreement or contract entered into with
 * DIRECTV providing access to this software. 
 *****************************************************************************
 */
package com.directv.uds.dao;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.hadoop.hbase.util.Bytes;
import org.perf4j.aop.Profiled;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.directv.uds.exceptions.RemoteSystemException;
import com.directv.uds.exceptions.RemoteSystemException.SystemName;
import com.directv.uds.model.EnumManager.LASTACTION_TOKENS;
import com.directv.uds.model.EnumManager.UVH;
import com.directv.uds.model.EventTime;
import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.model.LastAction;
import com.directv.uds.model.UserDataConfiguration;
import com.directv.uds.utils.Configuration;
import com.directv.uds.utils.JSONUtil;
import com.directv.uds.utils.QueryGeneration;

/**
 * Real class implement EventDAO interface.
 * 
 * <H3>HBaseEventDAOImpl</H3>
 *
 * @author TuTX1
 * @since Jul 1, 2014
 */
@Service
public class EventDAOImpl implements EventDAO {

	@Autowired
	private HBaseDAO hbaseDAO;
	
	@Autowired
	private Configuration config;
	
	/**
	 * Property key
	 */
	private static final String UVH_IMPALA_TABLE = "uvhImpalaTable";
	private static final String DEFAULT_EVENT_NUMBERS = "defaultEventNumbers";

	private static final Logger LOGGER = LoggerFactory.getLogger(EventDAOImpl.class);
	

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	/**
	 * New method to get user viewing history.
	 * 
	 * Description
	 * 
	 * @param userId
	 *            : requested userId
	 * @param startTime
	 *            : start time
	 * @param endTime
	 *            : end time
	 * @param removeDuplicates
	 *            : if true then remove duplicated tmsId or not
	 * @param mainCategory
	 *            : requested main category
	 * @return A map of InterpretedEvent that grouped by main category
	 * @return
	 */
	@Override
	@Profiled
	public Map<String, List<InterpretedEvent>> getUserViewingHistoryImpala(String userId, String mainCategory, int offset, int limit, boolean removeDuplicates, EventTime eventTime) {

		//Map<String, List<InterpretedEvent>> results = new HashMap<String, List<InterpretedEvent>>();

		String[] mainCategories = null;
		if (mainCategory != null) {
			mainCategories = new String[] { mainCategory };
		} else {
			mainCategories = UserDataConfiguration.MAIN_CATEGORIES.getValues();
		}

		if (offset < 0) {
			offset = 0;
		}

		if (limit < 0) {
			limit = com.directv.uds.utils.Configuration.getInstance().getInt(DEFAULT_EVENT_NUMBERS, 10);
		}

		String sql = QueryGeneration.selectUserViewingHistory(com.directv.uds.utils.Configuration.getInstance().getString(UVH_IMPALA_TABLE), userId, mainCategory, offset, limit, eventTime);
		LOGGER.info("query: {}", sql);
		return getUvhValues(sql, mainCategories, removeDuplicates);

	}

	private Map<String, List<InterpretedEvent>> getUvhValues(final String sql, final String[] mainCategoriesx, final boolean removeDuplicates) {

		Map<String, List<InterpretedEvent>> result = new HashMap<String, List<InterpretedEvent>>();
		Map<String, Set<String>> tmsidMap = new HashMap<String, Set<String>>();

		List<InterpretedEvent> uvhEvents;
		try {
			uvhEvents = this.jdbcTemplate.query(sql, new RowMapper<InterpretedEvent>(){
				@Override
				public InterpretedEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
					if(rs == null) {
						return new InterpretedEvent();
					}
	
					String tmsId = rs.getString(UVH.TMS_ID.getCode());
					//String eventTime = rs.getString(UVH.EVENT_TIME.getCode());
					String eventType = rs.getString(UVH.EVENT_TYPE.getCode());
					String source = rs.getString(UVH.SOURCE.getCode());
					String accountId = rs.getString(UVH.ACCOUNT_ID.getCode());
					String mainCategory = rs.getString(UVH.MAIN_CATEGORY.getCode());
					String interpretedeventtype = rs.getString(UVH.INTERPRETED_EVENT.getCode());
					String eventTime = rs.getString(UVH.EVENT_TIME.getCode());
					/*String eventTimeString = rs.getString(UVH.EVENT_TIME.getCode());
					if (eventTimeString != null && eventTimeString.length() > 8) {
						eventTime = eventTimeString.substring(0, 8);
					} else {
						eventTime = eventTimeString;
					}*/
	
					InterpretedEvent event = new InterpretedEvent();
					event.setAccountId(accountId);
					event.setEventTime(eventTime);
					event.setEventType(eventType);
					event.setTmsId(tmsId);
					event.setMainCategory(mainCategory);
					event.setSource(source);
					event.setInterpretedEvent(interpretedeventtype);
	
					return event;
				}
	
			});
		} catch (DataAccessException e) {
			throw new RemoteSystemException(SystemName.IMPALA, e);
		}

		if(uvhEvents != null && uvhEvents.size() > 0) {
			for(InterpretedEvent event : uvhEvents) {
				String mainCategory = event.getMainCategory();
				String tmsId = event.getTmsId();

				if(tmsId == null) {
					continue;
				}

				Set<String> tmsids = tmsidMap.get(mainCategory);
				if(tmsids == null) {
					tmsidMap.put(mainCategory, new HashSet<String>());
					tmsids = tmsidMap.get(mainCategory);
				}
				
				if(removeDuplicates) {
					if(tmsids.contains(tmsId)) {
						continue;
					}
					tmsids.add(tmsId);
				}

				List<InterpretedEvent> events = result.get(mainCategory);
				if(events == null) {
					result.put(mainCategory, new ArrayList<InterpretedEvent>());
					events = result.get(mainCategory);
				}

				events.add(event);
			}
		}

		return result;
	}

	/**
	 * 
	 * @see com.directv.clustermapping.dao.EventDAO#getLastActionEvents(java.lang.String,
	 *      java.lang.String, java.lang.String, boolean, String)
	 * @param userId
	 *            : requested userId
	 * @param mainCategory
	 *            : requested main category
	 * @param eventType
	 *            : requested event type
	 * @param groupSubCategory
	 *            : if true then result will be grouped by sub-category or
	 *            return AllSubCategory
	 * @return A map that group last action by main category and event type
	 */
	@Override
	@Profiled
	public Map<String, Map<String, List<LastAction>>> getLastActionGeneric(String userId, String mainCategory, String eventType, boolean groupSubCategory) {

		Map<String, Map<String, List<LastAction>>> results = new HashMap<String, Map<String, List<LastAction>>>();
		Map<String, List<LastAction>> events = null;
		List<LastAction> listActionEvents = null;

		// create column qualifier prefix of last-action table
		List<String> columnQualifiersPrefix = getLastActionColumnQualifiersPrefix(mainCategory, eventType, groupSubCategory);

		/*HbaseTableConfiguration conf = hbaseDAO.readLookupTable(serviceName);
		if (conf == null) {
			return null;
		}*/

		// query HBase using column qualifiers prefix filter
		Map<byte[], byte[]> hbresults;
		try {
			hbresults = hbaseDAO.getValuesByColumnQualifierPrefixFilter(
					userId, config.getString(LAST_ACTION_GENERIC_HBASE_TABLE), 
					config.getString(LAST_ACTION_GENERIC_COLUMN_FAMILY).getBytes(), columnQualifiersPrefix);
		} catch (IOException e) {
			throw new RemoteSystemException(SystemName.HBASE, e);
		}

		if (hbresults == null) {
			return null;
		}

		// iterate result set and parse the record
		for (Map.Entry<byte[], byte[]> entry : hbresults.entrySet()) {
			String qualifier = Bytes.toString(entry.getKey());
			String value = Bytes.toString(entry.getValue());

			//LOG.info("qualifier: " + qualifier + "---" + "value: " + value);

			// column name contain three elements separate by '.' character
			String[] tokens = qualifier.split("\\.");
			// make sure there is no case of wrong format of column name
			if (tokens.length != 3) {
				LOGGER.error("Name of column not match!");
				return null;
			}

			// first token is main category
			// second token is event type
			// third token is sub-category (such as Comedy, Action...) or
			// 'AllSubCategory'
			String currentMainCategory = tokens[LASTACTION_TOKENS.MAIN_CATEGORY.getIndex()];
			String currentEventType = tokens[LASTACTION_TOKENS.EVENT_TYPE.getIndex()];
			String currentSubCategory = tokens[LASTACTION_TOKENS.SUB_CATEGORY.getIndex()];

			// group by main category
			events = results.get(currentMainCategory);
			if (events == null) {
				events = new HashMap<String, List<LastAction>>();
				results.put(currentMainCategory, events);
			}

			// group by event type
			listActionEvents = events.get(currentEventType);
			if (listActionEvents == null) {
				listActionEvents = new ArrayList<LastAction>();
				events.put(currentEventType, listActionEvents);
			}

			InterpretedEvent[] interpretedEvents = JSONUtil.convertJsonToObject(value, InterpretedEvent[].class);
			listActionEvents.add(new LastAction(currentSubCategory, InterpretedEvent.toEvents(interpretedEvents)));
		}

		return results;
	}

	/**
	 * Generate column qualifier prefix to query last action table.
	 * 
	 * Description
	 * 
	 * @param mainCategory
	 *            : requested main category
	 * @param eventType
	 *            : requested event type
	 * @param groupSubCategory
	 * @return List<String>
	 */
	@Profiled
	public List<String> getLastActionColumnQualifiersPrefix(String mainCategory, String eventType, boolean groupSubCategory) {
		// if groupSubCategory = false then column qualifier suffix of
		// last-action table = "AllSubCategory" else suffix is empty
		//String[][] defaultColumnQualifiers = UserDataConfiguration.LAST_ACTION_COLUMN_QUALIFIER_ALL_SUB;

		List<String> result = new ArrayList<String>();
		String suffix = "";
		if (!groupSubCategory) {
			suffix = "AllSubCategory";
		}

		String[] maincategories = null;
		if(mainCategory == null) {
			maincategories = UserDataConfiguration.MAIN_CATEGORIES.removeLastValue();
		} else {
			maincategories = new String[]{mainCategory};
		}

		String[] eventtypes = null;
		if(eventType == null) {
			eventtypes = UserDataConfiguration.EVENT_TYPES.getValues();
		} else {
			eventtypes = new String[] {eventType};
		}

		for(String maincategory : maincategories) {
			for(String eventtype : eventtypes) {
				String columnName = maincategory + "." + eventtype;
				if(!suffix.isEmpty()) {
					columnName += "." + suffix;
				}

				result.add(columnName);
			}
		}


		//int rowIndex = UserDataConfiguration.MAIN_CATEGORIES.getIndex(mainCategory);
		//int columnIndex = UserDataConfiguration.EVENT_TYPES.getIndex(eventType);

		// create column qualifier prefix of last-action table
		//List<String> columnQualifiersPrefix = ArrayUtil.getValuesByIndex(rowIndex, columnIndex, defaultColumnQualifiers);
		return result;
	}

}
