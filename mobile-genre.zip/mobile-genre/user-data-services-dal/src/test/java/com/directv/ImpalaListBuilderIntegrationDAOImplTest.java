package com.directv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.directv.uds.model.rs.response.LastActionElement;
import com.directv.uds.model.rs.response.PreviewResponse;
import com.directv.uds.model.rs.response.PreviewResult;
import com.directv.uds.utils.JSONUtil;

public class ImpalaListBuilderIntegrationDAOImplTest {
	private LastActionElement lastActionElement = null;
	private PreviewResult previewResult =null;
	@Before
	public void setUp() throws Exception {
		lastActionElement = new LastActionElement();
		lastActionElement.setTmsId("EP017211070241");

		lastActionElement.setEventTime("20141030053730");

		lastActionElement.setProgramTitle("The Tonight Show Starring Jimmy Fallon");

		lastActionElement.setGenre1("Comedy");
		lastActionElement.setGenre2("Mystery/Crime");
		lastActionElement.setGenre3("Series");
		previewResult = new PreviewResult();
	}

	@After
	public void tearDown() throws Exception {
		lastActionElement = null;
		previewResult = null;
	}

	
	public void testConvertToJson() throws IOException {
		String json = JSONUtil.convertObjectToJson(lastActionElement);
		lastActionElement = JSONUtil.convertJsonToObject(json, LastActionElement.class);
		Assert.assertNull(lastActionElement.getGenre1());
		Assert.assertNull(lastActionElement.getGenre2());
		Assert.assertNull(lastActionElement.getGenre3());

	}
	@Test
	public void testConvertLastActionPreviewResultToJson() throws IOException{
		PreviewResponse udsPreviewRules = new PreviewResponse();
		previewResult.setRuleName("testRule");
		List<LastActionElement> lastActionElements = new ArrayList<LastActionElement>();
		lastActionElements.add(lastActionElement);
		String json = JSONUtil.convertObjectToJson(lastActionElements);
		System.out.println(json);
		lastActionElements = Arrays.asList(JSONUtil.convertJsonToObject(json, LastActionElement[].class));
		System.out.println(JSONUtil.convertObjectToJson(lastActionElements));
	}

}
