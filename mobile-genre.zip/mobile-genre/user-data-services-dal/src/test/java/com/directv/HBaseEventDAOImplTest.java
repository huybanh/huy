package com.directv;

import org.junit.Test;

import com.directv.uds.model.InterpretedEvent;
import com.directv.uds.utils.JSONUtil;

public class HBaseEventDAOImplTest {
	@Test
	public void test() {
		String json = "[{\"source\":\"1\",\"accountId\":\"88003033\",\"durationViewed\":20,\"runLength\":30,\"lastModifiedDate\":null,\"eventType\":\"LiveViewEvent\",\"mainCategory\":\"TV\",\"interpretedEventType\":\"Watch\",\"genre1\":\"Art\",\"genre2\":\"Animation\",\"genre3\":\"Kids\",\"tmsId\":\"EP007764580067\",\"programTitle\":\"Little Einsteins\",\"eventTime\":\"20141030080000\"}]";
		InterpretedEvent[] interpretedEvents = JSONUtil.convertJsonToObject(json, InterpretedEvent[].class);
		System.out.println(interpretedEvents.length);
	}
}
