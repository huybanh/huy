source("calculate_cbcf.R")
kMainHdfsDir <<- "/user/svc.cloudrec.dv2/CHANHNLT1/input"
FirsttimeCBCFTest <-function()
{
	# result from function
	rxSetComputeContext(my.hadoop.cluster)
	FirstTimeCbcf(10,"20141113")
	result.file <- file.path(paste(KFinalCbcfByday,"20141111.xdf",sep="/"))
	result.data <- rxDataStep(inData = result.file)
	result.data[] <- lapply(result.data, function(x) type.convert(as.character(x)))
	rxSetComputeContext('local')
	#set correct result
    fgenre <- paste("G", seq(1, 18), sep= "")
    fmoviegroup <- paste("MG", seq(1, 210), sep = "")
    fmovietype <- paste("MT", seq(1, 121), sep = "")
    fsubgenre <- paste("SG", seq(1, 49), sep = "")
	correct.result <- data.frame(matrix(NA, nrow = 0, ncol = length(fmoviegroup) + length(fmovietype) + length(fsubgenre) + length(fgenre) + 1),stringsAsFactors = FALSE)
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	#acc1
	acc1 <- data.frame(as.list(c("acc1",rep(0,398))), stringsAsFactors = FALSE)
	names(acc1) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result <- rbind(correct.result, acc1)
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result$accountid[1] <- "acc1"
	correct.result$MG130[1] <- 100
	correct.result$MG180[1] <- 100
	correct.result$MT70[1] <- 100
	correct.result$MT109[1] <- 100
	correct.result$SG25[1] <- 100
	correct.result$SG43[1] <- 100
	correct.result$G11[1] <- 100
	correct.result$G17[1] <- 100
	#acc2
	acc2 <- data.frame(as.list(c("acc2",rep(0,398))), stringsAsFactors = FALSE)
	names(acc2) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result <- rbind(correct.result, acc2)
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result$accountid[2] <- "acc2"
	correct.result$MG130[2] <- 100
	correct.result$MG180[2] <- 100
	correct.result$MT70[2] <- 100
	correct.result$MT109[2] <- 100
	correct.result$SG25[2] <- 100
	correct.result$SG43[2] <- 100
	correct.result$G11[2] <- 100
	correct.result$G17[2] <- 100
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result[] <- lapply(correct.result, function(x) type.convert(as.character(x)))
	
	return(all.equal(correct.result,result.data))
}

DailyUpdateTest <- function(){

# result from function
	rxSetComputeContext(my.hadoop.cluster)
	DailyUpdate(insertedtime = "20141113",number.day=10)
	result.file <- file.path(paste(KFinalCbcfBytimewindow,"20141104_20141113.xdf",sep="/"))
	result.data <- rxDataStep(inData = result.file)
	result.data[] <- lapply(result.data, function(x) type.convert(as.character(x)))
	rxSetComputeContext('local')
	#set correct result
    fgenre <- paste("G", seq(1, 18), sep= "")
    fmoviegroup <- paste("MG", seq(1, 210), sep = "")
    fmovietype <- paste("MT", seq(1, 121), sep = "")
    fsubgenre <- paste("SG", seq(1, 49), sep = "")
	correct.result <- data.frame(matrix(NA, nrow = 0, ncol = length(fmoviegroup) + length(fmovietype) + length(fsubgenre) + length(fgenre) + 1),stringsAsFactors = FALSE)
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	#acc1
	acc1 <- data.frame(as.list(c("acc1",rep(0,398))), stringsAsFactors = FALSE)
	names(acc1) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result <- rbind(correct.result, acc1)
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result$accountid[1] <- "acc1"
	correct.result$MG130[1] <- 1200
	correct.result$MG180[1] <- 1200
	correct.result$MT70[1] <- 1200
	correct.result$MT109[1] <- 1200
	correct.result$SG25[1] <- 1200
	correct.result$SG43[1] <- 1200
	correct.result$G11[1] <- 1200
	correct.result$G17[1] <- 1200
	#acc2
	acc2 <- data.frame(as.list(c("acc2",rep(0,398))), stringsAsFactors = FALSE)
	names(acc2) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result <- rbind(correct.result, acc2)
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result$accountid[2] <- "acc2"
	correct.result$MG130[2] <- 1200
	correct.result$MG180[2] <- 1200
	correct.result$MT70[2] <- 1200
	correct.result$MT109[2] <- 1200
	correct.result$SG25[2] <- 1200
	correct.result$SG43[2] <- 1200
	correct.result$G11[2] <- 1200
	correct.result$G17[2] <- 1200
	names(correct.result) <- c("accountid", fmoviegroup, fmovietype, fsubgenre, fgenre)
	correct.result[] <- lapply(correct.result, function(x) type.convert(as.character(x)))
	
	return(all.equal(correct.result,result.data))

}
