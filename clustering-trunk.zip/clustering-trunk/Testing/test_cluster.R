TestCluster <- function(filteredDir, clusterDir, clusterVar, accVar, cbcfVars, testConfig, clusterSize, fileSystem = rxGetFileSystem()) {
  # Performs cluster test.
  #
  # Args:
  #   filteredDir : Path to xdf filtered data i.e. CBCF data after filtering.
  #   clusterDir : Path to xdf cluster data. This data contains the cbcf vectors and an additional column for cluster labels.
  #   clusterVar : Cluster column's name.
  #   accVar : accountid column's name.
  #   cbcfVars : Vector of CBCF columns's names.
  #   testConfig: A list of test parameters.
  #     E.g. 
  #     + testConfig$top = c(0.1, 0.6) implies the test "The top 10% most frequent Movies will appear in more than 60% of the customers viewing history in that cluster".
  #     + testConfig$bottom = c(0.1, 0.1) implies the test "The bottom 10% least frequent Movie will appear in less than 10 % of the customers viewing history in that cluster".
  #   clusterSize: A table contains size of each cluster.
  #   fileSystem: An object indicating type of file system.
  # Returns:
  #  A data frame contains test results.
  
  cat("Checking arguments...\n")
  stopifnot(is.character(filteredDir))
  stopifnot(is.character(clusterDir))
  stopifnot(is.character(accVar))
  stopifnot(is.character(clusterVar))
  stopifnot(is.vector(cbcfVars))
  stopifnot(is.list(testConfig))
  cat("Successful.\n")
  
    
  # load cluster data
  cat("Retrieving cluster data...\n")
  cluster.data <- rxDataStep(RxXdfData(clusterDir,varsToKeep = c(clusterVar, accVar), fileSystem=fileSystem), maxRowsByCols = 30000000)
  cat("Successful.\n")
  
  # original cbcf data
  filtered.data <- RxXdfData(clusterDir,varsToKeep = c(accVar,cbcfVars), fileSystem=fileSystem)
  
  # return table
  pass.table <- data.frame()  
  
  # aggregation formula
  aggr.formula <- paste0("cbind(",paste(cbcfVars,collapse=","),")~",clusterVar)
  
  # aggregate data frame
  view.aggr <- data.frame()
  saw.aggr <- data.frame()
  
  cat("Aggregating cbcf values...\n")
  rxOpen(filtered.data)  
  is.empty.data <- FALSE
	#Read each chunk of data which is set maximum row is maxRow	
	while (!is.empty.data) {
    block.data <- rxReadNext(filtered.data)
    if (nrow(block.data) == 0) {
      is.empty.data = TRUE
    } else {
      # add cluster information
      block.data <- merge(block.data,cluster.data,by=accVar)
      # sometimes block.data is empty after merging
      if (nrow(block.data) > 0) {
        #aggregate view percentage for each feature
        view.aggr <- aggregate(formula(aggr.formula), data=rbind(view.aggr,block.data), sum, na.rm=TRUE)
        
        block.data[,cbcfVars][block.data[,cbcfVars] > 0] <- 1        
        # aggregate number of customers who watched this feature
        saw.aggr <- aggregate(formula(aggr.formula), data=rbind(saw.aggr,block.data), sum, na.rm=TRUE)    
      }
    }	
  }
  rxClose(filtered.data)
  cat("Successful.\n") 
    
    
  # number of features need to be tested
  top.n <- 0
  bottom.n <- 0
  if ("top" %in% names(testConfig))
    top.n <- round(testConfig$top[1] * length(cbcfVars))
  if ("bottom" %in% names(testConfig))
    bottom.n <- round(testConfig$bottom[1] * length(cbcfVars))
  
  
  clusters <- view.aggr[[clusterVar]]
  
  # translate to percentage
  for (cl in clusters){
    saw.aggr[saw.aggr[clusterVar]==cl,cbcfVars] <- saw.aggr[saw.aggr[clusterVar]==cl,cbcfVars]/clusterSize[[cl]]	
  }
  
  
  
  # test
  cat("Testing...\n")
  for (cl in clusters){
    is.pass <- TRUE    
    f.order <- names(view.aggr[view.aggr[clusterVar]==cl,cbcfVars][order(view.aggr[view.aggr[clusterVar]==cl,cbcfVars],decreasing = TRUE)])   
    
    # test top frequent
    if (top.n > 0){
      for (fea in f.order[1:top.n]){        
        if (saw.aggr[saw.aggr[clusterVar]==cl,fea] <  testConfig$top[2]){
          is.pass <- FALSE
          break
        }
      }
    }
    
    # test bottom frequent
    if (is.pass & bottom.n > 0){
      for (fea in f.order[(length(f.order)-bottom.n + 1):length(f.order)]){       
        if (saw.aggr[saw.aggr[clusterVar]==cl,fea] >  testConfig$top[2]){
          is.pass <- FALSE
          break
        }
      }  
    }    
    
    pass.table <- rbind(pass.table,data.frame(cluster=cl,pass=is.pass))
  }
  cat("Successful.\n")
  
   
  return(pass.table)
 
}

ExtractAccountIdFromFailedCluster <- function(inDir,passTable,idColName,clusterColName,fileSystem = rxGetFileSystem()){
  # Extracts the list of unclustered account id from input data.
  #
  # Args:
  #   inDir: A character string specifying input xdf data source.
  #   passTable: A data frame/matrix containing test results.
  #   idColName: A character string specifying the accountid column name.
  #   clusterColName: A character string specifying the cluster column name.
  #   fileSystem: Object indicating type of file system.
  # Returns:
  #   A data frame containing account ids.
  
  
  cluster.data <- RxXdfData(inDir,varsToKeep = c(idColName, clusterColName),fileSystem=fileSystem)    
  
  pass.cl <- passTable[[1]][!passTable[[2]]]
  logic.exp <- paste0(clusterColName," %in% pass")
  
  
  rxDataStep(cluster.data,rowSelection=parse(text=logic.exp),transformObjects = list(pass = pass.cl),varsToKeep = c(idColName))
}

ExtractAccountIdFromQualifiedCluster <- function(inDir,passTable,idColName,clusterColName,fileSystem = rxGetFileSystem()){
  # Extracts the list of clustered account id from input data.
  #
  # Args:
  #   inDir: A character string specifying input xdf data source.
  #   passTable: A data frame/matrix containing test results.
  #   idColName: A character string specifying the accountid column name.
  #   clusterColName: A character string specifying the cluster column name.
  #   fileSystem: Object indicating type of file system.
  # Returns:
  #   A data frame containing account ids.
  
  cluster.data <- RxXdfData(inDir,varsToKeep = c(idColName, clusterColName),fileSystem=fileSystem)    
  
  pass.cl <- passTable[[1]][passTable[[2]]]
  logic.exp <- paste0(clusterColName," %in% pass")
  
  
  rxDataStep(cluster.data,rowSelection=parse(text=logic.exp),transformObjects = list(pass = pass.cl),varsToKeep = c(clusterColName,idColName))
}