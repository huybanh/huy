#NOTE: Follow examples of transform function in RevoR when implementing new normalize method.


NormalizeQuartileFunc <- function(data){
  # Normalize by Quartile method.
  #
  # Args:
  #   data: A chunk of data.
  # Returns:
  #   Normalized data.
  
  for (acbcf.vars in cols){
    
    # initialize 
    q1 <- rep(0,length(data[[acbcf.vars[1]]]))	
    med <- q1
    q3 <- q1

    # store uniform row
    eq.row <- c()

    # compute quantiles
    for (i in 1:length(q1)){
      v <- c()
      for (var in acbcf.vars)
        v <- c(v,data[[var]][i])
      summ <- summary(v)
      q1[i] <- summ[[2]]
      med[i] <-summ[[3]]
      q3[i] <- summ[[5]]
  
      if(summ[[1]] == summ[[6]]) {# min == max
        eq.row <- c(eq.row,i)
      }
    }

    # set value
    for (var in acbcf.vars) {
      tbl1 <- data[[var]] <= q1
      tbl2 <- data[[var]] > q1 & data[[var]] <= med
      tbl3 <- data[[var]] > med & data[[var]] <= q3
      tblu <- rep(FALSE,length(tbl1))
      tblu[eq.row] <- TRUE
  
      data[[var]][tbl1] <- 0.25
      data[[var]][tbl2] <- 0.5
      data[[var]][tbl3] <- 0.75		
      data[[var]][!(tbl1 | tbl2 | tbl3)] <- 1.0				
  
      data[[var]][tblu] <- 0.5
    }
  }
  
  return(data)
}



NormalizeMinMaxFunc <- function(data){
  # Normalizes By MinMax method.
  # Args:
  #   data: A chunk of data.
  # Returns:
  #   Normalized data.
  
  for (acbcf.vars in cols){    
    mins <- NULL
    maxs <- NULL
    for (var in acbcf.vars){
      if (is.null(mins) & is.null(maxs)) {
        mins <- data[[var]] 
        maxs <- data[[var]]
      } else {
        mins[mins > data[[var]]] <- data[[var]][data[[var]] < mins] 
        maxs[maxs < data[[var]]] <- data[[var]][data[[var]] > maxs]      
      }
    }
    #print(mins)
    #print(maxs)
    maxs[maxs == 0] <- 1  
    tbl <- (maxs == mins)
    if (any(tbl)){
      maxs[tbl] <- maxs[tbl] + maxs[tbl]
      mins[tbl] <- 0
    }
    for (var in acbcf.vars){	
      data[[var]] <- (data[[var]] - mins) / (maxs - mins)
    }
  }
  return(data)
}



NormalizeCBCFByTransformFunc <- function(inDir, outDir, colList, func = NormalizeMinMaxFunc, fileSystem = rxGetFileSystem()) {
  # Performs normalization on CBCF data.
  #
  # Args:
  #   inDir: A character string specifying input xdf data source.
  #   outDir: A character string specifying output xdf data source.
  #   colList: A list of CBCF variables grouped by CBCF vector.
  #   func: Normalization function. Currently supports MinMax and Quartile.
  #   fileSystem: An object indicating type of file system.
  # Returns:
  #   A RxXdfData data source object containing normalized data.
  
  cat("Checking arguments...\n")
  stopifnot(is.character(inDir))
  stopifnot(is.character(outDir))
  stopifnot(is.list(colList))
  cat("Successful.\n")

  in.data <- RxXdfData(inDir,fileSystem=fileSystem)
  out.data <- RxXdfData(outDir,fileSystem=fileSystem)
  
  cat("Retrieving variable names...\n")
  vars <- rxGetVarNames(in.data) 
  cat("Successful.\n")

  cat("Normalizing...\n")
  rxDataStep(inData = in.data, outFile = out.data, transformObjects = list(cols = colList), transformFunc = func, transformVars = vars, overwrite = TRUE)
  cat("Successful.\n")  
  
  return(out.data)
}

 
