# import clustering modules
source("../hadoop_config.R")
source("../cluster_properties.R")
source("../FeatureSelection/feature.R")

# generate a list of cbcf variables corresponding to each level.
# e.g If level == 1100b (or 12 in decimal) then return list(genre,subgenre)
in.file <- "unittest.xdf"
out.file <- "out.xdf"
GenerateVarList <- function(level) {
  vars.keep = list()
  if (bitwAnd(level, 1))
    vars.keep[["mvgrp"]] =  movieGroup
  if (bitwAnd(level, 2))
    vars.keep[["mvtype"]] =  movieType
  if (bitwAnd(level, 4))
    vars.keep[["subgenre"]] = subGenre
  if (bitwAnd(level, 8))
    vars.keep[["genre"]] = Genre
  return(vars.keep)
}

# file system and compute context for clustering task
computeOn <- "local"
if (computeOn == "hadoop") {
  file.system <- GetHadoopFileSystem()
  #hdcc <- GetHadoopComputeContext()
  rxSetComputeContext(GetHadoopComputeContext())
} else if (computeOn == "local") {
  file.system <- RxFileSystem("native")
  rxSetComputeContext("local")
}

UnitTestFeaSel <- function(level = 1) {
	vars.list <- GenerateVarList(level)
	inCbcf <- RxXdfData(in.file ,fileSystem=file.system)
	outSelected <- RxXdfData(out.file ,fileSystem=file.system)
	FeatureSelection(inCbcf, outSelected,varsKeep = unlist(vars.list), firstTime = (level == 1), orphanFile = accFile,fileSys = file.system)
	filter.data.frame <- read.csv(accFile)
	
	num.vars <- 1
	if (bitwAnd(level, 1))
		num.vars = num.vars + 210
	if (bitwAnd(level, 2))
		num.vars = num.vars + 121
	if (bitwAnd(level, 4))
		num.vars = num.vars + 49
	if (bitwAnd(level, 8))
		num.vars = num.vars + 18
	info <- rxGetInfo(outSelected)
	
	if (info$numVars != num.vars)
		return(FALSE)
	seletedData <- rxDataStep(outSelected)
	cbcfData <- rxDataStep(inCbcf)
	for (str in filter.data.frame[["accountid"]]) {
	  if (str %in% cbcfData[["accountid"]]) {
	    if (!(str %in% seletedData[["accountid"]])) {
		  print(str)
		  return(FALSE)
		}
	  }
	}
	return(TRUE)
}

TestFeaSel <- function() {
	cat("Smoke Testing of Feature Selection")
	for (level in list(1, 3, 7, 15)) {
		if (UnitTestFeaSel(level) == FALSE) {
			cat("Smoke Test failed")
			return(FALSE)
		}
	}
	cat("Feature Selection: smoke test successful!")
	return(TRUE)
}
	