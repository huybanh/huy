source("clustering_config.R")



GenerateVarList <- function(level) {
  # Generates a list of cbcf variables corresponding to each level. 
  #   E.g. If level == 1100b (or 12 in decimal) then return list(genre,subgenre).
  #
  # Args:
  #   level: An integer indicating the level.
  # Returns:
  #   A list of cbcf variables.
  vars.keep = list()
  if (bitwAnd(level, 1))
    vars.keep[["mvgrp"]] =  movieGroup
  if (bitwAnd(level, 2))
    vars.keep[["mvtype"]] =  movieType
  if (bitwAnd(level, 4))
    vars.keep[["subgenre"]] = subGenre
  if (bitwAnd(level, 8))
    vars.keep[["genre"]] = Genre
  
  return(vars.keep)
}


 
RunClustering <- function() {
  # Main function of clustering task  
  
  # Logging config
  if (logMode == "file") {
    log.file <- paste0(logFile,".",format(Sys.time(),"%Y%m%d%H%M%S"))
    sink(file = log.file)
    on.exit({
      sink()      
      })
  }
  
  # output on local file system
  qualified.local.output <- paste(localOutDir, qualifiedClusterFile, sep = "/")  
  representative.local.output <- paste(localOutDir, representativeFile, sep = "/")
  
  cat("*******************************************************\n")
  cat(paste0("REVOSCALER: ",k,"-MEANS CLUSTERING ON CBCF DATA\n"))
  cat("*******************************************************\n")
  
  
  
  # Excution time measurement variables
  elapsed <- 3 # elapsed time column index. Refers to proc.time() object.
  classify.time <- 0
  norm.time <- 0
  feasel.time <- rep(0,length(levelOrder))
  kmeans.time <- rep(0,length(levelOrder))
  test.time <- rep(0,length(levelOrder))
  represent.time <- rep(0,length(levelOrder))
  extract.time <- rep(0,length(levelOrder))
  
  # count the number of clustering qualified and failure account for each iteration
  qualified.count <- rep(0,length(levelOrder))
  # count the number of iterations for each k-means clustering call
  kmeans.iter.count <- rep(0,length(levelOrder))
       
  cat("-------------------------------CLASSIFICATION-------------------------------\n")  
  logic.exp <- GetLowActivityFilterExpression(c(movieGroup,movieType,subGenre,Genre),viewThreshold)    # (var1 + var2 + ... + varn) > viewThreshold
  classify.time <- system.time(FilterAccountsByExpression(cbcfDir,filteredDir,logic.exp,fileSystem = file.system))[[elapsed]]    
  cat(paste("Done in",classify.time,"sec.\n"))
  
  
  cat("-------------------------------NORMALIZATION-------------------------------\n")    
  cat("Normalization method: ",normalizeMethod,"\n")  
  norm.time <- system.time(NormalizeCBCFByTransformFunc(filteredDir, normalizedDir, list(movieGroup,movieType,subGenre,Genre), func = NormalizeFunc, fileSystem = file.system))[[elapsed]]  
  cat("Done in",norm.time,"sec.\n")
  
  
  
  cat("-----------------------------START CLUSTERING JOBS-----------------------------\n")
  # loop control variables
  done.clustering <- FALSE
  iter <- 1 
  # max value of used cluster labels in previous interations  
  last.cluster.label <- 0
  cluster <- NULL
  
  # start the loop
  # normalizedDir as input  
  while(!done.clustering & iter <= length(levelOrder)) {    
    cat("ITERATION:",iter,"\n")
    current.level <- levelOrder[iter]
    cat("Level:",current.level,"\n")
    if (iter == length(levelOrder)){
      cat("Reach the final level. This is the last clustering iteration.\n")      
      done.clustering <- TRUE
    }    
    vars.list <- GenerateVarList(current.level)
    
    cat("-----------FEATURE SELECTION-----------\n")    
    feasel.time[iter] <- system.time(FeatureSelection(RxXdfData(normalizedDir,fileSystem=file.system),RxXdfData(selectedDir,fileSystem=file.system),varsKeep = unlist(vars.list), firstTime = (iter == 1), orphanFile = accFile,fileSys = file.system))[[elapsed]]    
    cat("Done in",feasel.time[iter],"sec.\n")
    
    
    cat("-----------K-MEANS CLUSTERING-----------\n")
    cat("Clustering...\n")
    # generate the clustering formula i.e. "~var1+var2+ ... +varn"
    fstr <- paste(unlist(vars.list), collapse = "+")
    fstr <- paste("~", fstr, sep="")    
    form = as.formula(fstr)
    kmeans.time[iter] <- system.time({cluster <- rxKmeans(formula = form, data = RxXdfData(selectedDir,fileSystem=file.system), outFile = RxXdfData(clusterDir,fileSystem=file.system), outColName = clusterColName, overwrite = TRUE, numClusters=k, writeModelVars=TRUE, extraVarsToWrite=c("accountid"))})[[elapsed]]
    kmeans.iter.count[iter] <- cluster$numIterations    
    cat("Successful.\n")
    cat("Done in",kmeans.time[iter],"sec.\n")
    
    
    
    cat("-----------TESTING-----------\n")        
    test.time[iter] <- system.time({test.result <- TestCluster(filteredDir = filteredDir, clusterDir = clusterDir, clusterVar = clusterColName, accVar = accColName, cbcfVars = unlist(vars.list), testConfig = clusterTestConfig , clusterSize = cluster$size, fileSystem = file.system)})[[elapsed]]
    print(test.result)    
    cat("Done in",test.time[iter],"sec.\n")
    
    
    if (any(test.result[[2]])){    
      cat("-----------PRODUCE REPRESENTATIVES-----------\n")      
      represent.time[iter] <- system.time({repres <- ProduceRepresentative(xdf.location=clusterDir,passed=test.result[[1]][test.result[[2]]], xdf.filtered = filteredDir, hdfs=file.system)})[[elapsed]]      
      repres[[clusterColName]] <- repres[[clusterColName]] + last.cluster.label      
      write.table(repres, representative.local.output, sep = ",", quote = FALSE,  col.names = FALSE, row.names = FALSE, append = (iter > 1))      
      cat("Done in",represent.time[iter],"sec.\n")      
    }
    
    cat("-----------MISC-----------\n")
    
    extract.time[iter] <- system.time({
    if (any(test.result[[2]])){    
      cat("Retrieving qualified cluster...\n")
      clustered <- ExtractAccountIdFromQualifiedCluster(clusterDir,test.result,accColName,clusterColName,fileSystem = file.system)      
      qualified.count[iter] <- nrow(clustered)
      
      # rxKmeans labelled cluster from 1 to k, which maybe already used in previous iteration, thus new labels are needed
      clustered[[clusterColName]] <- clustered[[clusterColName]] + last.cluster.label      
      write.table(clustered, qualified.local.output, sep = ",", quote = FALSE,  col.names = FALSE, row.names = FALSE, append = (iter > 1))  
      # update last.cluster.label
      last.cluster.label <- max(test.result[[1]][test.result[[2]]]) + last.cluster.label
      cat("Successful.\n")
      cat("Number of clustered accounts:",qualified.count[iter],"\n")
      
    }   
    
    
    
    if (all(test.result[[2]])) {
      cat("Successful clustering.\n")
      done.clustering <- TRUE   
    } else {      
      cat("Retrieving accounts from unqualified clusters...\n")
      write.table(ExtractAccountIdFromFailedCluster(clusterDir,test.result,accColName,clusterColName,fileSystem = file.system), accFile, sep = ",", quote = FALSE,  col.names = TRUE, row.names = FALSE) # return a data frame at the moment
      cat("Successful.\n")      
    }
    })[[elapsed]]
    
    iter <- iter + 1    
    
  }
  
  # copy results to hdfs
  if (computeOn == "hadoop") {
    cat("Removing old files if exist...\n")
    rxHadoopRemove(paste(hdfsOutDir,qualifiedClusterFile,sep="/"))
    rxHadoopRemove(paste(hdfsOutDir,representativeFile,sep="/"))
    cat("Copying results to hdfs...\n")
    rxHadoopCopyFromLocal(qualified.local.output, hdfsOutDir)
    rxHadoopCopyFromLocal(representative.local.output, hdfsOutDir)    
    if (removeLocalOutput) {
      file.remove(qualified.local.output)
      file.remove(representative.local.output)
    }
    cat("Successful.\n")
  }
  
  # remove temporary files
  file.remove(accFile)
  
  cat("-------------------------------CLUSTERING DONE-------------------------------\n")
  cat("Compute Context: ",computeOn, "\n")
  cat("K = ",k,"\n")
  cat("Levels:",paste(levelOrder,collapse=","), "\n")
  if ("top" %in% names(clusterTestConfig))
    cat(paste0("Cluster Test Requirement: The top ",clusterTestConfig$top[1]*100,"% most frequent Movies will appear in more than ",clusterTestConfig$top[2]*100,"% of the customers viewing history in that cluster.\n"))
  if ("bottom" %in% names(clusterTestConfig))
    cat(paste0("Cluster Test Requirement: The bottom ",clusterTestConfig$bottom[1]*100,"% least frequent Movie will appear in less than ",clusterTestConfig$bottom[2]*100,"% of the customers viewing history in that cluster.\n"))
  
  cat("Number of clustered accounts:\n")
  cat(qualified.count,"\n")
  cat("Number of iterations for each k-means call:\n")
  cat(kmeans.iter.count,"\n")
  
  cat("Execution time in seconds.\n")
  cat("Classification:",classify.time,"\n")
  cat("Normalization:",norm.time,"\n")
  cat("Feature Selection:\n")
  cat(feasel.time,"\n")
  cat("K-means Clustering:\n")
  cat(kmeans.time,"\n")
  cat("Test:\n")
  cat(test.time,"\n")
  cat("Representative Production:\n")
  cat(represent.time,"\n")
  cat("Misc:\n")
  cat(extract.time,"\n")  
  
  cat("------------------------------------EXIT------------------------------------\n")  
 } 

 RunClustering()