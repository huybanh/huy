#######################INPUT#######################
# Store computed cbcf data 
cbcfDir <- "/user/svc.cloudrec.dv2/thachln1/20141103_20141114.xdf"
accColName <- "accountid"
movieGroup <- paste("MG", 1:210, sep="")
movieType <- paste("MT", 1:121, sep="")
subGenre <- paste("SG", 1:49, sep="")
Genre <- paste("G", 1:18, sep="")
#cbcf.cols <- list(2:211,212:332,333:381,382:399)
###################################################

#######################OUTPUT######################
# output includes representativeFile and qualifiedClusterFile
hdfsOutDir <- "/data/dv/recommendation/analytics/clustering"
localOutDir <- "/tmp"
# output file names
representativeFile <- "representative.csv"
qualifiedClusterFile <- "qualified.csv"
# remove local output if compute context is hadoopmr
removeLocalOutput <- TRUE
###################################################

###################CLASSIFICATION###################
# Store cbcf data after filtering
filteredDir <- "/data/dv/recommendation/analytics/clustering/filtered"
# View threshold for filtering.
viewThreshold <- 50.0
####################################################


###################NORMALIZATION###################
# curretnly support "minmax" and "quartile"
normalizeMethod <- "minmax" 
# Store cbcf data after normalization
normalizedDir <- "/data/dv/recommendation/analytics/clustering/normalized"
####################################################


###################FEATURE SELECTION###################
# Store cbcf data after feature selection
selectedDir <- "/data/dv/recommendation/analytics/clustering/selected"
# Temporarily store unclustered account on local filesystem
accFile <- "/tmp/noCluster.csv"
#######################################################


###################K-MEANS CLUSTERING###################
# Store clustering output
clusterDir <- "/data/dv/recommendation/analytics/clustering/cluster"
clusterColName <- "cluster"
k <- 10
################################################


###################PRODUCE REPRESENTATIVES###################
#############################################################


###################TESTING###################
# test.cust.percent: Test requirement input. Percentage of customers required for a feature to pass the test.
# test.fea.percent: Test requirement input. Percentage of most frequent "features" 
# For example: The requirement "The top 10% most frequent Movies will appear in more than 60% of the customers viewing history in that cluster" implies test.cust.percent = 0.6 and test.fea.percent = 0.1
#test.fea.percent <- 0.01
#test.cust.percent <- 0.4

# test.config: A list of test parameters.
# E.g. 
# + test.config$top = c(0.1, 0.6) implies the test "The top 10% most frequent Movies will appear in more than 60% of the customers viewing history in that cluster".
# + test.config$bottom = c(0.1, 0.1) implies the test "The bottom 10% least frequent Movie will appear in less than 10 % of the customers viewing history in that cluster".
clusterTestConfig <- list(top = c(0.01, 0.4))
#############################################


###################MAIN CONFIGURATION###################

#start.level <- 1

levelL4L1 <- c(1,3,7,15)#0001->0011->0111->1111
levelL1L4 <- c(8,12,14,15)#1000->1100->1110->1111
levelOrder <- levelL4L1


# currently support "hadoop" and "local"
computeOn <- "hadoop"
########################################################

###################LOGGING###################
# currently support "file" and "console"
# if logMode == "file", logFile is ignored
logMode <- "console"
logFile <- "clustering.log"
#############################################################