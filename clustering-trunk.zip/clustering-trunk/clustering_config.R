# import clustering modules
source("hadoop_config.R")
source("cluster_properties.R")
source("Classification/filter_accounts.R")
source("Normalization/normalize_cbcf_vector.R")
source("Testing/test_cluster.R")
source("FeatureSelection/feature.R")
source("Clustering/produce_representative.R")


# file system and compute context for clustering task
if (computeOn == "hadoop") {
  file.system <- GetHadoopFileSystem()
  #hdcc <- GetHadoopComputeContext()
  rxSetComputeContext(GetHadoopComputeContext())
} else if (computeOn == "local") {
  file.system <- RxFileSystem("native")
  rxSetComputeContext("local")
}

# set normalize function
if (normalizeMethod == "minmax") {
  NormalizeFunc <- NormalizeMinMaxFunc
} else if (normalizeMethod == "quartile") {
  NormalizeFunc <- NormalizeQuartileFunc
}

