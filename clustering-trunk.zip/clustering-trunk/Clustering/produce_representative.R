#
# 
ProduceRepresentative <- function(xdf.location = "/user/svc.cloudrec.dv2/thachln1/Clustering/cluster", passed = c(1,26,28,33,35,37,41,42,44,48,50), xdf.filtered = "/user/svc.cloudrec.dv2/thachln1/Clustering/filtered", hdfs = rxGetFileSystem())
{
#Description: this function is to select represents for each cluster
#
#Args:
#  xdf.location: link to result of clustering output under xdf format
#  testing.result: result of cluster testing
#  xdf.filtered: original file keeps all information related to 4 vectors Genre, Subgenre, MovieType, MovieGroup for each accountid  
#  hdfs: file system
#
#Returns: a data.frame keeps clusters and its coresponding represent 

  if (length(passed) == 0) {
    print("No cluster satisfied testing. Program finishs!")
	return(0)
  }	

  xdf.source <- RxXdfData(file = xdf.location, fileSystem = hdfs)
  input.data <- rxDataStep(inData = xdf.source, stringsAsFactors = FALSE,
			               overwrite = TRUE,
			               rowSelection = cluster %in% passed,
			               transformObjects = list(passed = passed),
			               rowsPerRead = 20000,maxRowsByCols= 30000000)
  cluster.col <- which(names(input.data) == "cluster")
  accountid.col <- which(names(input.data) == "accountid")
  input.data$cluster <- as.factor(input.data$cluster)
  
  candidates <- tapply( 1:nrow(input.data),
                        input.data$cluster,
					    function (id, data = input.data[id, ]) 
						{
					      ##sapply to apply FUNC to data
					      if (length(id) > 1){
						    dists <- rowSums(sapply(data[, c(-cluster.col, -accountid.col)] , function(x) (x-mean(x))^2))
						    rownames(data)[dists == min(dists)]
					      }else{
						      #print(id)
						      rownames(data)
					      }
					   })
					   
  result <- data.frame(matrix(NA, nrow = 0, ncol = 2), stringsAsFactors = FALSE)
  names(result) <- c("cluster", "accountid")
  
  for (i in 1: length(candidates)){
  
	if (length(candidates[[i]]) > 1){
	  accounts <- input.data[candidates[[i]], accountid.col]
	  chosen.account <- FilterMaxTotalViewAccount(accounts = accounts, xdf.filtered = xdf.filtered, hdfs = hdfs)
	  newRow <- c(names(candidates[i]), chosen.account)
	  names(newRow) <- c("cluster", "accountid")
	  result <- rbind(result,  data.frame(as.list(newRow), stringsAsFactors=F))		
	  names(result) <- c("cluster", "accountid")
	}else if (length(candidates[[i]]) == 1){
	  newRow <- input.data[candidates[[i]], c(cluster.col, accountid.col)]
	  names(newRow) <- c("cluster", "accountid")
	  result <- rbind(result, data.frame(as.list(newRow), stringsAsFactors=F) )
	  names(result) <- c("cluster", "accountid")
	}
    
  }
  
  result[ , 1] <- as.numeric(as.character(result[ , 1]))
  return (result)
}


FilterMaxTotalViewAccount <- function(accounts, xdf.filtered = "/user/svc.cloudrec.dv2/thachln1/Clustering/filtered", hdfs)
{
#Description: this function is to get the accountid has max total view
#
#Args:
#  accounts: list of accountid
#  xdf.filtered: original file keeps all information related to 4 vectors Genre, Subgenre, MovieType, MovieGroup for each accountid  
#  hdfs: file system 
#
#Returns: a data.frame keeps clusters and its coresponding represent 

  xdf.source <- RxXdfData(file = xdf.filtered, fileSystem = hdfs)
  input.data <- rxDataStep(inData = xdf.source,
			               overwrite = TRUE,
			               rowSelection = accountid %in% accounts,
			               transformObjects = list(accounts = accounts), stringsAsFactors = FALSE
			              )
  max.total.view <- 0
  chosen.account <- ""
  
  for (i in 1 : dim(input.data)[1]){
  #sum genre
	temp <- sum(input.data[i, 382 : 399])
  # get accountid corresponding to max.total.view
	if (max.total.view <= temp){
	  max.total.view <- temp
	  chosen.account <- as.vector(input.data[i, 1]) 
	}
  }
  
  return (chosen.account)
}
