################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

hbase_zookeeper_quorum='hdpnn-h4-awsw01.ds.dtveng.net,hdpnn-h4-awsw03.ds.dtveng.net,hdpnn-h4-awsw02.ds.dtveng.net'
hbase_zookeeper_clientPort='2181'

recommendationJobHistory='dev_recommendationsjobhistory'
columnFamilyOfRJH='rjh'

lookupTable='dev_lookuptable'
lookupFamilyName='cf'
lookupColumnQualifier='batch'

# two tables will be used to get information such as tmsid, programId, starttime and endtime of a schedule ...
postingRoot='/data/dv/recommendation/processed/'

# we will generate raw data in the time range
# If we use the following values then we will generate data from 2014-DE-12 to 2015-JAN-20
fromDate='20141201000000'
toDate='20150128000000'
