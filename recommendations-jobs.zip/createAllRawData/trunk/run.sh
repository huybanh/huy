################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
workingDir="$(pwd)"

echo $workingDir

batchNumber=$1
propertiesFile=$workingDir/createAllRawData/config.properties
tokenIdFile=$workingDir/createAllRawData/cardId_tokenId.csv

#java -Xms5g -Xmx8g -classpath $workingDir/createAllRawData/lib/*:$workingDir/createAllRawData/generateAllRawData-0.0.1-SNAPSHOT.jar com.directv.generateAllRawData.GenerateRawData $batchNumber $propertiesFile $tokenIdFile
export HADOOP_CLIENT_OPTS="-Xmx6g $HADOOP_CLIENT_OPTS"
hadoop jar $workingDir/createAllRawData/generateAllRawData-0.0.1.jar com.directv.generateAllRawData.GenerateRawData $batchNumber $propertiesFile $tokenIdFile
