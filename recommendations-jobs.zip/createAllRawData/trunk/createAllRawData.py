################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

# using os
import os
import imp
import sys
import subprocess

# using Hbase
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig

# using FileSystem
from org.apache.hadoop.fs import *

location = os.getcwd()
utils = imp.load_source('createRawData', location + '/ingestionUtils/ingestionUtils.py')
specificProperties = imp.load_source('load specific properties file', location + '/createAllRawData/createAllRawData_properties.py')

hbase_zookeeper_quorum = specificProperties.hbase_zookeeper_quorum
hbase_zookeeper_clientPort = specificProperties.hbase_zookeeper_clientPort
recommendationJobHistory = specificProperties.recommendationJobHistory
columnFamilyOfRJH = specificProperties.columnFamilyOfRJH
lookupTable = specificProperties.lookupTable
lookupFamilyName = specificProperties.lookupFamilyName
lookupColumnQualifier = specificProperties.lookupColumnQualifier
postingRoot = specificProperties.postingRoot
fromDate = specificProperties.fromDate
toDate = specificProperties.toDate

rjhTable = None
lookupTableInstance = None

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)

fileSystem = FileSystem.get(config)

dataType = 'createRawData'
programKey = 'program'
scheduleKey = 'schedule'
channelObjecMappingKey='ChannelObjectMapping'
# location of program
programLocation = postingRoot + 'guidedata/programs/'
# location of schedule
scheduleLocation = postingRoot + 'guidedata/schedules/'
# location of channel object
channelLocation = postingRoot + 'ref/'

programScheduleLocation = postingRoot + 'createAllRawData/programschedule/'
locationOfRawData = postingRoot + 'createAllRawData/rawdata/'
savedLocation = postingRoot + 'createAllRawData/'

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        print "================================================ THERE IS A ERROR WHEN CONNECTING TO HBASE TABLE: " + str(sys.exc_info()[1])
        os._exit(1)

def joinProgramSchedule(batchNumber):
	try:
		lastBatchNumberProgram = utils.lookupString(programKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
		if not lastBatchNumberProgram:
			utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "lastBatchNumberProgram", 'No data for program')

		lastBatchNumberSchedule = utils.lookupString(scheduleKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
		if not lastBatchNumberSchedule:
			utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "lastBatchNumberSchedule", 'No data for schedule')
		
		lastBatchNumberChannel = utils.lookupString(channelObjecMappingKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
		if not lastBatchNumberChannel:
			utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "lastBatchNumberChannel", 'No data for channelObject')

		global programLocation
		programLocation = programLocation + str(lastBatchNumberProgram)
		global scheduleLocation
		scheduleLocation = scheduleLocation + str(lastBatchNumberSchedule)
		global channelLocation
		channelLocation = channelLocation + str(lastBatchNumberChannel) 

		print 'LOCATION OF PROGRAM DATA ' + programLocation
		print 'LOCATION OF SCHEDULE DATA ' + scheduleLocation
		print 'LOCATION OF CHANNEL OBJECT DATA ' + channelLocation

		# get the latest schedules		
		params = {
		'programLocation':programLocation,
		'scheduleLocation':scheduleLocation,
		'channelLocation':channelLocation,
		'fromDate':fromDate,
		'toDate':toDate,
		'programScheduleLocation':programScheduleLocation + str(batchNumber)
		}
		utils.process(location + '/createAllRawData/joinProgramSchedule.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'joinProgramSchedule', batchNumber)

	except:
		utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "joinProgramSchedule", str(sys.exc_info()[1]))

def main():
	numberParam = len(sys.argv)
	if numberParam == 2:
		batchNumber = str(sys.argv[1])
		connectToHbase()
		joinProgramSchedule(batchNumber)
		print 'Finish Job'
	else:
		utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "error", 'Not enough parameter')

if __name__ == '__main__':
	main()

