################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import sys
import os
import time
import subprocess
import imp
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
import datetime as dt

from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

# whenever a step finished, status of job will be logged to recommendationjobhistory.
def updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, columns, values):
    putList = []
    put = Put(Bytes.toBytes(batchNumber))
    for index in range(len(columns)): 
        put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes(str(dataType) + '_' + str(step) + '_' + str(columns[index])), Bytes.toBytes(values[index]))
        putList.append(put)
    rjhTable.put(putList)

# whenever any job failed, it will be logged to recommendationjobhistory.
def updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, message):
    columns = ['status', 'message']
    values = ['FAILED', message]
    updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, columns, values)
    # Print status if job failed:
    printFailedJob(dataType, step, columns, values)
    
def printFailedJob(dataType, step, columns, values):
    for index in range(len(columns)): 
        print 'Qualifier: ' + dataType + '_' + step + '_' + columns[index]
   	print 'Value: ' + values[index]
    os._exit(1)

# Check if the parameters from properties file is empty?
def validate(param, paramName, errorList):
    if not param:
        errorList.append(paramName + ' is empty')

def validateParameters(rjhTable, columnFamilyOfRJH, batchNumber, dataType, paramArray, paramName):
    errorList = []
    for i in range(len(paramArray)):
        validate(paramArray[i], paramName[i], errorList)
    if(len(errorList) > 0):
        updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'validateParameters', ['message', 'status'], [''.join(errorList), 'FAILED'])
        printFailedJob(dataType, 'validateParameters', ['message', 'status'], [''.join(errorList), 'FAILED'])
        #os._exit(1)

# the purpos of this function is to check if folder on HDFS exist or not.
def validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, folder):
    path = Path(folder)
    if not fileSystem.exists(path):
        updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'validateHDFS', ['message', 'status'], [folder + ' is not exist', 'FAILED'])
        printFailedJob(dataType, 'validateHDFS', ['message', 'status'], [folder + ' is not exist', 'FAILED'])
#        os._exit(1)
    if not fileSystem.isDirectory(path):
        updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'validateHDFS', ['message', 'status'], [folder + ' is not folder', 'FAILED'])
        printFailedJob(dataType, 'validateHDFS', ['message', 'status'], [folder + ' is not folder', 'FAILED'])
#        os._exit(1)
    ListofFiles = fileSystem.listStatus(path)
    if len(ListofFiles) == 0:
        updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'validateHDFS', ['message', 'status'], ['No news Data Files in ' + folder, 'FAILED'])
        printFailedJob(dataType, 'validateHDFS', ['message', 'status'], ['No news Data Files in ' + folder, 'FAILED'])
#        os._exit(1)

def process(scriptName, params, rjhTable, columnFamilyOfRJH, dataType, step, batchNumber):
    print "==========================process start======================================"
    startTime = datetime.now()
    try :
        jobIdList = []
        #execute the Pig script
        P = Pig.compileFromFile(scriptName)
        processData = P.bind(params).runSingle()
        # check if the script is successful?
        if processData.isSuccessful():
            # get stats job
            jobGraph = processData.getJobGraph()
            jobIds = jobGraph.iterator()
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, ['recordWritten'], [str(processData.getRecordWritten())])
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, ['byteOutputsWritten'], [str(processData.getBytesWritten())])
            jobCounterCpu = 0
            jobCounterMem = 0
            while jobIds.hasNext():
                jobId = jobIds.next()
                jobIdList.append(jobId.getJobId())
                counters = jobId.getHadoopCounters()
		if counters is not None:
	                jobCounterCpu = jobCounterCpu + counters.findCounter('org.apache.hadoop.mapreduce.TaskCounter', 'CPU_MILLISECONDS').getValue()
        	        jobCounterMem = jobCounterMem + counters.findCounter('org.apache.hadoop.mapreduce.TaskCounter', 'PHYSICAL_MEMORY_BYTES').getValue()

            inputs = processData.getInputStats()
            memory = 0
            for i in inputs: 
                memory = i.getBytes() + memory
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, ['byteInputsWritten', 'cpu_millis', 'physicmem_bytes'], [str(memory), str(jobCounterCpu), str(jobCounterMem)])
            outputs = processData.getOutputStats()
                     
            endTime = datetime.now()
            columns = ['status', 'message', 'startTime', 'endTime', 'jobIdList']
            values = ['SUCCEED', 'SUCCEED', startTime.strftime("%Y-%m-%d %H:%M:%S"), endTime.strftime("%Y-%m-%d %H:%M:%S"),''.join(jobIdList)]
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, columns, values)
        else:    
            updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, processData.getErrorMessage())
    except:
        updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, str(sys.exc_info()[1]))


def process2(scriptName, params, rjhTable, columnFamilyOfRJH, dataType, step, batchNumber, inputAlias, outputAlias):
    print "==========================process start======================================"
    startTime = datetime.now()
    try :
        jobIdList = []
        #execute the Pig script
        P = Pig.compileFromFile(scriptName)
        processData = P.bind(params).runSingle()
        # check if the script is successful?
        if processData.isSuccessful():
            # get stats job
            jobGraph = processData.getJobGraph()
            jobIds = jobGraph.iterator()
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, ['recordWritten'], [str(processData.getRecordWritten())])
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, ['byteOutputsWritten'], [str(processData.getBytesWritten())])
            jobCounterCpu = 0
            jobCounterMem = 0
            while jobIds.hasNext():
                jobId = jobIds.next()
                jobIdList.append(jobId.getJobId())
                counters = jobId.getHadoopCounters()
                jobCounterCpu = jobCounterCpu + counters.findCounter('org.apache.hadoop.mapreduce.TaskCounter', 'CPU_MILLISECONDS').getValue()
                jobCounterMem = jobCounterMem + counters.findCounter('org.apache.hadoop.mapreduce.TaskCounter', 'PHYSICAL_MEMORY_BYTES').getValue()

            inputs = processData.getInputStats()
            memory = 0
            for i in inputs: 
                memory = i.getBytes() + memory
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, ['byteInputsWritten', 'cpu_millis', 'physicmem_bytes'], [str(memory), str(jobCounterCpu), str(jobCounterMem)])
            outputs = processData.getOutputStats()
            
            # get statistics
            newDataJob = findJobStateByAlias(processData, inputAlias)
            loadedRow = sumNumberRecords(newDataJob.getInputs())
            
            finalPpvDataJob = findJobStateByAlias(processData, outputAlias)
            finalRow = sumNumberRecords(finalPpvDataJob.getOutputs())
            
            endTime = datetime.now()
            columns = ['status', 'message', 'startTime', 'endTime', 'loadedRow', 'finalRow', 'jobIdList']
            values = ['SUCCEED', 'SUCCEED', startTime.strftime("%Y-%m-%d %H:%M:%S"), endTime.strftime("%Y-%m-%d %H:%M:%S"), 
                  str(loadedRow), str(finalRow), ''.join(jobIdList)]
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, columns, values)
        else:    
            updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, processData.getErrorMessage())
    except:
        updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, step, str(sys.exc_info()[1]))
                
def findJobStateByAlias(processData, targetAlias):
    jobIterator = processData.getJobGraph().iterator()
    while jobIterator.hasNext():
        oneJob = jobIterator.next()
        if targetAlias in oneJob.getAlias():
            return oneJob
            
def sumNumberRecords(inoutStatList):
    sum = 0
    for oneState in inoutStatList:
        sum = sum + oneState.getNumberRecords()
    return sum

# Return current date subtract the num day which need to get data in properties.py
def getDate(numDate):
    now = dt.datetime.now()
    then = now - dt.timedelta(days=int(numDate))
    newThen= then.strftime('%Y%m%d%H%M')
    return long(newThen)

def lastBatch(scriptName, params, rjhTable, columnFamilyOfRJH, batchNumber, dataType):
    lastBatch = ''
    startTime = datetime.now()
    try :
        P = Pig.compileFromFile(scriptName)
        processData = P.bind(params).runSingle()
        # check if the script is successful?
        if processData.isSuccessful():
            # get statistics
            iter1 = processData.result('lastBatch').iterator()
            lastBatch = ''
            if iter1.hasNext():
                tuple1 = iter1.next()
                lastBatch = str(tuple1.get(1))

            # Log status of execution
            endTime = datetime.now()
            columns = ['status', 'message', 'startTime', 'endTime']
            values = ['SUCCEED', lastBatch, startTime.strftime("%Y-%m-%d %H:%M:%S"), endTime.strftime("%Y-%m-%d %H:%M:%S")]
            updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'lastBatch', columns, values)
            return lastBatch
        else:    
            updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'lastBatch', processData.getErrorMessage())
    except:
        updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'lastBatch', str(sys.exc_info()[1]))


def lookupBytes(key, lookupTable, familyName, columnQualifier):
#    print "Looking up for " + familyName + ":" + columnQualifier + "@" + key
    lookupGet = Get(Bytes.toBytes(key))
    lookupGet.addColumn(Bytes.toBytes(familyName), Bytes.toBytes(columnQualifier))
    lookupResult = lookupTable.get(lookupGet)
    return lookupResult.getValue(Bytes.toBytes(familyName), Bytes.toBytes(columnQualifier))

def lookupInt(key, lookupTable, familyName, columnQualifier):
    lookupValue = lookupBytes(key, lookupTable, familyName, columnQualifier)
    return Bytes.toInt(lookupValue)

def lookupLong(key, lookupTable, familyName, columnQualifier):
    lookupValue = lookupBytes(key, lookupTable, familyName, columnQualifier)
    return Bytes.toLong(lookupValue)

def lookupString(key, lookupTable, familyName, columnQualifier):
    lookupValue = lookupBytes(key, lookupTable, familyName, columnQualifier)
    if lookupValue == None or lookupValue =='':
        return ''
    return Bytes.toString(lookupValue, 0, len(lookupValue))

def storeOneValue(lookupTable, paramStoreData):
    putList = []
    currentLocation = paramStoreData[0]
    columnFamily = paramStoreData[1]
    qualifier = paramStoreData[2]
    newValue = paramStoreData[3]
    print "currentLocation :" + str(currentLocation)
    print "columnFamily :" + str(columnFamily)
    print "qualifier :" + str(qualifier)
    print "newValue :" + str(newValue)
    
    put = Put(Bytes.toBytes(currentLocation))
    put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier),Bytes.toBytes(str(newValue)))
    putList.append(put)
    lookupTable.put(putList)

def storeData(lookupTable, paramStoreData):
    putList = []
    dataType = paramStoreData[0]
    columnFamily = paramStoreData[1]
    qualifier= paramStoreData[2]
    batchNumber = paramStoreData[3]
    unprocessedFile = paramStoreData[4]
    modificationTimeValue = paramStoreData[5]
    archiveFolder = paramStoreData[6]
    incomingFolder = paramStoreData[7]
    
    print "dataType :" + str(dataType)
    print "columnFamily :" + str(columnFamily)
    print "qualifier :" + str(qualifier)
    print "batchNumber :" + str(batchNumber)
    print "unprocessedFile :" + str(unprocessedFile)
    print "modificationTimeValue :" + str(modificationTimeValue)
    print "archiveFolder :" + str(archiveFolder)
    print "incomingFolder :" + str(incomingFolder)
    
    # put the last batch number to Hbase table
    put = Put(Bytes.toBytes(dataType))
    put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier),Bytes.toBytes(str(batchNumber)))
    putList.append(put)
    
    # put modification time to Hbase table
    put = Put(Bytes.toBytes(unprocessedFile))
    put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier), Bytes.toBytes(modificationTimeValue))
    putList.append(put)
    lookupTable.put(putList)
    
    # move raw data from incoming folder to archive folder
    subprocess.call('hadoop fs -mkdir ' + archiveFolder, shell=True)
    subprocess.call('hadoop fs -mv ' + incomingFolder + ' ' + archiveFolder, shell=True)

def storeData2(lookupTable, paramStoreData):
    putList = []
    dataType = paramStoreData[0]
    columnFamily = paramStoreData[1]
    qualifier= paramStoreData[2]
    batchNumber = paramStoreData[3]
    unprocessedFile = paramStoreData[4]
    modificationTimeValue = paramStoreData[5]
    masterRoot = paramStoreData[6]
    workingRoot = paramStoreData[7]
    completeFolder = paramStoreData[8]

    print "dataType :" + str(dataType)
    print "columnFamily :" + str(columnFamily)
    print "qualifier :" + str(qualifier)
    print "batchNumber :" + str(batchNumber)
    print "unprocessedFile :" + str(unprocessedFile)
    print "modificationTimeValue :" + str(modificationTimeValue)
    print "masterRoot :" + str(masterRoot)
    print "workingRoot :" + str(workingRoot)
    print "completeFolder :" + str(completeFolder)
    
    # Create folder for master root
    subprocess.call('hadoop fs -mkdir ' + masterRoot + batchNumber, shell=True)
    print 'hadoop fs -mkdir ' + masterRoot + batchNumber
    # Move data from staging complete to master root
    subprocess.call('hadoop fs -mv ' + workingRoot + batchNumber + completeFolder + '/*' + ' ' + masterRoot + batchNumber , shell=True)
    print 'hadoop fs -mv ' + workingRoot + batchNumber + completeFolder +'/*'+ ' ' + masterRoot + batchNumber 

    # put the last batch number to Hbase table
    put = Put(Bytes.toBytes(dataType))
    put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier),Bytes.toBytes(str(batchNumber)))
    putList.append(put)
    
    # put modification time to Hbase table
    put = Put(Bytes.toBytes(unprocessedFile))
    put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier), Bytes.toBytes(modificationTimeValue))
    putList.append(put)
    lookupTable.put(putList)
    
    # Remove data in staging after move to processed
    subprocess.call('hadoop fs -rm -r ' + workingRoot + batchNumber + '/*', shell=True)
    print 'hadoop fs -rm -r ' + workingRoot + batchNumber+ '/*'
    # Remove firstMerging in the first time of ingestion
    subprocess.call('hadoop fs -rm -r ' + masterRoot  + 'firstMerging', shell=True)
    print 'hadoop fs -rm -r ' + masterRoot  + 'firstMerging'

# the purpose of this function is to store infor into Hbase table.
# para 1: name of table that you want to use to store data
# para 2: is column family
# para 3: is qualifier
# para 4: is value that you want to store into hbase table
def insertDataToHbase(lookupTable, columnFamily, qualifier, rowkey, value):
    putList = []
    put = Put(Bytes.toBytes(rowkey))
    put.add(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier), Bytes.toBytes(str(value)))
    putList.append(put)
    lookupTable.put(putList)

# This function will print all status message of job
# para 1: name of table that we will use to look up data
# para 2: is rowkey. in our jobs rowkey mean batch number
# para 3: is column family
# para 4: is a list of qualifiers
#         because when job is running we log much information, So it is better if we just keep printing the error message and ignore the rest of information
# e.g If you want to display error message of ams-ingestion
# qualifires should be ['ams_filtering_status', 'ams_stitching_message','ams_ingestDataLocation_status']
def printStatus(rjhTable, rowKey, columnFamily, qualifiers):
	keyObject = Get(Bytes.toBytes(rowKey))
	for qualifier in qualifiers:
		keyObject.addColumn(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier))
		result = rjhTable.get(keyObject).getValue(Bytes.toBytes(columnFamily), Bytes.toBytes(qualifier))
		if result != None and result != '':
			print qualifier + ':     ' + str(Bytes.toString(result, 0, len(result)))

# This function will print all status message of job
# para 1: name of table that we will use to look up data
# para 2: is rowkey. in our jobs rowkey mean batch number
# para 3: is column family
# para 4: is data type of job (ams, ppv ...)			
def printStatusToConsole(table, rowkey, columnFamily, dataType):
        s = Get(Bytes.toBytes(rowkey));
 	s.addFamily(Bytes.toBytes(columnFamily))
        res = table.get(s)
 	cells = res.raw()
 	for cell in cells:
  		value = cell.getValue().tostring()
  		qualifier = cell.getQualifier().tostring()
  		if qualifier.startswith(dataType):
   			print 'Qualifier: ' + qualifier
   			print 'Value: ' + value

# copy unprocess file from new landing zone to incoming folder
def copyFileToImcomingFolder(fileSystem, landingZone, currentFolder, incommingFolder, oldLastModificationTime):	
    newModificationTime = 0
    newSubFolder = ''
    pathOfYear = Path(landingZone)
    # level of year folder
    yearFolders = fileSystem.listStatus(pathOfYear)
    for yearFolder in yearFolders:
        # level of month folder
        if yearFolder.isDirectory():
            pathOfMonth = Path(yearFolder.getPath().toString())
            monthFolders = fileSystem.listStatus(pathOfMonth)
            yearFolder = yearFolder.getPath().getName()
            for monthFolder in monthFolders:
                if monthFolder.isDirectory():
                # level of day folder
                    pathOfDay = Path(monthFolder.getPath().toString())
                    dayFolders = fileSystem.listStatus(pathOfDay)
                    monthFolder =  monthFolder.getPath().getName()
                    for dayFolder in dayFolders:
                        if dayFolder.isDirectory():
                            # level of hour folder
                            pathOfHour = Path(dayFolder.getPath().toString())
                            hourFolders = fileSystem.listStatus(pathOfHour)
                            dayFolder = dayFolder.getPath().getName()
                            for hourFolder in hourFolders:
                                if hourFolder.isDirectory():
                                    subFolder = yearFolder + '/' + monthFolder + '/' + dayFolder + '/' + hourFolder.getPath().getName()
                                    if subFolder >= currentFolder:
                                        if newSubFolder == '' or subFolder > newSubFolder:
                                            newSubFolder = subFolder
                                        absolutePath = landingZone + subFolder
                                        time = copyFileFromLandingzoneToIncomingFolder(fileSystem, absolutePath, incommingFolder, oldLastModificationTime)
                                        if time > newModificationTime:
                                            newModificationTime = time
    print "newSubFolder = " + newSubFolder
    print "new modification time = " + str(newModificationTime)
    return newModificationTime,newSubFolder		

# copy unprocess file from landingzone to incoming folder
def copyFileFromLandingzoneToIncomingFolder(fileSystem, landingZone, incomingFolder, oldLastModificationTime):
    # make a new folder and then copy all unprocessed files to this folder
    # if folder is not existing then create a new folder
    incomingPath = Path(incomingFolder)
    if not fileSystem.exists(incomingPath):
        subprocess.call('hadoop fs -mkdir ' + incomingFolder, shell=True)
    
    path = Path(landingZone)
    if not fileSystem.exists(path):
        os._exit(1)
    if not fileSystem.isDirectory(path):
        os._exit(1)
    
    fileStatus = fileSystem.listStatus(path)
    newLastModificationTime = 0
    for sFile in fileStatus:
        if sFile.isFile():
            mTime = sFile.getModificationTime()
            if mTime > oldLastModificationTime:
                if mTime > newLastModificationTime:
                    newLastModificationTime = mTime
                print "processing file: " + str(sFile.getPath())
                subprocess.call('hadoop fs -cp ' + str(sFile.getPath()) + ' ' + incomingFolder, shell=True)
    #if newLastModificationTime == 0:
	#subprocess.call('hadoop fs -rm -R ' + incomingFolder, shell=True)
    return newLastModificationTime
