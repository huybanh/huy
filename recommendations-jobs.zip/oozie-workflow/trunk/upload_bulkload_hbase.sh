###Location of Recommendation Project ##########
OozieHome=/data/dv/recommendation_dev/oozie/
OozieVersion=oozie-workflow-0.1.1
###########Current Oozie workflow version ###############
hdfslocation=$OozieHome$OozieVersion
#######Old oozies#########
oozie=$OozieHome'/oozie-workflow-*'
archive=/data/dv/recommendation_dev/archive/
timestamp=$(date +%s)
hadoop fs -mkdir -p ${archive}${timestamp}
hadoop fs -mv  $oozie ${archive}${timestamp}
hadoop fs -mkdir $hdfslocation
hadoop fs -put Bulkload $hdfslocation