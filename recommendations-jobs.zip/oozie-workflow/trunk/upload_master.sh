###Location of Recommendation Project ##########
OozieHome=/data/dv/recommendation/oozie/
OozieVersion=oozie-workflow-0.1.1
###########Current Oozie workflow version ###############
hdfslocation=$OozieHome$OozieVersion
#######Old oozies#########33
oozie=$OozieHome'/oozie-workflow-*'
archive=/data/dv/recommendation/archive/
timestamp=$(date +%s)
hadoop fs -mkdir -p ${archive}${timestamp}
hadoop fs -mv  $oozie ${archive}${timestamp}
hadoop fs -mkdir $hdfslocation
hadoop fs -put Recommendation $hdfslocation
hadoop fs -put lastaction-integration $hdfslocation