hadoop fs -rm -r oozie-jobs/Recommendation/Recommendation_Coordinator
hadoop fs -mkdir oozie-jobs/Recommendation/Recommendation_Coordinator/
hadoop fs -put * oozie-jobs/Recommendation/Recommendation_Coordinator/

