hdfsLocation='/data/dv/recommendation/oozie/Recommendation/Recommendation_Workflow/SubWorkflows/GuideDataIngestion';
#older='/home/d458737/vishnu/Recommendation_Workflow/SubWorkflows/GuideDataIngestion/';
#utils='ingestionUtils';
#EventFolder='mergeEvent';
#ChannelFolder='mergeChannel';
#ProgramFolder='mergeProgram';
#ScheduleFolder='mergeSchedule';


hadoop fs -rm -r $hdfsLocation;
hadoop fs -mkdir $hdfsLocation;
hadoop fs -put * $hdfsLocation;

#hadoop fs -put $folder$utils $hdfsLocation;
#hadoop fs -put $folder$EventFolder $hdfsLocation;
#hadoop fs -put $folder$ChannelFolder $hdfsLocation;
#hadoop fs -put $folder$ProgramFolder $hdfsLocation;
#hadoop fs -put $folder$ScheduleFolder $hdfsLocation;
#hadoop fs -put 'workflow.xml' $hdfsLocation;
#hadoop fs -put 'hbase-site.xml' $hdfsLocation;
#hadoop fs -put 'job.properties' $hdfsLocation;
#hadoop fs -put 'upload.sh' $hdfsLocation;
#hadoop fs -put 'run.sh' $hdfsLocation;
