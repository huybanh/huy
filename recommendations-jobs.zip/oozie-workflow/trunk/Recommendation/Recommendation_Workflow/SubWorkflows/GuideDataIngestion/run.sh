kinit -kt svc.cloudrec.dv2.keytab  svc.cloudrec.dv2@DS.DTVENG.NET
export OOZIE_URL=http://hdpgtwh3-awsw01.ds.dtveng.net:11000/oozie
oozie job -config job.properties -run

