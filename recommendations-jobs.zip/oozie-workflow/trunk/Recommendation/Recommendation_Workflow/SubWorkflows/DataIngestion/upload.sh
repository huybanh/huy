hdfsLocation='/data/dv/recommendation/oozie/Recommendation/Recommendation_Workflow/SubWorkflows/DataIngestion';
#folder='/home/d458737/vishnu/Recommendation_Workflow/SubWorkflows/DataIngestion/';
#utils='ingestionUtils';
#ppvFolder='ppv-ingestion';
#cdnFolder='cdn-ingestion';
#socialFolder='social-ingestion';
#streamingFolder='streaming-ingestion';
#remoteFolder='remote-ingestion';
#amsFolder='ams-ingestion';
#submission to DS oozie job folders
#implicitSubmission_AMS='oozie_implicitSubmission_AMS';
#implicitSubmission_REMOTE='oozie_implicitSubmission_REMOTE';
#likeSubmission='oozie_likeSubmission';
#purchaseSubmission='oozie_purchaseSubmission';
#viewSubmission_STREAMING='oozie_viewSubmission_STREAMING';
#viewSubmission_AMS='oozie_viewSubmission_AMS';
#viewSubmission_CDN='not_available';
#mergeUVHData='mergeAllData';



hadoop fs -rm -r $hdfsLocation;
hadoop fs -mkdir $hdfsLocation;
hadoop fs -put * $hdfsLocation;
#hadoop fs -put $folder$utils $hdfsLocation;
#hadoop fs -put $folder$ppvFolder $hdfsLocation;
#hadoop fs -put $folder$amsFolder $hdfsLocation;
#hadoop fs -put $folder$cdnFolder $hdfsLocation;
#hadoop fs -put $folder$remoteFolder $hdfsLocation;
#hadoop fs -put $folder$streamingFolder $hdfsLocation;
#hadoop fs -put $folder$socialFolder $hdfsLocation;
#hadoop fs -put $folder$implicitSubmission_AMS $hdfsLocation;
#hadoop fs -put $folder$implicitSubmission_REMOTE $hdfsLocation;
#hadoop fs -put $folder$likeSubmission $hdfsLocation;
#hadoop fs -put $folder$purchaseSubmission $hdfsLocation;
#hadoop fs -put $folder$viewSubmission_AMS $hdfsLocation;
#hadoop fs -put $folder$viewSubmission_STREAMING $hdfsLocation;
#hadoop fs -put $folder$viewSubmission_CDN $hdfsLocation;
#hadoop fs -put $folder$mergeUVHData $hdfsLocation;
#hadoop fs -put 'hive-site.xml' $hdfsLocation;
#hadoop fs -put 'workflow.xml' $hdfsLocation;
#hadoop fs -put 'hbase-site.xml' $hdfsLocation;
#hadoop fs -put 'job.properties' $hdfsLocation;
#hadoop fs -put 'upload.sh' $hdfsLocation;
#hadoop fs -put 'run.sh' $hdfsLocation;
