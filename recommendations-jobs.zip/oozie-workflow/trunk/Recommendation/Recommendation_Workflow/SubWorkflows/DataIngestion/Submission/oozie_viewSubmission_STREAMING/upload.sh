hdfsLocation='/data/dv/recommendation/oozie/Recommendation/Recommendation_Workflow/SubWorkflows/DataIngestion/Submission/oozie_viewSubmission_STREAMING/';
#folder='/home/d458737/vishnu/Recommendation_Workflow/SubWorkflows/DataIngestion/Submission/';
#common='commonSubmission';
#scriptFolder='viewSubmission_STREAMING';



hadoop fs -rm -r $hdfsLocation;
hadoop fs -mkdir $hdfsLocation;
hadoop fs -put * $hdfsLocation;
#hadoop fs -put $folder$common $hdfsLocation;
#hadoop fs -put $folder$scriptFolder $hdfsLocation;
#hadoop fs -put 'workflow.xml' $hdfsLocation;
#hadoop fs -put 'hbase-site.xml' $hdfsLocation;
#hadoop fs -put 'hive-site.xml' $hdfsLocation;
#hadoop fs -put 'job.properties' $hdfsLocation;
#hadoop fs -put 'upload.sh' $hdfsLocation;
#hadoop fs -put 'run.sh' $hdfsLocation;

