echo 'batchnumber' $1
echo 'service account' $2
echo 'keytab file' $3
echo 'oozie_url' $4
echo 'nameNode' $5
echo 'JobTracker' $6
echo 'use libpath' $7
echo 'workflowpath' $8
echo 'hcatmetastoreuri'$9
echo 'hcatmetastoreprincipal' ${10}

if [[ -f action.xml ]];
then
kinit -kt  $3 $2
fi
export OOZIE_URL=$4
oozie job -config job.properties -run -D batchname=$1 -D keytab=$3 -D nameNode=$5 -D jobTracker=$6 -D oozie.use.system.libpath=$7 -D oozie.wf.application.path=$8 -D hcatmetastoreuri=$9 -D hcatmetastoreprincipal=${10}tab=$3