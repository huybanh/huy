if [[ -f action.xml ]];
then
kinit -kt  $3 $2
fi
export OOZIE_URL=$5
oozie job -config job.properties -run -D batchnumber=$1 -D bulkloadjar=$4 -D nameNode=$6 -D jobTracker=$7 -D oozie.use.system.libpath=$8 -D oozie.wf.application.path=$9 

