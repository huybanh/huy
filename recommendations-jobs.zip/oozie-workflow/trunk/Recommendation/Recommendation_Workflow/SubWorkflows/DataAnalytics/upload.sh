hdfslocation='/data/dv/recommendation/oozie/Recommendation/Recommendation_Workflow/SubWorkflows/DataAnalytics'
hadoop fs -rm -r $hdfslocation
hadoop fs -mkdir $hdfslocation
hadoop fs -put * $hdfslocation

