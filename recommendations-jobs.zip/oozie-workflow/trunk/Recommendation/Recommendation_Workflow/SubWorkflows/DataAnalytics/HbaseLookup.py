################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import sys
import os
import time
import subprocess
import imp
import datetime as dt
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count


column='batch'
			 			 
def lookupBytes(key,lookupTableInstance,family, column):
	lookupGet = Get(Bytes.toBytes(key))
	lookupGet.addColumn(Bytes.toBytes(family), Bytes.toBytes(column))
	lookupResult = lookupTableInstance.get(lookupGet)
	result = lookupResult.getValue(Bytes.toBytes(family), Bytes.toBytes(column))
	if result == None or result =='':
		return ''
	return Bytes.toString(result,0,len(result))		
	
def main():
	#	print 'the arguments are #####################' + str((len(sys.argv)))
		if (len(sys.argv)) == 4:
			config = HBaseConfiguration.create()
			key = sys.argv[2]
			famil=sys.argv[3]
			lookupTableInstance = HTable(config,sys.argv[1])
			try:
				batchnumber = lookupBytes(key,lookupTableInstance,famil,column)
				print batchnumber
				if not batchnumber:
					print 'firsttimejob=true'
				else:
					print 'firsttimejob=false'
			except:  
				print 'error connecting to Hbase'
				os._exit(1)
		else:
			print 'not enough arguments'
			os._exit(1)
        
		    

if __name__ == '__main__':
    main()
