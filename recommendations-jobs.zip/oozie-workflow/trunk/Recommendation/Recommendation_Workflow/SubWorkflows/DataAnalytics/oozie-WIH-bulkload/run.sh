if [[ -f action.xml ]];
then
kinit -kt  $3 $2
fi
export OOZIE_URL=http://hdpgtwh4-awsw01.ds.dtveng.net:11000/oozie
oozie job -config job.properties -run -D batchnumber=$1 -D bulkloadjar=$4 -D nameNode=$6 -D jobTracker=$7 -D oozie.use.system.libpath=$8 -D oozie.wf.application.path=$9

