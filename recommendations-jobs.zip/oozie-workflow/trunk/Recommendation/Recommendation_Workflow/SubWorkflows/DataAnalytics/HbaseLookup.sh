echo "LookupTable=" $1
echo "rowkey="$2
echo "columFamily="$3
pig HbaseLookup.py $1 $2 $3
