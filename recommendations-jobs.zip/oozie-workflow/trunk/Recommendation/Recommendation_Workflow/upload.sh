#kinit -kt svc.cloudrec.dv2.keytab  svc.cloudrec.dv2@DS.DTVENG.NET
hdfsLocation='/data/dv/recommendation/oozie/Recommendation/Recommendation_Workflow/';
#folder='/home/d458737/vishnu/Recommendation_Workflow/';
#utils='ingestionUtils';
#lib='lib';
#NewPreparedData='newData';
#MergePreparedData='generateRawData';
#GenerateFilteredData='generateFilteredData';
#AccountIngestion='zipcode-ingestion';

hadoop fs -rm -r $hdfsLocation;
hadoop fs -mkdir $hdfsLocation;
hadoop fs -put * $hdfsLocation;



#hadoop fs -put $folder$utils $hdfsLocation;
#hadoop fs -put $folder$lib $hdfsLocation;
#hadoop fs -put $folder$AccountIngestion $hdfsLocation;
#hadoop fs -put $folder$NewPreparedData $hdfsLocation;
#hadoop fs -put $folder$MergePreparedData $hdfsLocation;
#hadoop fs -put $folder$GenerateFilteredData $hdfsLocation;
#hadoop fs -put 'hive-site.xml' $hdfsLocation;
#hadoop fs -put 'workflow.xml' $hdfsLocation;
#hadoop fs -put 'hbase-site.xml' $hdfsLocation;
#hadoop fs -put 'job.properties' $hdfsLocation;
#hadoop fs -put 'upload.sh' $hdfsLocation;
#hadoop fs -put 'run.sh' $hdfsLocation;


