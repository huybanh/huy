export OOZIE_URL=http://hdpgtwh3-awsw01.ds.dtveng.net:11000/oozie
oozie job -config Recommendation/Recommendation_Coordinator/coordinator.properties -run
