export OOZIE_URL=http://hdpgtwh4-awsw01.ds.dtveng.net:11000/oozie
oozie job -config job.properties -run -D batchnumber=$1

