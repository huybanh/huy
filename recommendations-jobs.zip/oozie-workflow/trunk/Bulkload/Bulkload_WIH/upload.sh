hadoop fs -rm -r /data/dv/recommendation/oozie/Bulkload/Bulkload_WIH/
hadoop fs -mkdir /data/dv/recommendation/oozie/Bulkload/Bulkload_WIH/
hadoop fs -put * /data/dv/recommendation/oozie/Bulkload/Bulkload_WIH/

