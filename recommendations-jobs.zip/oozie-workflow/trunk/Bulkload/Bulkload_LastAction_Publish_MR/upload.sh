hdfsLocation='/data/dv/recommendation/oozie-jobs/bulkload-lastaction-integration/';

hadoop fs -rm -r $hdfsLocation;
hadoop fs -mkdir $hdfsLocation;
hadoop fs -put * $hdfsLocation;




