#export OOZIE_URL=http://hdpgtwh3-awsw01.ds.dtveng.net:11000/oozie
oozie job -oozie http://hdpgtwh3-awsw01.ds.dtveng.net:11000/oozie -kill $1
