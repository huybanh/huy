hadoop fs -rm -r /data/dv/recommendation/oozie-jobs/lastactionpublish/
hadoop fs -mkdir /data/dv/recommendation/oozie-jobs/lastactionpublish/
hadoop fs -put * /data/dv/recommendation/oozie-jobs/lastactionpublish/

