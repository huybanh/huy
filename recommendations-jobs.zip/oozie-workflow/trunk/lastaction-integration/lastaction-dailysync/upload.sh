hadoop fs -rm -r /data/dv/recommendation/oozie-jobs/lastactiondailysync/
hadoop fs -mkdir /data/dv/recommendation/oozie-jobs/lastactiondailysync/
hadoop fs -put * /data/dv/recommendation/oozie-jobs/lastactiondailysync/

