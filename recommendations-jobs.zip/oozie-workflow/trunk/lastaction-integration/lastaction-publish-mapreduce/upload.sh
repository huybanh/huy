hadoop fs -rm -r /data/dv/recommendation/oozie-jobs/lastactionpublish_mapreduce/
hadoop fs -mkdir /data/dv/recommendation/oozie-jobs/lastactionpublish_mapreduce/
hadoop fs -put * /data/dv/recommendation/oozie-jobs/lastactionpublish_mapreduce/