#impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -f top_active_user.sql
if [[ -f action.xml ]];
then
	mkdir -p /tmp/pythoneggs
	export PYTHON_EGG_CACHE='/tmp/pythoneggs'
fi
workingDir="$(pwd)"

. $workingDir/hive-top-active-user/conf.properties

echo 'Input table data: '$uvh_table
echo 'Output location HDFS: '$location
if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

# Calculate list active users
hive $hadoopTokenClause -hiveconf database=$database -hiveconf workingDir=$workingDir -hiveconf user_table=$user_table -hiveconf uvh_table=$uvh_table -hiveconf location=$location -hiveconf encrypt_flag=$encrypt_flag -f ${workingDir}/hive-top-active-user/top_active_user_hive.sql
#hive -e 'use cloudrec;show tables;'


status=$?
if [ $status -eq 0 ]; then
    echo "SUCCEED"
    $impalaCommand -q "invalidate metadata"
#    impala-shell -i hdpdn-h3-awsw01.ds.dtveng.net -q "refresh $user_table;"
else
    echo "FAILED"
fi
