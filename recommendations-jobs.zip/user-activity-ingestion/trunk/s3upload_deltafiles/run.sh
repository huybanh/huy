################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
workingDir="$(pwd)"
. $workingDir/s3upload_deltafiles/config/deltafile.properties
echo $workingDir
echo $JAR_FILE

java -jar $workingDir/s3upload_deltafiles/$JAR_FILE $workingDir/s3upload_deltafiles/config/deltafile.properties
