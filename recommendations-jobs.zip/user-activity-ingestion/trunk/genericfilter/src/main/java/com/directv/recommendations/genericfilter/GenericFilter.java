/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.genericfilter;

import java.util.LinkedList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapreduce.Mapper;

public class GenericFilter {
	
	private static final String CLOUDREC_GENERICFILTER = "CLOUDREC_GENERICFILTER_";
	
	static final String OPERATOR_EQUAL = "EQUAL";
	
	static final String OPERATOR_REGEX = "REGEX";
	
	private final FilterRule[] allRules;
	
	private GenericFilter(LinkedList<FilterRule> ruleList) {
		allRules = ruleList.toArray(new FilterRule[ruleList.size()]);
	}
	
	/*
	 * fieldindex1|EQUAL|v1|fieldindex2|EQUAL|v2|
	 * */
	public static GenericFilter configure(String ruleName, String params, Configuration conf) {
		GenericFilter genFilter = configureInternal(params);
		conf.set(CLOUDREC_GENERICFILTER + ruleName, params);
		System.out.println("Saved filter " + CLOUDREC_GENERICFILTER + ruleName + ": " + params);
		return genFilter;
	}
	
	private static GenericFilter configureInternal(String params) {
		
		LinkedList<FilterRule> ruleList = new LinkedList<FilterRule>();
		String[] paramArray = params.split("#");
		int i = 0;
		while (true) {
			
			//add one rule
			int fieldIndex = Integer.parseInt(paramArray[i++]);
			String operator = paramArray[i++];
			String target = paramArray[i++];
			boolean not = operator.startsWith("!");
			if (not) {
				operator = operator.substring(1);
			}
			FilterRule oneRule;
			if (OPERATOR_EQUAL.equals(operator)) {
				oneRule = new FilterRuleEqual();
			} else if (OPERATOR_REGEX.equals(operator)) {
				oneRule = new FilterRuleRegex();
			} else {
				throw new RuntimeException("Unknown filter operator: " + operator);
			}
			oneRule.fieldIndex = fieldIndex;
			oneRule.target = target;
			oneRule.not = not;
			ruleList.add(oneRule);
			
			//stop if no more found
			if (i == paramArray.length) {
				break;
			}
		}
		
		for (FilterRule oneRule : ruleList) {
			oneRule.initialize();
		}
		return new GenericFilter(ruleList);		
	}
	
	public static GenericFilter load(String ruleName, Configuration conf) {
		String params = conf.get(CLOUDREC_GENERICFILTER + ruleName);
		System.out.println("Loaded for filter " + CLOUDREC_GENERICFILTER + ruleName + ": " + params);
		if (params == null) {
			return null;
		}
		return configureInternal(params);
	}
	
	public boolean filter(String[] fields, Mapper<?, ?, ?, ?>.Context context) {
		for (FilterRule oneRule : allRules) {
			if (oneRule.filter(fields)) {
				context.getCounter(Counter.FILTERED_COUNT).increment(1);
				return true;
			}
		}
		return false;
	}
}
