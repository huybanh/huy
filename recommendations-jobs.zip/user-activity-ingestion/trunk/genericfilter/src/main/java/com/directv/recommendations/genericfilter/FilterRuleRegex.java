/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.genericfilter;

import java.util.regex.Pattern;

public class FilterRuleRegex extends FilterRule {
	
	private Pattern pattern;

	@Override
	void initialize() {
		pattern = Pattern.compile(super.target);
	}

	@Override
	boolean filter(String[] fields) {
		String s = fields[fieldIndex];
		s = s.trim();
		return pattern.matcher(s).matches();
	}

	@Override
	String getOperatorName() {
		return "REGEX";
	}

}
