################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

# Description:
# We have to configure parameters as below
# landingZone: point to the HDFS location where we are using to store remote booking data.
# source: is 6, it mean that if any row have source "6" then this row is remote booking data.
# originalFormat: is current time format of remote booking data.
#
# HOW DOES THE SCRIPT KNOW THE LOCATION OF ZIPCODE
# We have to set path for parameter "postingRoot" in the "common_properties" file.
# When we launch the script it will append sub-folder "zipcode/" to "postingRoot" to create absolute path of zipcode data automatically.
# Note: in this absolute path we have one or more sub-folder, the script only load data from the latest folder
# e.g if "postingRoot" is "/data/dv/recommendation/processed/" then absolute path is "/data/dv/recommendation/processed/zipcode"

# The landing zone
landingZone='/data/dv/raw/remote/'

originalFormat='yyyy-MM-dd HH:mm:ss'
source='Remote'

# tmsId field is at position 3 in the data tuple
cleansingConfig='className:FieldRegexMatcher;fieldNum:3;regex:MV.*;regex:SH.*;regex:EP.*;match:true'
