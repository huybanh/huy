################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

# using os
import os
import imp
import sys

# using Hbase
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig

# using FileSystem
from org.apache.hadoop.fs import *
from common_properties import *

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
rjhTable = None
lookupTableInstance = None

fileSystem = FileSystem.get(config)
location = os.getcwd()
utils = imp.load_source('dataIngestion', location + '/ingestionUtils/ingestionUtils.py')

specificProperties = imp.load_source('load properties file', location + '/tokenIdToDMA/tokenIdToDMA_properties.py')
hbaselib = specificProperties.hbaselib
mappingtable = specificProperties.mappingtable
mColumn = specificProperties.mColumn
dataType='tokenIdToDMA'
prepareuvh = postingRoot + 'prepareduvh/insertedtime='
insertedtimeKey = 'insertedTime'

paramArray = [postingRoot, mappingtable, recommendationJobHistory, columnFamilyOfRJH, hbaselib, mColumn]
paramName = ['postingRoot', 'mappingtable', 'recommendationJobHistory', 'columnFamilyOfRJH', 'hbaselib', 'mColumn']

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        print "================================================ THERE IS A ERROR WHEN CONNECTING TO HBASE TABLE: " + str(sys.exc_info()[1])
        os._exit(1)

def addCardId(batchNumber):
    try:
        # get the new inserted time from hbase table.
        insertedtime = utils.lookupString(insertedtimeKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if not insertedtime:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "lookupInsertedTime", 'No inserted time')
        path = prepareuvh + str(insertedtime)
        
        print 'path on HDFS: ' + path

        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, path)
        
        params = {
        'hbaseLib':location + hbaselib,
        'prepareuvh':path,
        'mappingTable':mappingtable,
        'hbase_zookeeper_quorum':hbase_zookeeper_quorum,
        'hbase_zookeeper_clientPort':hbase_zookeeper_clientPort,
        'mColumn':mColumn
        }
        utils.process(location + '/tokenIdToDMA/tokenIdToDMA.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'insertdatatohbase', batchNumber)

    except:
        try:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))
        except:
            print 'The issue comes from calling os._exit(1)'

def main():
    try:
        connectToHbase()
        numberParam = len(sys.argv)
        if numberParam == 2:
            batchNumber = str(sys.argv[1])
            addCardId(batchNumber)
        else:
            try:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "error", 'Not enough parameter')
            except:
                print 'The issue comes from calling os._exit(1)'
    except:
        print 'There are some problems when connecting hbase tables'

if __name__ == '__main__':
    main()
