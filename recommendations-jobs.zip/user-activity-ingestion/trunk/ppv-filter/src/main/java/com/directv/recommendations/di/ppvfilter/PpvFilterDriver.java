/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.ppvfilter;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 * HFile generating driver
 */
public class PpvFilterDriver {
	
	static final String CLOUDREC_PPVFILTER_PPVSOURCEID = "cloudrec.ppvfilter.ppvsourceid";

	/**
	 * @param args
	 *            args[0]: lookup table name 
	 *            args[1]: lookup key
	 *            args[2]: input folder
	 *            args[3]: outputRoot folder
	 *            
	 * @throws IOException 
	 * @throws InterruptedException 
	 * @throws ClassNotFoundException 
	 * @throws Exception
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		String ppvSourceId = args[0];
		String inputPath = args[1];
		String outputPath = args[2];

		Configuration hdfsConf = new Configuration();
		if (System.getenv("HADOOP_TOKEN_FILE_LOCATION") != null) {
            hdfsConf.set("mapreduce.job.credentials.binary", System.getenv("HADOOP_TOKEN_FILE_LOCATION"));
            System.out.println(System.getenv("HADOOP_TOKEN_FILE_LOCATION"));
         }
		Job job = new Job(hdfsConf, "PPVFilter on " + inputPath);
		job.setJarByClass(PpvFilterMapper.class);
		job.setMapperClass(PpvFilterMapper.class);
		job.setMapOutputKeyClass(PpvFilterKey.class);
		job.setMapOutputValueClass(PpvFilterValue.class);
		job.setInputFormatClass(TextInputFormat.class);
		
		job.setPartitionerClass(PpvFilterPartitioner.class);
		
		job.setReducerClass(PpvFilterReducer.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		
		
		job.getConfiguration().set(CLOUDREC_PPVFILTER_PPVSOURCEID, ppvSourceId);
		FileInputFormat.addInputPath(job, new Path(inputPath));
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		job.waitForCompletion(true);
	}
}

