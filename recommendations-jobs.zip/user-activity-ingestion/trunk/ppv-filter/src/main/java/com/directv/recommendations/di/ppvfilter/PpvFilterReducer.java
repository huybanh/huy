/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.ppvfilter;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

class PpvFilterReducer extends Reducer<PpvFilterKey, PpvFilterValue, NullWritable, Text> {
	
	private final NullWritable outKey = NullWritable.get();
	private final Text outValue = new Text();
	
	private String currentAccount;
	private String currentTms;
	private boolean ppvFound = false;

	/* 
	 * Keys are ordered by: accountId, tmsId, ppvFound (true comes first)
	 */
	@Override
	protected void reduce(PpvFilterKey key, Iterable<PpvFilterValue> values, Context context) 
	throws IOException, InterruptedException {
		
		if (currentAccount == null || !currentAccount.equals(key.accountId) || !currentTms.equals(key.tmsId)) {
			//new pair of account/tmsid
			currentAccount = key.accountId;
			currentTms = key.tmsId;
			ppvFound = key.ppvEvent;
		}
		
		Iterator<PpvFilterValue> it = values.iterator();
		while (it.hasNext()) {

			PpvFilterValue oneValue = it.next();
			context.getCounter(PpvFilterCounter.UVH_EXAMINED).increment(1);
			if (oneValue.ppvFlagExists) {
				context.getCounter(PpvFilterCounter.PPV_OLD).increment(1);
				//continue;
				return;
			}
			
			//counters
			context.getCounter(PpvFilterCounter.UVH_NEW).increment(1);
			if (key.ppvEvent) {
				context.getCounter(PpvFilterCounter.PPV_NEW).increment(1);
			}

			//not appending at the end, due to existing data structure
			//outValue.set(oneValue.uvh + ";" + ppvFound);
			
			//relace the place holder at location 68 by actual flag
			//this code snippet is inlined (not in a separate function) for performance purpose
			int fieldIndex = 0;
			int charIndex = 0;
			String uvh = oneValue.uvh;
						
			while (true) {
				//++ fixbug CR-2885. index = 68, but position is 69 in data format. Change index compare to 67
				if (fieldIndex == 67) {
					break;
				}
				charIndex = uvh.indexOf(';', charIndex);
				charIndex++;
				fieldIndex++;
			}
			
			int charNextIndex = uvh.indexOf(';', charIndex);
			String replacedUvh;
			if (charNextIndex < 0) {
				replacedUvh = uvh.substring(0, charIndex) + ppvFound;
			} else {
				replacedUvh = uvh.substring(0, charIndex) + ppvFound + uvh.substring(charNextIndex);
			}
			outValue.set(replacedUvh);
			context.write(outKey, outValue);
			
			//more counters
			if (!key.ppvEvent) {
				if (ppvFound) {
					context.getCounter(PpvFilterCounter.OTHER_TRUE).increment(1);
				} else {
					context.getCounter(PpvFilterCounter.OTHER_FALSE).increment(1);
				}
			}
		}
	}

	/*public static void main(String[] args) throws IOException, InterruptedException {
		PpvFilterReducer reducer = new PpvFilterReducer();
		
		PpvFilterKey key = new PpvFilterKey();
		key.accountId = "a";
		key.tmsId = "x";
		key.ppvEvent = true;
		reducer.reduce(key, null, null);

		key.tmsId = "x";
		key.ppvEvent = false;
		reducer.reduce(key, null, null);
		key.ppvEvent = false;
		reducer.reduce(key, null, null);
		
		key.accountId = "b";
		key.tmsId = "3";
		key.ppvEvent = false;
		reducer.reduce(key, null, null);
	}*/
	
	/**
	 * test string concat
	 */
	public static void main(String[] args) {
		testStringContact("a;b;c;d;e;f", 0);
		testStringContact("a;b;c;d;e;f", 1);
		testStringContact("a;b;c;d;e;f", 2);
		testStringContact("a;b;c;d;e;f", 3);
		testStringContact("a;b;c;d;e;f", 4);
		testStringContact("a;b;c;d;e;f", 5);
		
		System.out.println();
		testStringContact("a;b;;d;e;f", 0);
		testStringContact("a;b;;d;e;f", 1);
		testStringContact("a;b;;d;e;f", 2);
		testStringContact("a;b;;d;e;f", 3);
		testStringContact("a;b;;d;e;f", 4);
		testStringContact("a;b;;d;e;f", 5);
		
		System.out.println();
		testStringContact(";b;;d;e;f", 0);
		testStringContact(";b;;d;e;f", 1);
		testStringContact(";b;;d;e;f", 2);
		testStringContact(";b;;d;e;f", 3);
		testStringContact(";b;;d;e;f", 4);
		testStringContact(";b;;d;e;f", 5);
		
		System.out.println();
		testStringContact(";b;;d;e;", 0);
		testStringContact(";b;;d;e;", 1);
		testStringContact(";b;;d;e;", 2);
		testStringContact(";b;;d;e;", 3);
		testStringContact(";b;;d;e;", 4);
		testStringContact(";b;;d;e;", 5);
		
		System.out.println();
		testStringContact(";b;;d;;", 0);
		testStringContact(";b;;d;;", 1);
		testStringContact(";b;;d;;", 2);
		testStringContact(";b;;d;;", 3);
		testStringContact(";b;;d;;", 4);
		testStringContact(";b;;d;;", 5);
	}
	
	private static void testStringContact(String uvh, int loc) {
		int fieldIndex = 0;
		int charIndex = 0;
		while (true) {
			if (fieldIndex == loc) {
				break;
			}
			charIndex = uvh.indexOf(';', charIndex);
			charIndex++;
			fieldIndex++;
		}
		
		int charNextIndex = uvh.indexOf(';', charIndex);
		String replacedUvh;
		if (charNextIndex < 0) {
			replacedUvh = uvh.substring(0, charIndex) + "*";
		} else {
			replacedUvh = uvh.substring(0, charIndex) + "*" + uvh.substring(charNextIndex);
		}
		System.out.println(replacedUvh);
	}
}
