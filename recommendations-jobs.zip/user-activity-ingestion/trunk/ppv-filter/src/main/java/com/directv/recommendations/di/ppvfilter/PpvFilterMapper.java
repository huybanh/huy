/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.ppvfilter;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

class PpvFilterMapper extends Mapper<LongWritable, Text, PpvFilterKey, PpvFilterValue> {
	
	private final PpvFilterKey outKey = new PpvFilterKey();
	private final PpvFilterValue outValue = new PpvFilterValue();
	
	private String ppvSourceId;
	
	PpvFilterMapper() {
		this(false);
	}

	PpvFilterMapper(boolean ppvFlagExisting) {
		outValue.ppvFlagExists = ppvFlagExisting;
	}
	
	@Override
	protected void setup(Mapper<LongWritable, Text, PpvFilterKey, PpvFilterValue>.Context context) throws IOException, InterruptedException {
		
		super.setup(context);
		ppvSourceId = context.getConfiguration().get(PpvFilterDriver.CLOUDREC_PPVFILTER_PPVSOURCEID);
	}

	@Override
	protected void map(LongWritable key, Text uvhLine, Context context) throws IOException, InterruptedException {
		
		String uvhString = uvhLine.toString();
		outKey.populate(this.ppvSourceId, uvhString);
		outValue.uvh = uvhString;
		context.write(outKey, outValue);
	}
	
}
