/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.ppvfilter;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

class PpvFilterKey implements WritableComparable<PpvFilterKey> {
	
	/*
	 * Components of key
	 * */
	String accountId; //partition factor
	
	String tmsId; //partition factor
	
	boolean ppvEvent;

	/* Keys are ordered by: accountId, tmsId, scheduleStartTime, eventTime 
	 */
	@Override
	public int compareTo(PpvFilterKey o) {
		int c = this.accountId.compareTo(o.accountId);
		if (c != 0) {
			return c;
		}
		c = this.tmsId.compareTo(o.tmsId);
		if (c != 0) {
			return c;
		}
		
		if (this.ppvEvent) {
			if (o.ppvEvent) {
				return 0;
			} else {
				return -1;
			}
		} else {
			if (o.ppvEvent) {
				return 1;
			} else {
				return 0;
			}
		}
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(accountId);
		out.writeUTF(tmsId);
		out.writeBoolean(ppvEvent);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		accountId = in.readUTF();
		tmsId = in.readUTF();
		ppvEvent = in.readBoolean();
	}
	
	void populate(String ppvSourceId, String uvh) {
		
		//accountId: 1
		//tmsId: 2
		if (uvh == null) {
			return;
		}
		
		//performance consideration: replace split() by index handling?
		String[] fields = uvh.split(";");
		/*if (fields.length <= 1) {
			return;
		}*/
		accountId = fields[1]; //1
		
		/*if (fields.length <= 2) {
			return;
		}*/
		tmsId = fields[2]; //2
		
		/*if (fields.length <= 4) {
			return;
		}*/
		String eventType = fields[4]; //4
		ppvEvent = ppvSourceId.equals(eventType);
	}
	
	/**
	 * For debugging purpose only
	 */
	/*public static void main(String[] args) throws IOException, InterruptedException {
		String uvh = "0-20141003132452-EP010745711173;0;EP010745711173;20141003132452;2;LiveViewEvent;;20141003140000;20141003150000;984;1451689002;60;;;;;20141003140000;20141003150000;;Watch;1;0;Friday;Daytime;TV;Medical;Series;Talk;The Doctors;EP010745711173_751108;TVPG;;20141003000000;60;Linear;;;;;;;;;60;0;;-1;;SLL;0;524;;;;;;;;;;;;;;;;;;20141003;20141007";
		PpvFilterKey key = new PpvFilterKey();
		PpvFilterMapper mapper = new PpvFilterMapper();
		mapper.ppvSourceId = "2";
		mapper.populate(key, uvh);
		mapper.ppvSourceId = "3";
		mapper.populate(key, uvh);
	}*/
}

