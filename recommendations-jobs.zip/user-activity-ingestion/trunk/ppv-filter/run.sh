
#$1: ppv source number (according to current DI configuration, this is "2")
#$2: input
#$3: output

hadoop jar recommendations-ppvfilter-0.0.1-SNAPSHOT.jar com.directv.recommendations.di.ppvfilter.PpvFilterDriver $1 $2 $3
