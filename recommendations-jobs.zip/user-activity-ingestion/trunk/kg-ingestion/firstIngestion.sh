# Move data on the landing zone to the incoming folder
. ./properties.py;

batchNumber=$1;

echo "===========================START COPY PROCESSING DATA TO COMPLETE=============================";
eval "hadoop fs -mkdir $workingRoot$batchNumber$completeFolder";
eval "hadoop fs -cp $workingRoot$batchNumber$processingFolder/* $workingRoot$batchNumber$completeFolder";
