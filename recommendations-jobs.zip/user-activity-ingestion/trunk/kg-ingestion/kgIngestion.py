################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import sys
import os
import time
import subprocess
import imp
import datetime as dt
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from properties import *
# explicitly import Pig class 
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
rjhTable = HTable(config, recommendationJobHistory)
paramArray = [hbase_zookeeper_quorum, hbase_zookeeper_clientPort, landingZoneOfKgProgram, landingZoneOfKgGidmap, landingZoneOfKgPopularity, workingRoot, incomingFolder, 
              processingFolder, completeFolder, masterRoot, recommendationJobHistory, columnFamilyOfRJH, lookupTable, batchColumn, dataType, numDate]
paramName = ['hbase_zookeeper_quorum', 'hbase_zookeeper_clientPort', 'landingZoneOfKgProgram', 'landingZoneOfKgGidmap', 'landingZoneOfKgPopularity', 'workingRoot', 'incomingFolder', 
             'processingFolder', 'completeFolder', 'masterRoot', 'recommendationJobHistory', 'columnFamilyOfRJH', 'lookupTable', 'batchColumn', 'dataType', 'numDate']

fileSystem = FileSystem.get(config)
utils=imp.load_source('dataIngestion', '../ingestionUtils/ingestionUtils.py')

# Get current date for add filter
insertedTime=time.strftime("%Y%m%d%H%M")

def stitchingKg(batchNumber):
    try:
        params = {
        'program': str(workingRoot) + str(batchNumber) + str(incomingFolder) + '/program',
        'gidmap': str(workingRoot) + str(batchNumber) + str(incomingFolder) + '/gidmap',
        'popularity' : str(workingRoot) + str(batchNumber) + str(incomingFolder) + '/popularity',
        'processingFolder': str(workingRoot) + str(batchNumber) + str(processingFolder),
        'insertedTime':insertedTime
        }
        utils.process2('./stitchingKG.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'stitching', batchNumber, "finalKgData", "finalKgData")
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "stitching", str(sys.exc_info()[1]))

def kgMerging(previousBatch, batchNumber):
    print '===========================START SOCIAL MERGING============================='
    try:
        params = {
        'processing':str(workingRoot) + str(batchNumber) + str(processingFolder),
        'masterRoot':masterRoot,
        'lastBatch':previousBatch,
        'complete':str(workingRoot) + str(batchNumber) + str(completeFolder),
        'calculateNumDate': utils.getDate(numDate)
        }
        utils.process2('./mergingKG.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'merging', batchNumber, "processing", "finalKgData")
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "merging", str(sys.exc_info()[1]))

def kgLastBatch(batchNumber):
    print '===========================START SOCIAL LAST BATCH============================='
    try:
        params = {
        'dataType':dataType, 
        'lookupTable':lookupTable,
        'batchColumn':batchColumn
        }
        #execute the Pig script
        return utils.lastBatch('../ingestionUtils/lastBatch.pig', params, rjhTable, columnFamilyOfRJH, batchNumber, dataType)
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "lastBatch", str(sys.exc_info()[1]))

def main():
    numberParam = len(sys.argv)
    if numberParam == 2:
        batchNumber = str(sys.argv[1])
        try:
            # validate if the parameters is empty or not?
            utils.validateParameters(rjhTable, columnFamilyOfRJH, batchNumber, dataType, paramArray, paramName)
            # validate if the folders contain data or not including program, gidmap, popularity
            utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, landingZoneOfKgProgram)
            utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, landingZoneOfKgGidmap)
            utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, landingZoneOfKgPopularity)
            
            # KG PROGRAM
            params = {
            'dataType':unprocessedKgProgram,
            'lookupTable':lookupTable,
            'batchColumn':batchColumn
            }
            oldLastModificationTime = utils.lastBatch('../ingestionUtils/lastBatch.pig', params, rjhTable, columnFamilyOfRJH, batchNumber, dataType)
            modificationTime = 0
            if oldLastModificationTime:
                modificationTime = int(oldLastModificationTime)
            pathOfKgProgram = str(workingRoot) + str(batchNumber) + str(incomingFolder) + '/program'
            newTimeOfKgProgram = utils.copyFileFromLandingzoneToIncomingFolder(fileSystem, landingZoneOfKgProgram, pathOfKgProgram, modificationTime)
            
            if int(newTimeOfKgProgram) > 0:
                # KG GIDMAP
                params = {
                'dataType':unprocessedKgGidmap,
                'lookupTable':lookupTable,
                'batchColumn':batchColumn
                }
                oldLastModificationTime = utils.lastBatch('../ingestionUtils/lastBatch.pig', params, rjhTable, columnFamilyOfRJH, batchNumber, dataType)
                modificationTime = 0
                if oldLastModificationTime:
                    modificationTime = int(oldLastModificationTime)
                pathOfKgGidmap = str(workingRoot) + str(batchNumber) + str(incomingFolder) + '/gidmap'
                newTimeOfKgGidmap = utils.copyFileFromLandingzoneToIncomingFolder(fileSystem, landingZoneOfKgGidmap, pathOfKgGidmap, modificationTime)
                if int(newTimeOfKgGidmap) > 0:
                    # KG POPULARITY
                    params = {
                    'dataType':unprocessedKgPopularity,
                    'lookupTable':lookupTable,
                    'batchColumn':batchColumn
                    }
                    
                    oldLastModificationTime = utils.lastBatch('../ingestionUtils/lastBatch.pig', params, rjhTable, columnFamilyOfRJH, batchNumber, dataType)
                    modificationTime = 0
                    if oldLastModificationTime:
                        modificationTime = int(oldLastModificationTime)
                    pathOfKgPopularity = str(workingRoot) + str(batchNumber) + str(incomingFolder) + '/popularity'
                    newTimeOfKgPopularity = utils.copyFileFromLandingzoneToIncomingFolder(fileSystem, landingZoneOfKgPopularity, pathOfKgPopularity, modificationTime)
                    if int(newTimeOfKgPopularity) > 0:
                         # ingestion of kg data is here
                         stitchingKg(batchNumber)
                         # check if data in the folder "processing" exist or not?
                         utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(workingRoot) + str(batchNumber) + str(processingFolder))
                         
                         lastBatchNumber = kgLastBatch(batchNumber)
                         if not lastBatchNumber:
                             startTime = datetime.now()
                             subprocess.call('./firstIngestion.sh ' + batchNumber, shell=True)
                             columns = ['status', 'message', 'startTime', 'endTime']
                             endTime = datetime.now()
                             values = ['SUCCEED', 'This is the first batch', startTime.strftime("%Y-%m-%d %H:%M:%S"), endTime.strftime("%Y-%m-%d %H:%M:%S")]
                             utils.updateRjh(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'lastBatch', columns, values)
                         else:
                             # if lastBatchNumber is not empty, we have to merge the new data with old data.
                             kgMerging(lastBatchNumber, batchNumber)
                         # end of kg ingestion
                         subprocess.call('./storeData.sh ' + batchNumber + ' ' + str(newTimeOfKgProgram) + ' ' + str(newTimeOfKgGidmap) + ' ' + str(newTimeOfKgPopularity), shell=True)
                         utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(masterRoot) + str(batchNumber))
                    else:
                        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "main", "No new popularity file are in the folder \"Landingzone\"")
                else:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "main", "No new gidmap file are in the folder \"Landingzone\"")
            else:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "main", "No new program file are in the folder \"Landingzone\"")
        except:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "except", str(sys.exc_info()[1]))
    else:
        print '===========================Not enough parameter============================='
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "main", 'Not enough parameter')

if __name__ == '__main__':
    main()
