################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
. ./properties.py;
batchNumber=$1;
newTimeOfKgProgram=$2;
newTimeOfKgGidmap=$3;
newTimeOfKgPopularity=$4;

echo "'===========================MOVE COMPLETE TO MASTER============================='";
eval "hadoop fs -mkdir $masterRoot$batchNumber";
eval "hadoop fs -mv $workingRoot$batchNumber$completeFolder/* $masterRoot$batchNumber";

echo "'===========================UPDATE LOOKUP TABLE============================='";
echo "put '$lookupTable', '$dataType', '$batchColumn', '$batchNumber'" | hbase shell;
echo "put '$lookupTable', '$unprocessedKgProgram', '$batchColumn', '$newTimeOfKgProgram'" | hbase shell;
echo "put '$lookupTable', '$unprocessedKgGidmap', '$batchColumn', '$newTimeOfKgGidmap'" | hbase shell;
echo "put '$lookupTable', '$unprocessedKgPopularity', '$batchColumn', '$newTimeOfKgPopularity'" | hbase shell;

echo "'===========================DELETE PROCESSING DATA============================='";
eval "hadoop fs -rm -r $workingRoot$batchNumber$completeFolder";
eval "hadoop fs -rm -r $workingRoot$batchNumber$processingFolder";
eval "hadoop fs -rm -r $workingRoot$batchNumber$incomingFolder";
