################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
#hbase_zookeeper_quorum='hdpdb-tstmsdc01.ds.dtveng.net,hdpdb-tstmsdc02.ds.dtveng.net,hdpdb-tstmsdc03.ds.dtveng.net'
hbase_zookeeper_quorum='hdpnn-dv-msdc02.ds.dtveng.net,hdpnn-dv-msdc01.ds.dtveng.net,hdpdn-dv-msdc03.ds.dtveng.net'
hbase_zookeeper_clientPort='2181'

# The landing zone
landingZoneOfKgProgram='/user/d458737/viet/landing/kg/program/'
landingZoneOfKgGidmap='/user/d458737/viet/landing/kg/gidmap/'
landingZoneOfKgPopularity='/user/d458737/viet/landing/kg/popularity/'

# Root of working folders
workingRoot='/user/d458737/viet/working/kg/'

# Sub folders in each batch folder
incomingFolder='/incoming'
processingFolder='/processing'
completeFolder='/complete'

masterRoot='/user/d458737/viet/sor/uvh/kg/'

# Hbase table is used to store information such as: jobId, start time, end time ..
recommendationJobHistory='demo_5_2014_recommendationsjobhistory'
columnFamilyOfRJH='h'

# The lookup table
lookupTable='demo_5_2014_lookupTable'
lookupFamilyName='cf'
lookupColumnQualifier='batch'
batchColumn='cf:batch'
dataType='kg'
unprocessedKgProgram='unprocessedKgProgram'
unprocessedKgGidmap='unprocessedKgGidmap'
unprocessedKgPopularity='unprocessedKgPopularity'

# setting num day to get data
numDate='90'
