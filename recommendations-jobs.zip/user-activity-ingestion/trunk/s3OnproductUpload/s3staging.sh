################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#$1 action: list get delete file hdfs hdfsgzip
#$2 destPathInS3
#$3 sourcePath

export HADOOP_CLASSPATH=lib/*

hadoop jar lib/awsupload-0.2.0-SNAPSHOT.jar com.directv.s3upload.AwsUpload filegzip directv-external-7u93p5yb staging/next/ $1

