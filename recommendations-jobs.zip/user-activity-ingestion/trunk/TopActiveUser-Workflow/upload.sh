#kinit -kt svc.cloudrec.dv2.keytab  svc.cloudrec.dv2@DS.DTVENG.NET
hdfsLocation='/data/dv/recommendation/oozie/topactiveuser-workflow/';

hadoop fs -rm -r $hdfsLocation;
hadoop fs -mkdir $hdfsLocation;
hadoop fs -put * $hdfsLocation;




