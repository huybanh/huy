################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

# Description:
# This task will use data from various sources such as: ppv, streaming, ams ... as well as data from guide data such as: channel, program, schedule...
# So we have to point to location of both guide data and omniture data.

# path of output ams, ppv, social, stream
flixterPath="/data/dv/recommendation/landingzone/onproduct/flixters"
betterPath="/data/dv/recommendation/landingzone/onproduct/bettercategories"

# staging location for PPV filtering
ppvFilterJar="recommendations-ppvfilter-0.0.1.jar"
subtractionJar="recommendations-subtraction-0.0.1.jar"

timeFormat='HHmmss'
dateTimeFormat='yyyyMMddHHmmss'
timeOfDay='[{"key":"Daytime","fromHour":"090000","toHour":"175959"},{"key":"Early Fringe","fromHour":"180000","toHour":"195959"},{"key":"Prime Fringe","fromHour":"200000","toHour":"215959"},{"key":"Late Evening","fromHour":"220000","toHour":"005959"},{"key":"Late Night","fromHour":"010000","toHour":"045959"},{"key":"Early Morning","fromHour":"050000","toHour":"085959"}]'

