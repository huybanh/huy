#!/usr/bin/python


################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################


import sys
import os
import time
import subprocess
import imp
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

from common_properties import *

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)

rjhTable = None
lookupTableInstance = None
fileSystem = FileSystem.get(config)
location = os.getcwd()
utils = imp.load_source('prepareData', location + '/ingestionUtils/ingestionUtils.py')

# load specific properties file
specificProperties = imp.load_source('load properties file', location + '/prepareData/preparedata_properties.py')
flixterPath = specificProperties.flixterPath
betterPath = specificProperties.betterPath
ppvFilterJar = specificProperties.ppvFilterJar
subtractionJar = specificProperties.subtractionJar
timeFormat = specificProperties.timeFormat
dateTimeFormat = specificProperties.dateTimeFormat
timeOfDay = specificProperties.timeOfDay

# combine each sub-folder with "masterRoot" to create absolute paths for guide data
programPath = masterRoot + 'programs/'
channelPath = masterRoot + 'channels/'
contentPath = masterRoot + 'contents/'

# combine each sub-folder with "postingRoot" to create absolute paths for each data type
amsPath = postingRoot + 'ams/'
ppvPath = postingRoot + 'ppv/'
socialPath = postingRoot + 'social/'
streamingPath = postingRoot + 'streaming/'
cdnPath = postingRoot + 'cdn/'
remotePath = postingRoot + 'remote/'

# below are rowkeys in Hbase table
dataType = 'newData'
dataTypeProgram = 'program'
dataTypeChannel = 'channel'
dataTypeContent = 'content'
insertedTimeCol = 'insertedTime'
outputDataPath = postingRoot + 'newuvh/'
stagingPath = workingRoot + dataType + '/'

# Get current date for add filter
insertedTime=time.strftime("%Y%m%d%H")

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        print "================================================ THERE IS A ERROR WHEN CONNECTING TO HBASE TABLE: " + str(sys.exc_info()[1])
        os._exit(1)

# Get last batch of program, channel
def getLastBatch(batchNumber):
    print '===========================START GET LAST BATCH FOR NEW DATA============================='
    try:
        programLastBatch = utils.lookupString(dataTypeProgram, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        channelLastBatch = utils.lookupString(dataTypeChannel, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        contentLastBatch = utils.lookupString(dataTypeContent, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        print 'programLastBatch: ' + programLastBatch 
        print 'channelLastBatch: ' + channelLastBatch
        print 'contentLastBatch: ' + contentLastBatch 
        return programLastBatch, channelLastBatch, contentLastBatch 
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "getlastbatch", str(sys.exc_info()[1]))


def runPrepareData(batchNumber):
    print '===========================START ALL NEW DATA============================='
    try:
        amsLocation = Path(amsPath + str(batchNumber))
        ppvLocation = Path(ppvPath + str(batchNumber))
        socialLocation = Path(socialPath + str(batchNumber))
        streamingLocation = Path(streamingPath + str(batchNumber))
        cdnLocation = Path(cdnPath + str(batchNumber))
        remoteLocation = Path(remotePath + str(batchNumber))
        if not fileSystem.exists(amsLocation) or not fileSystem.isDirectory(amsLocation):
            subprocess.call('hadoop fs -mkdir ' + amsPath + batchNumber, shell=True)
        if not fileSystem.exists(ppvLocation) or not fileSystem.isDirectory(ppvLocation):
            subprocess.call('hadoop fs -mkdir ' + ppvPath + batchNumber, shell=True)
        if not fileSystem.exists(socialLocation) or not fileSystem.isDirectory(socialLocation):
            subprocess.call('hadoop fs -mkdir ' + socialPath + batchNumber, shell=True)
        if not fileSystem.exists(streamingLocation) or not fileSystem.isDirectory(streamingLocation):
            subprocess.call('hadoop fs -mkdir ' + streamingPath + batchNumber, shell=True)
        if not fileSystem.exists(cdnLocation) or not fileSystem.isDirectory(cdnLocation):
            subprocess.call('hadoop fs -mkdir ' + cdnPath + batchNumber, shell=True)
        if not fileSystem.exists(remoteLocation) or not fileSystem.isDirectory(remoteLocation):
            subprocess.call('hadoop fs -mkdir ' + remotePath + batchNumber, shell=True)

        programLastBatch, channelLastBatch, contentLastBatch = getLastBatch(batchNumber)
        # CR-4194
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(programPath) + str(programLastBatch))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(channelPath) + str(channelLastBatch))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(contentPath) + str(contentLastBatch))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(amsPath) + str(batchNumber))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(ppvPath) + str(batchNumber))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(socialPath) + str(batchNumber))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(streamingPath) + str(batchNumber))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(cdnPath) + str(batchNumber))
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(remotePath) + str(batchNumber))
        #utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, flixterPath)
        #utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, betterPath)
        
        params = {
        'dataType':dataType,
        'batchNumber':str(batchNumber),
        'workingDir':location + udfDataIngestion,
        'stagingPath':stagingPath,
        'programPath':str(programPath) + str(programLastBatch),
        'channelPath':str(channelPath) + str(channelLastBatch),
        'contentPath':str(contentPath) + str(contentLastBatch),
        'amsPath':str(amsPath) + str(batchNumber),
        'ppvPath':str(ppvPath) + str(batchNumber),
        'socialPath':str(socialPath) + str(batchNumber),
        'streamingPath':str(streamingPath) + str(batchNumber),
        'cdnPath':str(cdnPath) + str(batchNumber),
        'remotePath':str(remotePath) + str(batchNumber),
        'ppvFilterJar':ppvFilterJar,
        'outputDataPath':str(outputDataPath) + str(batchNumber),
        'flixterPath':flixterPath,
        'betterPath':betterPath,
        'timeFormat':timeFormat,
        'dateTimeFormat':dateTimeFormat,
        'timeOfDay':timeOfDay,
        'insertedTime':insertedTime
        }
        
        utils.process(location + '/prepareData/prepareData.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'processing', batchNumber)
        #remove duplicates
        #On first ingestion, we have empty lastBatchNumber. There are no duplicates to remove
        lastBatchNumber = utils.lookupString(dataType, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if lastBatchNumber != '':
                subprocess.call('hadoop jar ' + location + '/prepareData/' + subtractionJar + ' com.directv.recommendations.di.subtract.Driver ' + stagingPath + batchNumber + 
                '/prepareuvh_subtract_minuen/ ' + outputDataPath + lastBatchNumber + ' ' + stagingPath + batchNumber + '/prepareuvh_subtract_result true', shell=True)
                subtractionResultPath = stagingPath + batchNumber + '/prepareuvh_subtract_result'
        else:
                subtractionResultPath = stagingPath + batchNumber + '/prepareuvh_subtract_minuen/'

        #PPV filtering
        subprocess.call('hadoop jar ' + location + '/prepareData/' + ppvFilterJar + ' com.directv.recommendations.di.ppvfilter.PpvFilterDriver 2 ' +
                subtractionResultPath + ' ' +
                outputDataPath + batchNumber, shell=True)

    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "preparingData", str(sys.exc_info()[1]))
    print '===========================END ALL NEW DATA============================='

def main():
    try:
        connectToHbase()
        numberParam = len(sys.argv)
        if numberParam == 2:
            batchNumber = str(sys.argv[1])
            try:
                runPrepareData(batchNumber);
                # put lastbatch and insertedtime to hbase table
                utils.insertDataToHbase(lookupTableInstance, lookupFamilyName, lookupColumnQualifier, dataType, batchNumber)
                utils.insertDataToHbase(lookupTableInstance, lookupFamilyName, lookupColumnQualifier, insertedTimeCol, insertedTime)
                
                # print status to console:
                utils.printStatusToConsole(rjhTable, batchNumber, columnFamilyOfRJH, dataType)
            except:
                try:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))
                except:
                    print 'The issue comes from calling os._exit(1)'
        else:
            try:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "error", 'Not enough parameter')
            except:
                print 'The issue comes from calling os._exit(1)'
    except:
        print 'There are some problems when connecting hbase tables'

if __name__ == '__main__':
    main()
