
#$1: minuend input path
#$2: subtrahend input path
#$3: output path
#$4: doDistinct on output keys

hadoop jar recommendations-subtraction-0.0.1-SNAPSHOT.jar com.directv.recommendations.di.subtract.Driver $1 $2 $3 $4
