/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.subtract;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

class CRPartitioner extends Partitioner<CRKey, Text> {

	@Override
	public int getPartition(CRKey key, Text value, int module) {
		/*int c = key.rowkey.hashCode();
		int abs = Math.abs(c);
		return abs % module;*/
		
		int c = key.rowkey.hashCode();
		c = c % module;
		return Math.abs(c);
	}

	public static void main(String[] args) {
		CRKey key = new CRKey();
		key.rowkey = "4431263-20141115183000-EP011344190178";
		int p = new CRPartitioner().getPartition(key, null, 11);
		System.out.println(p);
	}
}
