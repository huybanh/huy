/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.subtract;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;

import org.apache.hadoop.io.WritableComparable;

class CRKey implements WritableComparable<CRKey> {
	
	/*
	 * Components of key
	 * */
	String rowkey;
	
	boolean minuend;

	/* Keys are ordered by: accountId, tmsId, scheduleStartTime, eventTime 
	 */
	@Override
	public int compareTo(CRKey o) {
		int c = this.rowkey.compareTo(o.rowkey);
		if (c != 0) {
			return c;
		}
		
		if (this.minuend) {
			if (o.minuend) {
				return 0;
			} else {
				return 1;
			}
		} else {
			if (o.minuend) {
				return -1;
			} else {
				return 0;
			}
		}
	}

	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(rowkey);
		out.writeBoolean(minuend);
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		rowkey = in.readUTF();
		minuend = in.readBoolean();
	}
	
	/**
	 * For debugging purpose only
	 */
	/*public static void main(String[] args) throws IOException, InterruptedException {
		CRKey minuend = new CRKey();
		CRKey subtrahend = new CRKey();
		minuend.rowkey = "a";
		minuend.minuend = true;
		subtrahend.rowkey = "a";
		subtrahend.minuend = false;
		if (minuend.compareTo(subtrahend) < 0) {
			throw new RuntimeException();
		}
		System.out.println("subtrahend < minuend: subtrahend comes first at reducer -> correct");
	}*/
	
	public static void main(String[] args) throws IOException, InterruptedException {
		
		LinkedList<CRKey> tests = new LinkedList<CRKey>();
		CRKey k = new CRKey();
		k.rowkey = "a";
		k.minuend = true;
		tests.add(k);
		
		k = new CRKey();
		k.rowkey = "b";
		k.minuend = true;
		tests.add(k);
		
		k = new CRKey();
		k.rowkey = "c";
		k.minuend = true;
		tests.add(k);
		
		k = new CRKey();
		k.rowkey = "b";
		k.minuend = false;
		tests.add(k);
		
		k = new CRKey();
		k.rowkey = "e";
		k.minuend = false;
		tests.add(k);
		
		k = new CRKey();
		k.rowkey = "f";
		k.minuend = false;
		tests.add(k);
		
		Collections.sort(tests);
		CRPartitioner p = new CRPartitioner();
		for (CRKey one : tests) {
			System.out.println(one.rowkey + ":" + one.minuend + " - " + p.getPartition(one, null, 10));
		}
		
		/*
		 * Expected outputs: (false before true, same rowkey same partition number
		 *  a:true - 7
			b:false - 8
			b:true - 8
			c:true - 9
			e:false - 1
			f:false - 2
		 * */
	}
}

