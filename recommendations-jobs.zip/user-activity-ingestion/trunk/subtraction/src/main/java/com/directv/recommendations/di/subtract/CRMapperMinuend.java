/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.subtract;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

class CRMapperMinuend extends Mapper<LongWritable, Text, CRKey, Text> {
	
	private final CRKey outKey = new CRKey();
	
	private final boolean minuend;
	
	public CRMapperMinuend() {
		this(true);
	}

	CRMapperMinuend(boolean minuend) {
		this.minuend = minuend;
	}

	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		
		String uvh = value.toString();
		int i = uvh.indexOf(';');
		if (i < 0) {
			outKey.rowkey = uvh;
		} else {
			outKey.rowkey = uvh.substring(0, i);
		}
		outKey.minuend = minuend;
		context.write(outKey, value);
		/*try {
			context.write(outKey, value);
		} catch (IOException ie) {
			CRPartitioner p = new CRPartitioner();
			int pn = p.getPartition(outKey, null, 11);
			throw new IOException(outKey.rowkey + ": " + pn, ie);
		}*/
		if (minuend) {
			context.getCounter(Counter.MINUEND_ROWCOUNT).increment(1);
		} else {
			context.getCounter(Counter.SUBTRAHEND_ROWCOUNT).increment(1);
		}
	}
	
	public static void main(String[] args) {
		String s = "a;b;c";
		System.out.println(s.substring(0, s.indexOf(';')));
	}
}
