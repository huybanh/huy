/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.subtract;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

class CRReducer extends Reducer<CRKey, Text, NullWritable, Text> {
	
	private final NullWritable outKey = NullWritable.get();
	
	private String currentRowkey;
	private boolean currentRowkeyExistsInSubtrahend;
	
	private boolean doDistinct = false;

	@Override
	protected void setup(Reducer<CRKey, Text, NullWritable, Text>.Context context)throws IOException, InterruptedException {
		
		super.setup(context);
		String s = context.getConfiguration().get(Driver.CLOUDREC_SUBTRACTION_DODISTINCT);
		doDistinct = Boolean.parseBoolean(s);
	}

	/* 
	 * Keys are ordered by: accountId, tmsId, ppvFound (true comes first)
	 */
	@Override
	protected void reduce(CRKey key, Iterable<Text> values, Context context) 
	throws IOException, InterruptedException {
		
		//System.out.println("Got " + key.rowkey + ": " + key.minuend);
		if (key.minuend) {
			context.getCounter(Counter.MINUEND_KEYCOUNT).increment(1);
		} else {
			context.getCounter(Counter.SUBTRAHEND_KEYCOUNT).increment(1);
		}
		
		if (currentRowkey == null || !currentRowkey.equals(key.rowkey)) {
			//new pair of account/tmsid
			currentRowkey = key.rowkey;
			if (key.minuend) {
				currentRowkeyExistsInSubtrahend = false;
			} else {
				currentRowkeyExistsInSubtrahend = true;
			}
		}
		
		if (currentRowkeyExistsInSubtrahend) {
			if (key.minuend) {
				context.getCounter(Counter.REMOVED_KEYCOUNT).increment(1);
			}
			return;
		}
		
		Iterator<Text> it = values.iterator();
		while (it.hasNext()) {

			Text oneValue = it.next();
			context.write(outKey, oneValue);
			context.getCounter(Counter.OUTPUT_ROWCOUNT).increment(1);
			
			//if doDistinct -> emit the one value only -> we are done
			if (doDistinct) {
				return;
			}
		}
	}

	public static void main(String[] args) throws IOException, InterruptedException {
		CRReducer reducer = new CRReducer();
		
		CRKey key = new CRKey();
		key.rowkey = "a";
		key.minuend = false;
		reducer.reduce(key, null, null);

		key.rowkey = "a";
		key.minuend = true;
		reducer.reduce(key, null, null);
	}
}
