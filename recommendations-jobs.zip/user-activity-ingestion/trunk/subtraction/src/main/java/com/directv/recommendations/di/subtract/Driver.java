/**
 * 
 * DIRECTV PROPRIETARY
 * Copyright© 2014 DIRECTV, INC.
 * UNPUBLISHED WORK
 * ALL RIGHTS RESERVED
 * 
 * This software is the confidential and proprietary information of
 * DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction, 
 * distribution or disclosure of the software or Proprietary Information, 
 * in whole or in part, must comply with the terms of the license 
 * agreement, nondisclosure agreement or contract entered into with 
 * DIRECTV providing access to this software.
 */
package com.directv.recommendations.di.subtract;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/**
 * Set subtraction (A - B): Remove elements from A, if those elements also belong to B. Result is the remain in A. 
 */
public class Driver {
	
	static final String CLOUDREC_SUBTRACTION_DODISTINCT = "CLOUDREC_SUBTRACTION_DODISTINCT";

	/**
	 * @param args
	 *            args[0]: lookup table name 
	 *            args[1]: lookup key
	 *            args[2]: input folder
	 *            args[3]: outputRoot folder
	 *            
	 * @throws IOException 
	 * @throws InterruptedException 
	 * @throws ClassNotFoundException 
	 * @throws Exception
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		String inputMinuend = args[0];
		String inputSubtrahend = args[1];
		String outputPath = args[2];
		boolean doDistinct = Boolean.parseBoolean(args[3]); //parsing here to early validate this parameter.

		//job configuration
		Configuration hdfsConf = new Configuration();
		if(System.getenv("HADOOP_TOKEN_FILE_LOCATION")!=null) {
			hdfsConf.set("mapreduce.job.credentials.binary",System.getenv("HADOOP_TOKEN_FILE_LOCATION"));
		}
		Job job = new Job(hdfsConf, "Subtraction from " + inputMinuend);
		job.getConfiguration().set(CLOUDREC_SUBTRACTION_DODISTINCT, Boolean.toString(doDistinct));
		job.setJarByClass(CRMapperMinuend.class);
		job.setPartitionerClass(CRPartitioner.class);

		
		//multiple inputs
		MultipleInputs.addInputPath(job, new Path(inputMinuend), TextInputFormat.class, CRMapperMinuend.class);
		MultipleInputs.addInputPath(job, new Path(inputSubtrahend), TextInputFormat.class, CRMapperSubtrahend.class);
		job.setMapOutputKeyClass(CRKey.class);
		job.setMapOutputValueClass(Text.class);
		
		//output
		job.setReducerClass(CRReducer.class);
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Text.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		FileOutputFormat.setOutputPath(job, new Path(outputPath));
		
		//submit the job
		job.waitForCompletion(true);
	}
}

