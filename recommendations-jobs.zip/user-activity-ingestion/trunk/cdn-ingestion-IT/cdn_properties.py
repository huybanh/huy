################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
# Description:
# landingZone: point to the HDFS location where we are using to store cdn raw data.
# source: is 5 it mean if any row have source "5" then this row comes from cdn data.
# originalFormat: is current date format of cdn data
#
# HOW DOES THE SCRIPT KNOW THE LOCATION OF ZIPCODE
# We have to create path of zipcode data by setting value for parameter "postingRoot" in the "common_properties" file.
# When we launch the script, it will automatically append sub-folder "zipcode/" to "postingRoot" to create absolute path of zipcde data
# Note: we can have one or more sub-folder from absolute path, but the script just load data from the latest folder.
# e.g if "postingRoot" is "/data/dv/recommendation/processed/" then absolute path of zipcode is "/data/dv/recommendation/processed/zipcode/"

# The landing zone
landingZone='/data/dv/raw/cdn-IT/'

source = 'CDN'
originalFormat = 'yyyy-MM-dd HH:mm:ss'
deviceType='STB'
# tmsId field is at position 5 in the data tuple
cleansingConfig='className:FieldRegexMatcher;fieldNum:5;regex:MV.*;regex:SH.*;regex:EP.*;match:true'
