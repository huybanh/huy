################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

# number days filter:
days=30
# check number days to run job
afterTime=30
# path of DI:
AMS="/data/dv/recommendation/processed/ams"
CDN="/data/dv/recommendation/processed/cdn"
PPV="/data/dv/recommendation/processed/ppv"
REMOTE="/data/dv/recommendation/processed/remote"
SOCIAL="/data/dv/recommendation/processed/social"
STREAMING="/data/dv/recommendation/processed/streaming"
NEWUVH="/data/dv/recommendation/processed/newuvh"
ACCOUNTID="/data/dv/recommendation/processed/accountId"
#PREPAREUVH="/data/dv/recommendation/processed/prepareduvh"

# path of DA:
#LA:
LA="/data/dv/recommendation/analytics/lastaction/result"
LA_Post="/data/dv/recommendation/analytics/lastaction/result_posting"
#CBCF:
CBCF="/data/dv/recommendation/analytics/cbcf/result/cbcf"
CBCFBD="/data/dv/recommendation/analytics/cbcf/result/cbcfbyday"
CBCFUT="/data/dv/recommendation/analytics/cbcf/result/usertaste"
#WIH:

