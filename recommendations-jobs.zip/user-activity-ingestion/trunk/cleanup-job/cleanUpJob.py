#!/usr/bin/python

################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

import sys
import os
import time
import imp
import subprocess
from org.apache.hadoop.fs import *
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from datetime import datetime
from datetime import timedelta

# Load properties file
from common_properties import *

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
rjhTable = None
lookupTableInstance = None

fileSystem = FileSystem.get(config);
location = os.getcwd()
utils = imp.load_source('dataIngestion', location + '/ingestionUtils/ingestionUtils.py')
currentDate = datetime.now().strftime('%Y%m%d')

dataType='cleanUpJob'
key = '-'.join([dataType, currentDate])

specificProperties = imp.load_source('load properties file', location + '/cleanup-job/cleanUp_properties.py')
days = specificProperties.days
afterTime = specificProperties.afterTime
# path of DI:
AMS = specificProperties.AMS
CDN = specificProperties.CDN
PPV = specificProperties.PPV
REMOTE = specificProperties.REMOTE
SOCIAL = specificProperties.SOCIAL
STREAMING = specificProperties.STREAMING
NEWUVH = specificProperties.NEWUVH
ACCOUNTID = specificProperties.ACCOUNTID
# path of DA:
LA = specificProperties.LA
LA_Post = specificProperties.LA_Post
CBCF = specificProperties.CBCF
CBCFBD = specificProperties.CBCFBD
CBCFUT = specificProperties.CBCFUT

pathArray = [AMS, CDN, PPV, REMOTE, SOCIAL, STREAMING, NEWUVH, ACCOUNTID, LA, LA_Post, CBCF, CBCFBD, CBCFUT]
pathName = ['AMS', 'CDN', 'PPV', 'REMOTE', 'SOCIAL', 'STREAMING', 'NEWUVH', 'ACCOUNTID', 'LA', 'LA_Post', 'CBCF', 'CBCFBD', 'CBCFUT']

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        print "================================================ THERE IS A ERROR WHEN CONNECTING TO HBASE TABLE: " + str(sys.exc_info()[1])
        os._exit(1)

def cleanUpJob(pathName ,location, numberDayFilter):
    pathList = []
    startTime = datetime.now()
    timeFilter = startTime - timedelta(days=numberDayFilter)
    path = Path(location);
    fileStatus = fileSystem.listStatus(path)
    for sFile in fileStatus:
        modificationTimeOfFolder = datetime.fromtimestamp(sFile.getModificationTime() / 1e3)
        if modificationTimeOfFolder < timeFilter:
            try:
                subprocess.call('hadoop fs -rm -R ' + str(sFile.getPath()), shell=True)
                pathList.append( sFile.getPath())
            except:
                updateRjh(['message', 'status'], [str(sys.exc_info()[1]), 'Job Failed'])
    if len(pathList) > 0:
        updateLog(pathName, pathList)
    else:
        updateLog(pathName, 'There is no removed data')

# put the all path removed to Hbase table
def updateLog(qualifier, values):
    put = Put(Bytes.toBytes(key))
    put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes(qualifier),Bytes.toBytes(str(values)))
    rjhTable.put(put)

def validateParameters():
    for i in range(len(pathArray)):
        # Check if the parameters from properties file is empty?
        if not pathArray[i]:
            updateRjh(['message', 'status'], [pathName[i] + ' is empty', 'Job Failed'])
        # check if folder on HDFS exist or not?
        path = Path(pathArray[i]);
        if not fileSystem.exists(path):
            updateRjh(['message', 'status'], [str(path) + ' is not exist', 'Job Failed'])
        if not fileSystem.isDirectory(path):
            updateRjh(['message', 'status'], [str(path) + ' is not folder', 'Job Failed'])

# whenever a step finished, status of job will be logged to recommendationjobhistory.
def updateRjh(columns, values):
    putList = []
    put = Put(Bytes.toBytes(key))
    for index in range(len(columns)): 
        put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes(str(columns[index])), Bytes.toBytes(values[index]))
        putList.append(put)
    rjhTable.put(putList)
    os._exit(1)

def main():
    try:
        connectToHbase()
        lastDate = utils.lookupString(dataType, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if (datetime.now() - timedelta(days=afterTime)).strftime('%Y%m%d') <= lastDate:
            print "Not enough " + str(afterTime) + " days after previous run time" 
            updateRjh(['message', 'status'], ['not enough ' + str(afterTime) + ' days after previous run time', 'Job Failed'])
        # Validate parameters:
        validateParameters()	
        print "================= REMOVE DATA OUT OF DATE :=================="
        for index in range(len(pathArray)):
            cleanUpJob(pathName[index], pathArray[index], days)
        print "=============== FINISH REMOVE DATA OUT OF DATE :=============="
        # store current date to Hbase table
        utils.insertDataToHbase(lookupTableInstance, lookupFamilyName, lookupColumnQualifier, dataType, currentDate)
        updateRjh(['message', 'status'], ['There is not message', 'Job Successful'])
    except:
        print 'The issue comes from calling os._exit(1)'

if __name__ == '__main__':
    main()


