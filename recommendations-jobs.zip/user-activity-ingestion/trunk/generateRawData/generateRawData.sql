---------------------------------------------------------------------------------
--                                                                              -
-- DIRECTV PROPRIETARY                                                          -
-- Copyright@ 2014 DIRECTV, INC.                                                -
-- UNPUBLISHED WORK                                                             -
-- ALL RIGHTS RESERVED                                                          -
--                                                                              -
-- This software is the confidential and proprietary information of             -
-- DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           -
-- distribution or disclosure of the software or Proprietary Information,       -
-- in whole or in part, must comply with the terms of the license               -
-- agreement, nondisclosure agreement or contract entered into with             -
-- DIRECTV providing access to this software.                                   -
---------------------------------------------------------------------------------
use ${hiveconf:database};

--SET mapreduce.job.credentials.binary=${hiveconf:tokens};

-- Load raw data
DROP TABLE IF EXISTS ${hiveconf:rawDataTable};
CREATE EXTERNAL TABLE ${hiveconf:rawDataTable}
(
    rowkey string, 
    accountId string, 
    tmsId string,
    eventTime string,
    source string, 
    eventType string,
    sourceType string,
    startTime string,
    endTime string,
    channelId string, 
    cardId string, 
    durationViewed string, 
    profileId string, 
    deviceId string,
    deviceType string, 
    channelNumber string, 
    startTimeSchedule string, 
    endTimeSchedule string, 
    statusCdn string, 
    interpretedEventType string, 
    weight string, 
    addition string, 
    dayOfWeek string, 
    timeOfDay string, 
    mainCategory string,
    genre1 string,
    genre2 string, 
    genre3 string, 
    title string,
    programId string,
    rating string,
    releaseYear string, 
    originalAirDate string,
    runLength string,
    delivery string,
    actor1 string,
    actor2 string,
    actor3 string,
    actor4 string,
    actor5 string,
    director1 string, 
    director2 string,
    director3 string,
    duration string,
    zipcode string,
    fipCoutryCode string,
    dma string,
    newTimezone string, 
    channelType string, 
    channelObjectId string,
    marketId string,
    tone1 string,
    tone2 string,
    tone3 string,
    mood1 string,
    mood2 string,
    mood3 string,
    theme1 string,
    theme2 string,
    theme3 string,
    rottenTomato string, 
    critic1 string,
    critic2 string,
    critic3 string, 
    audienceScore string,
    utcInt string,
    dmaDescription string,
    ppvFilter string,
    seriesId string,
    programType string,
    TmsConnectorId string,
    DescriptionLanguage string,
    eventDate bigint,
    tmsGenre1 string,
    tmsGenre2 string,
    tmsGenre3 string,
    actorId1 string,
    actorId2 string,
    actorId3 string,
    actorId4 string,
    actorId5 string,
    directorId1 string,
    directorId2 string,
    directorId3 string
)
PARTITIONED BY (insertedTime string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
STORED AS TEXTFILE
LOCATION '${hiveconf:rawData}';

-- Load new data
DROP TABLE IF EXISTS newData;
CREATE EXTERNAL TABLE newData
(
    rowkey string, 
    accountId string, 
    tmsId string,
    eventTime string,
    source string, 
    eventType string,
    sourceType string,
    startTime string,
    endTime string,
    channelId string, 
    cardId string, 
    durationViewed string, 
    profileId string, 
    deviceId string,
    deviceType string, 
    channelNumber string, 
    startTimeSchedule string, 
    endTimeSchedule string, 
    statusCdn string, 
    interpretedEventType string, 
    weight string, 
    addition string, 
    dayOfWeek string, 
    timeOfDay string, 
    mainCategory string,
    genre1 string,
    genre2 string, 
    genre3 string, 
    title string,
    programId string,
    rating string,
    releaseYear string, 
    originalAirDate string,
    runLength string,
    delivery string,
    actor1 string,
    actor2 string,
    actor3 string,
    actor4 string,
    actor5 string,
    director1 string, 
    director2 string,
    director3 string,
    duration string,
    zipcode string,
    fipCoutryCode string,
    dma string,
    newTimezone string, 
    channelType string, 
    channelObjectId string,
    marketId string,
    tone1 string,
    tone2 string,
    tone3 string,
    mood1 string,
    mood2 string,
    mood3 string,
    theme1 string,
    theme2 string,
    theme3 string,
    rottenTomato string, 
    critic1 string,
    critic2 string,
    critic3 string, 
    audienceScore string,
    utcInt string,
    dmaDescription string,
    ppvFilter string,
    seriesId string,
    programType string,
    TmsConnectorId string,
    DescriptionLanguage string,
    eventDate bigint,
    tmsGenre1 string,
    tmsGenre2 string,
    tmsGenre3 string,
    actorId1 string,
    actorId2 string,
    actorId3 string,
    actorId4 string,
    actorId5 string,
    directorId1 string,
    directorId2 string,
    directorId3 string,
    insertedtime string
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
STORED AS TEXTFILE
LOCATION '${hiveconf:newData}';

SET hive.exec.max.dynamic.partitions.pernode=100000;
SET hive.exec.max.dynamic.partitions=100000;
SET hive.exec.dynamic.partition.mode=nonstrict;

-- Insert new data into the raw data folder
INSERT INTO TABLE ${hiveconf:rawDataTable} PARTITION (insertedTime) SELECT * FROM newData;

-- Load all partition in this folder to Hive table
MSCK REPAIR TABLE ${hiveconf:rawDataTable};

-- drop temporary table
DROP TABLE IF EXISTS newData;
