################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

workingDir="$(pwd)"

. $workingDir/common_properties.py
. $workingDir/generateRawData/rawdata_properties.py;

tokens=${HADOOP_TOKEN_FILE_LOCATION};
batchNumber=$1;
rawData=$postingRoot'prepareduvh/'
newData=$postingRoot'newuvh/'$batchNumber

echo "PATH OF RAW DATA: $rawData"
echo "PATH OF NEW DATA: $newData"
echo "RAW DATA TABLE: $rawDataTable"

if [[ -f action.xml ]];
then
	mkdir -p /tmp/pythoneggs
	export PYTHON_EGG_CACHE='/tmp/pythoneggs'
fi

if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi
# to improve the speed of querying we will partition data by inserted time
hive $hadoopTokenClause -hiveconf database=$database -hiveconf rawData=$rawData -hiveconf rawDataTable=$rawDataTable -hiveconf newData=$newData -f "$workingDir/generateRawData/generateRawData.sql"
status=$?
if [ $status -ne 0 ]; then
	echo "THERE IS A ERROR WHEN EXECUTING THE JOB TO PARTITION DATA"
	exit
fi;

# using impala 
$impalaCommand -q "invalidate metadata"
