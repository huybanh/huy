################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import sys
import os
import time
import subprocess
import imp
import datetime as dt
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

# load common properties file
from common_properties import *

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
rjhTable = None
lookupTableInstance = None

fileSystem = FileSystem.get(config)
location = os.getcwd()
utils = imp.load_source('dataIngestion', location + '/ingestionUtils/ingestionUtils.py')

# Load specific properties
specificProperties = imp.load_source('load properties file', location + '/streaming-ingestion/streaming_properties.py')
landingZone = specificProperties.landingZone
cleansingConfig = specificProperties.cleansingConfig
source = specificProperties.source
originalFormat = specificProperties.originalFormat
zipCodeRoot = postingRoot + 'accountId/'
# Config parameters here
dataType='streaming'
unprocessedFileKey='unprocessedStreamingFile'
zipCodeKey='accountIngestion'
targetFormat='yyyyMMddHHmmss'
incomingFolder='/incoming'
workingRoot = workingRoot + 'streaming/'
postingRoot = postingRoot + 'streaming/'
backupRoot = backupRoot + 'streaming/'

paramArray = [workingRoot, landingZone, postingRoot, backupRoot, zipCodeRoot, source, originalFormat,
              columnFamilyOfRJH, lookupFamilyName, lookupColumnQualifier, udfDataIngestion]

paramName = ['workingRoot', 'landingZone','postingRoot', 'backupRoot', 'zipCodeRoot', 'source', 'originalFormat',
             'columnFamilyOfRJH', 'lookupFamilyName', 'lookupColumnQualifier', 'udfDataIngestion']

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        print "================================================ THERE IS A ERROR WHEN CONNECTING TO HBASE TABLE: " + str(sys.exc_info()[1])
        os._exit(1)

def streamingStitching(batchNumber):
    print '===========================START STREAMING STITCHING============================='
    try:
        # get last batch of data location
        lastZipCodeBatch = utils.lookupString(zipCodeKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if not lastZipCodeBatch:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "stitching", 'There is no data location')
        
        
        params = {
        'incomingFolder':str(workingRoot) + str(batchNumber) + str(incomingFolder),
        'posting': str(postingRoot) + str(batchNumber),
        'originalFormat':originalFormat,
        'targetFormat':targetFormat,
        'source':source,
        'like':like,
        'purchase':purchase,
        'watch':watch,
        'record':record,
        'zipCodeRoot':zipCodeRoot + lastZipCodeBatch,
        'udfDataIngestion':location + udfDataIngestion,
        'cleansingUdf':location + cleansingUdf,
        'cleansingConfig':cleansingConfig
        }
        print 'incomingFolder: ' + str(workingRoot) + str(batchNumber) + str(incomingFolder)
        print 'postingFoler: ' + str(postingRoot) + str(batchNumber)
        print 'accountData: ' + zipCodeRoot + lastZipCodeBatch
        
        # CR-4194
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, zipCodeRoot + str(lastZipCodeBatch))
        utils.process2(location + '/streaming-ingestion/stitchStreaming.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'stitching', batchNumber, "newStreamingData", "finalStreamingData")
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))

def main():
    try:
        connectToHbase()
        numberParam = len(sys.argv)
        if numberParam == 2:
            batchNumber = str(sys.argv[1])
            try:
                print '===================== LOCATION : ' + location
                
                # validate if the parameters is empty or not?
                utils.validateParameters(rjhTable, columnFamilyOfRJH, batchNumber, dataType, paramArray, paramName)
                
                # validate if the folders exist or not?
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, landingZone)
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, zipCodeRoot)
                
                oldLastModificationTime = utils.lookupString(unprocessedFileKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
                modificationTime = 0l
                if oldLastModificationTime:
                    modificationTime = long(oldLastModificationTime)
                pathOfIncomingFolder = str(workingRoot) + str(batchNumber) + str(incomingFolder)
                newLastModificationTime = utils.copyFileFromLandingzoneToIncomingFolder(fileSystem, landingZone, pathOfIncomingFolder, modificationTime)
                
                if long(newLastModificationTime) > 0:
                    
                    # stitching streaming data
                    streamingStitching(batchNumber)
                    
                    # check if the posting folder exists or not
                    utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, postingRoot + batchNumber)
                    
                    # store batchNumber, modificationTime to Hbase table
                    pathOfArchiveFolder = str(backupRoot) + str(batchNumber)
                    paramStoreData = [dataType, lookupFamilyName, lookupColumnQualifier, batchNumber, unprocessedFileKey, str(newLastModificationTime), pathOfArchiveFolder, pathOfIncomingFolder + "/*"]
                    utils.storeData(lookupTableInstance, paramStoreData)
                    # print status to console:
                    utils.printStatusToConsole(rjhTable, batchNumber, columnFamilyOfRJH, dataType)
                    
                else:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "error", "No new Files are in the folder \"Landingzone\"")
            except:
                try:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))
                except:
                    print 'The issue comes from calling os._exit(1)'
        else:
            try:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "error", 'Not enough parameter')
            except:
                print 'The issue comes from calling os._exit(1)'
    except:
        print 'There are some problems when connecting hbase tables'

if __name__ == '__main__':
    main()
