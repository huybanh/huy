USE ${hiveconf:database};

-- import transform function
ADD FILE ./encrypted_md5.py;

-- create temp table to transform accountid to encryptedid
DROP TABLE IF EXISTS tmp_table;
CREATE EXTERNAL TABLE tmp_table (accountid string, encryptedid string, dma string, dmadescription string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;';

--SELECT accountid, dma, zipcode, dmadescription FROM ${hiveconf:uvh_table} WHERE insertedtime=${hiveconf:insertedtime} and accountId <> 'INVALID CUST ACCT NUMBER' and dma is NOT NULL and dma <> '' and dma <> 'NULL' LIMIT 10;

-- insert data into temp table from raw data
INSERT OVERWRITE TABLE tmp_table 
SELECT TRANSFORM(accountid, dma, dmadescription)
USING 'encrypted_md5.py' AS accountid, encryptedid, dma, dmadescription
FROM ${hiveconf:uvh_table}
WHERE insertedtime=${hiveconf:insertedtime} and accountid <> 'INVALID CUST ACCT NUMBER' and dma is NOT NULL and dma <> '' and dma <> 'NULL';

-- create user table
DROP TABLE IF EXISTS ${hiveconf:user_table};
CREATE EXTERNAL TABLE ${hiveconf:user_table} (accountid string, encryptedid string, dma string, dmadescription string)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
STORED AS TEXTFILE LOCATION '${hiveconf:location}';

-- insert data into user table
INSERT INTO TABLE ${hiveconf:user_table} 
	SELECT distinct accountid, encryptedid, dma, dmadescription FROM tmp_table;
