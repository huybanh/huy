USE ${hiveconf:database};

-- hbase to hive
--DROP TABLE if EXISTS accountidToEncryptedid_hbase2;
create external table if not exists accountidtoencryptedid_hbase(accountid string, encryptedid string)
stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
with serdeproperties ("hbase.columns.mapping" = ":key, m:encryptedId")
tblproperties ("hbase.table.name" = 'demo_5_2014_accountidtoencryptedidmapping');

--DROP TABLE if EXISTS encryptedidToAccountid_hbase2;
create external table if not exists encryptedidToAccountid_hbase(encryptedid string, accountid string)
stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
with serdeproperties ("hbase.columns.mapping" = ":key, m:accountId")
tblproperties ("hbase.table.name" = 'demo_5_2014_encryptedidtoaccountidmapping');

drop table if exists encryptedidtodma_hbase;
create external table if not exists encryptedidtodma_hbase(encryptedid string, dma string, dmadescription string)
stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
with serdeproperties ("hbase.columns.mapping" = ":key, cf1:dma, cf1:dmadescription")
tblproperties ("hbase.table.name" = 'demo_5_2014_listactiveuser1');

INSERT OVERWRITE TABLE encryptedidtodma_hbase SELECT encryptedid, dma, dmadescription FROM ${hiveconf:user_table};

INSERT OVERWRITE TABLE accountidToEncryptedid_hbase SELECT accountid, encryptedid FROM ${hiveconf:user_table};

INSERT OVERWRITE TABLE encryptedidToAccountid_hbase SELECT encryptedid, accountid FROM ${hiveconf:user_table};
