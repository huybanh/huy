#!/usr/bin/env python

import hashlib
import sys

for line in sys.stdin:
 line = line.strip()
 array = line.split('\t')
 num_items = len(array)
 if num_items == 3:
  accountid=array[0]
  m = hashlib.md5()
  m.update(accountid)
  dma=array[1]
  dmadescription=array[2]
  print '%s\t%s\t%s\t%s' % (accountid, m.hexdigest(), dma, dmadescription)