. ./conf.properties
hive -hiveconf database=$database -hiveconf user_table=$user_table -hiveconf uvh_table=$uvh_table -hiveconf location=$location -hiveconf insertedtime=$1 -f "generate_user_table.sql"
#hive -hiveconf database=$database -hiveconf user_table=$user_table -f "update_hbase.sql"

status=$?
if [ $status -eq 0 ]; then
    echo "SUCCEED"
    impala-shell -i hdpdn-dv-msdc01.ds.dtveng.net -q "invalidate metadata;"
else
    echo "FAILED"
fi

#if [ "$update_hbase" == "yes" ]; then
 #  echo "Update related hbase table!"
 # #hive -f "update_hbase.sql"
#fi

