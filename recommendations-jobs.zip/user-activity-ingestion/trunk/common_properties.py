################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

################################ COMMON FIELDS OF USER-ACTIVITY-INGESTION AND GUIDE-DATA-INGESTION ##########################
hbase_zookeeper_quorum='hdpnn-h4-awsw01.ds.dtveng.net,hdpnn-h4-awsw03.ds.dtveng.net,hdpnn-h4-awsw02.ds.dtveng.net'
hbase_zookeeper_clientPort='2181'

# Root of working folders
workingRoot='/data/dv/recommendation/staging/'

# Two tables in Hbase
recommendationJobHistory='dev_recommendationsjobhistory'
columnFamilyOfRJH='rjh'

lookupTable='dev_lookuptable'
lookupFamilyName='cf'
lookupColumnQualifier='batch'

############################## SPECIFIC FIELDS OF USER-ACTIVITY-INGESTION ###########################
# postingRoot is a location where we are using to the final results once user-activity-script finish
postingRoot='/data/dv/recommendation/processed/'
errorRoot='/data/dv/recommendation/error/'

# backupRoot is a location where we are using to store raw data (ams, ppv, streaming, social, remote, cdn)
backupRoot='/data/dv/recommendation/archive/'

# when processing data we will use some functions in the following lib to convert date, stitch data ....
udfDataIngestion='/ingestionUtils/udf-data-ingestion-0.2.3.jar'
# consist lib in account ingestion with UDS
commonUDSDataIngestion='/ingestionUtils/recommendations-commons-0.1.13.jar'
# cleansing udf. Using to clean up TMSID with invalid format
cleansingUdf='/ingestionUtils/recommendations-udf-cleansing-0.0.1.jar'

like='["FBL_PD_TVS","FAV_PD_MV","FAV_PD_TV","FAV_SO_TVS","FB_PD_TV","FBL_CD_CH","FBL_CL_CL","FBL_CW_MV","FBL_CW_TV","FBL_NA_NA","FBL_PD_","FBL_PD_MV","FBL_PD_NA","FBL_PD_TV","FBL_RS_MV","FBL_SO_TVS","FBL_VP_MV","FBL_VP_TV"]'
purchase='["PCH","Purchase"]'
watch='["LiveViewEvent","PlaybackEvent","L","P","LIVE TV","EPISODE","OTHERS","MOVIE","TRAILER","NON-LINEAR TV"]'
record='["R","RecordingEvent"]'

############################## SPECIFIC FIELDS OF GUIDE-DATA-INGESTION ############################## 
# landingzone is area we using to store data of guide data when we run job processing dls file in order to extract information
landingZone='/data/dv/recommendation/landingzone/guidedata/'

# The master root folder
masterRoot='/data/dv/recommendation/processed/guidedata/'

# setting num day to get data
numDate='90'
