################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import os
import sys
import time
import imp
import subprocess
import datetime as dt
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

# load common properties file
from common_properties import *

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
rjhTable = None
lookupTableInstance = None

fileSystem = FileSystem.get(config);
location = os.getcwd()
utils = imp.load_source('dataIngestion', location + '/ingestionUtils/ingestionUtils.py')

specificProperties = imp.load_source('load properties file', location + '/account-ingestion/account_properties.py')
AccountdbLookup = specificProperties.AccountdbLookup
zipCodeTable = specificProperties.zipCodeTable
accountTable = specificProperties.accountTable
columnZipCode = specificProperties.columnZipCode
columnAccount = specificProperties.columnAccount
dataType='accountIngestion'
incomingFolder='/incoming'
postingRoot = postingRoot + 'accountId/'
backupRoot = backupRoot + 'accountId/'
workingRoot = workingRoot + 'accountId/'
unprocessedFileKey='unprocessedAccountFile'

paramArray = [workingRoot, postingRoot, backupRoot, columnFamilyOfRJH];

paramName = ['workingRoot', 'postingRoot', 'backupRoot','columnFamilyOfRJH'];

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        os._exit(1)

def accountIdStitching(batchNumber):
    print '===========================STITCHING============================='
    try:
        params = {
        'incomingFolder':str(workingRoot) + str(batchNumber) + str(incomingFolder),
        'posting': str(postingRoot) + str(batchNumber),
        'udfDataIngestion':location + udfDataIngestion,
        'commonUDSDataIngestion': location + commonUDSDataIngestion,
        'zipCodeTable':zipCodeTable,
        'accountTable':accountTable,
        'columnZipCode':columnZipCode,
        'columnAccount':columnAccount
        };
        utils.process2(location + '/account-ingestion/stitchAccountId.pig', params, rjhTable, columnFamilyOfRJH, dataType, 'stitching', batchNumber, 'newAccountData', 'finalAccountData')
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))

def getLocation(path):
    listAll = subprocess.Popen(["hadoop", "fs", "-cat", str(path)], stdout=subprocess.PIPE)
    listPath = listAll.stdout
    for line in listPath:
        location = line.split('|')
        return location[0]

def main():
    try:
        connectToHbase()
        numberParam = len(sys.argv);
        if numberParam == 2:
            batchNumber = str(sys.argv[1]);
            try:
                # validate if the parameters is empty or not?
                utils.validateParameters(rjhTable, columnFamilyOfRJH, batchNumber, dataType, paramArray, paramName);
                # get location account data:      
                rawData = getLocation(AccountdbLookup)
                fileStatus = fileSystem.getFileStatus(Path(AccountdbLookup))
                newLastModificationTime = fileStatus.getModificationTime()
                oldLastModificationTime = utils.lookupString(unprocessedFileKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
                modificationTime = 0l
                if oldLastModificationTime:
                    modificationTime = long(oldLastModificationTime)
                if newLastModificationTime <= modificationTime:
                    print "No new data"
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "error", "No new data")
                
                # validate if the folders exist or not?
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, rawData);
                # copy data to workingRoot
                print 'Waiting for coping raw data to process.....'
                subprocess.call('hadoop fs -mkdir ' + str(workingRoot) + str(batchNumber) + str(incomingFolder), shell=True)
                subprocess.call('hadoop fs -cp ' + str(rawData) + '/* ' + str(workingRoot) + str(batchNumber) + str(incomingFolder), shell=True)
                # stitching accountId data
                accountIdStitching(batchNumber);
                    
                # check if the posting folder exists or not
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, postingRoot + batchNumber)
                    
                # store batchNumber to Hbase table
                utils.insertDataToHbase(lookupTableInstance, lookupFamilyName, lookupColumnQualifier, unprocessedFileKey, newLastModificationTime)
                utils.insertDataToHbase(lookupTableInstance, lookupFamilyName, lookupColumnQualifier, dataType, batchNumber)
                # print status to console:
                utils.printStatusToConsole(rjhTable, batchNumber, columnFamilyOfRJH, dataType)

            except:
                try:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]));
                except:
                    print 'The issue comes from calling os.exit(1)'
        else:
            try:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "error", 'Not enough parameter');
            except:
                print 'The issue comes from calling os._exit(1)'
    except:
        print 'There are some problems when connecting hbase tables'

if __name__ == '__main__':
    main();
