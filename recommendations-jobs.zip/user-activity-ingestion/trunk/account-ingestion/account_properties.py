################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

# This file contains location where we can use to get data
AccountdbLookup='/data/dv/ref/up/Accountdb_Lookup/tablename=Account/000000_0'

# After ingesting we have to push all data to hbase table
# Name of table in Hbase
zipCodeTable='production_location'
accountTable='production_AccountToDMA'
# Name of column family in Hbase tabe
columnZipCode='loc'
columnAccount='account'

