################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import sys
import os
import time
import subprocess
import imp
import datetime as dt
from datetime import datetime
from org.apache.hadoop.fs import *
from java.util import UUID
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
from org.apache.pig.scripting import Pig
from org.apache.pig.backend.executionengine import *
from itertools import count

# Load common properties file
from common_properties import *

config = HBaseConfiguration.create()
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)

rjhTable = None
lookupTableInstance = None

fileSystem = FileSystem.get(config)
location = os.getcwd()
utils = imp.load_source('dataIngestion', location + '/ingestionUtils/ingestionUtils.py')

# Load specific properties
specificProperties = imp.load_source('load properties file', location + '/ams-ingestion/ams_properties.py')
landingZone = None
demoAMS = specificProperties.demoAMS
delimiter = specificProperties.delimiter
channelObjecMappingKey = specificProperties.channelObjecMappingKey
source = specificProperties.source
originalFormat = specificProperties.originalFormat
database = specificProperties.database
deviceType = specificProperties.deviceType

program = masterRoot + 'programs/'
schedule = masterRoot + 'schedules/'
zipCodeRoot = postingRoot + 'accountId/'
zipCodeKey = 'accountIngestion'
currentLocation = 'currentLocation'

# config parameters here
incomingFolder = '/incoming'
filteredFolder = '/filtered'
stitchingFolder = '/stitching'
dataType='ams'
programKey='program'
scheduleKey='schedule'
unprocessedFileKey='unprocessedAmsFile'
targetFormat='yyyyMMddHHmmss'
workingRoot = workingRoot + 'ams/'
channelRoot = postingRoot + 'ChannelObjectMapping/'
postingRoot = postingRoot + 'ams/'
backupRoot = backupRoot + 'ams/'
errorRoot = errorRoot + 'ams/'

paramArray = [workingRoot, postingRoot, backupRoot, columnFamilyOfRJH, source, originalFormat, masterRoot,
              lookupFamilyName, lookupColumnQualifier, udfDataIngestion, channelObjecMappingKey, program, schedule, database]

paramName = ['workingRoot', 'postingRoot', 'backupRoot', 'columnFamilyOfRJH', 'source', 'originalFormat', 'masterRoot',
             'lookupFamilyName', 'lookupColumnQualifier', 'udfDataIngestion', 'channelObjecMappingKey', 'program', 'schedule', 'database']

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        os._exit(1)

def stitchingAMS(batchNumber):
    print '===========================START OF STITCHING============================='
    try:
        lastBatchNumberOfProgram = utils.lookupString(programKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if not lastBatchNumberOfProgram:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "stitching", 'data of program does not exist')
        # CR-4194
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(masterRoot) +'programs/' + str(lastBatchNumberOfProgram))
        
        lastBatchNumberOfSchedule = utils.lookupString(scheduleKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if not lastBatchNumberOfSchedule:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "stitching", 'data of schedule does not exist')
            
        # CR-4194
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(masterRoot) +'schedules/' + str(lastBatchNumberOfSchedule))
        
        # from here we have to call hive script to stitch ams data
        subprocess.call(location + '/ams-ingestion/stitchingAms.sh ' + ' ' + batchNumber + ' ' + lastBatchNumberOfProgram + ' ' + lastBatchNumberOfSchedule, shell=True)
        print '===========================END OF STITCHING============================='
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))

def ingestDataLocation(batchNumber):
    print '=========================== INGEST DATA LOCATION ==========================='
    try:
        lastZipCodeBatch = utils.lookupString(zipCodeKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if not lastZipCodeBatch:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "stitching", 'No zipcode to ingest')
        # CR-4194
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, zipCodeRoot + str(lastZipCodeBatch))
        
        params = {
        'zipCodeRoot':str(zipCodeRoot) + str(lastZipCodeBatch),
        'stitchingFolder':workingRoot + batchNumber + stitchingFolder,
        'source':source,
        'deviceType':deviceType,
        'like':like,
        'purchase':purchase,
        'watch':watch,
        'record':record,
        'udfDataIngestion':location + udfDataIngestion,
        'postingRoot': postingRoot + batchNumber
        }
        utils.process2(location + "/ams-ingestion/ingestDataLocation.pig", params, rjhTable, columnFamilyOfRJH, dataType, "ingestDataLocation", batchNumber, "finalAmsData", "finalAmsData")
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))

def filteringAMS(batchNumber):
    print '===========================START OF FILTERING============================='
    try:
        lastChannelObjectMappingBatch = utils.lookupString(channelObjecMappingKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
        if not lastChannelObjectMappingBatch:
            utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "filtering", 'No channelObjectmapping to ingest')
        print "the location of channelobjectmapping: " + str(channelRoot) + str(lastChannelObjectMappingBatch)
        params = {
        'delimiter':delimiter,
        'incomingFolder':str(workingRoot) + str(batchNumber) + str(incomingFolder),
        'filteredFolder':str(workingRoot) + str(batchNumber) + str(filteredFolder),
        'errorRoot':str(errorRoot) + str(batchNumber) + '/',
        'landingZone':str(landingZone) + '*',
        'originalFormat':originalFormat,
        'targetFormat':targetFormat,
        'channelobjecttochannelid': str(channelRoot) + str(lastChannelObjectMappingBatch),
        'udfDataIngestion':location + udfDataIngestion
        }
        # CR-4194
        utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(channelRoot) + str(lastChannelObjectMappingBatch))
        # Note: "amsData" and "finalFilterAmsData" are alias when loading data from HDFS
        # With these alias we will ignore the process of counting by using Pig query, So we can reduce the processing time
        utils.process2(location + "/ams-ingestion/filteringAMS.pig", params, rjhTable, columnFamilyOfRJH, dataType, "filtering", batchNumber, "amsData", "finalFilterAmsData")
        print '===========================END OF FILTERING============================='
    except:
        utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))

def setLandingZone():
    if demoAMS == 'false':
        global landingZone
        landingZone = specificProperties.oldLandingZone
    else:
        global landingZone
        landingZone = specificProperties.newLandingZone

def main():
    try:
        connectToHbase()
        numberParam = len(sys.argv)
        if numberParam == 2:
            batchNumber = str(sys.argv[1])
            try:
                setLandingZone()
                print 'WE ARE LOADING DATA FROM LANDING ZONE: ' + landingZone
                # Validate if the parameters is empty or not?
                utils.validateParameters(rjhTable, columnFamilyOfRJH, batchNumber, dataType, paramArray, paramName)
                
                # Validate if the folders exist or not?
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, landingZone)
                
                # before stitching data we have to detect which files are not processed
                # If exist, we will copy data from landingzone to incoming folder
                oldLastModificationTime = utils.lookupString(unprocessedFileKey, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
                modificationTime = 0l
                if oldLastModificationTime != '':
                    modificationTime = long(oldLastModificationTime)
                pathOfIncomingFolder = str(workingRoot) + str(batchNumber) + str(incomingFolder)
                
                newLastModificationTime = ''
                newSubFolder = ''
                if demoAMS == 'false':
                    newLastModificationTime = utils.copyFileFromLandingzoneToIncomingFolder(fileSystem, landingZone, pathOfIncomingFolder, modificationTime)
                else:
                    currentFolder = utils.lookupString(currentLocation, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
                    newLastModificationTime,newSubFolder = utils.copyFileToImcomingFolder(fileSystem, landingZone, currentFolder, pathOfIncomingFolder, modificationTime)

                print '====================== newLastModificationTime = ' + str(newLastModificationTime)
                print '====================== newSubFolder = ' + str(newSubFolder)
                
                if long(newLastModificationTime) > 0:
                    print "====================================================================================================================================="
                    # Run Pig script to filter data based on event type.
                    filteringAMS(batchNumber)
                
                    # Check if the folder "filtered" has created or not?
                    utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(workingRoot) + str(batchNumber) + str(filteredFolder))
                
                    # Combinate with guide data by minutes to get tms ID (see more at wiki)
                    stitchingAMS(batchNumber)
                
                    # check if the stitching folder exists or not
                    utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(workingRoot) + str(batchNumber) + str(stitchingFolder))
                    
                    ingestDataLocation(batchNumber)
                    # check if the posting folder exists or not
                    utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, postingRoot + batchNumber)
                    
                    # store batch number, modification time and move raw data to archive folder
                    pathOfArchiveFolder = str(backupRoot) + str(batchNumber)
                    paramStoreData = [dataType, lookupFamilyName, lookupColumnQualifier, batchNumber, unprocessedFileKey, str(newLastModificationTime), pathOfArchiveFolder, pathOfIncomingFolder + "/*"]
                    utils.storeData(lookupTableInstance, paramStoreData)
                    if demoAMS == 'true':
                        paramStoreData = [currentLocation, lookupFamilyName, lookupColumnQualifier, newSubFolder]
                        utils.storeOneValue(lookupTableInstance, paramStoreData)
                    # print status to console:
                    utils.printStatusToConsole(rjhTable, batchNumber, columnFamilyOfRJH, dataType)
                   
                else:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "error", "No new Files are in the folder \"Landingzone\"")
            except:
                try:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, "exception", str(sys.exc_info()[1]))
                except:
                    print 'The issue comes from calling os._exit(1)'
        else:
            try:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "error", 'Not enough parameter')
            except:
                print 'The issue comes from calling os._exit(1)'
    except:
        print 'There are some problems when connecting hbase tables'

if __name__ == '__main__':
    main()
