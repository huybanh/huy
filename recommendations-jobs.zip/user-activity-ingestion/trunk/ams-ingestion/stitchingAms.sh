################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

pwd="$(pwd)"
# ADD COMMON PROPERTIES FILE
. $pwd/common_properties.py
# ADD SPECIFIC PROPERTIES FILE
. $pwd/ams-ingestion/ams_properties.py

# add this code to prevent the Kerberos issue or connect to Hbase table when deploying on AWS env.
if [[ -f action.xml ]];
then
kinit -kt svc.cloudrec.dv2.keytab svc.cloudrec.dv2@DS.DTVENG.NET
export HBASE_CONF_DIR=.
fi


if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

echo -e "Hbase Quorum: $hbase_zookeeper_quorum"
echo -e "Hbase port: $hbase_zookeeper_clientPort"
echo -e "Hbase table: $recommendationJobHistory"
echo -e "Column family: $columnFamilyOfRJH"
echo -e "MasterRoot: $masterRoot"
echo -e "workingRoot: $workingRoot"
echo -e "udfDataIngestion: $udfDataIngestion"
echo -e "database: $database"

batchNumber=$1;
lastBatchNumberOfProgram=$2
lastBatchNumberOfSchedule=$3
workingRoot=$workingRoot"ams/"

programPath="$masterRoot""programs/""$lastBatchNumberOfProgram"
schedulePath="$masterRoot""schedules/""$lastBatchNumberOfSchedule"
filteredPath="$workingRoot""$batchNumber""/filtered"
stitchedPath="$workingRoot""$batchNumber""/stitching"
lib=$pwd$udfDataIngestion
script="$pwd/ams-ingestion/stitchingAMS.sql"

echo -e "PATH OF FILTERED FOLDER: $filteredPath";
echo -e "PATH OF PROGRAM FOLDER: $programPath";
echo -e "PATH OF SCHEDULE FOLDER: $schedulePath";
echo -e "PATH OF STITCHING FOLDER: $stitchedPath";
echo -e "PATH OF THE SCRIPT: $script";
echo -e "PATH OF UDF HIVE: $lib";

startTime=$(date +"%Y-%m-%d %H:%M:%S");
message="[SUCCEED]"
 
hive $hadoopTokenClause -hiveconf database=$database -hiveconf program=$programPath -hiveconf schedule=$schedulePath -hiveconf filteredAmsData=$filteredPath -hiveconf stitching=$stitchedPath -hiveconf lib=$lib -f $script;
status=$?
if [ $status -ne 0 ]; then
	echo "THERE IS A ERROR WHEN EXECUTING HIVE SCRIPT. PLEASE SEE THE LOGS ON THE SCREEN"
	exit
fi;
endTime=$(date +"%Y-%m-%d %H:%M:%S")
echo "$batchNumber"
echo "$startTime"
echo "$programPath"
echo "$schedulePath"
echo "$message"
echo "$endTime"

# UPDATE STATUS TO HBASE TABLE USING PYTHON INSTEAD OF THE 'PUT' COMMAND OF HBASE
pig $pwd/ams-ingestion/pushDataToHbase.py "$batchNumber" "$startTime" "$programPath" "$schedulePath" "$message" "$endTime"

