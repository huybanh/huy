
--DATABASE NAME
USE ${hiveconf:database};

-- ADD UDF HIVE
ADD JAR ${hiveconf:lib};

-- CREATE FUNCTION
CREATE TEMPORARY function processAms AS 'com.directv.hive.stitchingAms.StitchingAms';

-- INITIALIZING HIVE TABLES
-- FIXED TABLES

DROP TABLE IF EXISTS ams_program;
CREATE EXTERNAL TABLE ams_program 
(
  mainCategory string,
  genre1 string,
  genre2 string,
  genre3 string,
  title string,
  programId string,
  rating string,
  releaseYear int,
  originalOnAirDate string,
  runLength int,
  tmsId string,
  otherColumn string
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
STORED AS TEXTFILE
LOCATION '${hiveconf:program}';

DROP TABLE IF EXISTS ams_schedule;
CREATE EXTERNAL TABLE ams_schedule
(
  scheduleId string,
  scheduleStartTime bigint,
  partitionedDate int,
  duration int,
  scheduleEndTime bigint,
  programId string,
  channelId int,
  otherColumn string
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
LOCATION '${hiveconf:schedule}';

-- eventType: LiveViewEvent, PlaybackEvent, RecordingEvent ...
-- sourceType: Playback, Recording, ReviewBufferPlayback, ReviewBufferRecording
DROP TABLE IF EXISTS ams_filteredData;
CREATE EXTERNAL TABLE ams_filteredData
(
  accountId string,
  cardId string,
  channelId int,
  eventType string,
  sourceType string,
  eventTime string,
  userStartTime bigint,
  userEndTime bigint,
  dma string,
  zip string,
  partitionedDate int
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
LOCATION '${hiveconf:filteredAmsData}';

-- TEMPORARY TABLES
DROP TABLE IF EXISTS ams_stitchingData;
CREATE EXTERNAL TABLE ams_stitchingData
(
  rowkey string, 
  accountId string, 
  cardId string, 
  channelId int, 
  scheduleStartTime string,
  scheduleEndTime string,
  scheduleDuration string,
  programId string,
  tmsId string, 
  sourceType string, 
  eventTime string,
  eventType string,
  userStartTime bigint, 
  userEndTime bigint, 
  viewedDuration int,
  dma string,
  zip string
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\;'
LOCATION '${hiveconf:stitching}';

-- STARTTIME IS THE WHEN A SCHEDULE START UP
-- ENDTIME IS THE WHEN A SCHEDULE FINISH
-- userStartTime IS THE WHEN USER STARTED WATCHING A PROGRAM
-- userEndTime IS THE WHEN USER ENDED WATCHING A PROGRAM
INSERT OVERWRITE TABLE ams_stitchingData
SELECT
	concat_ws('-', cast(table2.accountId as string), table2.eventTime, table2.tmsId) AS rowKey,
	table2.accountId,
	table2.cardId,
	table2.channelId,
	table2.scheduleStartTime,
	table2.scheduleEndTime,
	table2.scheduleDuration,
	table2.programId,
	table2.tmsId,
	table2.sourceType,
	table2.eventTime,
	table2.eventType,
	table2.userStartTime,
	table2.userEndTime,
	table2.viewedDuration,
	table2.dma,
	table2.zip
FROM
(
	SELECT	filteredAms.accountId, 
			filteredAms.cardId, 
			filteredAms.channelId,
			table1.scheduleStartTime,
			table1.scheduleEndTime,
			table1.scheduleDuration,
			table1.programId AS programId,
			table1.tmsId,
			filteredAms.sourceType,
			IF(filteredAms.eventType == 'LiveViewEvent', IF(filteredAms.userStartTime >= table1.scheduleStartTime, filteredAms.userStartTime, table1.scheduleStartTime), filteredAms.eventTime) AS eventTime,
			filteredAms.eventType,
			IF(filteredAms.userStartTime >= table1.scheduleStartTime, filteredAms.userStartTime, table1.scheduleStartTime) AS userStartTime,
			IF(filteredAms.userEndTime >= table1.scheduleEndTime, table1.scheduleEndTime, filteredAms.userEndTime) AS userEndTime,
			processAms(filteredAms.userStartTime, filteredAms.userEndTime, table1.scheduleStartTime, table1.scheduleEndTime, 'yyyyMMddHHmmss') AS viewedDuration,
			filteredAms.dma AS dma,
			filteredAms.zip AS zip
	FROM
	(
		SELECT  channelId, tmsId, ams_schedule.scheduleStartTime AS scheduleStartTime, 
				ams_schedule.scheduleEndTime AS scheduleEndTime, ams_schedule.programId AS programId, 
				ams_schedule.partitionedDate AS partitionedDate, ams_schedule.duration AS scheduleDuration
		FROM ams_program JOIN ams_schedule ON ams_program.programId = ams_schedule.programId
		--WHERE tmsId IS NOT NULL AND tmsID != 'null' AND tmsId != ''
	) table1 JOIN ams_filteredData filteredAms ON (table1.channelId = filteredAms.channelId AND table1.partitionedDate = filteredAms.partitionedDate)
	WHERE filteredAms.userEndTime > table1.scheduleStartTime AND table1.scheduleEndTime > filteredAms.userStartTime
) table2;

-- drop all temporary tables
DROP TABLE IF EXISTS ams_program;
DROP TABLE IF EXISTS ams_schedule;
DROP TABLE IF EXISTS ams_filteredData;
DROP TABLE IF EXISTS ams_stitchingData;
