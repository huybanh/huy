################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

#!/usr/bin/python

import sys
import os
import imp
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *

location = os.getcwd()
# Load common properties file
commonProperties = imp.load_source('load common properties file', location + '/common_properties.py')

def main():
    print 'location: ' + str(location)
    print 'you are calling to Py function to push data to Hbase table'
    hbase_zookeeper_quorum = commonProperties.hbase_zookeeper_quorum
    hbase_zookeeper_clientPort = commonProperties.hbase_zookeeper_clientPort
    recommendationJobHistory = commonProperties.recommendationJobHistory
    columnFamilyOfRJH = commonProperties.columnFamilyOfRJH
    
    batchNumber = str(sys.argv[1])
    startTime = str(sys.argv[2])
    lastbatchOfProgram = str(sys.argv[3])
    lastbatchOfSchedule = str(sys.argv[4])
    message = str(sys.argv[5])
    endtime = str(sys.argv[6])
    
    # set Hbase quorum and port
    config = HBaseConfiguration.create()
    config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
    config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)
    rjhTable = HTable(config, recommendationJobHistory)
    
    # initialize rowkey, family and qualifier columns
    putList = []
    put = Put(Bytes.toBytes(batchNumber))
    put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes('ams_stitching_starttime'), Bytes.toBytes(startTime))
    putList.append(put)
    
    put = Put(Bytes.toBytes(batchNumber))
    put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes('ams_stitching_lastbatch_program'), Bytes.toBytes(lastbatchOfProgram))
    putList.append(put)
    
    put = Put(Bytes.toBytes(batchNumber))
    put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes('ams_stitching_lastbatch_schedule'), Bytes.toBytes(lastbatchOfSchedule))
    putList.append(put)
    
    put = Put(Bytes.toBytes(batchNumber))
    put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes('ams_stitching_message'), Bytes.toBytes(message))
    putList.append(put)
    
    put = Put(Bytes.toBytes(batchNumber))
    put.add(Bytes.toBytes(columnFamilyOfRJH), Bytes.toBytes('ams_stitching_endtime'), Bytes.toBytes(endtime))
    putList.append(put)
    
    # push data to hbase table
    rjhTable.put(putList)
    
    print 'UPDATED SUCCESSFULLY'

if __name__ == '__main__':
    main()
