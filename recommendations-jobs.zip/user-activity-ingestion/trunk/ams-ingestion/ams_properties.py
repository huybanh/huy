################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

# Description:
# landingZone: is location where we are using to store ams raw data.
# zipUTC: is a file containing the mapping of zipcode and utc-offset
# zipDMA: is a file containing the mapping of zipcode and dma description.
# channelobjecttochannelid: is location where we are using to store the mapping between object channel and channel id.
# source: is 1 it mean if any row have source 1 then this row comes from ams data.
# originalFormat: is current date format of ams data.
# database: is database name in HIVE.
#
# HOW DOES THE SCRIPT KNOW THE LOCATION OF PROGRAM AND SCHEDULE
# The purpose of ams ingestion is get tmsId and calculate viewed duration for each row of ams data based on data of two tables "program" and "schedule"
# So we have to set path for the parameter "masterRoot"
# When we trigger the script it will automatically append two sub-folders "program/" and "schedule/" to "masterRoot" to create two absolute paths of both "program" and "schedule"
# Note: in these absolute paths we can have one or more sub-folders, but the script just load data from the latest folders
# e.g if "masterRoot" is "/data/dv/recommendation/processed/guidedata/" then absolute path of "program" is "/data/dv/recommendation/processed/guidedata/programs/" 
# and absolute of "schedule" is "/data/dv/recommendation/processed/guidedata/schedules/"

# For now, we have 2 locations to load data
# first location: all ams raw data will be stored into the same folder.
# second location: earch ams raw data will be stored into individual folder depend on when IT team collects them. all specific folders will be partitioned by year, month, day, hour.
# if demoAMS is true, ams-ingestion will load data from the new location
# otherwise will load data from the old one.

delimiter='|'
demoAMS='true'
# Paths on HDFS
newLandingZone='/data/ss/processed/ViewingHistory/cramsevents/'
oldLandingZone='/data/dv/processed/ViewingHistory/cramsevents/'
channelObjecMappingKey='ChannelObjectMapping'
source='AMS'
deviceType='STB'
originalFormat='yyyy-MM-dd HH:mm:ss'
database='cloudrec'
