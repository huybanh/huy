################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
#!/usr/bin/python

import sys
import os
import time
import imp
from org.apache.hadoop.fs import *
from org.apache.hadoop.conf import Configuration, Configured
from org.apache.hadoop.hbase import *
from org.apache.hadoop.hbase.client import *
from org.apache.hadoop.hbase.util import *
import subprocess
# Load properties file
from common_properties import *

config = HBaseConfiguration.create();
fileSystem = FileSystem.get(config);
config.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
config.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_clientPort)

lookupTableInstance = None
rjhTable = None

dataType='generateFilterData'
location = os.getcwd()
utils = imp.load_source('dataIngestion', location + '/ingestionUtils/ingestionUtils.py')

# Load specific properties
specificProperties = imp.load_source('load properties file', location + '/generateFilteredData/generatefilterdata_properties.py')
longDuration = int(specificProperties.longDuration)
shortDuration = int(specificProperties.shortDuration)

insertedTime = 'insertedTime'
path90Days = Path(postingRoot + '90daysfiltereduvh')
path7Days = Path(postingRoot + '7daysfiltereduvh')
stagingLocation = workingRoot + 'dayfilterduvh'

sevenDayData = postingRoot + '7daysfiltereduvh/insertedtime='
sevenDayDataParquet = postingRoot + '7daysfiltereduvh_parquet/'
sevenDayFilterUvh = postingRoot + '7daysfiltereduvh/'

def connectToHbase():
    print '================================================ START CONNECTING TO HBASE TABLE ==========================='
    try:
        if not recommendationJobHistory or not lookupTable:
            print '============================ NO TABLES IN HBASE ===================================================='
            os._exit(1)
        global rjhTable
        global lookupTableInstance
        rjhTable = HTable(config, recommendationJobHistory)
        lookupTableInstance = HTable(config, lookupTable)
        print '================================================ THE CONNECTION TO HBASE IS SUCCESSFUL ==========================='
    except:
        os._exit(1)

def deleteData(path, numberDay):
        if not fileSystem.exists(path):
                os._exit(1)
        if not fileSystem.isDirectory(path):
                os._exit(1)
    
        fileStatus = fileSystem.listStatus(path)
        if len(fileStatus) > numberDay:
                print "================= REMOVE DATA " + str(numberDay) + " DAYS :=================="
                listPath = list()
                # add path to list:
                for fullFile in fileStatus:
                        listPath.append(fullFile.getPath())
                # remove data:
                listPath.sort()
                for index in range(0, len(listPath) - numberDay):
                        print listPath[index]
                        subprocess.call('hadoop fs -rm -R ' + str(listPath[index]), shell=True)
                print "============= FINISH REMOVE DATA " + str(numberDay) + " DAYS ==============="
        else:
                print "=========== THERE IS NO REMOVED DATA " + str(numberDay) + " DAYS ==========="

def main():
    try:
        connectToHbase()
        numberParam = len(sys.argv)
        if numberParam == 2:
            batchNumber = str(sys.argv[1])
            try:
                print 'LOOKUP INSERTED TIME FROM HBASE TABLE'
                insertedTimeFolder = utils.lookupString(insertedTime, lookupTableInstance, lookupFamilyName, lookupColumnQualifier)
                if not insertedTimeFolder:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, batchNumber, dataType, 'insertedTime', 'There is no inserted time')
            
                # RUN JOB TO GENERATE DATA FOR 7 DAYS AND 90 DAYS
                print 'RUN JAR FILE TO GENERATE DATA FOR 7 DAYS AND 90 DAYS'
                # CR-4194
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, postingRoot+'prepareduvh/insertedtime='+insertedTimeFolder)
                subprocess.call(location + '/generateFilteredData/generateFilteredData.sh ' + insertedTimeFolder, shell=True)
                
                print 'JUST KEEP DATA IN 7 DAYS'
                deleteData(path7Days, shortDuration)

                print 'JUST KEEP DATA IN 90 DAYS'
                deleteData(path90Days, longDuration)
                
                print 'CHECK TO SEE IF WE HAVE NEW DATA'
                utils.validateHDFS(rjhTable, columnFamilyOfRJH, batchNumber, dataType, fileSystem, str(sevenDayData) + str(insertedTimeFolder))
                
                print 'AFTER GENERATING WE JUST KEEP DATA IN 7 DAYS'
              
                print 'GENERATE DATA IN PARQUET FORMAT'
                subprocess.call(location + '/generateFilteredData/convertParquetFormat.sh ' + sevenDayFilterUvh + ' ' + sevenDayDataParquet + ' ' + str(insertedTimeFolder) + ' ' + batchNumber, shell=True)
                
                print 'JUST KEEP DATA IN 7 DAYS PARQUET'
                deleteData(Path(sevenDayDataParquet), shortDuration)
        
                subprocess.call('hdfs dfs -rm -r ' + stagingLocation + '/' + insertedTimeFolder, shell=True)
                
                print 'JOB FINISHED'
            except:
                try:
                    utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "exception", str(sys.exc_info()[1]))
                except:
                    print 'The issue comes from calling os._exit(1)'
        else:
            try:
                utils.updateFailedJobs(rjhTable, columnFamilyOfRJH, '', dataType, "error", 'Not enough parameter')
            except:
                print 'The issue comes from calling os._exit(1)'
    except:
        print 'There are some problems when connecting hbase tables'

if __name__ == '__main__':
        main()
