################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

database='cloudrec'

# By default, the short duration has 7 days
shortDuration='7'
# By default, the long duration has 90 days
longDuration='90'

#jars
uvhStitchingJar='recommendations-uvh-stitching-0.0.1.jar'
genericFilterJar='recommendations-genericfilter-0.0.1.jar'

# The rate of viewedDuration and run length (0.3 -> 30%)
rate='0.3'

modulo='30'
impalaCommand='impala-shell -i hdpdn-h3-awsw01.ds.dtveng.net'
recommendationCommon='/ingestionUtils/recommendations-commons-0.1.13.jar'

# Raw Table
preparedUvhTable='preparedUvh'
# Hash Table for seven days data two level partition 
sevenDaysDataTwoLevelTable='sevenDaysDataTwoLevel'
# Prepare Table for 90 days
preparedLongDurationTable='preparedLongDuration'
# Prepare Table for 7 days
preparedShortDurationTable='preparedShortDuration'
