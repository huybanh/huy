################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################

workingDir="$(pwd)"
. $workingDir/common_properties.py
. $workingDir/generateFilteredData/generatefilterdata_properties.py

# Get inserted date
insertedDate=$1

echo "============================ insertedDate: $insertedDate"

stagingLocation=$workingRoot'dayfilterduvh'
preparedUvhLocation=$postingRoot'prepareduvh'
preparedLongDuration=$postingRoot'90daysfiltereduvh'
preparedShortDuration=$postingRoot'7daysfiltereduvh'

echo "GET TO PROCESS FROM: $preparedUvhLocation/insertedtime=$insertedDate"
echo 'PREPARE UVH TABLE: '$preparedUvhTable
echo 'PREPARE 90 DAYS TABLE: '$preparedLongDurationTable
echo 'PREPARE 7 DAYS TABLE: '$preparedShortDurationTable

#make the JAR available to the client JVM
export HADOOP_CLASSPATH=$HADOOP_CLASSPATH:$genericFilterJar

read -d '' stitchingFilteringCommand << EOF
hadoop jar $workingDir/generateFilteredData/$uvhStitchingJar
	com.directv.recommendations.analytics.stiching.StichingDriver 
	-libjars $workingDir/generateFilteredData/$genericFilterJar
	-IN $preparedUvhLocation/insertedtime=$insertedDate -OUT $stagingLocation/$insertedDate/uvhstitching/insertedtime=$insertedDate 
	-MINUTES 90 -PERCENT 30 $filterRules
EOF
$stitchingFilteringCommand

status=$?
if [ $status -ne 0 ]; then
	echo "THERE IS A ERROR WHEN EXECUTING THE JOB TO GENERATE DATA FOR 7DAYS AND 90DAYS DATA"
	exit
fi;

if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

hive $hadoopTokenClause -hiveconf database=$database -hiveconf preparedUvhTable=$preparedUvhTable -hiveconf preparedLongDurationTable=$preparedLongDurationTable -hiveconf preparedShortDurationTable=$preparedShortDurationTable -hiveconf stitchedFilteredLocation=$stagingLocation/$insertedDate/uvhstitching -hiveconf preparedLongDuration=$preparedLongDuration -hiveconf preparedShortDuration=$preparedShortDuration -hiveconf insertedDate=$insertedDate -f ${workingDir}/generateFilteredData/createPartitionTables.sql;
status=$?
if [ $status -ne 0 ]; then
	echo "THERE IS A ERROR WHEN EXECUTING THE JOB TO CREATE TWO TABLES IN HIVE"
	exit
fi;

echo "============================ Started inserting data ...";
hive $hadoopTokenClause -hiveconf database=$database -hiveconf preparedUvhTable=$preparedUvhTable -hiveconf preparedLongDurationTable=$preparedLongDurationTable -hiveconf preparedShortDurationTable=$preparedShortDurationTable -hiveconf rate=$rate -hiveconf insertedDate=$insertedDate -f ${workingDir}/generateFilteredData/generateFilteredData.sql;
status=$?
if [ $status -ne 0 ]; then
	echo "THERE IS A ERROR WHEN EXECUTING THE JOB TO INSERT 7DAYS-90DAYS DATA INTO HDFS"
	exit
fi;

echo "============================ Finished inserting data ...";
