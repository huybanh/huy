################################################################################
#                                                                              #
# DIRECTV PROPRIETARY                                                          #
# Copyright@ 2014 DIRECTV, INC.                                                #
# UNPUBLISHED WORK                                                             #
# ALL RIGHTS RESERVED                                                          #
#                                                                              #
# This software is the confidential and proprietary information of             #
# DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,           #
# distribution or disclosure of the software or Proprietary Information,       #
# in whole or in part, must comply with the terms of the license               #
# agreement, nondisclosure agreement or contract entered into with             #
# DIRECTV providing access to this software.                                   #
################################################################################
workingDir="$(pwd)"

. $workingDir/common_properties.py
. $workingDir/generateFilteredData/generatefilterdata_properties.py;

sevenDayFilterUvh=$1
sevenDayDataParquet=$2
insertedTime=$3
batchNumber=$4

lib=$workingDir$udfDataIngestion
libUDS=$workingDir$recommendationCommon

echo 'SEVEN DAY DATA: '$sevenDayFilterUvh
echo 'SEVEN DAY DATA WITH PARQUET FORMAT: '$sevenDayDataParquet
echo 'DATABASE NAME: '$database
echo 'HASH 7 DAYS TWO LEVEL TABLE: '$sevenDaysDataTwoLevelTable
echo 'LIB: '$lib
echo 'LIB FROM UDS: '$libUDS
echo 'INSERTED TIME: '$insertedTime
echo 'MODULO: '$modulo

# add the following code to fix the Kerberos issue if using hbase shell from shell 
if [[ -f action.xml ]];then
	mkdir -p /tmp/pythoneggs
	export PYTHON_EGG_CACHE='/tmp/pythoneggs'
	
	kinit -kt svc.cloudrec.dv2.keytab svc.cloudrec.dv2@DS.DTVENG.NET
	export HBASE_CONF_DIR=.
fi

if [ -z ${HADOOP_TOKEN_FILE_LOCATION} ]; then
	hadoopTokenClause="";
else
	hadoopTokenClause='-hiveconf mapreduce.job.credentials.binary='${HADOOP_TOKEN_FILE_LOCATION};
fi

startTime=$(date +"%Y-%m-%d %H:%M:%S")
echo "put '$recommendationJobHistory','$batchNumber','$columnFamilyOfRJH:partitionSevenDayData_startTime','$startTime'" | hbase shell;
status=$?
if [ $status -ne 0 ]; then
	echo "WE COULD NOT PUT DATA INTO HBASE TABLE"
	exit
fi;

# to improve the speed of querying we will partition data by inserted time
hive $hadoopTokenClause -hiveconf database=$database -hiveconf sevenDaysDataTwoLevelTable=$sevenDaysDataTwoLevelTable -hiveconf sevenDayFilterUvh=$sevenDayFilterUvh -hiveconf sevenDayDataParquet=$sevenDayDataParquet -hiveconf lib=$lib -hiveconf insertedTime=$insertedTime -hiveconf modulo=$modulo -hiveconf libUDS=$libUDS -f "$workingDir/generateFilteredData/convertParquetFormat.sql"
status=$?
if [ $status -ne 0 ]; then
	echo "THERE IS A ERROR WHEN EXECUTING THE JOB TO PARTITION DATA"
	echo "put '$recommendationJobHistory','$batchNumber','$columnFamilyOfRJH:partitionSevenDayData_status','[FAILED]'" | hbase shell;
	status=$?
	if [ $status -ne 0 ]; then
		echo "WE COULD NOT PUT DATA INTO HBASE TABLE"
	fi;
	exit
else
	echo "put '$recommendationJobHistory','$batchNumber','$columnFamilyOfRJH:partitionSevenDayData_status','[SUCCEED]'" | hbase shell;
	status=$?
	if [ $status -ne 0 ]; then
		echo "WE COULD NOT PUT DATA INTO HBASE TABLE"
		exit
	fi;
	endTime=$(date +"%Y-%m-%d %H:%M:%S")
	echo "put '$recommendationJobHistory','$batchNumber','$columnFamilyOfRJH:partitionSevenDayData_endTime','$endTime'" | hbase shell;
	status=$?
	if [ $status -ne 0 ]; then
		echo "WE COULD NOT PUT DATA INTO HBASE TABLE"
		exit
	fi;
fi;

# using impala 
$impalaCommand -q "invalidate metadata"
status=$?
if [ $status -ne 0 ]; then
	echo "RUN THE COMMAND 'invalidate metadata' UNSUCCESSFULLY"
	exit
fi;
