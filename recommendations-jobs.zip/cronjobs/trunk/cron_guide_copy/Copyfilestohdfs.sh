#!/bin/bash
/usr/bin/kinit -R
kinit -R
. $HOME/cron_guide_copy/properties.py
file_date1="$(date +'%Y%m%d')"
file_date2="$(date -d yesterday +%Y%m%d)"
file_date3="$(date -d "-2 days"  +%Y%m%d)"
hadoop fs -mkdir ${hdfslocation_onproduct}
hadoop fs -mkdir ${hdfslocation_guide} 
hadoop fs -put ${gatewaylocation_onproduct}pgwsop_full-${file_date1}*.json ${hdfslocation_onproduct}
hadoop fs -put ${gatewaylocation_guide}pgwslisting_full_restart-${file_date2}*.* ${hdfslocation_guide}
rm -f ${gatewaylocation_onproduct}/pgwsop_full-${file_date2}*.json
rm -f ${gatewaylocation_guide}/pgwslisting_full_restart-${file_date3}*.*
