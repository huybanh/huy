gatewaylocation_onproduct=/opt/cloud-rec/guidelistingfiles/onproduct/
gatewaylocation_guide=/opt/cloud-rec/guidelistingfiles/guideData/
hdfslocation_onproduct=/data/dv/ref/Guidelisting/onproduct/
hdfslocation_guide=/data/dv/ref/Guidelisting/dls/
