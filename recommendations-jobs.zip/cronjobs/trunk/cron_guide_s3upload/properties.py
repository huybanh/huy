# Paths on gateway node to get the files and run the s3upload
S3UploadProdDataLocation=/home/svc.cloudrec.dv2/cron/s3uploaderProd/data/
S3UploadStagingDataLocation=/home/svc.cloudrec.dv2/cron/s3uploaderstaging/data/
S3UploadProdScriptsLocation=/home/svc.cloudrec.dv2/cron/s3uploaderProd/
S3UploadStagingScriptsLocation=/home/svc.cloudrec.dv2/cron/s3uploaderstaging/
guidehdfslocation=/data/dv/ref/Guidelisting/dls
