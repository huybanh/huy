#!/bin/bash
. <deploymetdir>/recommendation-deployment-<version>/cronjobs-<version>/cron_guide_s3upload/properties.py
/usr/bin/kinit -R
kinit -R
file_date1="$(date +'%Y%m%d')"
file_date2="$(date -d yesterday +%Y%m%d)"
hadoop fs -get ${guidehdfslocation}/pgwslisting_full_restart-${file_date2}_*.* ${S3UploadProdDataLocation}
mv ${S3UploadProdDataLocation}pgwslisting_full_restart-${file_date2}_*_*.xml ${S3UploadProdDataLocation}pgwslisting_full_restart-${file_date1}_*_*.xml
cp ${S3UploadProdDataLocation}pgwslisting_full_restart-${file_date1}_*_*.xml ${S3UploadStagingDataLocation}
cd ${S3UploadProdScriptsLocation}
./run.sh
cd ${S3UploadStagingScriptsLocation}
./run.sh
rm -f ${S3UploadProdDataLocation}pgwslisting_full_restart-${file_date1}_*.*
rm -f ${S3UploadStagingDataLocation}pgwslisting_full_restart-${file_date1}_*.*