#common Properties
TARGET_DIR=/home/svc.dapee.tokenizer/input1
TARGET_USER=svc.dapee.tokenizer
TARGET_HOST=10.26.75.89


#Ppv Properties
SOURCE_FILE_PPV=/root/ITFS
HADOOP_DIR_PPV=/data/dv/test1/ppv

#cdn file properties
SOURCE_FILE_CDN=/root/ITFS
# The location of CDN file on HDFS
HADOOP_DIR_CDN=/data/dv/test1/cdn


#remote file properties
SOURCE_FILE_REMOTE=/root/ITFS
HADOOP_DIR_REMOTE=/data/dv/test1/remote

#Social file properties
SOURCE_FILE_SOCIAL=/root/ITFS
HADOOP_DIR_SOCIAL=/data/dv/test1/social


#Streaming file properties
SOURCE_FILE_STREAMING=/root/ITFS
HADOOP_DIR_STREAMING=/data/dv/test1/streaming
