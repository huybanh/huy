#!/bin/bash
cd $HOME/cron_ITfiles
kinit -k -t ./${TARGET_USER}.keytab ${TARGET_USER}@DS.DTVENG.NET
./push_latest_itfiles_cdn
./push_latest_itfiles_ppv
./push_latest_itfiles_remotebooking
./push_latest_itfiles_social
./push_latest_itfiles_streaming
