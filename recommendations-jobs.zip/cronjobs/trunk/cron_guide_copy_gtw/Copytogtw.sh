#!/bin/bash
. $HOME/cron_guide_copy_gtw/properties.py
# kerberos ticket intialization using service account
kinit -k -t $HOME/cron_guide_copy_gtw/${userid}.keytab ${userid}@DS.DTVENG.NET
file_date1="$(date +'%Y%m%d')"
file_date2="$(date -d yesterday +%Y%m%d)"
file_date3="$(date -d "-2 days"  +%Y%m%d)"
ssh ${userid}@${gatewayip} "mkdir -p ${gatewaylocation_onproduct}"
ssh ${userid}@${gatewayip} "mkdir -p ${gatewaylocation_guide}"
scp ${onproductlocation}pgwsop_full-${file_date1}*.json ${userid}@${gatewayip}:${gatewaylocation_onproduct}
scp ${guidefileslocation}pgwslisting_full_restart-${file_date2}*.* ${userid}@${gatewayip}:${gatewaylocation_guide}
