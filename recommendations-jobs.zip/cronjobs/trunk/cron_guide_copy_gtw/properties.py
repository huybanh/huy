gatewaylocation_onproduct=/opt/cloud-rec/guidelistingfiles/onproduct/
gatewaylocation_guide=/opt/cloud-rec/guidelistingfiles/guideData/
userid=<bias-id>

