#!/bin/bash
/usr/bin/kinit -R
kinit -R
. <deploymetdir>/recommendation-deployment-<version>/cronjobs-<version>/cron_guideingestion/properties_guide.py
file_date1="$(date +'%Y%m%d')"
file_date2="$(date -d yesterday +%Y%m%d)"
file_date3="$(date -d "-2 days" +%Y%m%d)"
hadoop fs -get ${onproducthdfslocation}/pgwsop_full-${file_date1}_*.json ${OnProductIngestionDataLocation}
hadoop fs -get ${guidehdfslocation}/pgwslisting_full_restart-${file_date2}_*.* ${GuideIngestionDataLocation}
cd ${ScriptsLocation}
./run.sh
rm -f ${GuideIngestionDataLocation}pgwslisting_full_restart-${file_date3}_*.*
cd ${ScriptsLocation}
./run_onproduct.sh
rm -f ${OnProductIngestionDataLocation}pgwsop_full-${file_date2}_*.json