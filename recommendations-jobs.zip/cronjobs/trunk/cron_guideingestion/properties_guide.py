# Paths for all the variables for guidedataIngestion
# Location of on product files for processing
OnProductIngestionDataLocation=/home/svc.cloudrec.dv2/cron/guide-data-ingestion/onproduct/
# Location of guide files for processing
GuideIngestionDataLocation=/home/svc.cloudrec.dv2/cron/guide-data-ingestion/dls/
# Location of scripts to run guide data ingestion and on product ingestion
ScriptsLocation=/home/svc.cloudrec.dv2/cron/guide-data-ingestion/
onproducthdfslocation=
guidehdfslocation=