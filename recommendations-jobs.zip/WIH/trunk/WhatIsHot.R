  #DIRECTV PROPRIETARY^M
  # Copyright� 2014 DIRECTV, INC.^M
  # UNPUBLISHED WORK^M
  # ALL RIGHTS RESERVED^M
  #
  # This software is the confidential and proprietary information of^M
  # DIRECTV, Inc. ("Proprietary Information").  Any use, reproduction,^M
  # distribution or disclosure of the software or Proprietary Information,^M
  # in whole or in part, must comply with the terms of the license^M
  # agreement, nondisclosure agreement or contract entered into with^M
  # DIRECTV providing access to this software.^M
  #
  #============================================================================== Computing What Is Hot Service ============================================================================^M

library('RevoScaleR')
source('Config.R')

ComputeWIHOnSource <- function(dataUrl = "/user/d458737/Namhnt/WIH/TestCase8", bigDataDirRoot, hdfs, sub = FALSE ) {
  # Computes WIH based on source location
  #
  # Args:
  #   dataUrl: link to location of data to compute
  #   bigDataDirRoot: location fo root HDFS data,
  #	in   hdfs: an of object which store location of HDFS imformation
  #   sub: If TRUE, we calculate sum of percentage with negative percentage value. If FALSE, we calculate sum of percentage with positive value. Default is FALSE.
  #
  # Returns:
  #   Data frame which store result of computing WIH on that location
  #   Format data frame "RegionId","MainCategory","ProgramTitle","Tmsid","Percentage" 
  #Get object which points to location of input data
 
  input.dir <- file.path(bigDataDirRoot, dataUrl)	
  #Get object which points to location of stored temp XDF data which can be used to read chunk of all data
  output.dir <- file.path(bigDataDirRoot, "/user/tmp.aepoc1/Namhnt")
  rxHadoopListFiles(input.dir)
  view.data <- RxTextData(file = input.dir, delimiter = ";", stringsAsFactor = FALSE, fileSystem = hdfs, firstRowIsColNames = FALSE, colInfo = colInfo, rowsPerRead = maxRow)
  parse.data = RxXdfData(output.dir,fileSystem = hdfs)
  #Store data as XDF file
  rxDataStep(inData = view.data, varsToKeep = c("V3","V12","V21","V22","V25","V26","V27","V28","V29","V34","V47"), outFile = parse.data, overwrite = TRUE)	 
  #Open connection to read a chunk fo data
  rxOpen(parse.data)
  #Initialize a object to point to result data frame
  result <- data.frame()
  generic.result <- data.frame()
  #A flag make sure whether data of a chunk is empty or not 
  isEmptyData <- TRUE
  #Read each chunk of data which is set maximum row is maxRow
  block.data <- rxReadNext(parse.data)
  iBlock <- 1
  while (isEmptyData) {
    if(length(block.data) != 0) {
      #Group By data by regionid, maincategory, title, tmsid then calculate
      print(length(block.data$maincategory))
      #Filter data with excluded maincategory
      block.data = block.data[which(!(block.data$maincategory %in% excludeMain)), ]
      print(paste("Block ", iBlock))
      #Filter data with excluded genre 
      block.data = block.data[which(!(block.data$genre1 %in% excludeGenre | block.data$genre2 %in% excludeGenre | block.data$genre3 %in% excludeGenre)), ] 
      #If TRUE, we calculate sum of percentage with negative percentage value. If FALSE, we calculate sum of percentage with positive value
      #Aggregate data then sum by formula: (durationview/runlenght + addition) * weight
      if(sub == TRUE) {
        new.result <- aggregate(-(ifelse(is.na(block.data$durationviewed), 0, block.data$durationviewed) / ifelse(is.na(block.data$runlength), 1.0, block.data$runlength) + block.data$addition) * block.data$weight, list(block.data$dma, block.data$maincategory, block.data$title, block.data$tmsid), sum)
      } else {		
        new.result <- aggregate((ifelse(is.na(block.data$durationviewed), 0, block.data$durationviewed) / ifelse(is.na(block.data$runlength), 1.0, block.data$runlength) + block.data$addition) * block.data$weight, list(block.data$dma, block.data$maincategory, block.data$title, block.data$tmsid ), sum)
      }
      #Merge all computing result for each block
      result <- rbind(result,new.result)
    } else {
      #Data reached to the end
      isEmptyData <- FALSE
    }
    #Fetch next block of data
    block.data <- rxReadNext(parse.data)
    iBlock <- iBlock + 1
  }
  print("Read All Data")
  colnames(result) <- c("RegionId","MainCategory","ProgramTitle","Tmsid","Percentage")
  generic.result <- aggregate(result$Percentage,list(result$MainCategory,result$ProgramTitle,result$Tmsid), sum)
  #Create generic type for region id
  length.of.data <- length(generic.result$x)
  generic.column <- rep("AllRegion", length.of.data)
  #Combine generic column with the result without having region id
  generic.result <- cbind(generic.column, generic.result)
  colnames(generic.result) <- c("RegionId","MainCategory","ProgramTitle","Tmsid","Percentage")
  #Merge all computing result
  result <- rbind(result, generic.result) 
  #Return a data frame of result value
  return (result)
}

ComputeMainWIH <- function(dataUrl ="/data/dv/recommendations/processed/joinFull/joinFullData2", lwtimeDataUrl="/user/d458737/Namhnt/WIH/TestCase4", zoomOutUrl = "/user/d458737/Namhnt/WIH/Result_Zoom", zoomBakUrl = "/user/d458737/Namhnt/WIH/Result_Zoom_Bak", udsOutUrl = "/user/d458737/Namhnt/WIH/Result_UDS", firstTimes = FALSE ) {
  #Compute What Is Hot for new coming data then store to HDFS data. That data will be used for UDS and Zoom Data
  #
  # Args:
  #   dataUrl: Location of new coming data.
  #   lwtimneDataUrl: Location of last day of window time data. For example, if window time is one week, the last day of window is the first day.
  #   firstTime: If TRUE, it is the first times to compute WIH. If FALSE, it is the remaining times you computing WIH. Default is FALSE.
  #   remaining times need to be merged with old result
  # Returns:
  #   
  #Initialize the cluster and set the compute context to Hadoop
  my.name.node <- hadoop.host
  my.port <- hadoop.port
  big.data.dir.root <- "/"
  hdfs.share <- paste("/user", Sys.info()[["user"]], sep="/")
  input.dir <- file.path(big.data.dir.root, dataUrl)
  my.hadoop.cluster <- RxHadoopMR(nameNode = my.name.node, hdfsShareDir = hdfs.share, showOutputWhileWaiting = TRUE, autoCleanup = TRUE, port = my.port)
  rxSetComputeContext(my.hadoop.cluster)
  #Check compute context from Hadoop
  print(rxGetComputeContext())
  #Determine the file System which has been used  
  hdfs <- RxHdfsFileSystem(hostName = my.name.node, port = my.port)
  #Compute New WIH
  result <- ComputeWIHOnSource(dataUrl, big.data.dir.root, hdfs)
  #If firstTimes is TRUE, it is the first times to compute WIH. If FALSE, it is the remaining times you computing WIH. Default is FALSE.
  #Merging data with old computing and first window date to get the final computing
  if(!firstTimes)
  {
    #Compute first day of Window Time WIH with sub equal TRUE because we want to minus these values on computing
    first.window.time.result <- ComputeWIHOnSource(lwtimeDataUrl, big.data.dir.root, hdfs, sub = TRUE)
    #Combine with previous result
    result <- rbind(result, first.window.time.result)	
    #Read the previous WIH computing then merge each other.
    input.dir <- file.path(big.data.dir.root, zoomOutUrl)
    view.data <- RxTextData(file = input.dir, delimiter = ",", stringsAsFactor = FALSE, fileSystem = hdfs, firstRowIsColNames = TRUE, colInfo = storeInfo, rowsPerRead = maxRow)
    #Open connection to read chunk of data
    rxOpen(view.data)
    is.empty.data <- FALSE
    #Read old result to Data Frame
    block.data <-  rxReadNext(view.data)
    old.result <- data.frame()
    while(is.empty.data != TRUE) {
      old.result <- rbind(block.data, old.result)
      block.data <-rxReadNext(view.data)
      if(length(block.data$Tmsid) == 0) {
        is.empty.data = TRUE
      }
    }
    #Store old data to back up
    rxHadoopRemove(paste(zoomBakUrl,"zoomdata_bak.csv",sep = "/"))
    write.table(old.result,"zoomdata_bak.csv", sep = ";", col.names = TRUE,row.names = FALSE)
    rxHadoopCopyFromLocal("zoomdata_bak.csv", zoomBakUrl)
    result <- rbind(result, old.result)
  }
  print("Begin to Merge all data then store to HDFS")
  #Agggregate then sum all, percentage in last is a negative value and in old is positive value
  result <- aggregate(as.double(result$Percentage), list(result$RegionId,result$MainCategory,result$ProgramTitle, result$Tmsid), sum)
  colnames(result) <- c("RegionId","MainCategory","ProgramTitle","Tmsid","Percentage")
  #Order result based on group by item In Des for Percentage
  order.of.result <- result[order(result$RegionId, result$MainCategory, -result$Percentage), ]
  #Get all main category
  main.categories <- unique(order.of.result$MainCategory)
  #Get all regionId
  region.ids <- unique(order.of.result$RegionId) 
  #Merge result as HBASE format before store to HDFS
  change.form.of.result <- data.frame()
  print("Format data for UDS service")	
  #Format data for UDS service
  print("All region we have")
  print(region.ids)

  for(reg in region.ids) {
    tmp.Cat <- paste(windowTime, reg, sep = '.')
    sub.data <- subset(order.of.result, RegionId == reg)
    #Get column quantify name and value
    row <- tmp.Cat
    column.name <- "Generic"
    row <- cbind(row,column.name)
    tmp.Cat <- paste(tmp.Cat, column.name, sep = ';')
    #Get string of jason object for each column quantifier (generic)
    tmp.Cat <- GetPrograms(sub.data)
    row <- cbind(row, tmp.Cat)
    #Combine row for all result
    change.form.of.result <- rbind(change.form.of.result, row)
    for(main in main.categories) {
      tmp.Cat <- paste(windowTime, reg, sep = '.')
      sub.data <- subset(sub.data, MainCategory == main)
      #Get column quantify name and value
      row <- tmp.Cat
      column.name <- main
      row <- cbind(row, column.name)
      tmp.Cat <- paste(tmp.Cat, column.name, sep = ';')
      #Get string of json object for each column quantifier (individual)
      tmp.Cat <- GetPrograms(sub.data)
      row <- cbind(row, tmp.Cat)
      #Combine row for all result
      change.form.of.result <- rbind(change.form.of.result, row)
    }
    print(paste0("Process Region : ", reg))
  }
  #Filter all excluded Tmsid in order_of_result for zoom data and change_form_of_result for UDS service
  #Write Zoomdata source to HDFS
  rxHadoopRemove(paste(zoomOutUrl, "zoomdata.csv", sep = "/"))
  write.table(order.of.result, "zoomdata.csv", sep = ",", col.names = TRUE, row.names = FALSE)
  rxHadoopCopyFromLocal("zoomdata.csv", zoomOutUrl)
  #Write UDS source to HDFS
  rxHadoopRemove(paste(udsOutUrl, "UDS.csv", sep = "/" ))
  write.table(change.form.of.result, "UDS.csv", sep = ";", col.names = FALSE, row.names = FALSE, quote = FALSE)
  rxHadoopCopyFromLocal("UDS.csv", udsOutUrl)
}

GetPrograms <- function(sub.data.result) {
  #Generate list json value from a data frame
  #
  # Args:
  #   sub.data.result: Data frame need to generate
  # Returns:
  #   string of programs from data frame

  tmsIds <- sub.data.result$Tmsid
  numberOfTmsid <- length(tmsIds)
  result <- ''
  if(numberOfTmsid > 0) {
    for(i in 1:numberOfTmsid) {
      #Get value for tmsid, score, title for each row of a data frame
      column.value.tmsid <- sub.data.result[i,4]
      column.value.score <- sub.data.result[i,5]
      column.value.title <- sub.data.result[i,3]
      #Create json string for each row of a data frame
      program.json <- FormatJson(column.value.tmsid, column.value.title, column.value.score)
      #Merge all json string to result
      result <- paste(result, program.json, sep = ',')
    }	
  }
  #enclose jason string
  result <- sub(',','',result)
  result <- paste("[", result, "]", sep='')
  return (result)
}	

FormatJson <- function(tmsid, title, score) {
  #Generate json for each data row of a data frame
  #
  # Args:
  #   tmsid: id of a program
  #   title: title of a program
  #   score: computing of a program
  # Returns:
  #   string of program for each row of a data frame
  tmsid <- paste("{\"tmsId\":\"", tmsid, "\"", sep = '')
  title <- paste("\"title\":\"", title, "\"", sep = '')
  score <- paste('"score":"', score, '"}', sep = '')
  result <- paste(tmsid, title, score, sep = ',') 
  return (result)
}
